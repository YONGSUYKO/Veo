import React, { useState, useRef } from 'react';
import { View, Text, Pressable, StyleSheet, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { CameraView, CameraType, useCameraPermissions } from 'expo-camera';
import * as FileSystem from 'expo-file-system';

interface DocumentScannerProps {
  onScanComplete: (pdfInfo: { uri: string; pages: number; name: string }) => void;
  onClose: () => void;
}

export default function DocumentScanner({ onScanComplete, onClose }: DocumentScannerProps) {
  const insets = useSafeAreaInsets();
  const [permission, requestPermission] = useCameraPermissions();
  const [flash, setFlash] = useState(false);
  const [scannedPages, setScannedPages] = useState<string[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const cameraRef = useRef<CameraView>(null);

  const handleCapturePage = async () => {
    if (cameraRef.current) {
      try {
        console.log('📸 Capturing page', scannedPages.length + 1);
        const photo = await cameraRef.current.takePictureAsync({
          quality: 0.9,
          base64: false,
        });
        
        setScannedPages([...scannedPages, photo.uri]);
        console.log('📄 Page captured, total pages:', scannedPages.length + 1);
        
        Alert.alert(
          'Page Captured',
          `Page ${scannedPages.length + 1} added to document. Add more pages or finish scanning.`,
          [{ text: 'OK' }]
        );
      } catch (error) {
        Alert.alert('Error', 'Failed to capture page');
      }
    }
  };

  const handleFinishScanning = async () => {
    if (scannedPages.length === 0) {
      Alert.alert('No Pages', 'Please scan at least one page');
      return;
    }

    setIsProcessing(true);
    try {
      // Create a mock PDF file info (in a real app, you'd convert images to PDF)
      const pdfName = `Scanned_Document_${Date.now()}.pdf`;
      const pdfUri = `${FileSystem.documentDirectory}${pdfName}`;
      
      // Mock PDF creation - in real app, use a library like react-native-pdf-lib
      console.log('📄 Creating PDF with', scannedPages.length, 'pages');
      
      // For now, we'll use the first scanned page as the "PDF" representation
      // In production, you'd use a PDF library to combine all images into one PDF
      await FileSystem.copyAsync({
        from: scannedPages[0],
        to: pdfUri
      });

      const pdfInfo = {
        uri: pdfUri,
        pages: scannedPages.length,
        name: pdfName,
      };

      console.log('✅ PDF created:', pdfInfo);
      onScanComplete(pdfInfo);
    } catch (error) {
      console.error('PDF creation failed:', error);
      Alert.alert('Error', 'Failed to create PDF document');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRemoveLastPage = () => {
    if (scannedPages.length > 0) {
      const newPages = scannedPages.slice(0, -1);
      setScannedPages(newPages);
      console.log('🗑️ Removed last page, remaining:', newPages.length);
    }
  };

  if (!permission) {
    return <View style={styles.container} />;
  }

  if (!permission.granted) {
    return (
      <View style={styles.container}>
        <View style={styles.permissionContainer}>
          <Ionicons name="camera-outline" size={80} color="#9CA3AF" />
          <Text style={styles.permissionText}>Camera permission required</Text>
          <Pressable style={styles.permissionButton} onPress={requestPermission}>
            <Text style={styles.permissionButtonText}>Grant Permission</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + 20 }]}>
        <Pressable onPress={onClose} style={styles.closeButton}>
          <Ionicons name="close" size={24} color="white" />
        </Pressable>
        <Text style={styles.title}>Document Scanner</Text>
        <View style={styles.placeholder} />
      </View>

      {/* Camera Preview */}
      <View style={styles.cameraContainer}>
        <CameraView
          ref={cameraRef}
          style={styles.camera}
          facing="back"
          enableTorch={flash}
        >
          {/* Scan Frame */}
          <View style={styles.scanFrame} />
          
          {/* Page Counter */}
          <View style={styles.pageCounter}>
            <Text style={styles.pageCounterText}>
              {scannedPages.length} page{scannedPages.length !== 1 ? 's' : ''} scanned
            </Text>
          </View>
        </CameraView>
      </View>

      {/* Controls */}
      <View style={styles.controls}>
        <Pressable 
          style={[styles.controlButton, scannedPages.length === 0 && styles.disabledButton]} 
          onPress={handleRemoveLastPage}
          disabled={scannedPages.length === 0}
        >
          <Ionicons name="arrow-undo" size={24} color="white" />
        </Pressable>

        <Pressable 
          style={[styles.captureButton, isProcessing && styles.disabledButton]} 
          onPress={handleCapturePage}
          disabled={isProcessing}
        >
          <View style={styles.captureInner}>
            <Ionicons name="camera" size={24} color="white" />
          </View>
        </Pressable>

        <Pressable style={styles.controlButton} onPress={() => setFlash(!flash)}>
          <Ionicons name={flash ? "flash" : "flash-off"} size={24} color="white" />
        </Pressable>
      </View>

      {/* Finish Button */}
      {scannedPages.length > 0 && (
        <View style={styles.finishContainer}>
          <Pressable 
            style={[styles.finishButton, isProcessing && styles.disabledButton]}
            onPress={handleFinishScanning}
            disabled={isProcessing}
          >
            <Ionicons name="document-text" size={20} color="white" />
            <Text style={styles.finishText}>
              {isProcessing ? 'Creating PDF...' : `Finish Document (${scannedPages.length} pages)`}
            </Text>
          </Pressable>
        </View>
      )}

      <View style={styles.instructions}>
        <Text style={styles.instructionText}>
          {scannedPages.length === 0 
            ? 'Position document in frame and tap capture to scan first page'
            : 'Scan more pages or tap "Finish Document" to create PDF'
          }
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  closeButton: {
    padding: 8,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  placeholder: {
    width: 40,
  },
  cameraContainer: {
    flex: 1,
    position: 'relative',
  },
  camera: {
    flex: 1,
  },
  scanFrame: {
    position: 'absolute',
    top: '15%',
    left: '8%',
    right: '8%',
    bottom: '35%',
    borderWidth: 3,
    borderColor: '#10B981',
    borderRadius: 12,
    backgroundColor: 'transparent',
  },
  pageCounter: {
    position: 'absolute',
    top: 40,
    left: 20,
    right: 20,
    alignItems: 'center',
  },
  pageCounterText: {
    backgroundColor: 'rgba(0,0,0,0.7)',
    color: 'white',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    fontSize: 14,
    fontWeight: '600',
  },
  permissionContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#1F2937',
    paddingHorizontal: 40,
  },
  permissionText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#9CA3AF',
    marginTop: 16,
    textAlign: 'center',
  },
  permissionButton: {
    backgroundColor: '#10B981',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
    marginTop: 20,
  },
  permissionButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  controls: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 40,
    paddingVertical: 20,
    backgroundColor: 'rgba(0,0,0,0.8)',
  },
  controlButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  captureButton: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
  },
  captureInner: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#10B981',
    alignItems: 'center',
    justifyContent: 'center',
  },
  finishContainer: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: 'rgba(0,0,0,0.8)',
  },
  finishButton: {
    backgroundColor: '#3B82F6',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 12,
  },
  finishText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  disabledButton: {
    opacity: 0.5,
  },
  instructions: {
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: 'rgba(0,0,0,0.8)',
  },
  instructionText: {
    fontSize: 14,
    color: 'white',
    textAlign: 'center',
    lineHeight: 20,
  },
});