import React, { useState } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { View, Text, Pressable, ScrollView, TextInput, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNewAppStore } from '../state/newAppStore';
import { cn } from '../utils/cn';

interface AdminPricingManagerProps {
  onClose?: () => void;
}

export default function AdminPricingManager({ onClose }: AdminPricingManagerProps) {
  const insets = useSafeAreaInsets();
  const { systemSettings, setSystemSettings } = useNewAppStore();
  const [activeTab, setActiveTab] = useState<'documents' | 'photos' | 'services'>('documents');

  // Loading check
  if (!systemSettings) {
    return (
      <View className="flex-1 bg-white items-center justify-center">
        <Text className="text-gray-600">Loading pricing settings...</Text>
      </View>
    );
  }

  const formatPrice = (centavos: number) => {
    if (isNaN(centavos) || centavos === undefined || centavos === null) {
      return '₱0.00';
    }
    return `₱${(centavos / 100).toFixed(2)}`;
  };

  // Safety defaults for pricing with migration support
  const migrateDocumentPricing = (pricing: any) => {
    const migrated = { ...pricing };
    // Ensure all sizes have doubleSidedSurcharge
    Object.keys(migrated).forEach(size => {
      if (!migrated[size].doubleSidedSurcharge) {
        migrated[size].doubleSidedSurcharge = size === 'A3' ? 200 : 50;
      }
    });
    return migrated;
  };

  const documentPricing = systemSettings.documentPricing 
    ? migrateDocumentPricing(systemSettings.documentPricing)
    : {
        'Letter': { blackwhite: 100, color: 200, doubleSidedSurcharge: 50 },
        'A4': { blackwhite: 100, color: 200, doubleSidedSurcharge: 50 },
        'Legal': { blackwhite: 150, color: 300, doubleSidedSurcharge: 50 },
        'A3': { blackwhite: 200, color: 400, doubleSidedSurcharge: 200 },
      };

  const photoPricing = systemSettings.photoPricing || {
    'Wallet': 50,
    '2R': 100,
    '3R': 150,
    '4R': 200,
    '5R': 350,
    '6R': 450,
    '8R': 650,
    'A4': 800,
    'A3': 1200,
  };

  // Migration functions for service pricing
  const migrateBindingPricing = (pricing: any) => {
    // Check if it's old format (direct object) vs new format (size-based)
    if (pricing.none !== undefined && typeof pricing.none === 'number') {
      // Old format - convert to new format
      return {
        'Letter': { none: 0, spiral: pricing.spiral || 1500, perfect: pricing.perfect || 2000, saddle: pricing.saddle || 800 },
        'A4': { none: 0, spiral: pricing.spiral || 1500, perfect: pricing.perfect || 2000, saddle: pricing.saddle || 800 },
        'Legal': { none: 0, spiral: 1800, perfect: 2500, saddle: 1000 },
        'A3': { none: 0, spiral: 2500, perfect: 3500, saddle: 1500 },
      };
    }
    return pricing; // Already new format
  };

  const migrateLaminationPricing = (pricing: any) => {
    // Check if it's old format (direct object) vs new format (size-based)
    if (pricing.none !== undefined && typeof pricing.none === 'number') {
      // Old format - convert to new format
      return {
        'Letter': { none: 0, matte: pricing.matte || 1000, glossy: pricing.glossy || 1200 },
        'A4': { none: 0, matte: pricing.matte || 1000, glossy: pricing.glossy || 1200 },
        'Legal': { none: 0, matte: 1200, glossy: 1500 },
        'A3': { none: 0, matte: 1800, glossy: 2200 },
      };
    }
    return pricing; // Already new format
  };

  const bindingPricing = systemSettings.bindingPricing 
    ? migrateBindingPricing(systemSettings.bindingPricing)
    : {
        'Letter': { none: 0, spiral: 1500, perfect: 2000, saddle: 800 },
        'A4': { none: 0, spiral: 1500, perfect: 2000, saddle: 800 },
        'Legal': { none: 0, spiral: 1800, perfect: 2500, saddle: 1000 },
        'A3': { none: 0, spiral: 2500, perfect: 3500, saddle: 1500 },
      };

  const laminationPricing = systemSettings.laminationPricing 
    ? migrateLaminationPricing(systemSettings.laminationPricing)
    : {
        'Letter': { none: 0, matte: 1000, glossy: 1200 },
        'A4': { none: 0, matte: 1000, glossy: 1200 },
        'Legal': { none: 0, matte: 1200, glossy: 1500 },
        'A3': { none: 0, matte: 1800, glossy: 2200 },
      };

  const adjustDocumentPrice = (size: string, type: 'blackwhite' | 'color' | 'doubleSidedSurcharge', increment: number) => {
    const currentPrice = documentPricing[size]?.[type] || 0;
    if (isNaN(currentPrice)) {
      console.warn(`Invalid current price for ${size}.${type}: ${currentPrice}`);
      return;
    }
    const newPrice = Math.max(0, currentPrice + increment);
    const newPricing = {
      ...documentPricing,
      [size]: {
        ...documentPricing[size],
        [type]: newPrice,
      },
    };
    setSystemSettings({ documentPricing: newPricing });
  };

  const adjustPhotoPrice = (size: string, increment: number) => {
    const currentPrice = photoPricing[size];
    const newPrice = Math.max(0, currentPrice + increment);
    const newPricing = { ...photoPricing, [size]: newPrice };
    setSystemSettings({ photoPricing: newPricing });
  };

  const adjustServicePrice = (service: 'binding' | 'lamination', size: string, type: string, increment: number) => {
    if (type === 'none') return; // Don't allow adjusting "none" prices
    
    const pricingKey = service === 'binding' ? 'bindingPricing' : 'laminationPricing';
    const currentPricing = service === 'binding' ? bindingPricing : laminationPricing;
    const currentPrice = currentPricing[size]?.[type] || 0;
    if (isNaN(currentPrice)) {
      console.warn(`Invalid current price for ${service}.${size}.${type}: ${currentPrice}`);
      return;
    }
    const newPrice = Math.max(0, currentPrice + increment);
    const newPricing = { 
      ...currentPricing, 
      [size]: {
        ...currentPricing[size],
        [type]: newPrice
      }
    };
    setSystemSettings({ [pricingKey]: newPricing });
  };

  // Price adjustment increments (in centavos)
  const increments = {
    small: 50,     // ₱0.50
    medium: 100,   // ₱1.00  
    large: 250,    // ₱2.50
    xlarge: 500,   // ₱5.00
  };

  // Price adjuster component
  const PriceAdjuster = ({ 
    price, 
    onAdjust, 
    label 
  }: { 
    price: number; 
    onAdjust: (increment: number) => void; 
    label?: string; 
  }) => {
    const safePrice = isNaN(price) || price === undefined || price === null ? 0 : price;
    
    return (
    <View className="flex-1">
      {label && <Text className="text-sm text-gray-600 mb-2">{label}</Text>}
      <View className="bg-white rounded-lg border border-gray-300 p-2">
        <Text className="text-center font-semibold text-lg text-gray-900 mb-2">
          {formatPrice(safePrice)}
        </Text>
        
        {/* Quick adjustment buttons */}
        <View className="flex-row justify-between mb-2">
          <Pressable 
            onPress={() => onAdjust(-increments.large)}
            className="bg-red-100 px-2 py-1 rounded"
          >
            <Text className="text-red-700 text-xs font-medium">-₱2.50</Text>
          </Pressable>
          <Pressable 
            onPress={() => onAdjust(-increments.medium)}
            className="bg-red-100 px-2 py-1 rounded"
          >
            <Text className="text-red-700 text-xs font-medium">-₱1.00</Text>
          </Pressable>
          <Pressable 
            onPress={() => onAdjust(increments.medium)}
            className="bg-green-100 px-2 py-1 rounded"
          >
            <Text className="text-green-700 text-xs font-medium">+₱1.00</Text>
          </Pressable>
          <Pressable 
            onPress={() => onAdjust(increments.large)}
            className="bg-green-100 px-2 py-1 rounded"
          >
            <Text className="text-green-700 text-xs font-medium">+₱2.50</Text>
          </Pressable>
        </View>
        
        {/* Fine adjustment buttons */}
        <View className="flex-row justify-center items-center">
          <Pressable 
            onPress={() => onAdjust(-increments.small)}
            className="w-8 h-8 bg-red-500 rounded-full items-center justify-center mr-3"
          >
            <Ionicons name="remove" size={16} color="white" />
          </Pressable>
          <Text className="text-xs text-gray-500 mx-2">₱0.50</Text>
          <Pressable 
            onPress={() => onAdjust(increments.small)}
            className="w-8 h-8 bg-green-500 rounded-full items-center justify-center"
          >
            <Ionicons name="add" size={16} color="white" />
          </Pressable>
        </View>
      </View>
    </View>
  );
};

  return (
    <View className="flex-1 bg-white">
      {/* Header */}
      <View className="bg-red-600 px-6" style={{ paddingTop: insets.top + 16, paddingBottom: 16 }}>
        <View className="flex-row items-center justify-between mb-2">
          <View className="flex-row items-center">
            {onClose && (
              <Pressable onPress={onClose} className="mr-4">
                <Ionicons name="chevron-back" size={24} color="white" />
              </Pressable>
            )}
            <Text className="text-white text-xl font-bold">Pricing Management</Text>
          </View>
        </View>
        <Text className="text-red-100 text-sm">Manage all printing and service prices</Text>
      </View>

      {/* Tab Navigation */}
      <View className="flex-row bg-white border-b border-gray-200">
        {[
          { id: 'documents', label: 'Documents', icon: 'document-text' },
          { id: 'photos', label: 'Photos', icon: 'camera' },
          { id: 'services', label: 'Services', icon: 'build' },
        ].map((tab) => (
          <Pressable
            key={tab.id}
            onPress={() => setActiveTab(tab.id as any)}
            className={`flex-1 py-4 items-center ${
              activeTab === tab.id ? 'border-b-2 border-red-500' : ''
            }`}
          >
            <Ionicons 
              name={tab.icon as any} 
              size={20} 
              color={activeTab === tab.id ? '#DC2626' : '#9CA3AF'} 
            />
            <Text className={`text-sm font-medium mt-1 ${
              activeTab === tab.id ? 'text-red-600' : 'text-gray-500'
            }`}>
              {tab.label}
            </Text>
          </Pressable>
        ))}
      </View>

      <ScrollView className="flex-1 p-6">
        {activeTab === 'documents' && (
          <View>
            <Text className="text-lg font-bold text-gray-900 mb-6">Document Printing Prices</Text>
            
            {Object.entries(documentPricing).map(([size, prices]) => (
              <View key={size} className="bg-gray-50 rounded-xl p-4 mb-4">
                <Text className="font-semibold text-gray-900 mb-3">{size} Size</Text>
                
                <View className="flex-row space-x-2 mb-4">
                  <PriceAdjuster
                    price={prices.blackwhite}
                    onAdjust={(increment) => adjustDocumentPrice(size, 'blackwhite', increment)}
                    label="Black & White"
                  />
                  <PriceAdjuster
                    price={prices.color}
                    onAdjust={(increment) => adjustDocumentPrice(size, 'color', increment)}
                    label="Color"
                  />
                </View>
                
                <View className="border-t border-gray-200 pt-3">
                  <Text className="text-sm text-gray-600 mb-2">Double-Sided Surcharge</Text>
                  <View className="w-40">
                    <PriceAdjuster
                      price={prices.doubleSidedSurcharge}
                      onAdjust={(increment) => adjustDocumentPrice(size, 'doubleSidedSurcharge', increment)}
                    />
                  </View>
                </View>
              </View>
            ))}
          </View>
        )}

        {activeTab === 'photos' && (
          <View>
            <Text className="text-lg font-bold text-gray-900 mb-6">Photo Printing Prices</Text>
            
            {Object.entries(photoPricing).map(([size, price]) => (
              <View key={size} className="bg-gray-50 rounded-xl p-4 mb-4">
                <View className="flex-row items-start justify-between">
                  <View className="flex-1 mr-4">
                    <Text className="font-semibold text-gray-900">{size}</Text>
                    <Text className="text-sm text-gray-600 mb-2">
                      {size === '4R' && 'Default photo size (4" × 6")'}
                      {size === 'Wallet' && '2.5" × 3.5"'}
                      {size === '2R' && '2.5" × 3.5"'}
                      {size === '3R' && '3.5" × 5"'}
                      {size === '4R' && '4" × 6"'}
                      {size === '5R' && '5" × 7"'}
                      {size === '6R' && '6" × 8"'}
                      {size === '8R' && '8" × 10"'}
                      {size === 'A4' && 'A4 Photo Paper'}
                      {size === 'A3' && 'A3 Photo Paper'}
                    </Text>
                  </View>
                  
                  <View className="w-40">
                    <PriceAdjuster
                      price={price}
                      onAdjust={(increment) => adjustPhotoPrice(size, increment)}
                    />
                  </View>
                </View>
              </View>
            ))}
          </View>
        )}

        {activeTab === 'services' && (
          <View>
            <Text className="text-lg font-bold text-gray-900 mb-6">Service Prices</Text>
            
            {/* Binding Prices */}
            <View className="bg-gray-50 rounded-xl p-4 mb-6">
              <Text className="font-semibold text-gray-900 mb-4">Binding Services (by size)</Text>
              
              {Object.entries(bindingPricing).map(([size, sizeBindingPrices]) => (
                <View key={size} className="mb-6">
                  <Text className="font-medium text-gray-900 mb-3">{size} Size</Text>
                  
                  {Object.entries(sizeBindingPrices).map(([type, price]) => (
                    <View key={`${size}-${type}`} className="flex-row items-start justify-between mb-3">
                      <View className="flex-1 mr-4">
                        <Text className="font-medium text-gray-700 capitalize">{type}</Text>
                        <Text className="text-sm text-gray-600">
                          {type === 'spiral' && 'Spiral binding'}
                          {type === 'perfect' && 'Perfect binding'}
                          {type === 'saddle' && 'Saddle stitching'}
                          {type === 'none' && 'No binding (free)'}
                        </Text>
                      </View>
                      
                      <View className="w-32">
                        {type === 'none' ? (
                          <View className="bg-white rounded-lg border border-gray-300 p-2">
                            <Text className="text-center font-semibold text-gray-500">
                              {formatPrice(price)}
                            </Text>
                          </View>
                        ) : (
                          <View className="bg-white rounded-lg border border-gray-300 p-1">
                            <Text className="text-center font-semibold text-sm mb-1">
                              {formatPrice(price)}
                            </Text>
                            <View className="flex-row justify-center">
                              <Pressable 
                                onPress={() => adjustServicePrice('binding', size, type, -50)}
                                className="w-6 h-6 bg-red-500 rounded-full items-center justify-center mr-2"
                              >
                                <Text className="text-white text-xs font-bold">-</Text>
                              </Pressable>
                              <Pressable 
                                onPress={() => adjustServicePrice('binding', size, type, 50)}
                                className="w-6 h-6 bg-green-500 rounded-full items-center justify-center"
                              >
                                <Text className="text-white text-xs font-bold">+</Text>
                              </Pressable>
                            </View>
                          </View>
                        )}
                      </View>
                    </View>
                  ))}
                </View>
              ))}
            </View>

            {/* Lamination Prices */}
            <View className="bg-gray-50 rounded-xl p-4">
              <Text className="font-semibold text-gray-900 mb-4">Lamination Services (per page, by size)</Text>
              
              {Object.entries(laminationPricing).map(([size, sizeLaminationPrices]) => (
                <View key={size} className="mb-6">
                  <Text className="font-medium text-gray-900 mb-3">{size} Size</Text>
                  
                  {Object.entries(sizeLaminationPrices).map(([type, price]) => (
                    <View key={`${size}-${type}`} className="flex-row items-start justify-between mb-3">
                      <View className="flex-1 mr-4">
                        <Text className="font-medium text-gray-700 capitalize">{type}</Text>
                        <Text className="text-sm text-gray-600">
                          {type === 'matte' && 'Matte lamination'}
                          {type === 'glossy' && 'Glossy lamination'}
                          {type === 'none' && 'No lamination (free)'}
                        </Text>
                      </View>
                      
                      <View className="w-32">
                        {type === 'none' ? (
                          <View className="bg-white rounded-lg border border-gray-300 p-2">
                            <Text className="text-center font-semibold text-gray-500">
                              {formatPrice(price)}
                            </Text>
                          </View>
                        ) : (
                          <View className="bg-white rounded-lg border border-gray-300 p-1">
                            <Text className="text-center font-semibold text-sm mb-1">
                              {formatPrice(price)}
                            </Text>
                            <View className="flex-row justify-center">
                              <Pressable 
                                onPress={() => adjustServicePrice('lamination', size, type, -50)}
                                className="w-6 h-6 bg-red-500 rounded-full items-center justify-center mr-2"
                              >
                                <Text className="text-white text-xs font-bold">-</Text>
                              </Pressable>
                              <Pressable 
                                onPress={() => adjustServicePrice('lamination', size, type, 50)}
                                className="w-6 h-6 bg-green-500 rounded-full items-center justify-center"
                              >
                                <Text className="text-white text-xs font-bold">+</Text>
                              </Pressable>
                            </View>
                          </View>
                        )}
                      </View>
                    </View>
                  ))}
                </View>
              ))}
            </View>
          </View>
        )}
      </ScrollView>

      {/* Save Button */}
      <View className="p-6 border-t border-gray-200">
        <Pressable 
          className="bg-red-600 py-4 rounded-xl"
          onPress={() => Alert.alert('Pricing Updated', 'All pricing changes have been saved successfully.')}
        >
          <Text className="text-white text-center font-semibold text-lg">
            Save Pricing Changes
          </Text>
        </Pressable>
      </View>
    </View>
  );
}