import React, { useState } from 'react';
import {
  View,
  Text,
  Pressable,
  Modal,
  StyleSheet,
  TextInput,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface GuestSmsApprovalModalProps {
  visible: boolean;
  onClose: () => void;
  onApprove: (phoneNumber: string) => void;
  onDecline: () => void;
  orderAmount: number;
  orderId: string;
}

const GuestSmsApprovalModal: React.FC<GuestSmsApprovalModalProps> = ({
  visible,
  onClose,
  onApprove,
  onDecline,
  orderAmount,
  orderId,
}) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isValidPhone, setIsValidPhone] = useState(false);

  const validatePhoneNumber = (phone: string) => {
    // Simple Philippine phone number validation
    const cleaned = phone.replace(/[^\d+]/g, '');
    const isValid = /^(\+63|63|0)?[9]\d{9}$/.test(cleaned) || /^\+63\d{10}$/.test(cleaned);
    setIsValidPhone(isValid);
    return isValid;
  };

  const handlePhoneChange = (text: string) => {
    setPhoneNumber(text);
    validatePhoneNumber(text);
  };

  const handleApprove = () => {
    if (isValidPhone) {
      onApprove(phoneNumber);
    }
  };

  const handleDecline = () => {
    onDecline();
    onClose();
  };

  return (
    <Modal visible={visible} transparent animationType="slide">
      <View style={styles.overlay}>
        <View style={styles.modal}>
          {/* Header */}
          <View style={styles.header}>
            <View style={styles.iconContainer}>
              <Ionicons name="chatbubble" size={24} color="#3B82F6" />
            </View>
            <Text style={styles.headerTitle}>SMS Order Updates</Text>
            <Text style={styles.headerSubtitle}>Stay informed about your order</Text>
          </View>

          {/* Content */}
          <View style={styles.content}>
            <View style={styles.orderInfo}>
              <Text style={styles.orderTitle}>Order #{orderId.slice(-6)}</Text>
              <Text style={styles.orderAmount}>Total: ₱{orderAmount}</Text>
            </View>

            <View style={styles.benefitsSection}>
              <Text style={styles.benefitsTitle}>📱 SMS Updates Include:</Text>
              <View style={styles.benefitsList}>
                <BenefitItem text="Order confirmation" />
                <BenefitItem text="Printing status updates" />
                <BenefitItem text="Ready for pickup notification" />
                <BenefitItem text="Pickup QR code delivery" />
              </View>
            </View>

            <View style={styles.phoneSection}>
              <Text style={styles.phoneLabel}>Enter your phone number:</Text>
              <TextInput
                style={[styles.phoneInput, !isValidPhone && phoneNumber && styles.phoneInputError]}
                value={phoneNumber}
                onChangeText={handlePhoneChange}
                placeholder="09XX XXX XXXX or +63 9XX XXX XXXX"
                keyboardType="phone-pad"
                autoFocus
              />
              {!isValidPhone && phoneNumber && (
                <Text style={styles.errorText}>Please enter a valid Philippine mobile number</Text>
              )}
            </View>

            <View style={styles.pricingCard}>
              <View style={styles.pricingRow}>
                <Text style={styles.pricingLabel}>Order Total:</Text>
                <Text style={styles.pricingValue}>₱{orderAmount}</Text>
              </View>
              <View style={styles.pricingRow}>
                <Text style={styles.pricingLabel}>SMS Updates (4-6 messages):</Text>
                <Text style={styles.pricingValue}>₱5</Text>
              </View>
              <View style={[styles.pricingRow, styles.pricingTotal]}>
                <Text style={styles.pricingTotalLabel}>New Total:</Text>
                <Text style={styles.pricingTotalValue}>₱{orderAmount + 5}</Text>
              </View>
            </View>

            <View style={styles.registrationPrompt}>
              <View style={styles.promotionIcon}>
                <Ionicons name="star" size={16} color="#10B981" />
              </View>
              <View style={styles.promotionContent}>
                <Text style={styles.promotionTitle}>💡 Want FREE notifications?</Text>
                <Text style={styles.promotionText}>
                  Create a free account to get SMS, email, and push notifications at no charge!
                </Text>
              </View>
            </View>
          </View>

          {/* Actions */}
          <View style={styles.actions}>
            <Pressable onPress={handleDecline} style={styles.declineButton}>
              <Text style={styles.declineButtonText}>Skip SMS Updates</Text>
            </Pressable>
            
            <Pressable 
              onPress={handleApprove} 
              style={[styles.approveButton, !isValidPhone && styles.approveButtonDisabled]}
              disabled={!isValidPhone}
            >
              <Text style={styles.approveButtonText}>Add SMS for ₱5</Text>
            </Pressable>
          </View>

          {/* Quick Registration Option */}
          <View style={styles.quickRegisterSection}>
            <Pressable style={styles.quickRegisterButton}>
              <Ionicons name="person-add" size={16} color="#10B981" />
              <Text style={styles.quickRegisterText}>Create Account Instead (FREE notifications)</Text>
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
};

const BenefitItem: React.FC<{ text: string }> = ({ text }) => (
  <View style={styles.benefitItem}>
    <Ionicons name="checkmark-circle" size={14} color="#10B981" />
    <Text style={styles.benefitText}>{text}</Text>
  </View>
);

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modal: {
    backgroundColor: 'white',
    borderRadius: 16,
    width: '100%',
    maxWidth: 400,
    maxHeight: '90%',
  },
  header: {
    alignItems: 'center',
    padding: 24,
    backgroundColor: '#F8FAFC',
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#DBEAFE',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
    textAlign: 'center',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#6B7280',
    textAlign: 'center',
    marginTop: 4,
  },
  content: {
    padding: 20,
  },
  orderInfo: {
    alignItems: 'center',
    marginBottom: 20,
    padding: 16,
    backgroundColor: '#F3F4F6',
    borderRadius: 8,
  },
  orderTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#111827',
  },
  orderAmount: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 2,
  },
  benefitsSection: {
    marginBottom: 20,
  },
  benefitsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 8,
  },
  benefitsList: {
    paddingLeft: 8,
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  benefitText: {
    fontSize: 13,
    color: '#374151',
    marginLeft: 8,
  },
  phoneSection: {
    marginBottom: 20,
  },
  phoneLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 8,
  },
  phoneInput: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    fontSize: 16,
  },
  phoneInputError: {
    borderColor: '#EF4444',
  },
  errorText: {
    fontSize: 12,
    color: '#EF4444',
    marginTop: 4,
  },
  pricingCard: {
    backgroundColor: '#F9FAFB',
    padding: 16,
    borderRadius: 8,
    marginBottom: 16,
  },
  pricingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  pricingTotal: {
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
    paddingTop: 8,
    marginTop: 4,
    marginBottom: 0,
  },
  pricingLabel: {
    fontSize: 14,
    color: '#6B7280',
  },
  pricingValue: {
    fontSize: 14,
    color: '#111827',
    fontWeight: '500',
  },
  pricingTotalLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#111827',
  },
  pricingTotalValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#10B981',
  },
  registrationPrompt: {
    flexDirection: 'row',
    backgroundColor: '#ECFDF5',
    padding: 12,
    borderRadius: 8,
    borderLeftWidth: 3,
    borderLeftColor: '#10B981',
  },
  promotionIcon: {
    marginRight: 8,
  },
  promotionContent: {
    flex: 1,
  },
  promotionTitle: {
    fontSize: 13,
    fontWeight: '600',
    color: '#065F46',
    marginBottom: 2,
  },
  promotionText: {
    fontSize: 12,
    color: '#059669',
    lineHeight: 16,
  },
  actions: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingBottom: 12,
    gap: 12,
  },
  declineButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    alignItems: 'center',
  },
  declineButtonText: {
    fontSize: 14,
    color: '#6B7280',
    fontWeight: '500',
  },
  approveButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    backgroundColor: '#3B82F6',
    borderRadius: 8,
    alignItems: 'center',
  },
  approveButtonDisabled: {
    backgroundColor: '#D1D5DB',
  },
  approveButtonText: {
    fontSize: 14,
    color: 'white',
    fontWeight: '600',
  },
  quickRegisterSection: {
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
    padding: 16,
  },
  quickRegisterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
  },
  quickRegisterText: {
    fontSize: 13,
    color: '#10B981',
    fontWeight: '600',
    marginLeft: 6,
  },
});

export default GuestSmsApprovalModal;