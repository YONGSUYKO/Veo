import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Pressable,
  StyleSheet,
  ScrollView,
  Alert,
  Modal,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { notificationManager, NotificationPreferences, CustomerTier } from '../services/notificationManager';
import { useAuthStore } from '../state/authStore';

interface UnifiedNotificationManagerProps {
  visible: boolean;
  onClose: () => void;
}

const UnifiedNotificationManager: React.FC<UnifiedNotificationManagerProps> = ({
  visible,
  onClose,
}) => {
  const { currentUser } = useAuthStore();
  const [preferences, setPreferences] = useState<NotificationPreferences | null>(null);
  const [costs, setCosts] = useState({ sms: 5, email: 0, push: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (visible && currentUser) {
      loadPreferences();
      loadCosts();
    }
  }, [visible, currentUser]);

  const loadPreferences = async () => {
    if (!currentUser) return;

    try {
      let userPreferences = await notificationManager.getUserPreferences(currentUser.id);
      
      if (!userPreferences) {
        // Create default preferences based on user type
        const tier: CustomerTier = currentUser.customerTier || 'registered';
        userPreferences = await notificationManager.createDefaultPreferences(
          currentUser.id,
          tier,
          currentUser.email,
          currentUser.phone
        );
      }
      
      setPreferences(userPreferences);
    } catch (error) {
      console.error('Error loading preferences:', error);
      // Create basic fallback preferences to prevent UI crashes
      const fallbackPreferences = {
        userId: currentUser.id,
        customerTier: 'registered' as CustomerTier,
        email: { enabled: false, orderUpdates: false, promotions: false, receipts: false },
        sms: { enabled: false, orderUpdates: false, promotions: false, chargeApproved: false },
        push: { enabled: false, orderUpdates: false, promotions: false, sound: false },
        emailAddress: currentUser.email,
        phone: currentUser.phone,
      };
      setPreferences(fallbackPreferences);
    } finally {
      setLoading(false);
    }
  };

  const loadCosts = async () => {
    try {
      const notificationCosts = await notificationManager.getNotificationCosts();
      setCosts(notificationCosts);
    } catch (error) {
      console.error('Error loading costs:', error);
    }
  };

  const updateNotificationType = async (type: 'email' | 'sms' | 'push', enabled: boolean) => {
    if (!preferences) return;

    // Special handling for SMS approval
    if (type === 'sms' && enabled && preferences.customerTier !== 'subscriber') {
      const approved = await showSmsApprovalDialog();
      if (!approved) return;
    }

    const updatedPreferences = {
      ...preferences,
      [type]: {
        ...preferences[type],
        enabled: enabled,
        orderUpdates: enabled,
      },
    };

    // For SMS, also set charge approval
    if (type === 'sms' && enabled && preferences.customerTier !== 'subscriber') {
      updatedPreferences.sms.chargeApproved = true;
    }

    setPreferences(updatedPreferences);
    await notificationManager.savePreferences(updatedPreferences);
  };

  const showSmsApprovalDialog = (): Promise<boolean> => {
    return new Promise((resolve) => {
      Alert.alert(
        'Enable SMS Notifications',
        `SMS notifications cost ₱${costs.sms} per message. This includes order updates, pickup notifications, and status changes.\n\nYou can upgrade to a subscriber plan to get unlimited FREE SMS.`,
        [
          {
            text: 'Cancel',
            onPress: () => resolve(false),
            style: 'cancel'
          },
          {
            text: `Enable (₱${costs.sms}/SMS)`,
            onPress: () => resolve(true)
          }
        ]
      );
    });
  };

  const showUpgradeToSubscriber = () => {
    Alert.alert(
      'Upgrade to Subscriber Plan',
      'Get unlimited FREE notifications (email, SMS, push), priority support, exclusive offers, and more!\n\nSpecial launch offer: Only ₱99/month',
      [
        { text: 'Maybe Later', style: 'cancel' },
        { text: 'Learn More', onPress: () => {/* Navigate to subscription */ }}
      ]
    );
  };

  if (loading || !preferences || !currentUser) {
    return (
      <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading notification settings...</Text>
        </View>
      </Modal>
    );
  }

  const isSubscriber = preferences.customerTier === 'subscriber';
  const isRegistered = preferences.customerTier === 'registered';
  const isGuest = preferences.customerTier === 'guest';

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Notification Settings</Text>
          <Pressable onPress={onClose} style={styles.closeButton}>
            <Ionicons name="close" size={24} color="#6B7280" />
          </Pressable>
        </View>

        <ScrollView style={styles.content}>
          {/* Customer Tier Banner */}
          <View style={[styles.tierBanner, {
            backgroundColor: isSubscriber ? '#ECFDF5' : isRegistered ? '#DBEAFE' : '#F3F4F6',
            borderColor: isSubscriber ? '#10B981' : isRegistered ? '#3B82F6' : '#6B7280',
          }]}>
            <View style={styles.tierInfo}>
              <Text style={[styles.tierTitle, {
                color: isSubscriber ? '#065F46' : isRegistered ? '#1E40AF' : '#374151',
              }]}>
                {isSubscriber ? '🌟 Subscriber Plan' : isRegistered ? '📱 Registered User' : '👤 Guest User'}
              </Text>
              <Text style={[styles.tierDescription, {
                color: isSubscriber ? '#059669' : isRegistered ? '#2563EB' : '#6B7280',
              }]}>
                {isSubscriber 
                  ? 'All notifications are FREE and unlimited'
                  : isRegistered 
                  ? 'Email & push notifications are FREE, SMS costs apply'
                  : 'Only SMS notifications available with charges'
                }
              </Text>
            </View>
            {!isSubscriber && (
              <Pressable onPress={showUpgradeToSubscriber} style={styles.upgradeButton}>
                <Text style={styles.upgradeButtonText}>Upgrade</Text>
              </Pressable>
            )}
          </View>

          {/* Notification Options */}
          <View style={styles.optionsContainer}>
            <Text style={styles.sectionTitle}>Choose Your Notification Methods</Text>
            <Text style={styles.sectionDescription}>
              Select how you want to receive order updates. You can enable multiple methods.
            </Text>

            {/* Email Notifications */}
            {!isGuest && (
              <NotificationOption
                icon="mail"
                title="Email Notifications"
                description="Order confirmations, status updates, receipts"
                cost="FREE"
                enabled={preferences.email.enabled}
                available={true}
                onToggle={(enabled) => updateNotificationType('email', enabled)}
                features={[
                  'Order confirmation emails',
                  'Status update notifications', 
                  'Digital receipts',
                  isSubscriber ? 'Promotional offers' : ''
                ].filter(Boolean)}
              />
            )}

            {/* Push Notifications */}
            {!isGuest && (
              <NotificationOption
                icon="notifications"
                title="Push Notifications"
                description="Instant alerts on your phone"
                cost="FREE"
                enabled={preferences.push.enabled}
                available={true}
                onToggle={(enabled) => updateNotificationType('push', enabled)}
                features={[
                  'Real-time order updates',
                  'Instant pickup alerts',
                  'Sound and vibration',
                  isSubscriber ? 'Special offer alerts' : ''
                ].filter(Boolean)}
              />
            )}

            {/* SMS Notifications */}
            <NotificationOption
              icon="chatbubble"
              title="SMS Notifications"
              description="Text messages to your phone"
              cost={isSubscriber ? "FREE" : `₱${costs.sms}/SMS`}
              enabled={preferences.sms.enabled}
              available={true}
              onToggle={(enabled) => updateNotificationType('sms', enabled)}
              features={[
                'Order status via SMS',
                'Ready for pickup alerts',
                'QR pickup code delivery',
                isSubscriber ? 'No charges ever' : `₱${costs.sms} per message`,
              ]}
              isCharged={!isSubscriber}
            />
          </View>

          {/* Current Settings Summary */}
          <View style={styles.summaryContainer}>
            <Text style={styles.summaryTitle}>📊 Your Current Setup</Text>
            
            <View style={styles.summaryGrid}>
              <SummaryItem 
                icon="mail" 
                label="Email" 
                status={preferences.email.enabled ? 'Enabled' : 'Disabled'} 
                enabled={preferences.email.enabled}
                available={!isGuest}
              />
              <SummaryItem 
                icon="notifications" 
                label="Push" 
                status={preferences.push.enabled ? 'Enabled' : 'Disabled'} 
                enabled={preferences.push.enabled}
                available={!isGuest}
              />
              <SummaryItem 
                icon="chatbubble" 
                label="SMS" 
                status={preferences.sms.enabled ? 'Enabled' : 'Disabled'} 
                enabled={preferences.sms.enabled}
                available={true}
              />
            </View>

            {!isSubscriber && (preferences.sms.enabled || isGuest) && (
              <View style={styles.costEstimate}>
                <Text style={styles.costEstimateTitle}>💰 Estimated SMS costs per order:</Text>
                <Text style={styles.costEstimateAmount}>
                  ₱{costs.sms} (typical order gets 4-6 SMS updates)
                </Text>
              </View>
            )}
          </View>

          {/* Benefits of Each Method */}
          <View style={styles.benefitsContainer}>
            <Text style={styles.benefitsTitle}>✨ Why Choose Each Method?</Text>
            
            <View style={styles.benefitsList}>
              {!isGuest && (
                <>
                  <BenefitItem 
                    icon="mail" 
                    title="Email" 
                    description="Best for detailed updates and keeping records"
                  />
                  <BenefitItem 
                    icon="notifications" 
                    title="Push" 
                    description="Perfect for instant alerts when you're using the app"
                  />
                </>
              )}
              <BenefitItem 
                icon="chatbubble" 
                title="SMS" 
                description="Most reliable - works even when app is closed"
              />
            </View>
          </View>

          {/* Upgrade Promotion */}
          {!isSubscriber && (
            <View style={styles.upgradePromotion}>
              <View style={styles.upgradePromotionContent}>
                <Text style={styles.upgradePromotionTitle}>🚀 Ready to Save Money?</Text>
                <Text style={styles.upgradePromotionText}>
                  Subscriber plan includes unlimited FREE notifications, priority support, and exclusive offers.
                </Text>
                <Text style={styles.upgradePromotionPrice}>Only ₱99/month</Text>
              </View>
              <Pressable onPress={showUpgradeToSubscriber} style={styles.upgradePromotionButton}>
                <Text style={styles.upgradePromotionButtonText}>Learn More</Text>
              </Pressable>
            </View>
          )}
        </ScrollView>
      </View>
    </Modal>
  );
};

const NotificationOption: React.FC<{
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  description: string;
  cost: string;
  enabled: boolean;
  available: boolean;
  onToggle: (enabled: boolean) => void;
  features: string[];
  isCharged?: boolean;
}> = ({ icon, title, description, cost, enabled, available, onToggle, features, isCharged }) => (
  <View style={[styles.optionCard, !available && styles.optionCardDisabled]}>
    <View style={styles.optionHeader}>
      <View style={styles.optionHeaderLeft}>
        <View style={[styles.optionIcon, enabled && styles.optionIconEnabled]}>
          <Ionicons name={icon} size={20} color={enabled ? '#FFFFFF' : '#6B7280'} />
        </View>
        <View style={styles.optionInfo}>
          <Text style={[styles.optionTitle, !available && styles.optionTitleDisabled]}>
            {title}
          </Text>
          <Text style={[styles.optionDescription, !available && styles.optionDescriptionDisabled]}>
            {description}
          </Text>
        </View>
      </View>
      <View style={styles.optionRight}>
        <Text style={[styles.optionCost, isCharged && styles.optionCostCharged]}>
          {cost}
        </Text>
        <Pressable
          onPress={() => available && onToggle(!enabled)}
          style={[styles.optionToggle, enabled && styles.optionToggleEnabled]}
          disabled={!available}
        >
          {enabled && <Ionicons name="checkmark" size={16} color="white" />}
        </Pressable>
      </View>
    </View>
    
    {available && (
      <View style={styles.featuresList}>
        {features.map((feature, index) => (
          <Text key={index} style={styles.featureItem}>• {feature}</Text>
        ))}
      </View>
    )}
    
    {!available && (
      <View style={styles.unavailableNotice}>
        <Text style={styles.unavailableText}>Not available for your account type</Text>
      </View>
    )}
  </View>
);

const SummaryItem: React.FC<{
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  status: string;
  enabled: boolean;
  available: boolean;
}> = ({ icon, label, status, enabled, available }) => (
  <View style={[styles.summaryItem, !available && styles.summaryItemDisabled]}>
    <Ionicons 
      name={icon} 
      size={16} 
      color={available ? (enabled ? '#10B981' : '#6B7280') : '#D1D5DB'} 
    />
    <Text style={[styles.summaryLabel, !available && styles.summaryLabelDisabled]}>
      {label}
    </Text>
    <Text style={[
      styles.summaryStatus, 
      enabled && styles.summaryStatusEnabled,
      !available && styles.summaryStatusDisabled
    ]}>
      {available ? status : 'N/A'}
    </Text>
  </View>
);

const BenefitItem: React.FC<{
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  description: string;
}> = ({ icon, title, description }) => (
  <View style={styles.benefitItem}>
    <Ionicons name={icon} size={16} color="#3B82F6" />
    <View style={styles.benefitContent}>
      <Text style={styles.benefitTitle}>{title}</Text>
      <Text style={styles.benefitDescription}>{description}</Text>
    </View>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    fontSize: 16,
    color: '#6B7280',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
  },
  closeButton: {
    padding: 4,
  },
  content: {
    flex: 1,
  },
  tierBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    margin: 16,
    padding: 16,
    borderRadius: 12,
    borderWidth: 2,
  },
  tierInfo: {
    flex: 1,
  },
  tierTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  tierDescription: {
    fontSize: 13,
  },
  upgradeButton: {
    backgroundColor: '#10B981',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  upgradeButtonText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '600',
  },
  optionsContainer: {
    paddingHorizontal: 16,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 8,
  },
  sectionDescription: {
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 16,
    lineHeight: 20,
  },
  optionCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  optionCardDisabled: {
    backgroundColor: '#F9FAFB',
  },
  optionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  optionHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  optionIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  optionIconEnabled: {
    backgroundColor: '#10B981',
  },
  optionInfo: {
    flex: 1,
  },
  optionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 2,
  },
  optionTitleDisabled: {
    color: '#9CA3AF',
  },
  optionDescription: {
    fontSize: 13,
    color: '#6B7280',
  },
  optionDescriptionDisabled: {
    color: '#D1D5DB',
  },
  optionRight: {
    alignItems: 'flex-end',
  },
  optionCost: {
    fontSize: 12,
    fontWeight: '600',
    color: '#10B981',
    marginBottom: 4,
  },
  optionCostCharged: {
    color: '#F59E0B',
  },
  optionToggle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#E5E7EB',
    alignItems: 'center',
    justifyContent: 'center',
  },
  optionToggleEnabled: {
    backgroundColor: '#10B981',
  },
  featuresList: {
    paddingLeft: 52,
  },
  featureItem: {
    fontSize: 12,
    color: '#6B7280',
    marginBottom: 2,
  },
  unavailableNotice: {
    paddingLeft: 52,
    paddingTop: 4,
  },
  unavailableText: {
    fontSize: 12,
    color: '#9CA3AF',
    fontStyle: 'italic',
  },
  summaryContainer: {
    backgroundColor: 'white',
    margin: 16,
    padding: 16,
    borderRadius: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  summaryTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 12,
  },
  summaryGrid: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 16,
  },
  summaryItem: {
    alignItems: 'center',
    flex: 1,
  },
  summaryItemDisabled: {
    opacity: 0.5,
  },
  summaryLabel: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 4,
    marginBottom: 2,
  },
  summaryLabelDisabled: {
    color: '#D1D5DB',
  },
  summaryStatus: {
    fontSize: 11,
    color: '#9CA3AF',
    fontWeight: '500',
  },
  summaryStatusEnabled: {
    color: '#10B981',
  },
  summaryStatusDisabled: {
    color: '#D1D5DB',
  },
  costEstimate: {
    backgroundColor: '#FEF3C7',
    padding: 12,
    borderRadius: 8,
  },
  costEstimateTitle: {
    fontSize: 13,
    color: '#92400E',
    fontWeight: '600',
    marginBottom: 2,
  },
  costEstimateAmount: {
    fontSize: 12,
    color: '#92400E',
  },
  benefitsContainer: {
    paddingHorizontal: 16,
    marginBottom: 20,
  },
  benefitsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 12,
  },
  benefitsList: {
    gap: 8,
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: 'white',
    padding: 12,
    borderRadius: 8,
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 1,
  },
  benefitContent: {
    marginLeft: 8,
    flex: 1,
  },
  benefitTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 2,
  },
  benefitDescription: {
    fontSize: 12,
    color: '#6B7280',
  },
  upgradePromotion: {
    backgroundColor: '#10B981',
    margin: 16,
    padding: 16,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
  },
  upgradePromotionContent: {
    flex: 1,
    marginRight: 12,
  },
  upgradePromotionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 4,
  },
  upgradePromotionText: {
    fontSize: 13,
    color: 'rgba(255,255,255,0.9)',
    marginBottom: 4,
  },
  upgradePromotionPrice: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
  },
  upgradePromotionButton: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  upgradePromotionButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
});

export default UnifiedNotificationManager;