import React from 'react';
import { View, Text, Pressable, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useDeviceInfo } from '../../utils/deviceDetection';

interface DesktopLayoutProps {
  title: string;
  subtitle?: string;
  userInfo?: {
    name: string;
    role: string;
    avatar?: string;
  };
  navigation?: Array<{
    id: string;
    label: string;
    icon: keyof typeof Ionicons.glyphMap;
    active?: boolean;
    onPress: () => void;
  }>;
  actions?: Array<{
    id: string;
    label: string;
    icon: keyof typeof Ionicons.glyphMap;
    variant?: 'primary' | 'secondary' | 'danger';
    onPress: () => void;
  }>;
  onLogout?: () => void;
  children: React.ReactNode;
}

export default function DesktopLayout({
  title,
  subtitle,
  userInfo,
  navigation = [],
  actions = [],
  onLogout,
  children,
}: DesktopLayoutProps) {
  const deviceInfo = useDeviceInfo();

  // Fallback to mobile layout if not desktop
  if (!deviceInfo.isDesktop) {
    return (
      <View style={{ flex: 1, backgroundColor: '#F9FAFB' }}>
        {children}
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: '#F9FAFB', flexDirection: 'row' }}>
      {/* Sidebar Navigation */}
      <View style={{ 
        width: 280, 
        backgroundColor: 'white', 
        borderRightWidth: 1, 
        borderRightColor: '#E5E7EB',
        flexDirection: 'column'
      }}>
        {/* Header */}
        <View style={{ 
          padding: 24, 
          borderBottomWidth: 1, 
          borderBottomColor: '#E5E7EB' 
        }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16 }}>
            <View style={{ 
              width: 48, 
              height: 48, 
              backgroundColor: '#3B82F6', 
              borderRadius: 12, 
              alignItems: 'center', 
              justifyContent: 'center',
              marginRight: 12
            }}>
              <Ionicons name="print" size={24} color="white" />
            </View>
            <View>
              <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#111827' }}>
                PISO Print Express
              </Text>
              <Text style={{ fontSize: 14, color: '#6B7280' }}>
                {userInfo?.role === 'admin' ? 'Administration' : 'Operator Station'}
              </Text>
            </View>
          </View>
          
          {userInfo && (
            <View style={{ 
              backgroundColor: '#F3F4F6', 
              borderRadius: 12, 
              padding: 16, 
              flexDirection: 'row', 
              alignItems: 'center' 
            }}>
              <View style={{ 
                width: 40, 
                height: 40, 
                backgroundColor: userInfo.role === 'admin' ? '#DC2626' : '#10B981', 
                borderRadius: 20, 
                alignItems: 'center', 
                justifyContent: 'center',
                marginRight: 12
              }}>
                <Ionicons 
                  name={userInfo.role === 'admin' ? 'shield' : 'construct'} 
                  size={20} 
                  color="white" 
                />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827' }}>
                  {userInfo.name}
                </Text>
                <Text style={{ fontSize: 12, color: '#6B7280', textTransform: 'capitalize' }}>
                  {userInfo.role}
                </Text>
              </View>
            </View>
          )}
        </View>

        {/* Navigation Menu */}
        <ScrollView style={{ flex: 1 }}>
          <View style={{ padding: 16 }}>
            {navigation.map((item, index) => (
              <Pressable
                key={item.id}
                onPress={item.onPress}
                style={({ pressed }) => [
                  {
                    flexDirection: 'row',
                    alignItems: 'center',
                    padding: 12,
                    borderRadius: 8,
                    marginBottom: 4,
                  },
                  item.active && {
                    backgroundColor: '#EFF6FF',
                    borderWidth: 1,
                    borderColor: '#3B82F6',
                  },
                  pressed && {
                    backgroundColor: '#F3F4F6',
                  }
                ]}
              >
                <View style={{ 
                  width: 36, 
                  height: 36, 
                  borderRadius: 8,
                  alignItems: 'center', 
                  justifyContent: 'center',
                  backgroundColor: item.active ? '#3B82F6' : '#F3F4F6',
                  marginRight: 12
                }}>
                  <Ionicons 
                    name={item.icon} 
                    size={18} 
                    color={item.active ? 'white' : '#6B7280'} 
                  />
                </View>
                <Text style={{ 
                  flex: 1, 
                  fontSize: 14, 
                  fontWeight: item.active ? '600' : '500',
                  color: item.active ? '#1D4ED8' : '#374151'
                }}>
                  {item.label}
                </Text>
                {item.active && (
                  <Ionicons name="chevron-forward" size={16} color="#3B82F6" />
                )}
              </Pressable>
            ))}
          </View>
        </ScrollView>

        {/* Footer Actions */}
        <View style={{ 
          padding: 16, 
          borderTopWidth: 1, 
          borderTopColor: '#E5E7EB' 
        }}>
          {onLogout && (
            <Pressable
              onPress={onLogout}
              style={({ pressed }) => [
                {
                  flexDirection: 'row',
                  alignItems: 'center',
                  padding: 12,
                  borderRadius: 8,
                },
                pressed && {
                  backgroundColor: '#FEF2F2',
                }
              ]}
            >
              <View style={{ 
                width: 36, 
                height: 36, 
                borderRadius: 8,
                alignItems: 'center', 
                justifyContent: 'center',
                backgroundColor: '#FEF2F2',
                marginRight: 12
              }}>
                <Ionicons name="log-out" size={18} color="#DC2626" />
              </View>
              <Text style={{ 
                flex: 1, 
                fontSize: 14, 
                fontWeight: '500',
                color: '#DC2626'
              }}>
                Sign Out
              </Text>
            </Pressable>
          )}
        </View>
      </View>

      {/* Main Content Area */}
      <View style={{ flex: 1, flexDirection: 'column' }}>
        {/* Top Bar */}
        <View style={{ 
          backgroundColor: 'white', 
          borderBottomWidth: 1, 
          borderBottomColor: '#E5E7EB',
          paddingHorizontal: 32,
          paddingVertical: 20,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between'
        }}>
          <View>
            <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#111827' }}>
              {title}
            </Text>
            {subtitle && (
              <Text style={{ fontSize: 16, color: '#6B7280', marginTop: 4 }}>
                {subtitle}
              </Text>
            )}
          </View>
          
          {actions.length > 0 && (
            <View style={{ flexDirection: 'row', gap: 12 }}>
              {actions.map((action) => (
                <Pressable
                  key={action.id}
                  onPress={action.onPress}
                  style={({ pressed }) => [
                    {
                      flexDirection: 'row',
                      alignItems: 'center',
                      paddingHorizontal: 16,
                      paddingVertical: 8,
                      borderRadius: 8,
                      borderWidth: 1,
                    },
                    action.variant === 'primary' && {
                      backgroundColor: '#3B82F6',
                      borderColor: '#3B82F6',
                    },
                    action.variant === 'danger' && {
                      backgroundColor: '#DC2626',
                      borderColor: '#DC2626',
                    },
                    (!action.variant || action.variant === 'secondary') && {
                      backgroundColor: 'white',
                      borderColor: '#D1D5DB',
                    },
                    pressed && {
                      opacity: 0.8,
                    }
                  ]}
                >
                  <Ionicons 
                    name={action.icon} 
                    size={18} 
                    color={
                      action.variant === 'primary' || action.variant === 'danger' 
                        ? 'white' 
                        : '#374151'
                    }
                    style={{ marginRight: 8 }}
                  />
                  <Text style={{ 
                    fontSize: 14, 
                    fontWeight: '500',
                    color: action.variant === 'primary' || action.variant === 'danger' 
                      ? 'white' 
                      : '#374151'
                  }}>
                    {action.label}
                  </Text>
                </Pressable>
              ))}
            </View>
          )}
        </View>

        {/* Content */}
        <View style={{ flex: 1, padding: 32 }}>
          {children}
        </View>
      </View>
    </View>
  );
}