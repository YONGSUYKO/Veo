import React, { useEffect } from 'react';
import { useAuthStore } from '../state/authStore';
import { Alert } from 'react-native';

// Guest Session Management Component
const GuestSessionManager: React.FC = () => {
  const { currentUser, isGuestMode, logout } = useAuthStore();

  useEffect(() => {
    // If user is in guest mode and has completed an order
    if (isGuestMode && currentUser?.isGuest) {
      // Show post-order options after 30 seconds
      const timer = setTimeout(() => {
        Alert.alert(
          'Order Submitted! 📋',
          'Want to track your order and get FREE notifications next time?',
          [
            { 
              text: 'Stay Guest', 
              onPress: () => {
                // Keep guest session active
                console.log('Guest continues session');
              }
            },
            { 
              text: 'Create Account', 
              onPress: () => {
                // Navigate to registration
                console.log('Convert guest to registered user');
              }
            }
          ]
        );
      }, 30000); // 30 seconds after checkout

      return () => clearTimeout(timer);
    }
  }, [currentUser, isGuestMode]);

  return null; // This is a logic-only component
};

export default GuestSessionManager;