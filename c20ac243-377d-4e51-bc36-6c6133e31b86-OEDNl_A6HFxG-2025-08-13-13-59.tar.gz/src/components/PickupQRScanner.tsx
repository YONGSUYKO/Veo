import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Pressable,
  Alert,
  Modal,
  TextInput,
  StyleSheet,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Camera } from 'expo-camera';
import { qrCodeService } from '../services/qrCodeService';
import { StaffSupportOrder } from '../types/staffSupportOrder';
import { useAuthStore } from '../state/authStore';

interface PickupQRScannerProps {
  visible: boolean;
  onClose: () => void;
  onOrderPickedUp: (order: StaffSupportOrder) => void;
}

const PickupQRScanner: React.FC<PickupQRScannerProps> = ({ 
  visible, 
  onClose, 
  onOrderPickedUp 
}) => {
  const { currentUser } = useAuthStore();
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [scanned, setScanned] = useState(false);
  const [manualEntry, setManualEntry] = useState(false);
  const [manualCode, setManualCode] = useState('');
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    getCameraPermissions();
  }, []);

  const getCameraPermissions = async () => {
    const { status } = await Camera.requestCameraPermissionsAsync();
    setHasPermission(status === 'granted');
  };

  const handleBarCodeScanned = async ({ type, data }: { type: string; data: string }) => {
    if (scanned || processing) return;
    
    setScanned(true);
    setProcessing(true);

    try {
      const result = await qrCodeService.validatePickupQR(data, currentUser?.id || 'operator');
      
      if (result.success && result.order) {
        Alert.alert(
          'Pickup Successful!',
          `Order #${result.order.id.slice(-6)} has been marked as picked up.`,
          [
            {
              text: 'OK',
              onPress: () => {
                onOrderPickedUp(result.order!);
                onClose();
              }
            }
          ]
        );
      } else {
        Alert.alert(
          'Pickup Failed',
          result.message,
          [
            {
              text: 'Scan Again',
              onPress: () => setScanned(false)
            },
            {
              text: 'Manual Entry',
              onPress: () => {
                setScanned(false);
                setManualEntry(true);
              }
            },
            {
              text: 'Cancel',
              onPress: onClose,
              style: 'cancel'
            }
          ]
        );
      }
    } catch (error) {
      console.error('Error processing QR scan:', error);
      Alert.alert(
        'Error',
        'Failed to process QR code. Please try again.',
        [
          {
            text: 'Retry',
            onPress: () => setScanned(false)
          },
          {
            text: 'Cancel',
            onPress: onClose,
            style: 'cancel'
          }
        ]
      );
    } finally {
      setProcessing(false);
    }
  };

  const handleManualEntry = async () => {
    if (!manualCode.trim()) {
      Alert.alert('Error', 'Please enter a pickup code');
      return;
    }

    setProcessing(true);

    try {
      const result = await qrCodeService.validatePickupCode(manualCode.trim(), currentUser?.id || 'operator');
      
      if (result.success && result.order) {
        Alert.alert(
          'Pickup Successful!',
          `Order #${result.order.id.slice(-6)} has been marked as picked up.`,
          [
            {
              text: 'OK',
              onPress: () => {
                onOrderPickedUp(result.order!);
                onClose();
              }
            }
          ]
        );
      } else {
        Alert.alert('Pickup Failed', result.message);
      }
    } catch (error) {
      console.error('Error processing manual code:', error);
      Alert.alert('Error', 'Failed to process pickup code. Please try again.');
    } finally {
      setProcessing(false);
    }
  };

  const resetScanner = () => {
    setScanned(false);
    setManualEntry(false);
    setManualCode('');
    setProcessing(false);
  };

  if (hasPermission === null) {
    return (
      <Modal visible={visible} animationType="slide">
        <View style={styles.permissionContainer}>
          <Text style={styles.permissionText}>Requesting camera permission...</Text>
        </View>
      </Modal>
    );
  }

  if (hasPermission === false) {
    return (
      <Modal visible={visible} animationType="slide">
        <View style={styles.permissionContainer}>
          <Ionicons name="camera-off" size={64} color="#EF4444" />
          <Text style={styles.permissionTitle}>Camera Access Denied</Text>
          <Text style={styles.permissionText}>
            Camera access is required to scan QR codes. Please enable camera permissions in settings.
          </Text>
          <Pressable onPress={onClose} style={styles.closeButton}>
            <Text style={styles.closeButtonText}>Close</Text>
          </Pressable>
        </View>
      </Modal>
    );
  }

  return (
    <Modal visible={visible} animationType="slide">
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Pressable onPress={onClose} style={styles.headerButton}>
            <Ionicons name="close" size={24} color="white" />
          </Pressable>
          <Text style={styles.headerTitle}>Scan Pickup QR</Text>
          <Pressable 
            onPress={() => setManualEntry(!manualEntry)} 
            style={styles.headerButton}
          >
            <Ionicons name="keypad" size={24} color="white" />
          </Pressable>
        </View>

        {manualEntry ? (
          /* Manual Entry Mode */
          <View style={styles.manualEntryContainer}>
            <View style={styles.manualEntryContent}>
              <Ionicons name="keypad" size={64} color="#3B82F6" />
              <Text style={styles.manualEntryTitle}>Manual Pickup Code Entry</Text>
              <Text style={styles.manualEntryInstructions}>
                Enter the 6-digit pickup code shown on customer's device
              </Text>
              
              <TextInput
                style={styles.codeInput}
                value={manualCode}
                onChangeText={setManualCode}
                placeholder="Enter 6-digit code"
                keyboardType="numeric"
                maxLength={6}
                autoFocus
              />
              
              <View style={styles.manualEntryButtons}>
                <Pressable 
                  onPress={() => setManualEntry(false)}
                  style={[styles.button, styles.secondaryButton]}
                >
                  <Text style={styles.secondaryButtonText}>Back to Scanner</Text>
                </Pressable>
                
                <Pressable 
                  onPress={handleManualEntry}
                  style={[styles.button, styles.primaryButton]}
                  disabled={processing || manualCode.length !== 6}
                >
                  <Text style={styles.primaryButtonText}>
                    {processing ? 'Processing...' : 'Process Pickup'}
                  </Text>
                </Pressable>
              </View>
            </View>
          </View>
        ) : (
          /* Camera Scanner Mode */
          <View style={styles.cameraContainer}>
            <Camera
              style={styles.camera}
              type={Camera.Constants.Type.back}
              onBarCodeScanned={scanned ? undefined : handleBarCodeScanned}
              barCodeScannerSettings={{
                barCodeTypes: ['qr'],
              }}
            />
            
            {/* Scanning Overlay */}
            <View style={styles.overlay}>
              <View style={styles.scanArea}>
                <View style={[styles.corner, styles.topLeft]} />
                <View style={[styles.corner, styles.topRight]} />
                <View style={[styles.corner, styles.bottomLeft]} />
                <View style={[styles.corner, styles.bottomRight]} />
              </View>
              
              <Text style={styles.scanInstructions}>
                Position the QR code within the frame
              </Text>
              
              {scanned && (
                <Pressable onPress={resetScanner} style={styles.scanAgainButton}>
                  <Text style={styles.scanAgainButtonText}>
                    {processing ? 'Processing...' : 'Scan Again'}
                  </Text>
                </Pressable>
              )}
            </View>
          </View>
        )}

        {/* Instructions */}
        <View style={styles.instructionsContainer}>
          <Text style={styles.instructionsTitle}>📋 How to use:</Text>
          <Text style={styles.instructionsText}>
            • Ask customer to show their pickup QR code{'\n'}
            • Point camera at the QR code{'\n'}
            • Use manual entry if QR code won't scan{'\n'}
            • System will automatically mark order as picked up
          </Text>
        </View>
      </View>
    </Modal>
  );
};

const { width, height } = Dimensions.get('window');

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  permissionContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
    padding: 40,
  },
  permissionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#111827',
    marginTop: 16,
    marginBottom: 8,
    textAlign: 'center',
  },
  permissionText: {
    fontSize: 16,
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 20,
  },
  closeButton: {
    backgroundColor: '#3B82F6',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  closeButtonText: {
    color: 'white',
    fontWeight: '600',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
    backgroundColor: 'rgba(0,0,0,0.8)',
  },
  headerButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  cameraContainer: {
    flex: 1,
  },
  camera: {
    flex: 1,
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scanArea: {
    width: 250,
    height: 250,
    position: 'relative',
  },
  corner: {
    position: 'absolute',
    width: 20,
    height: 20,
    borderColor: '#3B82F6',
    borderWidth: 3,
  },
  topLeft: {
    top: 0,
    left: 0,
    borderRightWidth: 0,
    borderBottomWidth: 0,
  },
  topRight: {
    top: 0,
    right: 0,
    borderLeftWidth: 0,
    borderBottomWidth: 0,
  },
  bottomLeft: {
    bottom: 0,
    left: 0,
    borderRightWidth: 0,
    borderTopWidth: 0,
  },
  bottomRight: {
    bottom: 0,
    right: 0,
    borderLeftWidth: 0,
    borderTopWidth: 0,
  },
  scanInstructions: {
    color: 'white',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 30,
    backgroundColor: 'rgba(0,0,0,0.6)',
    padding: 12,
    borderRadius: 8,
  },
  scanAgainButton: {
    backgroundColor: '#3B82F6',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
    marginTop: 20,
  },
  scanAgainButtonText: {
    color: 'white',
    fontWeight: '600',
  },
  manualEntryContainer: {
    flex: 1,
    backgroundColor: 'white',
  },
  manualEntryContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  manualEntryTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#111827',
    marginTop: 16,
    marginBottom: 8,
    textAlign: 'center',
  },
  manualEntryInstructions: {
    fontSize: 16,
    color: '#6B7280',
    textAlign: 'center',
    marginBottom: 30,
    lineHeight: 22,
  },
  codeInput: {
    width: '100%',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    borderWidth: 2,
    borderColor: '#D1D5DB',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 20,
    marginBottom: 30,
    letterSpacing: 4,
    fontFamily: 'monospace',
  },
  manualEntryButtons: {
    flexDirection: 'row',
    width: '100%',
    gap: 12,
  },
  button: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignItems: 'center',
  },
  primaryButton: {
    backgroundColor: '#3B82F6',
  },
  primaryButtonText: {
    color: 'white',
    fontWeight: '600',
    fontSize: 16,
  },
  secondaryButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: '#D1D5DB',
  },
  secondaryButtonText: {
    color: '#6B7280',
    fontWeight: '600',
    fontSize: 16,
  },
  instructionsContainer: {
    backgroundColor: 'rgba(0,0,0,0.8)',
    padding: 20,
  },
  instructionsTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 8,
  },
  instructionsText: {
    fontSize: 12,
    color: '#D1D5DB',
    lineHeight: 18,
  },
});

export default PickupQRScanner;