import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Pressable,
  Alert,
  StyleSheet,
  Share,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { StaffSupportOrder } from '../types/staffSupportOrder';
import { qrCodeService } from '../services/qrCodeService';
import * as Clipboard from 'expo-clipboard';

interface PickupQRCodeDisplayProps {
  order: StaffSupportOrder;
  onClose?: () => void;
}

const PickupQRCodeDisplay: React.FC<PickupQRCodeDisplayProps> = ({ order, onClose }) => {
  const [pickupCode, setPickupCode] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    generatePickupCode();
  }, [order.id]);

  const generatePickupCode = async () => {
    try {
      setLoading(true);
      
      // Check if pickup code already exists
      let existingCode = await qrCodeService.getPickupCodeForOrder(order.id);
      
      if (!existingCode) {
        // Generate new pickup code
        existingCode = await qrCodeService.generatePickupQR(order);
      }
      
      setPickupCode(existingCode);
    } catch (error) {
      console.error('Error generating pickup code:', error);
      Alert.alert('Error', 'Failed to generate pickup code. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const copyPickupCode = async () => {
    if (pickupCode) {
      await Clipboard.setStringAsync(pickupCode.pickupCode);
      Alert.alert('Copied!', 'Pickup code copied to clipboard');
    }
  };

  const sharePickupInfo = async () => {
    if (pickupCode) {
      const shareMessage = `
PISO Print Express - Order Ready for Pickup!

Order: #${order.id.slice(-6)}
Pickup Code: ${pickupCode.pickupCode}
Amount: ₱${order.totalAmount}

Show this code or scan QR at pickup.
Valid until: ${pickupCode.expiresAt.toLocaleDateString()}

Visit: PISO Print Express
      `.trim();

      try {
        await Share.share({
          message: shareMessage,
          title: 'PISO Print Order Pickup',
        });
      } catch (error) {
        console.error('Error sharing pickup info:', error);
      }
    }
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <View style={styles.loadingContainer}>
          <Ionicons name="qr-code" size={48} color="#3B82F6" />
          <Text style={styles.loadingText}>Generating pickup code...</Text>
        </View>
      </View>
    );
  }

  if (!pickupCode) {
    return (
      <View style={styles.container}>
        <View style={styles.errorContainer}>
          <Ionicons name="alert-circle" size={48} color="#EF4444" />
          <Text style={styles.errorText}>Failed to generate pickup code</Text>
          <Pressable onPress={generatePickupCode} style={styles.retryButton}>
            <Text style={styles.retryButtonText}>Try Again</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Ready for Pickup!</Text>
        {onClose && (
          <Pressable onPress={onClose} style={styles.closeButton}>
            <Ionicons name="close" size={24} color="#6B7280" />
          </Pressable>
        )}
      </View>

      {/* Order Info */}
      <View style={styles.orderInfo}>
        <Text style={styles.orderNumber}>Order #{order.id.slice(-6)}</Text>
        <Text style={styles.orderAmount}>₱{order.totalAmount}</Text>
      </View>

      {/* QR Code Section */}
      <View style={styles.qrSection}>
        <Text style={styles.qrTitle}>Show this QR code at pickup</Text>
        
        {/* QR Code Placeholder (In production, use actual QR code library) */}
        <View style={styles.qrCodeContainer}>
          <View style={styles.qrCodePlaceholder}>
            <Ionicons name="qr-code" size={120} color="#3B82F6" />
            <Text style={styles.qrCodeText}>QR CODE</Text>
            <Text style={styles.qrCodeSubtext}>Order #{order.id.slice(-6)}</Text>
          </View>
        </View>

        <Text style={styles.qrInstructions}>
          Present this QR code to any PISO Print staff member for quick pickup
        </Text>
      </View>

      {/* Backup Pickup Code */}
      <View style={styles.backupSection}>
        <Text style={styles.backupTitle}>Backup Pickup Code</Text>
        <View style={styles.codeContainer}>
          <Text style={styles.pickupCode}>{pickupCode.pickupCode}</Text>
          <Pressable onPress={copyPickupCode} style={styles.copyButton}>
            <Ionicons name="copy" size={20} color="#3B82F6" />
          </Pressable>
        </View>
        <Text style={styles.backupInstructions}>
          If QR code doesn't work, give this 6-digit code to staff
        </Text>
      </View>

      {/* Validity Info */}
      <View style={styles.validitySection}>
        <View style={styles.validityItem}>
          <Ionicons name="time" size={16} color="#10B981" />
          <Text style={styles.validityText}>
            Valid until: {pickupCode.expiresAt.toLocaleDateString()}
          </Text>
        </View>
        <View style={styles.validityItem}>
          <Ionicons name="location" size={16} color="#10B981" />
          <Text style={styles.validityText}>
            Any PISO Print Express location
          </Text>
        </View>
      </View>

      {/* Action Buttons */}
      <View style={styles.actionButtons}>
        <Pressable onPress={sharePickupInfo} style={styles.shareButton}>
          <Ionicons name="share" size={20} color="#6B7280" />
          <Text style={styles.shareButtonText}>Share Pickup Info</Text>
        </Pressable>
      </View>

      {/* Important Notes */}
      <View style={styles.notesSection}>
        <Text style={styles.notesTitle}>📋 Important Notes:</Text>
        <Text style={styles.notesText}>
          • Bring this QR code or pickup code{'\n'}
          • Valid ID may be required{'\n'}
          • Code expires in 30 days{'\n'}
          • Contact us if you have issues
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#6B7280',
    marginTop: 12,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  errorText: {
    fontSize: 16,
    color: '#EF4444',
    marginTop: 12,
    marginBottom: 20,
    textAlign: 'center',
  },
  retryButton: {
    backgroundColor: '#3B82F6',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  retryButtonText: {
    color: 'white',
    fontWeight: '600',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#10B981',
  },
  closeButton: {
    padding: 4,
  },
  orderInfo: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  orderNumber: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 4,
  },
  orderAmount: {
    fontSize: 18,
    color: '#10B981',
    fontWeight: '600',
  },
  qrSection: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  qrTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 16,
  },
  qrCodeContainer: {
    padding: 20,
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    marginBottom: 16,
  },
  qrCodePlaceholder: {
    alignItems: 'center',
    padding: 20,
  },
  qrCodeText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#3B82F6',
    marginTop: 8,
  },
  qrCodeSubtext: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 4,
  },
  qrInstructions: {
    fontSize: 14,
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 20,
  },
  backupSection: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 12,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  backupTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 12,
    textAlign: 'center',
  },
  codeContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
  },
  pickupCode: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#111827',
    fontFamily: 'monospace',
    letterSpacing: 4,
  },
  copyButton: {
    marginLeft: 12,
    padding: 8,
  },
  backupInstructions: {
    fontSize: 12,
    color: '#6B7280',
    textAlign: 'center',
  },
  validitySection: {
    backgroundColor: '#F0FDF4',
    padding: 16,
    borderRadius: 8,
    marginBottom: 16,
  },
  validityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  validityText: {
    fontSize: 14,
    color: '#059669',
    marginLeft: 8,
    fontWeight: '500',
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 20,
  },
  shareButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#D1D5DB',
  },
  shareButtonText: {
    fontSize: 14,
    color: '#6B7280',
    fontWeight: '500',
    marginLeft: 8,
  },
  notesSection: {
    backgroundColor: '#FEF3C7',
    padding: 16,
    borderRadius: 8,
  },
  notesTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#92400E',
    marginBottom: 8,
  },
  notesText: {
    fontSize: 12,
    color: '#92400E',
    lineHeight: 18,
  },
});

export default PickupQRCodeDisplay;