import React, { useState, useRef, useEffect } from 'react';
import { View, Text, Pressable, Animated, Dimensions } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import CameraService, { DocumentScanResult } from '../services/CameraService';

const { width: screenWidth, height: screenHeight } = Dimensions.get('window');

interface ProfessionalDocumentScannerProps {
  onCapture: (result: DocumentScanResult) => void;
  onClose: () => void;
  title?: string;
}

export default function ProfessionalDocumentScanner({
  onCapture,
  onClose,
  title = "Scan Document"
}: ProfessionalDocumentScannerProps) {
  const insets = useSafeAreaInsets();
  const [permission, requestPermission] = useCameraPermissions();
  const [isCapturing, setIsCapturing] = useState(false);
  const [flashMode, setFlashMode] = useState<'off' | 'on' | 'auto'>('auto');
  const [detectionActive, setDetectionActive] = useState(false);
  
  const cameraRef = useRef<any>(null);
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const scanLineAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Start document detection animation
    startDetectionAnimation();
    
    // Simulate document detection after a short delay
    const timeout = setTimeout(() => {
      setDetectionActive(true);
    }, 1500);

    return () => clearTimeout(timeout);
  }, []);

  const startDetectionAnimation = () => {
    // Pulse animation for scan area
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.1,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    // Scanning line animation
    Animated.loop(
      Animated.timing(scanLineAnim, {
        toValue: 1,
        duration: 2000,
        useNativeDriver: false,
      })
    ).start();
  };

  const handleCapture = async () => {
    if (!cameraRef.current || isCapturing) return;

    setIsCapturing(true);
    try {
      const photo = await cameraRef.current.takePictureAsync({
        quality: 0.8,
        base64: false,
      });

      // Analyze the captured document
      const result = await CameraService.analyzeDocument(photo.uri);
      
      // Add capture metadata
      const scanResult: DocumentScanResult = {
        ...result,
        uri: photo.uri,
      };

      onCapture(scanResult);
    } catch (error) {
      console.error('Failed to capture document:', error);
    } finally {
      setIsCapturing(false);
    }
  };

  const toggleFlash = () => {
    const modes: Array<'off' | 'on' | 'auto'> = ['off', 'auto', 'on'];
    const currentIndex = modes.indexOf(flashMode);
    setFlashMode(modes[(currentIndex + 1) % modes.length]);
  };

  const getFlashIcon = () => {
    switch (flashMode) {
      case 'on': return 'flash';
      case 'auto': return 'flash-auto';
      default: return 'flash-off';
    }
  };

  if (!permission) {
    return <View />;
  }

  if (!permission.granted) {
    return (
      <View className="flex-1 bg-black items-center justify-center px-8">
        <View className="w-24 h-24 bg-gray-800 rounded-full items-center justify-center mb-8">
          <Ionicons name="camera-outline" size={48} color="#9CA3AF" />
        </View>
        <Text className="text-white text-xl font-bold text-center mb-4">
          Camera Permission Required
        </Text>
        <Text className="text-gray-300 text-center mb-8 leading-relaxed">
          We need access to your camera to scan documents. This allows you to capture high-quality scans of your documents.
        </Text>
        <Pressable 
          className="bg-blue-600 px-8 py-4 rounded-xl"
          onPress={requestPermission}
        >
          <Text className="text-white font-semibold text-lg">
            Grant Camera Access
          </Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View className="flex-1 bg-black">
      <CameraView
        ref={cameraRef}
        style={{ flex: 1 }}
        facing="back"
        flash={flashMode}
      />

      {/* Dark overlay with scan area */}
      <View style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}>
        {/* Top overlay */}
        <LinearGradient
          colors={['rgba(0,0,0,0.8)', 'rgba(0,0,0,0.3)', 'transparent']}
          style={{ height: screenHeight * 0.25 }}
        />
        
        {/* Bottom overlay */}
        <View style={{ position: 'absolute', bottom: 0, left: 0, right: 0 }}>
          <LinearGradient
            colors={['transparent', 'rgba(0,0,0,0.3)', 'rgba(0,0,0,0.8)']}
            style={{ height: screenHeight * 0.25 }}
          />
        </View>

        {/* Side overlays */}
        <View style={{ 
          position: 'absolute',
          top: screenHeight * 0.15,
          bottom: screenHeight * 0.15,
          left: 0,
          width: screenWidth * 0.1,
          backgroundColor: 'rgba(0,0,0,0.6)'
        }} />
        
        <View style={{ 
          position: 'absolute',
          top: screenHeight * 0.15,
          bottom: screenHeight * 0.15,
          right: 0,
          width: screenWidth * 0.1,
          backgroundColor: 'rgba(0,0,0,0.6)'
        }} />
      </View>

      {/* Scan area frame */}
      <Animated.View
        style={{
          position: 'absolute',
          top: screenHeight * 0.2,
          left: screenWidth * 0.1,
          right: screenWidth * 0.1,
          height: screenHeight * 0.5,
          transform: [{ scale: pulseAnim }],
        }}
      >
        {/* Document detection frame */}
        <View style={{
          flex: 1,
          borderWidth: 2,
          borderColor: detectionActive ? '#10B981' : '#3B82F6',
          borderRadius: 16,
          backgroundColor: 'transparent',
        }}>
          {/* Corner indicators */}
          {[
            { top: -8, left: -8, borderTopWidth: 4, borderLeftWidth: 4 },
            { top: -8, right: -8, borderTopWidth: 4, borderRightWidth: 4 },
            { bottom: -8, left: -8, borderBottomWidth: 4, borderLeftWidth: 4 },
            { bottom: -8, right: -8, borderBottomWidth: 4, borderRightWidth: 4 },
          ].map((corner, index) => (
            <View
              key={index}
              style={{
                position: 'absolute',
                width: 24,
                height: 24,
                borderColor: detectionActive ? '#10B981' : '#3B82F6',
                ...corner,
              }}
            />
          ))}
          
          {/* Scanning line */}
          <Animated.View
            style={{
              position: 'absolute',
              left: 0,
              right: 0,
              height: 2,
              backgroundColor: detectionActive ? '#10B981' : '#3B82F6',
              opacity: 0.8,
              top: scanLineAnim.interpolate({
                inputRange: [0, 1],
                outputRange: ['10%', '90%'],
              }),
            }}
          />
        </View>
      </Animated.View>

      {/* Header */}
      <View 
        className="absolute top-0 left-0 right-0 px-6 pb-4"
        style={{ paddingTop: insets.top + 16 }}
      >
        <View className="flex-row items-center justify-between">
          <View className="flex-row items-center">
            <Pressable 
              className="w-12 h-12 bg-black/50 rounded-full items-center justify-center mr-4"
              onPress={onClose}
            >
              <Ionicons name="close" size={24} color="white" />
            </Pressable>
            <Text className="text-white text-xl font-bold">{title}</Text>
          </View>
          
          <Pressable 
            className="w-12 h-12 bg-black/50 rounded-full items-center justify-center"
            onPress={toggleFlash}
          >
            <Ionicons name={getFlashIcon() as any} size={24} color="white" />
          </Pressable>
        </View>
      </View>

      {/* Status indicator */}
      <View className="absolute top-1/3 left-6 right-6">
        <View className="bg-black/70 rounded-xl p-4">
          <View className="flex-row items-center justify-center">
            <View className={`w-3 h-3 rounded-full mr-3 ${detectionActive ? 'bg-green-500' : 'bg-blue-500'}`} />
            <Text className="text-white font-medium">
              {detectionActive ? 'Document detected - Ready to scan' : 'Looking for document...'}
            </Text>
          </View>
          
          {detectionActive && (
            <Text className="text-green-400 text-sm text-center mt-2">
              Position document within the frame and tap capture
            </Text>
          )}
        </View>
      </View>

      {/* Instructions */}
      <View className="absolute bottom-32 left-6 right-6">
        <View className="bg-black/70 rounded-xl p-4">
          <Text className="text-white text-center font-medium mb-2">
            Scanning Tips
          </Text>
          <View className="space-y-1">
            <Text className="text-gray-300 text-sm">• Place document on flat surface</Text>
            <Text className="text-gray-300 text-sm">• Ensure good lighting</Text>
            <Text className="text-gray-300 text-sm">• Keep camera steady</Text>
          </View>
        </View>
      </View>

      {/* Bottom controls */}
      <View 
        className="absolute bottom-0 left-0 right-0 px-8"
        style={{ paddingBottom: insets.bottom + 32 }}
      >
        <View className="flex-row items-center justify-center">
          {/* Gallery button */}
          <Pressable className="w-16 h-16 bg-black/50 rounded-full items-center justify-center">
            <Ionicons name="images-outline" size={24} color="white" />
          </Pressable>
          
          {/* Capture button */}
          <Pressable 
            className={`w-20 h-20 rounded-full mx-8 items-center justify-center border-4 border-white ${
              detectionActive ? 'bg-green-600' : 'bg-blue-600'
            }`}
            onPress={handleCapture}
            disabled={isCapturing}
          >
            {isCapturing ? (
              <View className="w-6 h-6 border-2 border-white rounded-full border-t-transparent animate-spin" />
            ) : (
              <Ionicons 
                name={detectionActive ? "checkmark" : "camera"} 
                size={32} 
                color="white" 
              />
            )}
          </Pressable>
          
          {/* Settings button */}
          <Pressable className="w-16 h-16 bg-black/50 rounded-full items-center justify-center">
            <Ionicons name="settings-outline" size={24} color="white" />
          </Pressable>
        </View>
      </View>
    </View>
  );
}