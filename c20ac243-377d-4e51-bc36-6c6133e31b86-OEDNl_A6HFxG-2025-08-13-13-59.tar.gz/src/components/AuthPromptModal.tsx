import React, { useState } from 'react';
import { View, Text, Pressable, TextInput, Modal, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { cn } from '../utils/cn';

interface AuthPromptModalProps {
  visible: boolean;
  onClose: () => void;
  onGuestCheckout: (info: {name: string; phone?: string; email?: string}) => void;
  onLogin: (email: string, password: string) => void;
  onSignup: (info: {name: string; email: string; phone?: string; password: string}) => void;
}

export default function AuthPromptModal({ 
  visible, 
  onClose, 
  onGuestCheckout, 
  onLogin, 
  onSignup 
}: AuthPromptModalProps) {
  const [mode, setMode] = useState<'choice' | 'guest' | 'login' | 'signup'>('choice');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
  });

  const resetForm = () => {
    setFormData({ name: '', email: '', phone: '', password: '' });
    setMode('choice');
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  const handleGuestSubmit = () => {
    if (!formData.name.trim()) {
      Alert.alert('Missing Information', 'Please enter your name');
      return;
    }
    onGuestCheckout({
      name: formData.name,
      phone: formData.phone,
      email: formData.email,
    });
    resetForm();
  };

  const handleLoginSubmit = () => {
    if (!formData.email.trim() || !formData.password.trim()) {
      Alert.alert('Missing Information', 'Please enter email and password');
      return;
    }
    onLogin(formData.email, formData.password);
    resetForm();
  };

  const handleSignupSubmit = () => {
    if (!formData.name.trim() || !formData.email.trim() || !formData.password.trim()) {
      Alert.alert('Missing Information', 'Please fill in all required fields');
      return;
    }
    onSignup({
      name: formData.name,
      email: formData.email,
      phone: formData.phone,
      password: formData.password,
    });
    resetForm();
  };

  const renderChoice = () => (
    <View className="p-6">
      <View className="items-center mb-6">
        <View className="w-16 h-16 bg-blue-500 rounded-full items-center justify-center mb-4">
          <Ionicons name="person" size={32} color="white" />
        </View>
        <Text className="text-xl font-bold text-gray-900 mb-2">
          Ready to checkout?
        </Text>
        <Text className="text-gray-600 text-center">
          Choose how you'd like to complete your order
        </Text>
      </View>

      <View className="space-y-3">
        <Pressable 
          onPress={() => setMode('guest')}
          className="bg-gray-100 border border-gray-200 rounded-xl p-4"
        >
          <View className="flex-row items-center">
            <Ionicons name="flash" size={24} color="#6B7280" />
            <View className="ml-3 flex-1">
              <Text className="text-base font-semibold text-gray-900">
                Quick Checkout
              </Text>
              <Text className="text-sm text-gray-600">
                Just enter your name and contact info
              </Text>
            </View>
            <Ionicons name="arrow-forward" size={20} color="#6B7280" />
          </View>
        </Pressable>

        <Pressable 
          onPress={() => setMode('login')}
          className="bg-blue-50 border border-blue-200 rounded-xl p-4"
        >
          <View className="flex-row items-center">
            <Ionicons name="log-in" size={24} color="#3B82F6" />
            <View className="ml-3 flex-1">
              <Text className="text-base font-semibold text-blue-900">
                Log In
              </Text>
              <Text className="text-sm text-blue-700">
                Access your account and loyalty points
              </Text>
            </View>
            <Ionicons name="arrow-forward" size={20} color="#3B82F6" />
          </View>
        </Pressable>

        <Pressable 
          onPress={() => setMode('signup')}
          className="bg-green-50 border border-green-200 rounded-xl p-4"
        >
          <View className="flex-row items-center">
            <Ionicons name="person-add" size={24} color="#10B981" />
            <View className="ml-3 flex-1">
              <Text className="text-base font-semibold text-green-900">
                Create Account
              </Text>
              <Text className="text-sm text-green-700">
                Sign up for loyalty points and faster checkout
              </Text>
            </View>
            <Ionicons name="arrow-forward" size={20} color="#10B981" />
          </View>
        </Pressable>
      </View>
    </View>
  );

  const renderGuestForm = () => (
    <View className="p-6">
      <View className="flex-row items-center mb-6">
        <Pressable onPress={() => setMode('choice')} className="mr-4">
          <Ionicons name="arrow-back" size={24} color="#374151" />
        </Pressable>
        <Text className="text-xl font-bold text-gray-900">
          Quick Checkout
        </Text>
      </View>

      <View className="space-y-4 mb-6">
        <View>
          <Text className="text-sm font-medium text-gray-700 mb-2">
            Full Name <Text className="text-red-500">*</Text>
          </Text>
          <TextInput
            className="border border-gray-300 rounded-xl px-4 py-3 text-base"
            value={formData.name}
            onChangeText={(text) => setFormData({...formData, name: text})}
            placeholder="Enter your full name"
            autoCapitalize="words"
          />
        </View>
        
        <View>
          <Text className="text-sm font-medium text-gray-700 mb-2">
            Phone Number
          </Text>
          <TextInput
            className="border border-gray-300 rounded-xl px-4 py-3 text-base"
            value={formData.phone}
            onChangeText={(text) => setFormData({...formData, phone: text})}
            placeholder="+639123456789 (optional)"
            keyboardType="phone-pad"
          />
        </View>
        
        <View>
          <Text className="text-sm font-medium text-gray-700 mb-2">
            Email Address
          </Text>
          <TextInput
            className="border border-gray-300 rounded-xl px-4 py-3 text-base"
            value={formData.email}
            onChangeText={(text) => setFormData({...formData, email: text})}
            placeholder="email@example.com (optional)"
            keyboardType="email-address"
            autoCapitalize="none"
          />
        </View>
      </View>

      <Pressable 
        onPress={handleGuestSubmit}
        className="bg-blue-500 py-4 rounded-xl mb-4"
      >
        <Text className="text-white text-center font-semibold text-lg">
          Continue as Guest
        </Text>
      </Pressable>
      
      <Text className="text-xs text-gray-500 text-center">
        Your information is only used for order processing
      </Text>
    </View>
  );

  const renderLoginForm = () => (
    <View className="p-6">
      <View className="flex-row items-center mb-6">
        <Pressable onPress={() => setMode('choice')} className="mr-4">
          <Ionicons name="arrow-back" size={24} color="#374151" />
        </Pressable>
        <Text className="text-xl font-bold text-gray-900">
          Log In
        </Text>
      </View>

      <View className="space-y-4 mb-6">
        <View>
          <Text className="text-sm font-medium text-gray-700 mb-2">
            Email Address
          </Text>
          <TextInput
            className="border border-gray-300 rounded-xl px-4 py-3 text-base"
            value={formData.email}
            onChangeText={(text) => setFormData({...formData, email: text})}
            placeholder="Enter your email"
            keyboardType="email-address"
            autoCapitalize="none"
          />
        </View>
        
        <View>
          <Text className="text-sm font-medium text-gray-700 mb-2">
            Password
          </Text>
          <TextInput
            className="border border-gray-300 rounded-xl px-4 py-3 text-base"
            value={formData.password}
            onChangeText={(text) => setFormData({...formData, password: text})}
            placeholder="Enter your password"
            secureTextEntry
          />
        </View>
      </View>

      <Pressable 
        onPress={handleLoginSubmit}
        className="bg-blue-500 py-4 rounded-xl mb-4"
      >
        <Text className="text-white text-center font-semibold text-lg">
          Log In
        </Text>
      </Pressable>

      <Pressable onPress={() => setMode('signup')}>
        <Text className="text-blue-500 text-center">
          Don't have an account? Sign up
        </Text>
      </Pressable>
    </View>
  );

  const renderSignupForm = () => (
    <View className="p-6">
      <View className="flex-row items-center mb-6">
        <Pressable onPress={() => setMode('choice')} className="mr-4">
          <Ionicons name="arrow-back" size={24} color="#374151" />
        </Pressable>
        <Text className="text-xl font-bold text-gray-900">
          Create Account
        </Text>
      </View>

      <View className="space-y-4 mb-6">
        <View>
          <Text className="text-sm font-medium text-gray-700 mb-2">
            Full Name <Text className="text-red-500">*</Text>
          </Text>
          <TextInput
            className="border border-gray-300 rounded-xl px-4 py-3 text-base"
            value={formData.name}
            onChangeText={(text) => setFormData({...formData, name: text})}
            placeholder="Enter your full name"
            autoCapitalize="words"
          />
        </View>

        <View>
          <Text className="text-sm font-medium text-gray-700 mb-2">
            Email Address <Text className="text-red-500">*</Text>
          </Text>
          <TextInput
            className="border border-gray-300 rounded-xl px-4 py-3 text-base"
            value={formData.email}
            onChangeText={(text) => setFormData({...formData, email: text})}
            placeholder="Enter your email"
            keyboardType="email-address"
            autoCapitalize="none"
          />
        </View>
        
        <View>
          <Text className="text-sm font-medium text-gray-700 mb-2">
            Phone Number
          </Text>
          <TextInput
            className="border border-gray-300 rounded-xl px-4 py-3 text-base"
            value={formData.phone}
            onChangeText={(text) => setFormData({...formData, phone: text})}
            placeholder="+639123456789 (optional)"
            keyboardType="phone-pad"
          />
        </View>
        
        <View>
          <Text className="text-sm font-medium text-gray-700 mb-2">
            Password <Text className="text-red-500">*</Text>
          </Text>
          <TextInput
            className="border border-gray-300 rounded-xl px-4 py-3 text-base"
            value={formData.password}
            onChangeText={(text) => setFormData({...formData, password: text})}
            placeholder="Create a password"
            secureTextEntry
          />
        </View>
      </View>

      <Pressable 
        onPress={handleSignupSubmit}
        className="bg-green-500 py-4 rounded-xl mb-4"
      >
        <Text className="text-white text-center font-semibold text-lg">
          Create Account
        </Text>
      </Pressable>

      <Pressable onPress={() => setMode('login')}>
        <Text className="text-blue-500 text-center">
          Already have an account? Log in
        </Text>
      </Pressable>
    </View>
  );

  const renderContent = () => {
    switch (mode) {
      case 'choice':
        return renderChoice();
      case 'guest':
        return renderGuestForm();
      case 'login':
        return renderLoginForm();
      case 'signup':
        return renderSignupForm();
      default:
        return renderChoice();
    }
  };

  return (
    <Modal 
      visible={visible} 
      animationType="slide" 
      presentationStyle="pageSheet"
      onRequestClose={handleClose}
    >
      <View className="flex-1 bg-white">
        <View className="flex-row items-center justify-between p-4 border-b border-gray-200">
          <View />
          <Text className="text-lg font-semibold">Checkout Options</Text>
          <Pressable onPress={handleClose}>
            <Ionicons name="close" size={24} color="#374151" />
          </Pressable>
        </View>
        
        {renderContent()}
      </View>
    </Modal>
  );
}