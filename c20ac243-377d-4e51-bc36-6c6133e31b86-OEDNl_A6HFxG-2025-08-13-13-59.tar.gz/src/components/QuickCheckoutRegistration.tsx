import React, { useState } from 'react';
import {
  View,
  Text,
  Pressable,
  Modal,
  StyleSheet,
  TextInput,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';

interface QuickCheckoutRegistrationProps {
  visible: boolean;
  onClose: () => void;
  onRegistrationComplete: (userData: any) => void;
  onContinueAsGuest: () => void;
  orderAmount: number;
  prefilledPhone?: string;
}

const QuickCheckoutRegistration: React.FC<QuickCheckoutRegistrationProps> = ({
  visible,
  onClose,
  onRegistrationComplete,
  onContinueAsGuest,
  orderAmount,
  prefilledPhone,
}) => {
  const { login } = useAuthStore();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: prefilledPhone || '',
    password: '',
  });
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const validatePhone = (phone: string) => {
    const cleaned = phone.replace(/[^\d+]/g, '');
    return /^(\+63|63|0)?[9]\d{9}$/.test(cleaned) || /^\+63\d{10}$/.test(cleaned);
  };

  const canRegister = () => {
    return formData.name.trim().length >= 2 &&
           validateEmail(formData.email) &&
           validatePhone(formData.phone) &&
           formData.password.length >= 6;
  };

  const handleQuickRegister = async () => {
    if (!canRegister()) return;

    setLoading(true);
    try {
      // Create new user account
      const newUser = {
        id: `user_${Date.now()}`,
        name: formData.name.trim(),
        email: formData.email.toLowerCase(),
        phone: formData.phone,
        role: 'customer',
        customerTier: 'registered',
        createdAt: new Date(),
        isVerified: false,
      };

      // Log them in
      login(newUser);

      // Create notification preferences with free notifications enabled
      const { notificationManager } = await import('../services/notificationManager');
      await notificationManager.createDefaultPreferences(
        newUser.id,
        'registered',
        newUser.email,
        newUser.phone
      );

      Alert.alert(
        'Account Created! 🎉',
        'You now get FREE email and push notifications for all your orders!',
        [{ text: 'Continue', onPress: () => onRegistrationComplete(newUser) }]
      );

    } catch (error) {
      console.error('Registration error:', error);
      Alert.alert('Registration Failed', 'Please try again or continue as guest.');
    } finally {
      setLoading(false);
    }
  };

  const handleContinueAsGuest = () => {
    onContinueAsGuest();
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Pressable onPress={onClose} style={styles.closeButton}>
            <Ionicons name="close" size={24} color="#6B7280" />
          </Pressable>
          <Text style={styles.headerTitle}>Save Money & Stay Updated</Text>
        </View>

        <View style={styles.content}>
          {/* Benefits Comparison */}
          <View style={styles.comparisonSection}>
            <View style={styles.comparisonCard}>
              <View style={styles.guestOption}>
                <Text style={styles.optionTitle}>👤 Continue as Guest</Text>
                <View style={styles.featuresList}>
                  <FeatureItem icon="close" text="No email notifications" negative />
                  <FeatureItem icon="close" text="No push notifications" negative />
                  <FeatureItem icon="cash" text="₱5 for SMS updates" negative />
                  <FeatureItem icon="close" text="No order history" negative />
                </View>
                <View style={styles.costCard}>
                  <Text style={styles.costLabel}>Total Cost:</Text>
                  <Text style={styles.costAmount}>₱{orderAmount + 5}</Text>
                </View>
              </View>

              <View style={styles.divider}>
                <Text style={styles.dividerText}>VS</Text>
              </View>

              <View style={styles.registerOption}>
                <Text style={styles.optionTitle}>🌟 Create Free Account</Text>
                <View style={styles.featuresList}>
                  <FeatureItem icon="checkmark" text="FREE email notifications" />
                  <FeatureItem icon="checkmark" text="FREE push notifications" />
                  <FeatureItem icon="checkmark" text="FREE SMS (optional)" />
                  <FeatureItem icon="checkmark" text="Order history & tracking" />
                </View>
                <View style={[styles.costCard, styles.savingsCostCard]}>
                  <Text style={styles.costLabel}>Total Cost:</Text>
                  <Text style={styles.savingsAmount}>₱{orderAmount}</Text>
                  <Text style={styles.savingsText}>Save ₱5!</Text>
                </View>
              </View>
            </View>
          </View>

          {/* Quick Registration Form */}
          <View style={styles.registrationForm}>
            <Text style={styles.formTitle}>Quick Registration (30 seconds)</Text>
            
            <View style={styles.inputGroup}>
              <TextInput
                style={styles.input}
                value={formData.name}
                onChangeText={(text) => setFormData(prev => ({...prev, name: text}))}
                placeholder="Your full name"
                autoCapitalize="words"
                returnKeyType="next"
              />

              <TextInput
                style={styles.input}
                value={formData.email}
                onChangeText={(text) => setFormData(prev => ({...prev, email: text}))}
                placeholder="Email address"
                keyboardType="email-address"
                autoCapitalize="none"
                returnKeyType="next"
              />

              <TextInput
                style={styles.input}
                value={formData.phone}
                onChangeText={(text) => setFormData(prev => ({...prev, phone: text}))}
                placeholder="Phone number"
                keyboardType="phone-pad"
                returnKeyType="next"
              />

              <View style={styles.passwordContainer}>
                <TextInput
                  style={[styles.input, styles.passwordInput]}
                  value={formData.password}
                  onChangeText={(text) => setFormData(prev => ({...prev, password: text}))}
                  placeholder="Create password (min 6 chars)"
                  secureTextEntry={!showPassword}
                  returnKeyType="done"
                />
                <Pressable 
                  onPress={() => setShowPassword(!showPassword)}
                  style={styles.passwordToggle}
                >
                  <Ionicons 
                    name={showPassword ? 'eye-off' : 'eye'} 
                    size={20} 
                    color="#6B7280" 
                  />
                </Pressable>
              </View>
            </View>

            {/* Quick Benefits */}
            <View style={styles.quickBenefits}>
              <Text style={styles.quickBenefitsTitle}>✨ Instant Benefits:</Text>
              <Text style={styles.quickBenefitsText}>
                • Save ₱5 on this order{'\n'}
                • Get FREE notifications forever{'\n'}
                • Track all your print orders{'\n'}
                • Faster checkout next time
              </Text>
            </View>
          </View>
        </View>

        {/* Actions */}
        <View style={styles.actions}>
          <Pressable 
            onPress={handleContinueAsGuest}
            style={styles.guestButton}
          >
            <Text style={styles.guestButtonText}>Continue as Guest (+₱5)</Text>
          </Pressable>

          <Pressable 
            onPress={handleQuickRegister}
            style={[styles.registerButton, !canRegister() && styles.registerButtonDisabled]}
            disabled={!canRegister() || loading}
          >
            <Text style={styles.registerButtonText}>
              {loading ? 'Creating Account...' : 'Create Account & Save ₱5'}
            </Text>
          </Pressable>
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            By creating an account, you agree to our Terms of Service and Privacy Policy
          </Text>
        </View>
      </View>
    </Modal>
  );
};

const FeatureItem: React.FC<{ icon: string; text: string; negative?: boolean }> = ({ 
  icon, text, negative 
}) => (
  <View style={styles.featureItem}>
    <Ionicons 
      name={icon as any} 
      size={14} 
      color={negative ? '#EF4444' : '#10B981'} 
    />
    <Text style={[styles.featureText, negative && styles.negativeFeatureText]}>
      {text}
    </Text>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  closeButton: {
    padding: 4,
    marginRight: 12,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  comparisonSection: {
    marginBottom: 24,
  },
  comparisonCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 20,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  guestOption: {
    paddingBottom: 16,
  },
  registerOption: {
    paddingTop: 16,
  },
  optionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 12,
  },
  featuresList: {
    marginBottom: 12,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  featureText: {
    fontSize: 13,
    color: '#374151',
    marginLeft: 8,
  },
  negativeFeatureText: {
    color: '#6B7280',
  },
  costCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    padding: 12,
    borderRadius: 8,
  },
  savingsCostCard: {
    backgroundColor: '#ECFDF5',
  },
  costLabel: {
    fontSize: 14,
    color: '#6B7280',
    marginRight: 8,
  },
  costAmount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#111827',
  },
  savingsAmount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#10B981',
    marginRight: 8,
  },
  savingsText: {
    fontSize: 12,
    color: '#10B981',
    fontWeight: '600',
    backgroundColor: 'white',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  divider: {
    alignItems: 'center',
    paddingVertical: 8,
  },
  dividerText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#9CA3AF',
    backgroundColor: '#F9FAFB',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  registrationForm: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 20,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  formTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 16,
    textAlign: 'center',
  },
  inputGroup: {
    marginBottom: 16,
  },
  input: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    fontSize: 16,
    marginBottom: 12,
  },
  passwordContainer: {
    position: 'relative',
  },
  passwordInput: {
    marginBottom: 0,
    paddingRight: 48,
  },
  passwordToggle: {
    position: 'absolute',
    right: 12,
    top: 12,
    padding: 4,
  },
  quickBenefits: {
    backgroundColor: '#F0F9FF',
    padding: 12,
    borderRadius: 8,
    borderLeftWidth: 3,
    borderLeftColor: '#3B82F6',
  },
  quickBenefitsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1E40AF',
    marginBottom: 4,
  },
  quickBenefitsText: {
    fontSize: 12,
    color: '#1E40AF',
    lineHeight: 18,
  },
  actions: {
    padding: 20,
    gap: 12,
  },
  guestButton: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    alignItems: 'center',
  },
  guestButtonText: {
    fontSize: 14,
    color: '#6B7280',
    fontWeight: '500',
  },
  registerButton: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    backgroundColor: '#10B981',
    borderRadius: 8,
    alignItems: 'center',
  },
  registerButtonDisabled: {
    backgroundColor: '#D1D5DB',
  },
  registerButtonText: {
    fontSize: 14,
    color: 'white',
    fontWeight: '600',
  },
  footer: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  footerText: {
    fontSize: 11,
    color: '#9CA3AF',
    textAlign: 'center',
    lineHeight: 16,
  },
});

export default QuickCheckoutRegistration;