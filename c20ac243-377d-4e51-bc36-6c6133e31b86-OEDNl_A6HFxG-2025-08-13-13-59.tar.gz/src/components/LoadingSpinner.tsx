import React from 'react';
import { View, ActivityIndicator, Text } from 'react-native';
import { cn } from '../utils/cn';

interface LoadingSpinnerProps {
  size?: 'small' | 'large';
  color?: string;
  message?: string;
  className?: string;
}

export default function LoadingSpinner({ 
  size = 'large', 
  color = '#3B82F6',
  message,
  className 
}: LoadingSpinnerProps) {
  return (
    <View className={cn("flex-1 items-center justify-center p-8", className)}>
      <ActivityIndicator size={size} color={color} />
      {message && (
        <Text className="text-gray-600 text-center mt-4 text-base">
          {message}
        </Text>
      )}
    </View>
  );
}