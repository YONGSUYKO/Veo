import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Pressable,
  Switch,
  Alert,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { notificationManager, NotificationPreferences, CustomerTier } from '../services/notificationManager';
import { useAuthStore } from '../state/authStore';

interface NotificationSettingsProps {
  userId: string;
  customerTier: CustomerTier;
  onClose?: () => void;
}

const NotificationSettings: React.FC<NotificationSettingsProps> = ({
  userId,
  customerTier,
  onClose,
}) => {
  const { currentUser } = useAuthStore();
  const [preferences, setPreferences] = useState<NotificationPreferences | null>(null);
  const [loading, setLoading] = useState(true);
  const [costs, setCosts] = useState({ sms: 5, email: 0, push: 0 });

  useEffect(() => {
    loadPreferences();
    loadCosts();
  }, [userId]);

  const loadPreferences = async () => {
    try {
      let userPreferences = await notificationManager.getUserPreferences(userId);
      
      if (!userPreferences) {
        // Create default preferences
        userPreferences = await notificationManager.createDefaultPreferences(
          userId,
          customerTier,
          currentUser?.email,
          currentUser?.phone
        );
      }
      
      setPreferences(userPreferences);
    } catch (error) {
      console.error('Error loading preferences:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadCosts = async () => {
    try {
      const notificationCosts = await notificationManager.getNotificationCosts();
      setCosts(notificationCosts);
    } catch (error) {
      console.error('Error loading costs:', error);
    }
  };

  const updatePreference = async (section: string, key: string, value: boolean) => {
    if (!preferences) return;

    const updatedPreferences = {
      ...preferences,
      [section]: {
        ...preferences[section as keyof NotificationPreferences],
        [key]: value,
      },
    };

    // Special handling for SMS charge approval
    if (section === 'sms' && key === 'chargeApproved' && value && customerTier !== 'subscriber') {
      const approved = await showSmsChargeConfirmation();
      if (!approved) return;
    }

    setPreferences(updatedPreferences);
    await notificationManager.savePreferences(updatedPreferences);
  };

  const showSmsChargeConfirmation = (): Promise<boolean> => {
    return new Promise((resolve) => {
      Alert.alert(
        'SMS Notification Charges',
        `By enabling this, you agree to pay ₱${costs.sms} for each SMS notification sent to you. This helps us provide reliable communication about your orders.`,
        [
          {
            text: 'Cancel',
            onPress: () => resolve(false),
            style: 'cancel'
          },
          {
            text: `Accept ₱${costs.sms}/SMS`,
            onPress: () => resolve(true)
          }
        ]
      );
    });
  };

  const getTierBenefits = (tier: CustomerTier) => {
    switch (tier) {
      case 'subscriber':
        return {
          title: '🌟 Subscriber Plan',
          benefits: [
            '✅ FREE Email notifications',
            '✅ FREE SMS notifications', 
            '✅ FREE Push notifications',
            '✅ Promotional offers',
            '✅ Priority support',
          ],
          color: '#10B981',
        };
      case 'registered':
        return {
          title: '📱 Registered User',
          benefits: [
            '✅ FREE Email notifications',
            '✅ FREE Push notifications',
            `💰 SMS: ₱${costs.sms} per message`,
            '⚠️ Limited promotional offers',
          ],
          color: '#3B82F6',
        };
      case 'guest':
        return {
          title: '👤 Guest User',
          benefits: [
            '❌ No Email notifications',
            '❌ No Push notifications',
            `💰 SMS only: ₱${costs.sms} per message`,
            '❌ No promotional offers',
          ],
          color: '#6B7280',
        };
    }
  };

  if (loading || !preferences) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>Loading notification settings...</Text>
      </View>
    );
  }

  const tierInfo = getTierBenefits(customerTier);

  return (
    <ScrollView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        {onClose && (
          <Pressable onPress={onClose} style={styles.closeButton}>
            <Ionicons name="close" size={24} color="#6B7280" />
          </Pressable>
        )}
        <Text style={styles.headerTitle}>Notification Settings</Text>
      </View>

      {/* Customer Tier Info */}
      <View style={[styles.tierCard, { borderLeftColor: tierInfo.color }]}>
        <Text style={styles.tierTitle}>{tierInfo.title}</Text>
        <View style={styles.benefitsList}>
          {tierInfo.benefits.map((benefit, index) => (
            <Text key={index} style={styles.benefitItem}>{benefit}</Text>
          ))}
        </View>
        {customerTier !== 'subscriber' && (
          <Pressable style={styles.upgradeButton}>
            <Text style={styles.upgradeButtonText}>Upgrade to Subscriber</Text>
          </Pressable>
        )}
      </View>

      {/* Email Notifications */}
      {customerTier !== 'guest' && (
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Ionicons name="mail" size={20} color="#3B82F6" />
            <Text style={styles.sectionTitle}>Email Notifications (FREE)</Text>
          </View>
          
          <SettingItem
            title="Order Updates"
            description="Receive email updates about your order status"
            value={preferences.email.orderUpdates}
            onValueChange={(value) => updatePreference('email', 'orderUpdates', value)}
            enabled={preferences.email.enabled}
          />
          
          <SettingItem
            title="Order Receipts"
            description="Email copies of your order confirmations and receipts"
            value={preferences.email.receipts}
            onValueChange={(value) => updatePreference('email', 'receipts', value)}
            enabled={preferences.email.enabled}
          />
          
          {customerTier === 'subscriber' && (
            <SettingItem
              title="Promotional Offers"
              description="Receive special offers and discounts via email"
              value={preferences.email.promotions}
              onValueChange={(value) => updatePreference('email', 'promotions', value)}
              enabled={preferences.email.enabled}
            />
          )}
        </View>
      )}

      {/* Push Notifications */}
      {customerTier !== 'guest' && (
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Ionicons name="notifications" size={20} color="#10B981" />
            <Text style={styles.sectionTitle}>Push Notifications (FREE)</Text>
          </View>
          
          <SettingItem
            title="Order Updates"
            description="Instant notifications about your order progress"
            value={preferences.push.orderUpdates}
            onValueChange={(value) => updatePreference('push', 'orderUpdates', value)}
            enabled={preferences.push.enabled}
          />
          
          <SettingItem
            title="Notification Sound"
            description="Play sound when receiving push notifications"
            value={preferences.push.sound}
            onValueChange={(value) => updatePreference('push', 'sound', value)}
            enabled={preferences.push.enabled && preferences.push.orderUpdates}
          />
          
          {customerTier === 'subscriber' && (
            <SettingItem
              title="Promotional Alerts"
              description="Get notified about special offers and deals"
              value={preferences.push.promotions}
              onValueChange={(value) => updatePreference('push', 'promotions', value)}
              enabled={preferences.push.enabled}
            />
          )}
        </View>
      )}

      {/* SMS Notifications */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Ionicons name="chatbubble" size={20} color="#F59E0B" />
          <Text style={styles.sectionTitle}>
            SMS Notifications {customerTier === 'subscriber' ? '(FREE)' : `(₱${costs.sms}/SMS)`}
          </Text>
        </View>
        
        <SettingItem
          title="Order Updates"
          description="SMS updates about your order status and pickup notifications"
          value={preferences.sms.orderUpdates}
          onValueChange={(value) => updatePreference('sms', 'orderUpdates', value)}
          enabled={preferences.sms.enabled}
        />
        
        {customerTier !== 'subscriber' && (
          <SettingItem
            title={`Auto-approve SMS charges (₱${costs.sms} each)`}
            description="Automatically send SMS without asking for approval each time"
            value={preferences.sms.chargeApproved}
            onValueChange={(value) => updatePreference('sms', 'chargeApproved', value)}
            enabled={preferences.sms.enabled && preferences.sms.orderUpdates}
            isChargeRelated
          />
        )}
        
        {customerTier === 'subscriber' && (
          <SettingItem
            title="Promotional SMS"
            description="Receive special offers and updates via SMS"
            value={preferences.sms.promotions}
            onValueChange={(value) => updatePreference('sms', 'promotions', value)}
            enabled={preferences.sms.enabled}
          />
        )}
      </View>

      {/* Contact Information */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Ionicons name="person" size={20} color="#6B7280" />
          <Text style={styles.sectionTitle}>Contact Information</Text>
        </View>
        
        <View style={styles.contactInfo}>
          <Text style={styles.contactLabel}>Email:</Text>
          <Text style={styles.contactValue}>
            {preferences.emailAddress || 'Not provided'}
          </Text>
        </View>
        
        <View style={styles.contactInfo}>
          <Text style={styles.contactLabel}>Phone:</Text>
          <Text style={styles.contactValue}>
            {preferences.phone || 'Not provided'}
          </Text>
        </View>
        
        <Text style={styles.contactNote}>
          Update your contact information in your profile to receive notifications.
        </Text>
      </View>

      {/* Important Notes */}
      <View style={styles.notesSection}>
        <Text style={styles.notesTitle}>📋 Important Notes:</Text>
        <Text style={styles.notesText}>
          • SMS charges apply only to non-subscribers{'\n'}
          • You can upgrade to subscriber plan for unlimited notifications{'\n'}
          • All notification types are optional{'\n'}
          • Changes take effect immediately
        </Text>
      </View>
    </ScrollView>
  );
};

const SettingItem: React.FC<{
  title: string;
  description: string;
  value: boolean;
  onValueChange: (value: boolean) => void;
  enabled: boolean;
  isChargeRelated?: boolean;
}> = ({ title, description, value, onValueChange, enabled, isChargeRelated }) => (
  <View style={[styles.settingItem, !enabled && styles.settingItemDisabled]}>
    <View style={styles.settingContent}>
      <Text style={[styles.settingTitle, !enabled && styles.settingTitleDisabled]}>
        {title}
      </Text>
      <Text style={[styles.settingDescription, !enabled && styles.settingDescriptionDisabled]}>
        {description}
      </Text>
      {isChargeRelated && (
        <Text style={styles.chargeWarning}>
          ⚠️ This will authorize automatic SMS charges
        </Text>
      )}
    </View>
    <Switch
      value={value}
      onValueChange={onValueChange}
      disabled={!enabled}
      trackColor={{ false: '#E5E7EB', true: '#3B82F6' }}
      thumbColor={value ? '#FFFFFF' : '#FFFFFF'}
    />
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  loadingText: {
    fontSize: 16,
    color: '#6B7280',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  closeButton: {
    padding: 4,
    marginRight: 12,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
  },
  tierCard: {
    backgroundColor: 'white',
    margin: 16,
    padding: 20,
    borderRadius: 12,
    borderLeftWidth: 4,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  tierTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 12,
  },
  benefitsList: {
    marginBottom: 16,
  },
  benefitItem: {
    fontSize: 14,
    color: '#374151',
    marginBottom: 4,
    lineHeight: 20,
  },
  upgradeButton: {
    backgroundColor: '#10B981',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  upgradeButtonText: {
    color: 'white',
    fontWeight: '600',
    fontSize: 14,
  },
  section: {
    backgroundColor: 'white',
    marginHorizontal: 16,
    marginBottom: 16,
    borderRadius: 12,
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginLeft: 8,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  settingItemDisabled: {
    opacity: 0.5,
  },
  settingContent: {
    flex: 1,
    marginRight: 12,
  },
  settingTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 2,
  },
  settingTitleDisabled: {
    color: '#9CA3AF',
  },
  settingDescription: {
    fontSize: 12,
    color: '#6B7280',
    lineHeight: 16,
  },
  settingDescriptionDisabled: {
    color: '#D1D5DB',
  },
  chargeWarning: {
    fontSize: 11,
    color: '#F59E0B',
    marginTop: 2,
    fontWeight: '500',
  },
  contactInfo: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  contactLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    width: 60,
  },
  contactValue: {
    fontSize: 14,
    color: '#6B7280',
    flex: 1,
  },
  contactNote: {
    fontSize: 12,
    color: '#9CA3AF',
    paddingHorizontal: 16,
    paddingBottom: 12,
    lineHeight: 16,
  },
  notesSection: {
    backgroundColor: '#FEF3C7',
    margin: 16,
    padding: 16,
    borderRadius: 8,
    marginBottom: 40,
  },
  notesTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#92400E',
    marginBottom: 8,
  },
  notesText: {
    fontSize: 12,
    color: '#92400E',
    lineHeight: 18,
  },
});

export default NotificationSettings;