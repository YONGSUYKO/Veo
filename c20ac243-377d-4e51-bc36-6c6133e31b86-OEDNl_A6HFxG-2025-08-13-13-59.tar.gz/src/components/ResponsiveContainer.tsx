import React from 'react';
import { View, ScrollView, Dimensions, Text, Pressable } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { PlatformUtils } from '../utils/platform';
import { cn } from '../utils/cn';

interface ResponsiveContainerProps {
  children: React.ReactNode;
  className?: string;
  scrollable?: boolean;
  centerContent?: boolean;
  maxWidth?: number;
  padding?: 'none' | 'small' | 'medium' | 'large';
}

export default function ResponsiveContainer({ 
  children, 
  className,
  scrollable = true,
  centerContent = false,
  maxWidth,
  padding = 'medium'
}: ResponsiveContainerProps) {
  const insets = useSafeAreaInsets();
  const styles = PlatformUtils.getResponsiveStyles();
  const deviceType = PlatformUtils.getDeviceType();
  const { width } = Dimensions.get('window');
  
  // Calculate padding based on device type and prop
  const getPadding = () => {
    const basePadding = {
      none: 0,
      small: styles.spacing.small,
      medium: styles.spacing.medium,
      large: styles.spacing.large,
    }[padding];
    
    // Increase padding for larger screens
    switch (deviceType) {
      case 'kiosk':
        return Math.max(basePadding, 48);
      case 'desktop':
        return Math.max(basePadding, 32);
      case 'tablet':
        return Math.max(basePadding, 24);
      default:
        return basePadding;
    }
  };
  
  const paddingValue = getPadding();
  const containerMaxWidth = maxWidth || (deviceType === 'mobile' ? width : Math.min(1200, width * 0.9));
  
  const containerStyle = {
    flex: 1,
    paddingTop: insets.top + (deviceType === 'kiosk' ? 40 : 20),
    paddingBottom: Math.max(insets.bottom, 20),
    paddingHorizontal: paddingValue,
  };
  
  const contentStyle = {
    width: '100%' as const,
    maxWidth: containerMaxWidth,
    ...(centerContent && {
      alignSelf: 'center' as const,
    }),
  };
  
  if (scrollable) {
    return (
      <ScrollView 
        className={cn("flex-1", className)}
        contentContainerStyle={centerContent ? { flex: 1, justifyContent: 'center' } : undefined}
        showsVerticalScrollIndicator={false}
      >
        <View style={containerStyle}>
          <View style={contentStyle}>
            {children}
          </View>
        </View>
      </ScrollView>
    );
  }
  
  return (
    <View className={cn("flex-1", className)}>
      <View style={containerStyle}>
        <View style={contentStyle}>
          {children}
        </View>
      </View>
    </View>
  );
}

// Grid component for responsive layouts
interface ResponsiveGridProps {
  children: React.ReactNode;
  minColWidth?: number;
  gap?: number;
  className?: string;
}

export function ResponsiveGrid({ 
  children, 
  minColWidth = 280, 
  gap = 16,
  className 
}: ResponsiveGridProps) {
  const columns = PlatformUtils.getGridColumns(minColWidth);
  const deviceType = PlatformUtils.getDeviceType();
  
  // Adjust gap for device type
  const responsiveGap = {
    mobile: gap,
    tablet: gap * 1.2,
    desktop: gap * 1.5,
    kiosk: gap * 2,
  }[deviceType];
  
  return (
    <View 
      className={cn("flex-row flex-wrap", className)}
      style={{ 
        marginHorizontal: -responsiveGap / 2,
      }}
    >
      {React.Children.map(children, (child, index) => (
        <View 
          key={index}
          style={{ 
            width: `${100 / columns}%`,
            paddingHorizontal: responsiveGap / 2,
            marginBottom: responsiveGap,
          }}
        >
          {child}
        </View>
      ))}
    </View>
  );
}

// Responsive text component
interface ResponsiveTextProps {
  children: React.ReactNode;
  size?: 'small' | 'medium' | 'large' | 'xl' | 'xxl';
  className?: string;
  weight?: 'normal' | 'medium' | 'semibold' | 'bold';
}

export function ResponsiveText({ 
  children, 
  size = 'medium', 
  className,
  weight = 'normal' 
}: ResponsiveTextProps) {
  const styles = PlatformUtils.getResponsiveStyles();
  const optimizations = PlatformUtils.getOptimizations();
  
  const fontSize = styles.text[size] * optimizations.fontScale;
  
  const weightClass = {
    normal: '',
    medium: 'font-medium',
    semibold: 'font-semibold', 
    bold: 'font-bold',
  }[weight];
  
  return (
    <Text style={{ fontSize }} className={cn(weightClass, className)}>
      {children}
    </Text>
  );
}

// Platform-specific button with optimal touch targets
interface ResponsiveButtonProps {
  children: React.ReactNode;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'small' | 'medium' | 'large';
  className?: string;
  disabled?: boolean;
}

export function ResponsiveButton({
  children,
  onPress,
  variant = 'primary',
  size = 'medium',
  className,
  disabled = false
}: ResponsiveButtonProps) {
  const optimizations = PlatformUtils.getOptimizations();
  const deviceType = PlatformUtils.getDeviceType();
  
  const buttonHeight = {
    small: optimizations.touchTarget * 0.8,
    medium: optimizations.touchTarget,
    large: optimizations.touchTarget * 1.2,
  }[size];
  
  const variantClass = {
    primary: 'bg-blue-500',
    secondary: 'bg-gray-500',
    outline: 'bg-transparent border-2 border-blue-500',
  }[variant];
  
  const textColor = {
    primary: 'text-white',
    secondary: 'text-white', 
    outline: 'text-blue-500',
  }[variant];
  
  // Increase font size for kiosk
  const fontSize = deviceType === 'kiosk' ? 18 : 16;
  
  return (
    <Pressable
      style={{ height: buttonHeight }}
      className={cn(
        "rounded-xl items-center justify-center px-6",
        variantClass,
        disabled ? "opacity-50" : "",
        className
      )}
      onPress={disabled ? undefined : onPress}
      disabled={disabled}
    >
      <Text style={{ fontSize }} className={cn("font-semibold", textColor)}>
        {children}
      </Text>
    </Pressable>
  );
}