import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  FlatList,
  Alert,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { OrderMessage } from '../types/staffSupportOrder';
import { useAuthStore } from '../state/authStore';

interface ChatComponentProps {
  orderId: string;
}

const ChatComponent: React.FC<ChatComponentProps> = ({ orderId }) => {
  const { currentUser } = useAuthStore();
  const [messages, setMessages] = useState<OrderMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!orderId) return;
    
    // Set up real-time subscription to messages
    const { staffSupportService } = require('../services/staffSupportService');
    const unsubscribe = staffSupportService.subscribeToMessages(orderId, (messagesList: OrderMessage[]) => {
      setMessages(messagesList.reverse()); // Reverse for proper order in FlatList
    });

    return unsubscribe;
  }, [orderId]);

  const sendMessage = async () => {
    if (!newMessage.trim()) return;

    setLoading(true);
    try {
      const { staffSupportService } = await import('../services/staffSupportService');
      
      await staffSupportService.sendMessage({
        orderId,
        senderId: currentUser?.id || 'customer',
        senderType: 'customer',
        message: newMessage.trim(),
        isRead: false,
      });
      
      setNewMessage('');
    } catch (error) {
      console.error('Error sending message:', error);
      Alert.alert('Error', 'Failed to send message.');
    } finally {
      setLoading(false);
    }
  };

  const renderMessage = ({ item }: { item: OrderMessage }) => (
    <View style={[
      styles.messageContainer,
      item.senderType === 'customer' ? styles.customerMessage : styles.operatorMessage
    ]}>
      <Text style={styles.senderLabel}>
        {item.senderType === 'customer' ? 'You' : 'Print Shop Staff'}
      </Text>
      <Text style={[
        styles.messageText,
        item.senderType === 'customer' ? styles.customerMessageText : styles.operatorMessageText
      ]}>
        {item.message}
      </Text>
      <Text style={styles.timestamp}>
        {item.timestamp.toLocaleString()}
      </Text>
    </View>
  );

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      {/* Messages Header */}
      <View style={styles.header}>
        <Ionicons name="chatbubbles" size={20} color="#3B82F6" />
        <Text style={styles.headerText}>Chat with Print Shop</Text>
      </View>

      {/* Messages List */}
      <FlatList
        data={messages}
        renderItem={renderMessage}
        keyExtractor={item => item.id}
        inverted
        style={styles.messagesList}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Ionicons name="chatbubble-outline" size={48} color="#D1D5DB" />
            <Text style={styles.emptyText}>No messages yet</Text>
            <Text style={styles.emptySubText}>
              Ask questions about your order or share additional requirements
            </Text>
          </View>
        }
      />
      
      {/* Message Input */}
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.textInput}
          value={newMessage}
          onChangeText={setNewMessage}
          placeholder="Type your message..."
          multiline
          maxLength={500}
        />
        <Pressable 
          style={[
            styles.sendButton, 
            (!newMessage.trim() || loading) && styles.sendButtonDisabled
          ]}
          onPress={sendMessage}
          disabled={loading || !newMessage.trim()}
        >
          <Ionicons 
            name="send" 
            size={18} 
            color={(!newMessage.trim() || loading) ? '#9CA3AF' : 'white'} 
          />
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
    marginLeft: 8,
  },
  messagesList: {
    flex: 1,
    padding: 16,
  },
  messageContainer: {
    marginVertical: 4,
    padding: 12,
    borderRadius: 16,
    maxWidth: '80%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  customerMessage: {
    alignSelf: 'flex-end',
    backgroundColor: '#3B82F6',
    borderBottomRightRadius: 4,
  },
  operatorMessage: {
    alignSelf: 'flex-start',
    backgroundColor: 'white',
    borderBottomLeftRadius: 4,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  senderLabel: {
    fontSize: 10,
    fontWeight: 'bold',
    marginBottom: 4,
    opacity: 0.8,
  },
  messageText: {
    fontSize: 14,
    lineHeight: 20,
  },
  customerMessageText: {
    color: 'white',
  },
  operatorMessageText: {
    color: '#1F2937',
  },
  timestamp: {
    fontSize: 10,
    marginTop: 4,
    opacity: 0.6,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 40,
    transform: [{ scaleY: -1 }], // Flip back since FlatList is inverted
  },
  emptyText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#6B7280',
    marginTop: 12,
  },
  emptySubText: {
    fontSize: 14,
    color: '#9CA3AF',
    textAlign: 'center',
    marginTop: 4,
    paddingHorizontal: 32,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    padding: 16,
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
  },
  textInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginRight: 12,
    maxHeight: 100,
    fontSize: 16,
    backgroundColor: 'white',
  },
  sendButton: {
    backgroundColor: '#3B82F6',
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButtonDisabled: {
    backgroundColor: '#E5E7EB',
  }
});

export default ChatComponent;