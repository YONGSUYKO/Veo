import React, { useState } from 'react';
import { View, Text, Pressable, TextInput, Modal, Alert, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { emailService } from '../services/emailService';
import { useAuthStore } from '../state/authStore';

interface ContactSupportModalProps {
  visible: boolean;
  onClose: () => void;
  orderId?: string;
  prefilledSubject?: string;
  prefilledMessage?: string;
}

export default function ContactSupportModal({ 
  visible, 
  onClose, 
  orderId,
  prefilledSubject = '',
  prefilledMessage = ''
}: ContactSupportModalProps) {
  const { currentUser } = useAuthStore();
  const [formData, setFormData] = useState({
    name: currentUser?.name || '',
    email: currentUser?.email || '',
    phone: currentUser?.phone || '',
    subject: prefilledSubject,
    message: prefilledMessage,
  });
  const [sending, setSending] = useState(false);

  const handleClose = () => {
    if (!sending) {
      setFormData({
        name: currentUser?.name || '',
        email: currentUser?.email || '',
        phone: currentUser?.phone || '',
        subject: '',
        message: '',
      });
      onClose();
    }
  };

  const handleSend = async () => {
    // Validation
    if (!formData.name.trim()) {
      Alert.alert('Missing Information', 'Please enter your name');
      return;
    }
    
    if (!formData.email.trim()) {
      Alert.alert('Missing Information', 'Please enter your email address');
      return;
    }
    
    if (!formData.email.includes('@')) {
      Alert.alert('Invalid Email', 'Please enter a valid email address');
      return;
    }
    
    if (!formData.subject.trim()) {
      Alert.alert('Missing Information', 'Please enter a subject');
      return;
    }
    
    if (!formData.message.trim()) {
      Alert.alert('Missing Information', 'Please enter your message');
      return;
    }

    setSending(true);
    
    try {
      const success = await emailService.sendCustomerMessage({
        customerEmail: formData.email,
        customerName: formData.name,
        subject: formData.subject,
        message: formData.message,
        orderId: orderId,
        phone: formData.phone || undefined,
      });

      if (success) {
        Alert.alert(
          'Message Sent!', 
          'Your message has been sent to our support team. We\'ll get back to you soon!',
          [{ text: 'OK', onPress: handleClose }]
        );
      } else {
        Alert.alert(
          'Send Failed',
          'Could not send your message. Please try again or contact us directly.',
          [{ text: 'OK' }]
        );
      }
    } catch (error) {
      Alert.alert('Error', 'Something went wrong. Please try again.');
    } finally {
      setSending(false);
    }
  };

  const quickSubjects = [
    '❓ General Question',
    '📋 Order Issue',
    '💰 Billing Question',
    '🚚 Delivery Problem',
    '🖨️ Print Quality Issue',
    '⭐ Feedback',
    '💡 Feature Request',
  ];

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <KeyboardAvoidingView 
        style={{ flex: 1 }} 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <View className="flex-1 bg-white">
          {/* Header */}
          <View className="flex-row items-center justify-between p-4 border-b border-gray-200">
            <View />
            <Text className="text-lg font-semibold">Contact Support</Text>
            <Pressable onPress={handleClose} disabled={sending}>
              <Ionicons name="close" size={24} color="#374151" />
            </Pressable>
          </View>

          <ScrollView className="flex-1 p-6">
            {/* Info Banner */}
            <View className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
              <View className="flex-row items-center">
                <Ionicons name="mail" size={20} color="#3B82F6" />
                <Text className="text-blue-900 font-semibold ml-2">
                  Direct Message to Owner
                </Text>
              </View>
              <Text className="text-blue-700 text-sm mt-1">
                Your message will be sent directly to the business owner who can reply to your email.
              </Text>
            </View>

            {/* Contact Form */}
            <View className="space-y-4">
              {/* Name */}
              <View>
                <Text className="text-sm font-medium text-gray-700 mb-2">
                  Your Name <Text className="text-red-500">*</Text>
                </Text>
                <TextInput
                  className="border border-gray-300 rounded-xl px-4 py-3 text-base"
                  value={formData.name}
                  onChangeText={(text) => setFormData({...formData, name: text})}
                  placeholder="Enter your full name"
                  autoCapitalize="words"
                  editable={!sending}
                />
              </View>

              {/* Email */}
              <View>
                <Text className="text-sm font-medium text-gray-700 mb-2">
                  Email Address <Text className="text-red-500">*</Text>
                </Text>
                <TextInput
                  className="border border-gray-300 rounded-xl px-4 py-3 text-base"
                  value={formData.email}
                  onChangeText={(text) => setFormData({...formData, email: text})}
                  placeholder="your.email@example.com"
                  keyboardType="email-address"
                  autoCapitalize="none"
                  editable={!sending}
                />
              </View>

              {/* Phone (Optional) */}
              <View>
                <Text className="text-sm font-medium text-gray-700 mb-2">
                  Phone Number (Optional)
                </Text>
                <TextInput
                  className="border border-gray-300 rounded-xl px-4 py-3 text-base"
                  value={formData.phone}
                  onChangeText={(text) => setFormData({...formData, phone: text})}
                  placeholder="+639123456789"
                  keyboardType="phone-pad"
                  editable={!sending}
                />
              </View>

              {/* Order ID (if provided) */}
              {orderId && (
                <View className="bg-gray-50 rounded-xl p-4">
                  <Text className="text-sm font-medium text-gray-700">
                    Related Order: <Text className="text-blue-600">#{orderId}</Text>
                  </Text>
                </View>
              )}

              {/* Quick Subject Selection */}
              <View>
                <Text className="text-sm font-medium text-gray-700 mb-2">
                  Quick Subject Selection
                </Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} className="mb-3">
                  <View className="flex-row space-x-2">
                    {quickSubjects.map((subject) => (
                      <Pressable
                        key={subject}
                        onPress={() => setFormData({...formData, subject})}
                        className="bg-gray-100 px-3 py-2 rounded-full"
                        disabled={sending}
                      >
                        <Text className="text-sm text-gray-700">{subject}</Text>
                      </Pressable>
                    ))}
                  </View>
                </ScrollView>
              </View>

              {/* Subject */}
              <View>
                <Text className="text-sm font-medium text-gray-700 mb-2">
                  Subject <Text className="text-red-500">*</Text>
                </Text>
                <TextInput
                  className="border border-gray-300 rounded-xl px-4 py-3 text-base"
                  value={formData.subject}
                  onChangeText={(text) => setFormData({...formData, subject: text})}
                  placeholder="Brief description of your message"
                  editable={!sending}
                />
              </View>

              {/* Message */}
              <View>
                <Text className="text-sm font-medium text-gray-700 mb-2">
                  Message <Text className="text-red-500">*</Text>
                </Text>
                <TextInput
                  className="border border-gray-300 rounded-xl px-4 py-3 text-base"
                  value={formData.message}
                  onChangeText={(text) => setFormData({...formData, message: text})}
                  placeholder="Please describe your question or concern in detail..."
                  multiline
                  numberOfLines={5}
                  textAlignVertical="top"
                  editable={!sending}
                />
              </View>
            </View>

            {/* Response Time Info */}
            <View className="bg-green-50 border border-green-200 rounded-xl p-4 mt-6">
              <View className="flex-row items-center">
                <Ionicons name="time" size={16} color="#10B981" />
                <Text className="text-green-800 font-medium ml-2">
                  Response Time
                </Text>
              </View>
              <Text className="text-green-700 text-sm mt-1">
                We typically respond within 2-4 hours during business hours (9 AM - 6 PM).
              </Text>
            </View>
          </ScrollView>

          {/* Send Button */}
          <View className="p-6 border-t border-gray-200">
            <Pressable
              className={`py-4 rounded-xl ${sending ? 'bg-gray-400' : 'bg-blue-500'}`}
              onPress={handleSend}
              disabled={sending}
            >
              <View className="flex-row items-center justify-center">
                {sending && (
                  <Ionicons name="hourglass" size={20} color="white" className="mr-2" />
                )}
                <Text className="text-white font-semibold text-lg">
                  {sending ? 'Sending Message...' : 'Send Message'}
                </Text>
              </View>
            </Pressable>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}