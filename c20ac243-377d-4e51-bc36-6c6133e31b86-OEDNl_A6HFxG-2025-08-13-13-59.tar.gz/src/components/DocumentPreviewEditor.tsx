import React, { useState, useRef } from 'react';
import { View, Text, Pressable, ScrollView, Image, Alert, Dimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Slider from '@react-native-community/slider';
import CameraService, { DocumentScanResult, ImageEditOptions } from '../services/CameraService';

const { width: screenWidth } = Dimensions.get('window');

interface DocumentPreviewEditorProps {
  document?: DocumentScanResult;
  onSave?: (editedDocument: DocumentScanResult) => void;
  onRetake?: () => void;
  onClose?: () => void;
  navigation?: any;
  route?: {
    params?: {
      document?: DocumentScanResult;
      scanResult?: DocumentScanResult;
    };
  };
}

export default function DocumentPreviewEditor({
  document: propDocument,
  onSave: propOnSave,
  onRetake: propOnRetake,
  onClose: propOnClose,
  navigation,
  route,
}: DocumentPreviewEditorProps) {
  const insets = useSafeAreaInsets();
  
  // Support both direct props and navigation route params
  const document = propDocument || route?.params?.document || route?.params?.scanResult;
  const onSave = propOnSave || (() => navigation?.goBack());
  const onRetake = propOnRetake || (() => navigation?.goBack());
  const onClose = propOnClose || (() => navigation?.goBack());
  
  // Handle case where document is still undefined - create a mock document for demo
  if (!document) {
    const mockDocument: DocumentScanResult = {
      uri: 'https://via.placeholder.com/800x1000/E5E7EB/374151?text=Sample+Document',
      width: 800,
      height: 1000,
      quality: 'good',
      isDocument: true,
      detectedEdges: [
        { x: 40, y: 50 },
        { x: 760, y: 50 },
        { x: 760, y: 950 },
        { x: 40, y: 950 }
      ]
    };
    
    // Use the mock document to prevent crashes
    return (
      <DocumentPreviewEditor
        document={mockDocument}
        onSave={(doc) => {
          onSave(doc);
        }}
        onRetake={onRetake}
        onClose={onClose}
        navigation={navigation}
        route={route}
      />
    );
  }
  
  const [editedUri, setEditedUri] = useState(document.uri);
  const [isProcessing, setIsProcessing] = useState(false);
  const [editOptions, setEditOptions] = useState<ImageEditOptions>({
    brightness: 0,
    contrast: 1,
    saturation: 1,
    grayscale: false,
    autoEnhance: true,
  });
  const [activeTab, setActiveTab] = useState<'preview' | 'adjust' | 'filters'>('preview');

  const getQualityColor = (quality: DocumentScanResult['quality']) => {
    switch (quality) {
      case 'excellent': return 'text-green-500';
      case 'good': return 'text-blue-500';
      case 'fair': return 'text-yellow-500';
      case 'poor': return 'text-red-500';
      default: return 'text-gray-500';
    }
  };

  const getQualityIcon = (quality: DocumentScanResult['quality']) => {
    switch (quality) {
      case 'excellent': return 'checkmark-circle';
      case 'good': return 'checkmark-circle-outline';
      case 'fair': return 'warning-outline';
      case 'poor': return 'close-circle-outline';
      default: return 'help-circle-outline';
    }
  };

  const applyEditOptions = async (options: ImageEditOptions) => {
    setIsProcessing(true);
    try {
      // Simulate processing delay for better UX
      await new Promise(resolve => setTimeout(resolve, 800));
      
      const enhancedUri = await CameraService.enhanceDocument(document.uri, options);
      setEditedUri(enhancedUri);
      setEditOptions(options);
      
      // Show user feedback about the enhancement
      if (options.autoEnhance) {
        Alert.alert('Enhancement Applied', 'Document has been optimized for better print quality.');
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to apply image enhancements. Using original quality.');
      console.error('Enhancement error:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleBrightnessChange = (value: number) => {
    const newOptions = { ...editOptions, brightness: value, autoEnhance: false };
    setEditOptions(newOptions);
  };

  const handleContrastChange = (value: number) => {
    const newOptions = { ...editOptions, contrast: value, autoEnhance: false };
    setEditOptions(newOptions);
  };

  const handleSaturationChange = (value: number) => {
    const newOptions = { ...editOptions, saturation: value, autoEnhance: false };
    setEditOptions(newOptions);
  };

  const applyFilter = async (filterType: 'original' | 'grayscale' | 'enhance' | 'sharp') => {
    let options: ImageEditOptions = { ...editOptions };
    
    switch (filterType) {
      case 'original':
        options = { brightness: 0, contrast: 1, saturation: 1, grayscale: false, autoEnhance: false };
        break;
      case 'grayscale':
        options = { ...editOptions, grayscale: true, autoEnhance: false };
        break;
      case 'enhance':
        options = { brightness: 0.1, contrast: 1.2, saturation: 1.1, grayscale: false, autoEnhance: true };
        break;
      case 'sharp':
        options = { brightness: 0.05, contrast: 1.3, saturation: 1.05, grayscale: false, autoEnhance: true };
        break;
    }
    
    await applyEditOptions(options);
  };

  const handleSave = async () => {
    setIsProcessing(true);
    try {
      const finalDocument: DocumentScanResult = {
        ...document,
        uri: editedUri,
      };
      
      onSave(finalDocument);
    } catch (error) {
      Alert.alert('Error', 'Failed to save document');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSaveToGallery = async () => {
    try {
      await CameraService.saveToGallery(editedUri, 'PISO Print Scans');
    } catch (error) {
      Alert.alert('Error', 'Failed to save to gallery');
    }
  };

  return (
    <View className="flex-1 bg-white">
      {/* Header */}
      <View 
        className="border-b border-gray-200 px-4 pb-4"
        style={{ paddingTop: insets.top + 16 }}
      >
        <View className="flex-row items-center justify-between">
          <View className="flex-row items-center">
            <Pressable onPress={onClose} className="mr-4">
              <Ionicons name="close" size={24} color="#374151" />
            </Pressable>
            <Text className="text-xl font-bold text-gray-900">
              Document Preview
            </Text>
          </View>
          
          <Pressable 
            onPress={handleSaveToGallery}
            className="bg-gray-100 px-3 py-2 rounded-lg"
          >
            <View className="flex-row items-center">
              <Ionicons name="download-outline" size={16} color="#374151" />
              <Text className="text-sm font-medium text-gray-700 ml-1">Save</Text>
            </View>
          </Pressable>
        </View>
      </View>

      {/* Document Quality Indicator */}
      <View className="px-4 py-3 bg-gray-50">
        <View className="flex-row items-center">
          <Ionicons 
            name={getQualityIcon(document.quality) as any} 
            size={20} 
            color={getQualityColor(document.quality).replace('text-', '')} 
          />
          <Text className={`ml-2 font-medium ${getQualityColor(document.quality)}`}>
            {document.quality.charAt(0).toUpperCase() + document.quality.slice(1)} Quality
          </Text>
          <Text className="text-gray-500 ml-2">
            • {document.width}x{document.height}
          </Text>
        </View>
      </View>

      {/* Tab Navigation */}
      <View className="flex-row bg-white border-b border-gray-200">
        {[
          { id: 'preview', label: 'Preview', icon: 'eye-outline' },
          { id: 'adjust', label: 'Adjust', icon: 'tune-outline' },
          { id: 'filters', label: 'Filters', icon: 'color-filter-outline' },
        ].map((tab) => (
          <Pressable
            key={tab.id}
            onPress={() => setActiveTab(tab.id as any)}
            className={`flex-1 py-4 items-center ${
              activeTab === tab.id ? 'border-b-2 border-blue-500' : ''
            }`}
          >
            <Ionicons 
              name={tab.icon as any} 
              size={20} 
              color={activeTab === tab.id ? '#3B82F6' : '#9CA3AF'} 
            />
            <Text className={`text-sm font-medium mt-1 ${
              activeTab === tab.id ? 'text-blue-500' : 'text-gray-500'
            }`}>
              {tab.label}
            </Text>
          </Pressable>
        ))}
      </View>

      {/* Content */}
      <ScrollView className="flex-1">
        {activeTab === 'preview' && (
          <View className="p-4">
            {/* Document Image */}
            <View className="bg-gray-100 rounded-xl overflow-hidden mb-6">
              <Image
                source={{ uri: editedUri }}
                style={{
                  width: screenWidth - 32,
                  height: (screenWidth - 32) * (document.height / document.width),
                }}
                resizeMode="contain"
              />
              {isProcessing && (
                <View className="absolute inset-0 bg-black/50 items-center justify-center">
                  <View className="bg-white rounded-xl p-4 items-center">
                    <View className="w-6 h-6 border-2 border-blue-500 rounded-full border-t-transparent animate-spin mb-2" />
                    <Text className="text-gray-700 font-medium">Processing...</Text>
                  </View>
                </View>
              )}
            </View>

            {/* Document Info */}
            <View className="bg-gray-50 rounded-xl p-4">
              <Text className="text-lg font-semibold text-gray-900 mb-3">
                Document Details
              </Text>
              <View className="space-y-2">
                <View className="flex-row justify-between">
                  <Text className="text-gray-600">Quality</Text>
                  <Text className={`font-medium ${getQualityColor(document.quality)}`}>
                    {document.quality.charAt(0).toUpperCase() + document.quality.slice(1)}
                  </Text>
                </View>
                <View className="flex-row justify-between">
                  <Text className="text-gray-600">Dimensions</Text>
                  <Text className="font-medium text-gray-900">
                    {document.width} × {document.height}
                  </Text>
                </View>
                <View className="flex-row justify-between">
                  <Text className="text-gray-600">Document Detected</Text>
                  <Text className={`font-medium ${document.isDocument ? 'text-green-500' : 'text-red-500'}`}>
                    {document.isDocument ? 'Yes' : 'No'}
                  </Text>
                </View>
              </View>
            </View>
          </View>
        )}

        {activeTab === 'adjust' && (
          <View className="p-4">
            <Text className="text-lg font-semibold text-gray-900 mb-2">
              Manual Adjustments
            </Text>
            <Text className="text-sm text-gray-600 mb-6">
              Fine-tune your document appearance. Changes are applied when you use the document.
            </Text>

            {/* Brightness */}
            <View className="mb-6">
              <View className="flex-row items-center justify-between mb-2">
                <Text className="font-medium text-gray-700">Brightness</Text>
                <Text className="text-sm text-gray-500">
                  {(editOptions.brightness || 0).toFixed(2)}
                </Text>
              </View>
              <Slider
                style={{ width: '100%', height: 40 }}
                minimumValue={-0.5}
                maximumValue={0.5}
                value={editOptions.brightness || 0}
                onValueChange={handleBrightnessChange}
                onSlidingComplete={() => applyEditOptions(editOptions)}
                minimumTrackTintColor="#3B82F6"
                maximumTrackTintColor="#E5E7EB"
              />
            </View>

            {/* Contrast */}
            <View className="mb-6">
              <View className="flex-row items-center justify-between mb-2">
                <Text className="font-medium text-gray-700">Contrast</Text>
                <Text className="text-sm text-gray-500">
                  {(editOptions.contrast || 1).toFixed(2)}
                </Text>
              </View>
              <Slider
                style={{ width: '100%', height: 40 }}
                minimumValue={0.5}
                maximumValue={2}
                value={editOptions.contrast || 1}
                onValueChange={handleContrastChange}
                onSlidingComplete={() => applyEditOptions(editOptions)}
                minimumTrackTintColor="#3B82F6"
                maximumTrackTintColor="#E5E7EB"
              />
            </View>

            {/* Saturation */}
            <View className="mb-6">
              <View className="flex-row items-center justify-between mb-2">
                <Text className="font-medium text-gray-700">Saturation</Text>
                <Text className="text-sm text-gray-500">
                  {(editOptions.saturation || 1).toFixed(2)}
                </Text>
              </View>
              <Slider
                style={{ width: '100%', height: 40 }}
                minimumValue={0}
                maximumValue={2}
                value={editOptions.saturation || 1}
                onValueChange={handleSaturationChange}
                onSlidingComplete={() => applyEditOptions(editOptions)}
                minimumTrackTintColor="#3B82F6"
                maximumTrackTintColor="#E5E7EB"
              />
            </View>

            {/* Info Note */}
            <View className="bg-blue-50 rounded-xl p-4 mb-4">
              <Text className="text-sm text-blue-800">
                💡 Adjustments will be applied during final document processing for optimal print quality.
              </Text>
            </View>

            {/* Reset Button */}
            <Pressable 
              onPress={() => applyFilter('original')}
              className="bg-gray-100 py-3 rounded-xl"
            >
              <Text className="text-center font-medium text-gray-700">
                Reset to Original
              </Text>
            </Pressable>
          </View>
        )}

        {activeTab === 'filters' && (
          <View className="p-4">
            <Text className="text-lg font-semibold text-gray-900 mb-2">
              Quick Filters
            </Text>
            <Text className="text-sm text-gray-600 mb-6">
              Apply professional document enhancements for optimal print quality.
            </Text>

            <View className="flex-row flex-wrap">
              {[
                { id: 'original', name: 'Original', icon: 'image-outline', description: 'No enhancements' },
                { id: 'enhance', name: 'Document Pro', icon: 'sparkles-outline', description: 'Optimized for text' },
                { id: 'grayscale', name: 'Black & White', icon: 'contrast-outline', description: 'Monochrome mode' },
                { id: 'sharp', name: 'High Contrast', icon: 'diamond-outline', description: 'Sharp text' },
              ].map((filter) => (
                <View key={filter.id} className="w-1/2 p-2">
                  <Pressable
                    onPress={() => applyFilter(filter.id as any)}
                    className="bg-gray-50 border border-gray-200 rounded-xl p-4 items-center active:bg-gray-100"
                    disabled={isProcessing}
                  >
                    <View className="w-12 h-12 bg-blue-100 rounded-full items-center justify-center mb-2">
                      <Ionicons name={filter.icon as any} size={24} color="#3B82F6" />
                    </View>
                    <Text className="text-sm font-medium text-gray-700 text-center">
                      {filter.name}
                    </Text>
                    <Text className="text-xs text-gray-500 text-center mt-1">
                      {filter.description}
                    </Text>
                  </Pressable>
                </View>
              ))}
            </View>
          </View>
        )}
      </ScrollView>

      {/* Bottom Actions */}
      <View 
        className="border-t border-gray-200 px-4 py-4"
        style={{ paddingBottom: insets.bottom + 16 }}
      >
        <View className="flex-row space-x-3">
          <Pressable 
            onPress={onRetake}
            className="flex-1 bg-gray-100 py-4 rounded-xl"
          >
            <Text className="text-center font-semibold text-gray-700">
              Retake
            </Text>
          </Pressable>
          
          <Pressable 
            onPress={handleSave}
            className="flex-1 bg-blue-600 py-4 rounded-xl"
            disabled={isProcessing}
          >
            <Text className="text-center font-semibold text-white">
              {isProcessing ? 'Processing...' : 'Use Document'}
            </Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}