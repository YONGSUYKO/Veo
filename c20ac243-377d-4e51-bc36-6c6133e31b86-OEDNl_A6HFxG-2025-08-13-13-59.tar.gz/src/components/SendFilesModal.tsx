import React, { useState } from 'react';
import { View, Text, Pressable, Modal, Alert, ScrollView, TextInput } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as DocumentPicker from 'expo-document-picker';
import { emailService } from '../services/emailService';
import { useAuthStore } from '../state/authStore';

interface SendFilesModalProps {
  visible: boolean;
  onClose: () => void;
  navigation?: any;
}

interface FileItem {
  name: string;
  uri: string;
  size: number;
  type: string;
}

export default function SendFilesModal({ visible, onClose, navigation }: SendFilesModalProps) {
  const { currentUser } = useAuthStore();
  const [selectedFiles, setSelectedFiles] = useState<FileItem[]>([]);
  const [customerInfo, setCustomerInfo] = useState({
    name: currentUser?.name || '',
    email: currentUser?.email || '',
    phone: currentUser?.phone || '',
  });
  const [sending, setSending] = useState(false);

  const handleFileSelect = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: '*/*',
        multiple: true,
        copyToCacheDirectory: true,
      });

      if (!result.canceled && result.assets) {
        const newFiles = result.assets.map(asset => ({
          name: asset.name,
          uri: asset.uri,
          size: asset.size || 0,
          type: asset.mimeType || 'unknown',
        }));
        setSelectedFiles([...selectedFiles, ...newFiles]);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to select files');
    }
  };

  const handleRemoveFile = (index: number) => {
    setSelectedFiles(selectedFiles.filter((_, i) => i !== index));
  };

  const handleSendFiles = async () => {
    if (selectedFiles.length === 0) {
      Alert.alert('No Files', 'Please select files to send');
      return;
    }

    if (!customerInfo.name.trim() || !customerInfo.email.trim()) {
      Alert.alert('Missing Info', 'Please provide your name and email');
      return;
    }

    setSending(true);
    
    try {
      // Import the staff support service
      const { staffSupportService } = await import('../services/staffSupportService');
      
      // Create staff support order
      const orderData = {
        customerId: currentUser?.id || `guest_${Date.now()}`,
        files: selectedFiles.map((file, index) => ({
          id: `file_${index + 1}`,
          name: file.name,
          url: file.uri, // In production, upload to cloud storage
          preview: file.uri,
          type: file.type.includes('image') ? 'photo' as const : 'document' as const,
          printSpecs: {
            size: 'A4',
            pages: 1,
            color: 'color' as const,
            copies: 1,
          },
        })),
        printSpecs: [],
        totalAmount: 0, // Will be set by operator during review
      };

      const newOrder = await staffSupportService.createOrder(orderData);
      
      Alert.alert(
        'Order Created Successfully!', 
        `Your staff support order #${newOrder.id.slice(-6)} has been created. Our team will review your files and contact you with pricing and specifications.`,
        [
          {
            text: 'View Order Status',
            onPress: () => {
              handleClose();
              if (navigation) {
                navigation.navigate('CustomerOrderStatus', { orderId: newOrder.id });
              }
            }
          },
          { text: 'OK', onPress: handleClose }
        ]
      );
      
    } catch (error) {
      console.error('Error creating staff support order:', error);
      Alert.alert('Error', 'Failed to create order. Please try again.');
    } finally {
      setSending(false);
    }
  };

  const handleClose = () => {
    setSelectedFiles([]);
    setCustomerInfo({
      name: currentUser?.name || '',
      email: currentUser?.email || '',
      phone: currentUser?.phone || '',
    });
    onClose();
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View className="flex-1 bg-white">
        {/* Header */}
        <View className="flex-row items-center justify-between p-4 border-b border-gray-200">
          <View />
          <Text className="text-lg font-semibold">Send Files for Printing</Text>
          <Pressable onPress={handleClose} disabled={sending}>
            <Ionicons name="close" size={24} color="#374151" />
          </Pressable>
        </View>

        <ScrollView className="flex-1 p-6">
          {/* Info Banner */}
          <View className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
            <View className="flex-row items-start">
              <Ionicons name="information-circle" size={20} color="#3B82F6" />
              <View className="flex-1 ml-3">
                <Text className="text-blue-900 font-semibold mb-1">
                  Quick Print Request
                </Text>
                <Text className="text-blue-700 text-sm">
                  Select your files and we'll contact you about the best way to receive them for printing.
                </Text>
              </View>
            </View>
          </View>

          {/* File Selection */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 mb-4">
              Select Files to Print
            </Text>
            
            <Pressable
              onPress={handleFileSelect}
              className="border-2 border-dashed border-gray-300 rounded-xl p-6 items-center"
              disabled={sending}
            >
              <Ionicons name="cloud-upload" size={48} color="#6B7280" />
              <Text className="text-lg font-medium text-gray-700 mt-2">
                Choose Files
              </Text>
              <Text className="text-sm text-gray-500 text-center mt-1">
                PDFs, Word docs, Excel, PowerPoint, Images
              </Text>
            </Pressable>

            {/* Selected Files List */}
            {selectedFiles.length > 0 && (
              <View className="mt-4 space-y-2">
                <Text className="text-sm font-medium text-gray-700">
                  Selected Files ({selectedFiles.length}):
                </Text>
                {selectedFiles.map((file, index) => (
                  <View key={index} className="flex-row items-center bg-gray-50 rounded-lg p-3">
                    <Ionicons 
                      name={file.type.includes('pdf') ? 'document-text' : 
                            file.type.includes('image') ? 'image' : 'document'} 
                      size={20} 
                      color="#6B7280" 
                    />
                    <View className="flex-1 ml-3">
                      <Text className="font-medium text-gray-900" numberOfLines={1}>
                        {file.name}
                      </Text>
                      <Text className="text-sm text-gray-500">
                        {(file.size / 1024 / 1024).toFixed(1)} MB
                      </Text>
                    </View>
                    <Pressable
                      onPress={() => handleRemoveFile(index)}
                      className="p-1"
                      disabled={sending}
                    >
                      <Ionicons name="close-circle" size={20} color="#EF4444" />
                    </Pressable>
                  </View>
                ))}
              </View>
            )}
          </View>

          {/* Customer Info - Only if not logged in */}
          {!currentUser && (
            <View className="mb-6">
              <Text className="text-lg font-semibold text-gray-900 mb-4">
                Your Information
              </Text>
              <View className="space-y-3">
                <TextInput
                  className="border border-gray-300 rounded-xl px-4 py-3 text-base"
                  value={customerInfo.name}
                  onChangeText={(text) => setCustomerInfo({...customerInfo, name: text})}
                  placeholder="Your name"
                  editable={!sending}
                />
                <TextInput
                  className="border border-gray-300 rounded-xl px-4 py-3 text-base"
                  value={customerInfo.email}
                  onChangeText={(text) => setCustomerInfo({...customerInfo, email: text})}
                  placeholder="Your email"
                  keyboardType="email-address"
                  editable={!sending}
                />
                <TextInput
                  className="border border-gray-300 rounded-xl px-4 py-3 text-base"
                  value={customerInfo.phone}
                  onChangeText={(text) => setCustomerInfo({...customerInfo, phone: text})}
                  placeholder="Your phone (optional)"
                  keyboardType="phone-pad"
                  editable={!sending}
                />
              </View>
            </View>
          )}

          {/* How It Works */}
          <View className="bg-green-50 border border-green-200 rounded-xl p-4 mb-6">
            <Text className="text-green-900 font-semibold mb-2">
              📋 How This Works:
            </Text>
            <Text className="text-green-800 text-sm">
              1. Select your files here{'\n'}
              2. We'll receive your print request{'\n'}
              3. We'll contact you about file delivery (USB, email, or cloud link){'\n'}
              4. Bring files to store or send them to us{'\n'}
              5. We'll print and notify you when ready!
            </Text>
          </View>
        </ScrollView>

        {/* Send Button */}
        <View className="p-6 border-t border-gray-200">
          <Pressable
            className={`py-4 rounded-xl ${sending ? 'bg-gray-400' : 'bg-blue-500'}`}
            onPress={handleSendFiles}
            disabled={sending || selectedFiles.length === 0}
          >
            <Text className="text-white font-semibold text-lg text-center">
              {sending ? 'Sending Request...' : `Send Print Request (${selectedFiles.length} files)`}
            </Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}