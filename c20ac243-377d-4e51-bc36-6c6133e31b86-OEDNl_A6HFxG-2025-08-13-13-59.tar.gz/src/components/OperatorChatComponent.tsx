import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  FlatList,
  Alert,
  StyleSheet,
} from 'react-native';
import { OrderMessage } from '../types/staffSupportOrder';

interface OperatorChatComponentProps {
  orderId: string;
}

const OperatorChatComponent: React.FC<OperatorChatComponentProps> = ({ orderId }) => {
  const [messages, setMessages] = useState<OrderMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Set up real-time subscription to messages
    const { staffSupportService } = require('../services/staffSupportService');
    const unsubscribe = staffSupportService.subscribeToMessages(orderId, (messagesList: OrderMessage[]) => {
      setMessages(messagesList.reverse()); // Reverse for proper order in FlatList
    });

    return unsubscribe;
  }, [orderId]);

  const sendMessage = async () => {
    if (!newMessage.trim()) return;

    setLoading(true);
    try {
      const { staffSupportService } = await import('../services/staffSupportService');
      
      await staffSupportService.sendMessage({
        orderId,
        senderId: 'operator',
        senderType: 'operator',
        message: newMessage.trim(),
        isRead: false,
      });
      
      setNewMessage('');
    } catch (error) {
      console.error('Error sending message:', error);
      Alert.alert('Error', 'Failed to send message.');
    } finally {
      setLoading(false);
    }
  };

  const renderMessage = ({ item }: { item: OrderMessage }) => (
    <View style={[
      styles.messageContainer,
      item.senderType === 'operator' ? styles.operatorMessage : styles.customerMessage
    ]}>
      <Text style={styles.senderLabel}>
        {item.senderType === 'operator' ? 'You (Print Shop)' : 'Customer'}
      </Text>
      <Text style={styles.messageText}>{item.message}</Text>
      <Text style={styles.timestamp}>
        {item.timestamp.toLocaleString()}
      </Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={messages}
        renderItem={renderMessage}
        keyExtractor={item => item.id}
        inverted
        style={styles.messagesList}
      />
      
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.textInput}
          value={newMessage}
          onChangeText={setNewMessage}
          placeholder="Type your message to customer..."
          multiline
        />
        <Pressable 
          style={[
            styles.sendButton, 
            (!newMessage.trim() || loading) && styles.sendButtonDisabled
          ]}
          onPress={sendMessage}
          disabled={loading || !newMessage.trim()}
        >
          <Text style={styles.sendButtonText}>Send</Text>
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    height: 250,
    backgroundColor: '#fff',
    borderRadius: 8,
    overflow: 'hidden'
  },
  messagesList: {
    flex: 1,
    padding: 8
  },
  messageContainer: {
    marginVertical: 4,
    padding: 10,
    borderRadius: 8,
    maxWidth: '80%'
  },
  operatorMessage: {
    alignSelf: 'flex-end',
    backgroundColor: '#28a745',
    borderBottomRightRadius: 2
  },
  customerMessage: {
    alignSelf: 'flex-start',
    backgroundColor: '#e9ecef',
    borderBottomLeftRadius: 2
  },
  senderLabel: {
    fontSize: 10,
    fontWeight: 'bold',
    marginBottom: 2,
    color: '#666'
  },
  messageText: {
    fontSize: 13,
    color: '#000'
  },
  timestamp: {
    fontSize: 9,
    opacity: 0.6,
    marginTop: 2
  },
  inputContainer: {
    flexDirection: 'row',
    padding: 8,
    borderTopWidth: 1,
    borderTopColor: '#ddd'
  },
  textInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 8,
    maxHeight: 80
  },
  sendButton: {
    marginLeft: 8,
    backgroundColor: '#28a745',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 16,
    justifyContent: 'center'
  },
  sendButtonDisabled: {
    backgroundColor: '#ccc'
  },
  sendButtonText: {
    color: 'white',
    fontWeight: 'bold'
  }
});

export default OperatorChatComponent;