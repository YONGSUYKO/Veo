import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { cn } from '../utils/cn';

interface EmptyStateProps {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  description: string;
  actionText?: string;
  onAction?: () => void;
  className?: string;
}

export default function EmptyState({
  icon,
  title,
  description,
  actionText,
  onAction,
  className
}: EmptyStateProps) {
  return (
    <View className={cn("items-center justify-center p-8", className)}>
      <View className="w-20 h-20 bg-gray-100 rounded-full items-center justify-center mb-6">
        <Ionicons name={icon} size={40} color="#9CA3AF" />
      </View>
      
      <Text className="text-xl font-semibold text-gray-900 mb-2 text-center">
        {title}
      </Text>
      
      <Text className="text-gray-600 text-center mb-6 leading-relaxed">
        {description}
      </Text>
      
      {actionText && onAction && (
        <Pressable
          className="bg-blue-500 px-6 py-3 rounded-lg"
          onPress={onAction}
        >
          <Text className="text-white font-semibold">
            {actionText}
          </Text>
        </Pressable>
      )}
    </View>
  );
}