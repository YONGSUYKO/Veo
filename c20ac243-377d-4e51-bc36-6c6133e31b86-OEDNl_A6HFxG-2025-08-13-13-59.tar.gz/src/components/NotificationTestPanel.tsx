import React, { useState } from 'react';
import {
  View,
  Text,
  Pressable,
  Alert,
  StyleSheet,
  ScrollView,
  Modal,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { notificationManager, CustomerTier } from '../services/notificationManager';
import { emailService } from '../services/emailService';
import { smsService } from '../services/smsService';
import { pushNotificationService } from '../services/pushNotificationService';

interface NotificationTestPanelProps {
  visible: boolean;
  onClose: () => void;
  userId: string;
  customerTier: CustomerTier;
}

const NotificationTestPanel: React.FC<NotificationTestPanelProps> = ({
  visible,
  onClose,
  userId,
  customerTier,
}) => {
  const [testing, setTesting] = useState(false);

  const testNotificationService = async (service: 'email' | 'sms' | 'push' | 'all') => {
    setTesting(true);

    try {
      switch (service) {
        case 'email':
          await testEmailService();
          break;
        case 'sms':
          await testSmsService();
          break;
        case 'push':
          await testPushService();
          break;
        case 'all':
          await testCompleteNotificationFlow();
          break;
      }
    } catch (error) {
      console.error(`Error testing ${service} service:`, error);
      Alert.alert('Test Failed', `Error testing ${service} notifications: ${error}`);
    } finally {
      setTesting(false);
    }
  };

  const testEmailService = async () => {
    const success = await emailService.sendToCustomer({
      to: 'test@example.com',
      subject: 'Test Email Notification',
      message: 'This is a test email from PISO Print Express notification system.',
      customerName: 'Test Customer',
    });

    Alert.alert(
      'Email Test Result',
      success ? 'Test email sent successfully!' : 'Email test failed. Check your email configuration.',
    );
  };

  const testSmsService = async () => {
    const success = await smsService.sendSms({
      to: '+639123456789', // Test phone number
      message: 'PISO Print Express: This is a test SMS notification. Service is working properly!',
    });

    Alert.alert(
      'SMS Test Result',
      success ? 'Test SMS sent successfully!' : 'SMS test failed. Check your Twilio configuration.',
    );
  };

  const testPushService = async () => {
    const success = await pushNotificationService.sendToUser(userId, {
      title: 'Test Push Notification',
      body: 'This is a test push notification from PISO Print Express!',
      data: { type: 'test' },
      priority: 'high',
      sound: true,
    });

    Alert.alert(
      'Push Test Result',
      success ? 'Test push notification sent successfully!' : 'Push test failed. Check push notification setup.',
    );
  };

  const testCompleteNotificationFlow = async () => {
    const testOrderId = `test_${Date.now()}`;
    
    const result = await notificationManager.sendOrderUpdate(
      userId,
      testOrderId,
      'ready',
      'This is a complete notification test for all enabled services.'
    );

    const summary = `
Notification Test Results:
• Email: ${result.email ? '✅ Sent' : '❌ Failed'}
• SMS: ${result.sms ? '✅ Sent' : '❌ Failed/Skipped'}
• Push: ${result.push ? '✅ Sent' : '❌ Failed'}
• Total Cost: ₱${result.totalCost}

Customer Tier: ${customerTier.toUpperCase()}
    `;

    Alert.alert('Complete Test Results', summary.trim());
  };

  const showNotificationPricing = () => {
    const pricingInfo = {
      subscriber: {
        title: 'Subscriber Plan (FREE)',
        details: [
          '✅ Unlimited Email notifications',
          '✅ Unlimited SMS notifications',
          '✅ Unlimited Push notifications',
          '✅ All promotional notifications',
          '✅ Priority delivery',
        ]
      },
      registered: {
        title: 'Registered User',
        details: [
          '✅ FREE Email notifications',
          '✅ FREE Push notifications',
          '💰 SMS: ₱5 per message (optional)',
          '⚠️ Limited promotional offers',
        ]
      },
      guest: {
        title: 'Guest User',
        details: [
          '❌ No Email notifications',
          '❌ No Push notifications',
          '💰 SMS only: ₱5 per message (with approval)',
          '❌ No promotional offers',
        ]
      }
    };

    const info = pricingInfo[customerTier];
    Alert.alert(info.title, info.details.join('\n'));
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Notification Test Panel</Text>
          <Pressable onPress={onClose} style={styles.closeButton}>
            <Ionicons name="close" size={24} color="#6B7280" />
          </Pressable>
        </View>

        <ScrollView style={styles.content}>
          {/* Customer Tier Info */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Customer Tier: {customerTier.toUpperCase()}</Text>
            <Pressable onPress={showNotificationPricing} style={styles.infoButton}>
              <Ionicons name="information-circle" size={16} color="#3B82F6" />
              <Text style={styles.infoButtonText}>View Pricing Details</Text>
            </Pressable>
          </View>

          {/* Individual Service Tests */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Individual Service Tests</Text>
            
            <TestButton
              title="Test Email Service"
              description="Send a test email notification"
              icon="mail"
              onPress={() => testNotificationService('email')}
              disabled={testing || customerTier === 'guest'}
              unavailable={customerTier === 'guest'}
            />

            <TestButton
              title="Test SMS Service"
              description={`Send a test SMS (₱5 charge for non-subscribers)`}
              icon="chatbubble"
              onPress={() => testNotificationService('sms')}
              disabled={testing}
              showCharge={customerTier !== 'subscriber'}
            />

            <TestButton
              title="Test Push Notifications"
              description="Send a test push notification"
              icon="notifications"
              onPress={() => testNotificationService('push')}
              disabled={testing || customerTier === 'guest'}
              unavailable={customerTier === 'guest'}
            />
          </View>

          {/* Complete Flow Test */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Complete Integration Test</Text>
            
            <TestButton
              title="Test Complete Flow"
              description="Test all enabled notification methods together"
              icon="checkmark-circle"
              onPress={() => testNotificationService('all')}
              disabled={testing}
              isMain
            />
          </View>

          {/* Service Status */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Service Configuration Status</Text>
            
            <ServiceStatus
              name="Email Service"
              configured={!!process.env.EXPO_PUBLIC_BREVO_API_KEY}
              description="Brevo API integration"
            />
            
            <ServiceStatus
              name="SMS Service"
              configured={smsService.isConfigured()}
              description="Twilio SMS integration"
            />
            
            <ServiceStatus
              name="Push Notifications"
              configured={true} // Expo push is always available
              description="Expo Push Notifications"
            />
          </View>

          {/* Usage Guidelines */}
          <View style={styles.guidelinesSection}>
            <Text style={styles.guidelinesTitle}>💡 Testing Guidelines</Text>
            <Text style={styles.guidelinesText}>
              • Subscribers get all notifications FREE{'\n'}
              • Registered users: Email & Push are FREE, SMS costs ₱5{'\n'}
              • Guests: Only SMS available (₱5 with approval){'\n'}
              • Configure API keys in .env file for full functionality{'\n'}
              • Test notifications use mock data and recipients
            </Text>
          </View>
        </ScrollView>
      </View>
    </Modal>
  );
};

const TestButton: React.FC<{
  title: string;
  description: string;
  icon: keyof typeof Ionicons.glyphMap;
  onPress: () => void;
  disabled: boolean;
  unavailable?: boolean;
  showCharge?: boolean;
  isMain?: boolean;
}> = ({ title, description, icon, onPress, disabled, unavailable, showCharge, isMain }) => (
  <Pressable
    onPress={onPress}
    disabled={disabled || unavailable}
    style={[
      styles.testButton,
      isMain && styles.mainTestButton,
      unavailable && styles.unavailableButton,
    ]}
  >
    <View style={styles.testButtonIcon}>
      <Ionicons 
        name={icon} 
        size={20} 
        color={unavailable ? '#9CA3AF' : isMain ? '#FFFFFF' : '#3B82F6'} 
      />
    </View>
    <View style={styles.testButtonContent}>
      <Text style={[
        styles.testButtonTitle,
        isMain && styles.mainTestButtonTitle,
        unavailable && styles.unavailableButtonTitle,
      ]}>
        {title}
      </Text>
      <Text style={[
        styles.testButtonDescription,
        isMain && styles.mainTestButtonDescription,
        unavailable && styles.unavailableButtonDescription,
      ]}>
        {description}
      </Text>
      {showCharge && (
        <Text style={styles.chargeText}>💰 ₱5 charge applies</Text>
      )}
      {unavailable && (
        <Text style={styles.unavailableText}>❌ Not available for your tier</Text>
      )}
    </View>
  </Pressable>
);

const ServiceStatus: React.FC<{
  name: string;
  configured: boolean;
  description: string;
}> = ({ name, configured, description }) => (
  <View style={styles.serviceStatus}>
    <View style={styles.serviceStatusIcon}>
      <Ionicons 
        name={configured ? 'checkmark-circle' : 'alert-circle'} 
        size={16} 
        color={configured ? '#10B981' : '#EF4444'} 
      />
    </View>
    <View style={styles.serviceStatusContent}>
      <Text style={styles.serviceStatusName}>{name}</Text>
      <Text style={styles.serviceStatusDescription}>{description}</Text>
    </View>
    <Text style={[
      styles.serviceStatusBadge,
      configured ? styles.serviceStatusConfigured : styles.serviceStatusNotConfigured,
    ]}>
      {configured ? 'READY' : 'NOT CONFIGURED'}
    </Text>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
  },
  closeButton: {
    padding: 4,
  },
  content: {
    flex: 1,
  },
  section: {
    backgroundColor: 'white',
    margin: 16,
    borderRadius: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#111827',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  infoButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    paddingHorizontal: 16,
  },
  infoButtonText: {
    fontSize: 14,
    color: '#3B82F6',
    marginLeft: 6,
    fontWeight: '500',
  },
  testButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  mainTestButton: {
    backgroundColor: '#3B82F6',
    marginHorizontal: 16,
    marginVertical: 8,
    borderRadius: 8,
    borderBottomWidth: 0,
  },
  unavailableButton: {
    backgroundColor: '#F9FAFB',
  },
  testButtonIcon: {
    width: 40,
    alignItems: 'center',
  },
  testButtonContent: {
    flex: 1,
    marginLeft: 12,
  },
  testButtonTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 2,
  },
  mainTestButtonTitle: {
    color: 'white',
  },
  unavailableButtonTitle: {
    color: '#9CA3AF',
  },
  testButtonDescription: {
    fontSize: 12,
    color: '#6B7280',
    lineHeight: 16,
  },
  mainTestButtonDescription: {
    color: 'rgba(255,255,255,0.8)',
  },
  unavailableButtonDescription: {
    color: '#D1D5DB',
  },
  chargeText: {
    fontSize: 11,
    color: '#F59E0B',
    fontWeight: '500',
    marginTop: 2,
  },
  unavailableText: {
    fontSize: 11,
    color: '#EF4444',
    fontWeight: '500',
    marginTop: 2,
  },
  serviceStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  serviceStatusIcon: {
    marginRight: 12,
  },
  serviceStatusContent: {
    flex: 1,
  },
  serviceStatusName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 2,
  },
  serviceStatusDescription: {
    fontSize: 12,
    color: '#6B7280',
  },
  serviceStatusBadge: {
    fontSize: 10,
    fontWeight: 'bold',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  serviceStatusConfigured: {
    color: '#065F46',
    backgroundColor: '#D1FAE5',
  },
  serviceStatusNotConfigured: {
    color: '#991B1B',
    backgroundColor: '#FEE2E2',
  },
  guidelinesSection: {
    backgroundColor: '#FEF3C7',
    margin: 16,
    padding: 16,
    borderRadius: 8,
    marginBottom: 40,
  },
  guidelinesTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#92400E',
    marginBottom: 8,
  },
  guidelinesText: {
    fontSize: 12,
    color: '#92400E',
    lineHeight: 18,
  },
});

export default NotificationTestPanel;