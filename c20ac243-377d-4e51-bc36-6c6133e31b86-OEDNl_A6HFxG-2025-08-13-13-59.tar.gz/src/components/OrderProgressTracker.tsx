import React from 'react';
import { View, Text, Pressable, Modal } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { cn } from '../utils/cn';

interface OrderProgressTrackerProps {
  visible: boolean;
  onClose: () => void;
  order: any;
}

export default function OrderProgressTracker({ visible, onClose, order }: OrderProgressTrackerProps) {
  const getDeliverySteps = () => {
    const steps = [
      { id: 'queue', label: 'Order Received', icon: 'checkmark-circle', description: 'Your order has been confirmed' },
      { id: 'ongoing', label: 'Printing', icon: 'print', description: 'Your files are being printed' },
      { id: 'ready', label: 'Ready for Pickup', icon: 'checkmark-done', description: 'Printing completed, preparing for delivery' },
      { id: 'shipped', label: 'Out for Delivery', icon: 'bicycle', description: 'Courier is on the way to your location' },
      { id: 'completed', label: 'Delivered', icon: 'home', description: 'Order successfully delivered' },
    ];

    return steps;
  };

  const getPickupSteps = () => {
    const steps = [
      { id: 'queue', label: 'Order Received', icon: 'checkmark-circle', description: 'Your order has been confirmed' },
      { id: 'ongoing', label: 'Printing', icon: 'print', description: 'Your files are being printed' },
      { id: 'ready', label: 'Ready for Pickup', icon: 'storefront', description: 'Ready to collect from our store' },
      { id: 'completed', label: 'Collected', icon: 'checkmark-done', description: 'Order successfully collected' },
    ];

    return steps;
  };

  const steps = order?.fulfillmentMethod === 'delivery' ? getDeliverySteps() : getPickupSteps();
  
  const getCurrentStepIndex = () => {
    switch (order?.status) {
      case 'queue': return 0;
      case 'ongoing': return 1;
      case 'ready': return 2;
      case 'shipped': return order?.fulfillmentMethod === 'delivery' ? 3 : 2;
      case 'completed': return steps.length - 1;
      default: return 0;
    }
  };

  const currentStepIndex = getCurrentStepIndex();

  const getEstimatedTime = () => {
    switch (order?.status) {
      case 'queue': return '15-20 minutes';
      case 'ongoing': return '5-10 minutes';
      case 'ready': return order?.fulfillmentMethod === 'delivery' ? 'Awaiting courier' : 'Ready now';
      case 'shipped': return '20-30 minutes';
      case 'completed': return 'Completed';
      default: return 'Processing';
    }
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View className="flex-1 bg-white">
        {/* Header */}
        <View className="flex-row items-center justify-between p-4 border-b border-gray-200">
          <View />
          <Text className="text-lg font-semibold">Order Progress</Text>
          <Pressable onPress={onClose}>
            <Ionicons name="close" size={24} color="#374151" />
          </Pressable>
        </View>

        <View className="flex-1 p-6">
          {/* Order Info */}
          <View className="bg-gray-50 rounded-2xl p-6 mb-6">
            <View className="flex-row items-center justify-between mb-4">
              <Text className="text-xl font-bold text-gray-900">
                Order #{order?.id?.slice(-6)}
              </Text>
              <Text className="text-lg font-bold text-blue-600">
                ₱{((order?.totalPrice || 0) / 100).toFixed(2)}
              </Text>
            </View>
            
            <View className="space-y-2">
              <View className="flex-row justify-between">
                <Text className="text-gray-600">Files:</Text>
                <Text className="font-medium">{order?.files?.length || 0} files</Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-gray-600">Payment:</Text>
                <Text className="font-medium">{order?.paymentMethod?.toUpperCase()}</Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-gray-600">Delivery:</Text>
                <Text className="font-medium capitalize">{order?.fulfillmentMethod}</Text>
              </View>
              {order?.deliveryCourier && (
                <View className="flex-row justify-between">
                  <Text className="text-gray-600">Courier:</Text>
                  <Text className="font-medium">{order.deliveryCourier}</Text>
                </View>
              )}
            </View>
          </View>

          {/* Progress Steps */}
          <View className="space-y-4">
            <Text className="text-lg font-semibold text-gray-900 mb-2">
              Order Progress
            </Text>
            
            {/* Current Status Badge */}
            <View className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-4">
              <View className="flex-row items-center">
                <Ionicons name="clock" size={20} color="#3B82F6" />
                <Text className="text-blue-900 font-semibold ml-2">
                  Estimated Time: {getEstimatedTime()}
                </Text>
              </View>
            </View>

            {/* Progress Steps */}
            {steps.map((step, index) => {
              const isCompleted = index <= currentStepIndex;
              const isCurrent = index === currentStepIndex;
              
              return (
                <View key={step.id} className="flex-row items-start">
                  {/* Step Icon */}
                  <View className="mr-4 items-center">
                    <View className={cn(
                      "w-10 h-10 rounded-full items-center justify-center",
                      isCompleted 
                        ? "bg-green-500" 
                        : isCurrent 
                          ? "bg-blue-500" 
                          : "bg-gray-200"
                    )}>
                      <Ionicons 
                        name={step.icon as any} 
                        size={20} 
                        color={isCompleted || isCurrent ? "white" : "#9CA3AF"} 
                      />
                    </View>
                    
                    {/* Connector Line */}
                    {index < steps.length - 1 && (
                      <View className={cn(
                        "w-0.5 h-8 mt-2",
                        index < currentStepIndex ? "bg-green-500" : "bg-gray-200"
                      )} />
                    )}
                  </View>

                  {/* Step Content */}
                  <View className="flex-1 pb-6">
                    <Text className={cn(
                      "text-base font-semibold",
                      isCompleted ? "text-green-900" : isCurrent ? "text-blue-900" : "text-gray-500"
                    )}>
                      {step.label}
                    </Text>
                    <Text className={cn(
                      "text-sm mt-1",
                      isCompleted ? "text-green-700" : isCurrent ? "text-blue-700" : "text-gray-500"
                    )}>
                      {step.description}
                    </Text>
                    
                    {isCurrent && (
                      <View className="bg-blue-50 rounded-lg p-3 mt-2">
                        <Text className="text-blue-800 text-sm font-medium">
                          🔄 Currently in progress...
                        </Text>
                      </View>
                    )}
                  </View>
                </View>
              );
            })}
          </View>

          {/* Contact Support */}
          <View className="mt-6 bg-gray-50 rounded-xl p-4">
            <Text className="text-gray-900 font-semibold mb-2">Need Help?</Text>
            <Text className="text-gray-600 text-sm">
              Contact our support team if you have questions about your order.
            </Text>
          </View>
        </View>
      </View>
    </Modal>
  );
}