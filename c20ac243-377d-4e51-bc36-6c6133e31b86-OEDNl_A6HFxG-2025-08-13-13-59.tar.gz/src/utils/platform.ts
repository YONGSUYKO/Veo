import { Dimensions, Platform } from 'react-native';

const { width, height } = Dimensions.get('window');

// Platform detection utilities
export const PlatformUtils = {
  // Device type detection
  isTablet: width >= 768,
  isDesktop: width >= 1024,
  isMobile: width < 768,
  isKiosk: width >= 1024 && height >= 768, // Large screen devices
  
  // Platform specific
  isWeb: Platform.OS === 'web',
  isIOS: Platform.OS === 'ios',
  isAndroid: Platform.OS === 'android',
  isWindows: Platform.OS === 'windows',
  
  // User role compatible devices
  customerDevices: {
    mobile: true, // Android/iOS phones
    tablet: true, // Android/iOS tablets
    kiosk: true,  // Self-service kiosks
  },
  
  operatorDevices: {
    mobile: true,  // Android/iOS phones
    tablet: true,  // Android/iOS tablets
    desktop: true, // Windows/Mac computers
  },
  
  adminDevices: {
    mobile: true,  // Android/iOS phones (limited functionality)
    tablet: true,  // Android/iOS tablets
    desktop: true, // Windows/Mac computers (full functionality)
  },
  
  // Get responsive styles based on screen size
  getResponsiveStyles: () => ({
    container: {
      paddingHorizontal: width < 768 ? 16 : width < 1024 ? 32 : 48,
      maxWidth: width < 768 ? '100%' : width < 1024 ? 768 : 1200,
    },
    text: {
      small: width < 768 ? 12 : 14,
      medium: width < 768 ? 14 : 16,
      large: width < 768 ? 16 : 18,
      xl: width < 768 ? 18 : 24,
      xxl: width < 768 ? 24 : 32,
    },
    spacing: {
      small: width < 768 ? 8 : 12,
      medium: width < 768 ? 16 : 24,
      large: width < 768 ? 24 : 32,
      xl: width < 768 ? 32 : 48,
    },
  }),
  
  // Get grid columns based on screen size
  getGridColumns: (minColWidth: number = 280) => {
    return Math.max(1, Math.floor(width / minColWidth));
  },
  
  // Check if user role is compatible with current device
  isRoleCompatible: (role: 'customer' | 'operator' | 'admin') => {
    const deviceType = width >= 1024 ? 'desktop' : width >= 768 ? 'tablet' : 'mobile';
    
    switch (role) {
      case 'customer':
        return PlatformUtils.customerDevices[deviceType as keyof typeof PlatformUtils.customerDevices];
      case 'operator':
        return PlatformUtils.operatorDevices[deviceType as keyof typeof PlatformUtils.operatorDevices];
      case 'admin':
        return PlatformUtils.adminDevices[deviceType as keyof typeof PlatformUtils.adminDevices];
      default:
        return true;
    }
  },
  
  // Get device type string
  getDeviceType: (): 'mobile' | 'tablet' | 'desktop' | 'kiosk' => {
    if (width >= 1024 && height >= 768) return 'kiosk';
    if (width >= 1024) return 'desktop';
    if (width >= 768) return 'tablet';
    return 'mobile';
  },
  
  // Platform-specific optimizations
  getOptimizations: () => ({
    // Touch target sizes
    touchTarget: {
      mobile: 44,
      tablet: 48,
      desktop: 40,
      kiosk: 56, // Larger for kiosk accessibility
    }[PlatformUtils.getDeviceType()],
    
    // Font scaling
    fontScale: {
      mobile: 1,
      tablet: 1.1,
      desktop: 1,
      kiosk: 1.2, // Larger text for kiosk visibility
    }[PlatformUtils.getDeviceType()],
    
    // Layout density
    density: {
      mobile: 'compact',
      tablet: 'normal',
      desktop: 'normal',
      kiosk: 'comfortable', // More spacing for kiosk
    }[PlatformUtils.getDeviceType()],
  }),
};

// Platform compatibility matrix
export const PLATFORM_COMPATIBILITY = {
  customer: {
    android: '✅ Full Support (Phone/Tablet)',
    ios: '✅ Full Support (Phone/iPad)',
    kiosk: '✅ Optimized for Self-Service',
    web: '⚠️ Limited (Mobile Web Browser)',
  },
  operator: {
    android: '✅ Full Support (Phone/Tablet)',
    ios: '✅ Full Support (Phone/iPad)', 
    windows: '✅ Full Support (Desktop)',
    macos: '✅ Full Support (Desktop)',
    web: '✅ Full Support (Desktop Browser)',
  },
  admin: {
    android: '⚠️ Limited (Phone/Tablet)',
    ios: '⚠️ Limited (Phone/iPad)',
    windows: '✅ Full Support (Desktop)',
    macos: '✅ Full Support (Desktop)',
    web: '✅ Full Support (Desktop Browser)',
  },
};

// Screen size breakpoints
export const BREAKPOINTS = {
  mobile: { min: 0, max: 767 },
  tablet: { min: 768, max: 1023 },
  desktop: { min: 1024, max: 1440 },
  kiosk: { min: 1441, max: Infinity },
} as const;

// Get current breakpoint
export const getCurrentBreakpoint = (): keyof typeof BREAKPOINTS => {
  const { width } = Dimensions.get('window');
  
  if (width >= BREAKPOINTS.kiosk.min) return 'kiosk';
  if (width >= BREAKPOINTS.desktop.min) return 'desktop';
  if (width >= BREAKPOINTS.tablet.min) return 'tablet';
  return 'mobile';
};