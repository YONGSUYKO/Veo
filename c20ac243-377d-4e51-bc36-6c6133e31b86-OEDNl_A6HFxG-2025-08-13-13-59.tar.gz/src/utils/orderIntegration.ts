import { staffSupportService } from '../services/staffSupportService';
import { StaffSupportFile } from '../types/staffSupportOrder';

interface FileUploadData {
  name: string;
  uri: string;
  size?: number;
  type?: string;
}

interface CustomerInfo {
  name: string;
  email: string;
  phone?: string;
}

/**
 * Handles file upload and creates a staff support order
 * This replaces the old direct-to-payment flow
 */
export const handleFileUploadAndCreateOrder = async (
  selectedFiles: FileUploadData[],
  customerInfo: CustomerInfo,
  customerId?: string
): Promise<string> => {
  try {
    // Convert uploaded files to staff support file format
    const staffSupportFiles: StaffSupportFile[] = selectedFiles.map((file, index) => ({
      id: `file_${Date.now()}_${index}`,
      name: file.name,
      url: file.uri, // In production, this would be the uploaded URL
      preview: file.uri,
      type: file.name.toLowerCase().includes('.pdf') ? 'document' : 'photo',
      operatorComments: '',
      printSpecs: {
        size: '',
        pages: 1,
        color: 'color',
        copies: 1
      }
    }));

    // Create the staff support order
    const orderData = {
      customerId: customerId || `guest_${Date.now()}`,
      files: staffSupportFiles,
      printSpecs: [],
      totalAmount: 0, // Will be set by operator
      status: 'uploaded' as const,
    };

    const newOrder = await staffSupportService.createOrder(orderData);
    
    console.log('✅ Staff support order created:', newOrder.id);
    return newOrder.id;
    
  } catch (error) {
    console.error('❌ Error creating staff support order:', error);
    throw new Error('Failed to create order. Please try again.');
  }
};

/**
 * Gets the customer-friendly status message
 */
export const getCustomerStatusMessage = (status: string): string => {
  const messages = {
    uploaded: 'Your files have been uploaded successfully! Our team will review them shortly.',
    under_review: 'Our print specialists are reviewing your files and preparing a quote.',
    approved_for_payment: 'Great news! Your order has been reviewed and is ready for payment.',
    paid: 'Payment received! Your order is now in the print queue.',
    printing: 'Your order is currently being printed.',
    ready: 'Your order is ready for pickup!',
    completed: 'Order completed. Thank you for choosing our print services!'
  };
  
  return messages[status as keyof typeof messages] || 'Order status updated.';
};

/**
 * Checks if payment is required for the current order status
 */
export const isPaymentRequired = (status: string): boolean => {
  return status === 'approved_for_payment';
};

/**
 * Checks if the order can be cancelled by the customer
 */
export const canCancelOrder = (status: string): boolean => {
  return ['uploaded', 'under_review'].includes(status);
};