import { Dimensions, Platform } from 'react-native';

export interface DeviceInfo {
  isDesktop: boolean;
  isMobile: boolean;
  isTablet: boolean;
  isKiosk: boolean;
  screenWidth: number;
  screenHeight: number;
  isLandscape: boolean;
  deviceType: 'desktop' | 'mobile' | 'tablet' | 'kiosk';
}

export const getDeviceInfo = (): DeviceInfo => {
  const { width, height } = Dimensions.get('window');
  const isLandscape = width > height;
  
  // Desktop detection - wide screens, typically > 1024px
  const isDesktop = width >= 1024 && (Platform.OS === 'web' || Platform.OS === 'windows' || Platform.OS === 'macos');
  
  // Kiosk detection - disabled for stability (large touch screens would be >= 1280px)
  const isKiosk = false; // Temporarily disabled to prevent routing issues
  
  // Tablet detection - medium screens 768-1023px
  const isTablet = width >= 768 && width < 1024;
  
  // Mobile detection - small screens < 768px
  const isMobile = width < 768;
  
  let deviceType: 'desktop' | 'mobile' | 'tablet' | 'kiosk';
  if (isDesktop) deviceType = 'desktop';
  else if (isTablet) deviceType = 'tablet';
  else deviceType = 'mobile';
  
  return {
    isDesktop,
    isMobile,
    isTablet,
    isKiosk,
    screenWidth: width,
    screenHeight: height,
    isLandscape,
    deviceType,
  };
};

export const useDeviceInfo = () => {
  return getDeviceInfo();
};