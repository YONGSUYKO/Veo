import { Alert } from 'react-native';

export const handleServiceError = (error: any, serviceName: string, fallback?: () => void) => {
  console.error(`${serviceName} Error:`, error);
  
  // Common error handling
  if (error?.message?.includes('network') || error?.code === 'NETWORK_ERROR') {
    Alert.alert(
      'Connection Issue',
      'Please check your internet connection and try again.',
      [{ text: 'OK', onPress: fallback }]
    );
    return;
  }
  
  if (error?.message?.includes('unavailable') || error?.status === 503) {
    Alert.alert(
      'Service Temporarily Unavailable',
      'The service is currently unavailable. Please try again in a moment.',
      [{ text: 'OK', onPress: fallback }]
    );
    return;
  }
  
  // Generic error fallback
  Alert.alert(
    'Error',
    `${serviceName} is currently experiencing issues. Please try again later.`,
    [{ text: 'OK', onPress: fallback }]
  );
};

export const safeAsyncOperation = async <T>(
  operation: () => Promise<T>,
  errorMessage: string = 'Operation failed'
): Promise<T | null> => {
  try {
    return await operation();
  } catch (error) {
    console.error(errorMessage, error);
    return null;
  }
};