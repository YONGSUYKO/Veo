import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { useColorScheme } from 'react-native';

import DashboardScreen from '../screens/DashboardScreen';
import PrintJobsScreen from '../screens/PrintJobsScreen';
import PhotoPrintingScreen from '../screens/PhotoPrintingScreen';
import SubscriptionsScreen from '../screens/SubscriptionsScreen';
import MarketplaceScreen from '../screens/MarketplaceScreen';

const Tab = createBottomTabNavigator();

export default function TabNavigator() {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: keyof typeof Ionicons.glyphMap;

          switch (route.name) {
            case 'Dashboard':
              iconName = focused ? 'grid' : 'grid-outline';
              break;
            case 'Print Jobs':
              iconName = focused ? 'print' : 'print-outline';
              break;
            case 'Photo Printing':
              iconName = focused ? 'camera' : 'camera-outline';
              break;
            case 'Subscriptions':
              iconName = focused ? 'card' : 'card-outline';
              break;
            case 'Marketplace':
              iconName = focused ? 'storefront' : 'storefront-outline';
              break;
            default:
              iconName = 'ellipse';
          }

          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#007AFF',
        tabBarInactiveTintColor: isDark ? '#8E8E93' : '#8E8E93',
        tabBarStyle: {
          backgroundColor: isDark ? '#000000' : '#F2F2F7',
          borderTopColor: isDark ? '#38383A' : '#C6C6C8',
        },
        headerStyle: {
          backgroundColor: isDark ? '#000000' : '#F2F2F7',
        },
        headerTintColor: isDark ? '#FFFFFF' : '#000000',
        headerTitleStyle: {
          fontWeight: '600',
        },
      })}
    >
      <Tab.Screen name="Dashboard" component={DashboardScreen} />
      <Tab.Screen name="Print Jobs" component={PrintJobsScreen} />
      <Tab.Screen name="Photo Printing" component={PhotoPrintingScreen} />
      <Tab.Screen name="Subscriptions" component={SubscriptionsScreen} />
      <Tab.Screen name="Marketplace" component={MarketplaceScreen} />
    </Tab.Navigator>
  );
}