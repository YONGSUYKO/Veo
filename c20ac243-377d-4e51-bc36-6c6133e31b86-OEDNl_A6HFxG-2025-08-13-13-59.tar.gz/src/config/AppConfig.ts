// App Deployment Configuration
// This determines which version of the app is running

export type AppDeploymentType = 'customer' | 'operator' | 'admin';

// Set this during build/deployment to determine app type
const APP_DEPLOYMENT_TYPE: AppDeploymentType = 
  (process.env.EXPO_PUBLIC_APP_TYPE as AppDeploymentType) || 'customer';

export interface AppConfig {
  deploymentType: AppDeploymentType;
  appName: string;
  features: {
    allowRoleSelection: boolean;
    showCustomerFeatures: boolean;
    showOperatorFeatures: boolean;
    showAdminFeatures: boolean;
    requireAuthentication: boolean;
  };
  deployment: {
    platform: 'mobile' | 'tablet' | 'desktop' | 'web';
    target: string;
    environment: 'development' | 'staging' | 'production';
  };
}

// Configuration for each deployment type
const getAppConfig = (deploymentType: AppDeploymentType): AppConfig => {
  switch (deploymentType) {
    case 'customer':
      return {
        deploymentType: 'customer',
        appName: 'PISO Print Express',
        features: {
          allowRoleSelection: false, // No role selection for customers
          showCustomerFeatures: true,
          showOperatorFeatures: false,
          showAdminFeatures: false,
          requireAuthentication: false, // Optional guest users
        },
        deployment: {
          platform: 'mobile',
          target: 'Google Play Store / Apple App Store',
          environment: 'production',
        },
      };

    case 'operator':
      return {
        deploymentType: 'operator',
        appName: 'PISO Print - Operator Station',
        features: {
          allowRoleSelection: false, // Pre-configured as operator
          showCustomerFeatures: true, // Can help customers place orders
          showOperatorFeatures: true,
          showAdminFeatures: false, // No admin access
          requireAuthentication: true, // Must login as operator
        },
        deployment: {
          platform: 'tablet',
          target: 'In-store kiosks / tablets',
          environment: 'production',
        },
      };

    case 'admin':
      return {
        deploymentType: 'admin',
        appName: 'PISO Print - Admin Dashboard',
        features: {
          allowRoleSelection: false, // Pre-configured as admin
          showCustomerFeatures: true, // Can test customer experience
          showOperatorFeatures: true, // Can monitor operations
          showAdminFeatures: true, // Full admin access
          requireAuthentication: true, // Must login as admin
        },
        deployment: {
          platform: 'desktop',
          target: 'Office computers / Web portal',
          environment: 'production',
        },
      };

    default:
      throw new Error(`Invalid deployment type: ${deploymentType}`);
  }
};

export const APP_CONFIG = getAppConfig(APP_DEPLOYMENT_TYPE);

// Helper functions
export const isCustomerApp = () => APP_CONFIG.deploymentType === 'customer';
export const isOperatorApp = () => APP_CONFIG.deploymentType === 'operator';
export const isAdminApp = () => APP_CONFIG.deploymentType === 'admin';

// Feature flags
export const canShowRoleSelection = () => APP_CONFIG.features.allowRoleSelection;
export const canShowCustomerFeatures = () => APP_CONFIG.features.showCustomerFeatures;
export const canShowOperatorFeatures = () => APP_CONFIG.features.showOperatorFeatures;
export const canShowAdminFeatures = () => APP_CONFIG.features.showAdminFeatures;
export const requiresAuthentication = () => APP_CONFIG.features.requireAuthentication;

// Development mode override (for testing all features in one app)
export const isDevelopmentMode = () => 
  process.env.NODE_ENV === 'development' && 
  process.env.EXPO_PUBLIC_DEV_MODE === 'true';