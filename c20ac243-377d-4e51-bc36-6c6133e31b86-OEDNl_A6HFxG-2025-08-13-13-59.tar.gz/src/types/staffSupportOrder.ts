// Database Schema Types for Staff Support Orders

export interface StaffSupportFile {
  id: string;
  name: string;
  url: string;
  preview: string;
  type: 'document' | 'photo';
  operatorComments?: string;
  printSpecs: {
    size: string;
    pages: number;
    color: 'color' | 'black_white';
    copies: number;
  };
}

export interface PrintSpecification {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
}

export type OrderStatus = 
  | 'uploaded' 
  | 'under_review' 
  | 'approved_for_payment' 
  | 'paid' 
  | 'printing' 
  | 'ready' 
  | 'completed';

export interface StaffSupportOrder {
  id: string;
  customerId: string;
  status: OrderStatus;
  createdAt: Date;
  files: StaffSupportFile[];
  printSpecs: PrintSpecification[];
  operatorMessage?: string;
  paymentCode?: string;
  totalAmount: number;
  completionTime?: string;
}

export interface OrderMessage {
  id: string;
  orderId: string;
  senderId: string;
  senderType: 'customer' | 'operator';
  message: string;
  timestamp: Date;
  attachments?: string[];
  isRead: boolean;
}