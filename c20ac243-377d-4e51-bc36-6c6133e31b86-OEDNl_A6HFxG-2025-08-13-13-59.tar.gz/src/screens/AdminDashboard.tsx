import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, ScrollView, RefreshControl, Modal } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';
import { useNewAppStore } from '../state/newAppStore';
import { newApiClient } from '../api/newPisoAPI';
import AdminSettingsScreen from './AdminSettingsScreen';
import AdminPricingManager from '../components/AdminPricingManager';
import { cn } from '../utils/cn';

interface AdminDashboardProps {
  onSwitchToCustomer: () => void;
}

export default function AdminDashboard({ onSwitchToCustomer }: AdminDashboardProps) {
  const insets = useSafeAreaInsets();
  const { currentUser, logout } = useAuthStore();
  const { printJobs, setPrintJobs } = useNewAppStore();
  const [refreshing, setRefreshing] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showPricing, setShowPricing] = useState(false);
  const [showLogoutModal, setShowLogoutModal] = useState(false);
  const [showAnalyticsModal, setShowAnalyticsModal] = useState(false);
  const [showStaffModal, setShowStaffModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [dashboardStats, setDashboardStats] = useState({
    totalJobs: 0,
    todayRevenue: 0,
    activeOperators: 0,
    queueLength: 0,
  });

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const jobs = await newApiClient.getPrintJobs();
      setPrintJobs(jobs);
      
      // Calculate stats
      const today = new Date().toISOString().split('T')[0];
      const todayJobs = jobs.filter(job => 
        job.createdAt.toISOString().split('T')[0] === today
      );
      
      setDashboardStats({
        totalJobs: jobs.length,
        todayRevenue: todayJobs.reduce((sum, job) => sum + job.totalPrice, 0),
        activeOperators: 2, // Mock data
        queueLength: jobs.filter(job => job.status === 'queue').length,
      });
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadDashboardData();
    setRefreshing(false);
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 12) return 'Good Morning';
    if (hour >= 12 && hour < 17) return 'Good Afternoon';
    if (hour >= 17 && hour < 21) return 'Good Evening';
    return 'Good Night';
  };

  const recentJobs = printJobs.slice(0, 5);
  const pendingJobs = printJobs.filter(job => ['queue', 'ongoing'].includes(job.status));

  if (showSettings) {
    return (
      <AdminSettingsScreen onBack={() => setShowSettings(false)} />
    );
  }

  if (showPricing) {
    return (
      <View className="flex-1">
        <AdminPricingManager onClose={() => setShowPricing(false)} />
      </View>
    );
  }

  return (
    <>
      <ScrollView 
        className="flex-1 bg-white"
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
      <View style={{ paddingTop: insets.top + 20 }} className="px-6 pb-8">
        
        {/* Header */}
        <View className="flex-row items-center justify-between mb-8">
          <View className="flex-1">
            <Text className="text-3xl font-bold text-gray-900 mb-2">
              {getGreeting()}, Admin!
            </Text>
            <Text className="text-lg text-gray-600">
              Welcome to your PISO Print Express control center
            </Text>
          </View>
          
          <View className="flex-row space-x-3">
            <Pressable 
              className="w-12 h-12 bg-blue-500 rounded-full items-center justify-center"
              onPress={onSwitchToCustomer}
            >
              <Ionicons name="person" size={24} color="white" />
            </Pressable>
            
            <Pressable 
              className="w-12 h-12 bg-gray-100 rounded-full items-center justify-center"
              onPress={() => setShowLogoutModal(true)}
            >
              <Ionicons name="log-out" size={24} color="#374151" />
            </Pressable>
          </View>
        </View>

        {/* Key Metrics */}
        <View className="mb-8">
          <Text className="text-xl font-semibold text-gray-900 mb-4">
            Business Overview
          </Text>
          
          <View className="grid grid-cols-2 gap-4 mb-4">
            <MetricCard
              icon="print"
              title="Total Jobs"
              value={dashboardStats.totalJobs.toString()}
              subtitle="All time"
              color="bg-blue-500"
            />
            <MetricCard
              icon="cash"
              title="Today's Revenue"
              value={`₱${(dashboardStats.todayRevenue / 100).toFixed(2)}`}
              subtitle="Current day"
              color="bg-green-500"
            />
          </View>
          
          <View className="grid grid-cols-2 gap-4">
            <MetricCard
              icon="time"
              title="Queue Length"
              value={dashboardStats.queueLength.toString()}
              subtitle="Pending jobs"
              color="bg-orange-500"
            />
            <MetricCard
              icon="people"
              title="Active Staff"
              value={dashboardStats.activeOperators.toString()}
              subtitle="Currently online"
              color="bg-purple-500"
            />
          </View>
        </View>

        {/* Quick Actions */}
        <View className="mb-8">
          <Text className="text-xl font-semibold text-gray-900 mb-4">
            Quick Actions
          </Text>
          
          <View className="grid grid-cols-2 gap-4">
            <ActionCard
              icon="settings"
              title="System Settings"
              description="Configure print options"
              color="bg-gray-600"
              onPress={() => setShowSettings(true)}
            />
            <ActionCard
              icon="pricetag"
              title="Manage Pricing"
              description="Update print prices"
              color="bg-blue-600"
              onPress={() => setShowPricing(true)}
            />
            <ActionCard
              icon="bar-chart"
              title="Business Analytics"
              description="Revenue, trends, and reports"
              color="bg-indigo-600"
              onPress={() => setShowAnalyticsModal(true)}
            />
            <ActionCard
              icon="people"
              title="Staff Management"
              description="Operator shifts and performance"
              color="bg-teal-600"
              onPress={() => setShowStaffModal(true)}
            />
            <ActionCard
              icon="card"
              title="Payment Systems"
              description="Transaction monitoring"
              color="bg-emerald-600"
              onPress={() => setShowPaymentModal(true)}
            />
          </View>
        </View>

        {/* Recent Activity */}
        <View className="mb-8">
          <View className="flex-row items-center justify-between mb-4">
            <Text className="text-xl font-semibold text-gray-900">
              Recent Print Jobs
            </Text>
            <Pressable>
              <Text className="text-blue-500 font-medium">View All</Text>
            </Pressable>
          </View>

          {recentJobs.length > 0 ? (
            <View className="space-y-3">
              {recentJobs.map((job) => (
                <JobCard key={job.id} job={job} isAdmin={true} />
              ))}
            </View>
          ) : (
            <View className="bg-gray-50 rounded-xl p-8 items-center">
              <Ionicons name="document-text-outline" size={48} color="#9CA3AF" />
              <Text className="text-gray-500 mt-2">No recent jobs</Text>
            </View>
          )}
        </View>

        {/* Pending Jobs Alert */}
        {pendingJobs.length > 0 && (
          <View className="bg-orange-50 border-l-4 border-orange-400 rounded-r-xl p-4 mb-8">
            <View className="flex-row items-start">
              <Ionicons name="warning" size={20} color="#F97316" />
              <View className="ml-3 flex-1">
                <Text className="text-orange-800 font-medium">
                  {pendingJobs.length} Job(s) Need Attention
                </Text>
                <Text className="text-orange-700 text-sm mt-1">
                  There are pending print jobs waiting to be processed by operators.
                </Text>
              </View>
            </View>
          </View>
        )}

        {/* System Status */}
        <View className="bg-green-50 rounded-xl p-6">
          <View className="flex-row items-center mb-4">
            <View className="w-3 h-3 bg-green-500 rounded-full mr-3" />
            <Text className="text-lg font-semibold text-green-900">
              System Status: Online
            </Text>
          </View>
          
          <View className="space-y-2">
            <StatusItem label="Print Queue" status="Active" />
            <StatusItem label="Payment Gateway" status="Connected" />
            <StatusItem label="Notification Service" status="Running" />
            <StatusItem label="File Storage" status="Available" />
          </View>
        </View>

      </View>
    </ScrollView>

    {/* Modals */}
    <LogoutModal 
      visible={showLogoutModal}
      onClose={() => setShowLogoutModal(false)}
      onConfirm={() => {
        setShowLogoutModal(false);
        logout();
      }}
    />
    
    <InfoModal
      visible={showAnalyticsModal}
      onClose={() => setShowAnalyticsModal(false)}
      title="Analytics Dashboard"
      content={`Today's Stats:\n• Revenue: ₱${(dashboardStats.todayRevenue / 100).toFixed(2)}\n• Total Jobs: ${dashboardStats.totalJobs}\n• Queue Length: ${dashboardStats.queueLength}\n\nDetailed analytics dashboard is being developed.`}
    />
    
    <InfoModal
      visible={showStaffModal}
      onClose={() => setShowStaffModal(false)}
      title="Staff Overview"
      content={`Current Status:\n• Active Operators: ${dashboardStats.activeOperators}\n• Morning Shift: Online\n• Afternoon Shift: Online\n\nFull staff management features are being developed.`}
    />
    
    <InfoModal
      visible={showPaymentModal}
      onClose={() => setShowPaymentModal(false)}
      title="Payment Summary"
      content="Payment Methods Today:\n• Cash: 70%\n• GCash: 20%\n• Card: 10%\n\nAdvanced payment management features are being developed."
    />
    </>
  );
}

// Custom Modal Components
function LogoutModal({ visible, onClose, onConfirm }: { visible: boolean; onClose: () => void; onConfirm: () => void }) {
  return (
    <Modal visible={visible} transparent animationType="fade">
      <View className="flex-1 bg-black/50 justify-center items-center px-4">
        <View className="bg-white rounded-xl p-6 w-full max-w-sm">
          <Text className="text-lg font-semibold text-gray-900 mb-2">Logout</Text>
          <Text className="text-gray-600 mb-6">Are you sure you want to logout?</Text>
          <View className="flex-row space-x-3">
            <Pressable 
              className="flex-1 bg-gray-100 rounded-lg py-3 items-center"
              onPress={onClose}
            >
              <Text className="text-gray-700 font-medium">Cancel</Text>
            </Pressable>
            <Pressable 
              className="flex-1 bg-red-500 rounded-lg py-3 items-center"
              onPress={onConfirm}
            >
              <Text className="text-white font-medium">Logout</Text>
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
}

function InfoModal({ visible, onClose, title, content }: { visible: boolean; onClose: () => void; title: string; content: string }) {
  return (
    <Modal visible={visible} transparent animationType="fade">
      <View className="flex-1 bg-black/50 justify-center items-center px-4">
        <View className="bg-white rounded-xl p-6 w-full max-w-sm">
          <Text className="text-lg font-semibold text-gray-900 mb-4">{title}</Text>
          <Text className="text-gray-600 mb-6 leading-relaxed">{content}</Text>
          <Pressable 
            className="bg-blue-500 rounded-lg py-3 items-center"
            onPress={onClose}
          >
            <Text className="text-white font-medium">Close</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

interface MetricCardProps {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  value: string;
  subtitle: string;
  color: string;
}

function MetricCard({ icon, title, value, subtitle, color }: MetricCardProps) {
  return (
    <View className="bg-white rounded-xl p-4 border border-gray-200">
      <View className="flex-row items-center justify-between mb-3">
        <View className={cn("w-10 h-10 rounded-lg items-center justify-center", color)}>
          <Ionicons name={icon} size={20} color="white" />
        </View>
      </View>
      <Text className="text-2xl font-bold text-gray-900 mb-1">{value}</Text>
      <Text className="text-sm text-gray-600">{title}</Text>
      <Text className="text-xs text-gray-500">{subtitle}</Text>
    </View>
  );
}

interface ActionCardProps {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  description: string;
  color: string;
  onPress: () => void;
}

function ActionCard({ icon, title, description, color, onPress }: ActionCardProps) {
  return (
    <Pressable 
      className="bg-white rounded-xl p-4 border border-gray-200 active:bg-gray-50"
      onPress={onPress}
    >
      <View className={cn("w-12 h-12 rounded-xl items-center justify-center mb-3", color)}>
        <Ionicons name={icon} size={24} color="white" />
      </View>
      <Text className="text-base font-semibold text-gray-900 mb-1">
        {title}
      </Text>
      <Text className="text-sm text-gray-600">
        {description}
      </Text>
    </Pressable>
  );
}

function JobCard({ job, isAdmin }: { job: any; isAdmin?: boolean }) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'ongoing': return 'bg-blue-100 text-blue-800';
      case 'ready': return 'bg-purple-100 text-purple-800';
      case 'queue': return 'bg-orange-100 text-orange-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <View className="bg-white rounded-xl p-4 border border-gray-200">
      <View className="flex-row items-center justify-between mb-2">
        <View className="flex-row items-center">
          <Ionicons name="document-text" size={20} color="#6B7280" />
          <Text className="text-base font-medium text-gray-900 ml-2">
            Order #{job.id.slice(-6)}
          </Text>
        </View>
        <Text className={cn("px-2 py-1 rounded-full text-xs font-medium", getStatusColor(job.status))}>
          {job.status.charAt(0).toUpperCase() + job.status.slice(1)}
        </Text>
      </View>
      
      <View className="flex-row items-center justify-between">
        <View>
          <Text className="text-sm text-gray-600">
            {job.customerInfo.name}
          </Text>
          <Text className="text-xs text-gray-500">
            {job.files.length} file(s) • {job.fulfillmentMethod}
          </Text>
        </View>
        <Text className="text-base font-semibold text-gray-900">
          ₱{(job.totalPrice / 100).toFixed(2)}
        </Text>
      </View>
    </View>
  );
}

function StatusItem({ label, status }: { label: string; status: string }) {
  return (
    <View className="flex-row items-center justify-between">
      <Text className="text-green-700 text-sm">{label}</Text>
      <Text className="text-green-800 text-sm font-medium">{status}</Text>
    </View>
  );
}