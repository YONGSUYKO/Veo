import React, { useState } from 'react';
import { View, Text, Pressable, ScrollView, Alert, Modal } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';

// Import FULL DESKTOP dashboard components
import OperatorDesktopDashboardFull from '../screens/OperatorDesktopDashboardFull';
import AdminDesktopDashboardFull from '../screens/AdminDesktopDashboardFull';

interface TempDesktopDashboardAccessProps {
  navigation?: any;
}

export default function TempDesktopDashboardAccess({ navigation }: TempDesktopDashboardAccessProps) {
  const insets = useSafeAreaInsets();
  const { login, currentUser } = useAuthStore();
  const [currentDashboard, setCurrentDashboard] = useState<'none' | 'operator' | 'admin'>('none');

  const mockUsers = {
    operator: {
      id: 'operator-1',
      email: 'staff@pisoprint.com',
      name: 'Store Operator',
      role: 'operator' as const,
      loyaltyPoints: 0,
    },
    admin: {
      id: 'admin-1',
      email: 'admin@pisoprint.com',
      name: 'Admin User', 
      role: 'admin' as const,
      loyaltyPoints: 0,
    },
  };

  const handleDesktopDashboardAccess = (type: 'operator' | 'admin') => {
    const user = mockUsers[type];
    login(user);
    setCurrentDashboard(type);
    
    Alert.alert(
      'Desktop Dashboard Loaded',
      `You are now viewing the DESKTOP ${type} dashboard on mobile. Use pinch-to-zoom and scroll to navigate.`,
      [{ text: 'OK' }]
    );
  };

  const handleBackToSelector = () => {
    setCurrentDashboard('none');
  };

  // Render desktop dashboard in full-screen modal
  if (currentDashboard !== 'none') {
    return (
      <Modal visible={true} animationType="slide" presentationStyle="fullScreen">
        <View style={{ flex: 1 }}>
          
          {/* Mobile Control Bar */}
          <View style={{
            backgroundColor: '#1F2937',
            paddingTop: insets.top + 10,
            paddingHorizontal: 16,
            paddingBottom: 10,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}>
            <Pressable
              onPress={handleBackToSelector}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                backgroundColor: 'rgba(255,255,255,0.1)',
                paddingHorizontal: 12,
                paddingVertical: 8,
                borderRadius: 8,
              }}
            >
              <Ionicons name="arrow-back" size={16} color="white" />
              <Text style={{ color: 'white', fontSize: 12, marginLeft: 6, fontWeight: '600' }}>
                Back
              </Text>
            </Pressable>

            <View style={{ alignItems: 'center', flex: 1 }}>
              <Text style={{ color: 'white', fontSize: 12, fontWeight: '600' }}>
                DESKTOP {currentDashboard.toUpperCase()} DASHBOARD
              </Text>
              <Text style={{ color: 'rgba(255,255,255,0.7)', fontSize: 10 }}>
                Pinch to zoom • Scroll to navigate
              </Text>
            </View>

            <View style={{ width: 60 }} />
          </View>

          {/* Desktop Dashboard Content */}
          <View style={{ flex: 1, backgroundColor: '#F3F4F6' }}>
            {currentDashboard === 'operator' && (
              <OperatorDesktopDashboardFull 
                onSwitchToCustomer={() => {
                  Alert.alert('Customer View', 'This would switch to customer interface in kiosk mode');
                }}
              />
            )}
            {currentDashboard === 'admin' && (
              <AdminDesktopDashboardFull 
                onSwitchToCustomer={() => {
                  Alert.alert('Customer View', 'This would switch to customer interface in kiosk mode');
                }}
              />
            )}
          </View>

        </View>
      </Modal>
    );
  }

  // Dashboard Selector Screen
  return (
    <View style={{ flex: 1, backgroundColor: '#F3F4F6' }}>
      <ScrollView contentContainerStyle={{ paddingBottom: 20 }}>
        
        {/* Header */}
        <View style={{
          backgroundColor: '#1F2937',
          paddingTop: insets.top + 20,
          paddingHorizontal: 24,
          paddingBottom: 32,
        }}>
          <View style={{ alignItems: 'center', marginBottom: 20 }}>
            <View style={{
              width: 80,
              height: 80,
              backgroundColor: 'rgba(255,255,255,0.1)',
              borderRadius: 40,
              alignItems: 'center',
              justifyContent: 'center',
              marginBottom: 16,
            }}>
              <Ionicons name="desktop" size={40} color="white" />
            </View>
            <Text style={{
              fontSize: 24,
              fontWeight: 'bold',
              color: 'white',
              textAlign: 'center',
              marginBottom: 8,
            }}>
              Desktop Dashboard Access
            </Text>
            <Text style={{
              fontSize: 14,
              color: 'rgba(255,255,255,0.8)',
              textAlign: 'center',
              lineHeight: 20,
            }}>
              Force load desktop dashboards on mobile for editing and review
            </Text>
          </View>

          <View style={{
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            borderWidth: 1,
            borderColor: 'rgba(59, 130, 246, 0.3)',
            borderRadius: 8,
            padding: 12,
          }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 4 }}>
              <Ionicons name="information-circle" size={16} color="#3B82F6" />
              <Text style={{ 
                fontSize: 12, 
                color: '#3B82F6', 
                fontWeight: '600',
                marginLeft: 6,
              }}>
                DESKTOP OVERRIDE
              </Text>
            </View>
            <Text style={{
              fontSize: 11,
              color: 'rgba(255,255,255,0.7)',
              lineHeight: 16,
            }}>
              This loads the full DESKTOP dashboard interfaces on mobile, bypassing responsive design.
            </Text>
          </View>
        </View>

        {/* Dashboard Options */}
        <View style={{ paddingHorizontal: 24, marginTop: 24 }}>
          <Text style={{
            fontSize: 18,
            fontWeight: 'bold',
            color: '#111827',
            marginBottom: 16,
          }}>
            Select Desktop Dashboard
          </Text>

          {/* Operator Desktop Dashboard */}
          <DesktopDashboardCard
            title="Operator Desktop Dashboard"
            subtitle="Full desktop interface for store management"
            icon="storefront"
            color="#10B981"
            description="Complete desktop operator interface with advanced order management, customer communication, inventory tracking, and reporting tools."
            features={[
              'Advanced Order Queue Management',
              'Real-time Print Job Monitoring', 
              'Customer Communication Panel',
              'Inventory Management System',
              'Daily/Weekly Revenue Reports',
              'Staff Performance Analytics',
              'System Status Monitoring'
            ]}
            credentials="staff@pisoprint.com / staff123"
            onPress={() => handleDesktopDashboardAccess('operator')}
          />

          {/* Admin Desktop Dashboard */}
          <DesktopDashboardCard
            title="Admin Desktop Dashboard"
            subtitle="Full desktop interface for system administration"
            icon="settings"
            color="#7C3AED"
            description="Complete desktop admin interface with comprehensive system controls, user management, analytics, and business intelligence tools."
            features={[
              'User & Role Management',
              'System Configuration',
              'Business Analytics & Reports',
              'Franchise Management',
              'Financial Overview',
              'Service Pricing Controls',
              'Global Settings Management'
            ]}
            credentials="admin@pisoprint.com / admin123"
            onPress={() => handleDesktopDashboardAccess('admin')}
          />
        </View>

        {/* Usage Instructions */}
        <View style={{ 
          paddingHorizontal: 24, 
          marginTop: 32,
        }}>
          <View style={{
            backgroundColor: '#FEF3C7',
            borderRadius: 12,
            padding: 16,
          }}>
            <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
              <Ionicons name="bulb" size={20} color="#D97706" />
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={{
                  fontSize: 14,
                  fontWeight: '600',
                  color: '#92400E',
                  marginBottom: 4,
                }}>
                  Mobile Desktop Navigation Tips
                </Text>
                <Text style={{
                  fontSize: 12,
                  color: '#A16207',
                  lineHeight: 18,
                }}>
                  • Pinch to zoom in/out for better visibility{'\n'}
                  • Scroll in all directions to navigate{'\n'}
                  • Tap elements carefully as they're desktop-sized{'\n'}
                  • Rotate to landscape for wider view{'\n'}
                  • Use two fingers to scroll within panels
                </Text>
              </View>
            </View>
          </View>
        </View>

        {/* Return Button */}
        <View style={{ paddingHorizontal: 24, marginTop: 20 }}>
          <Pressable
            onPress={() => navigation?.goBack()}
            style={{
              backgroundColor: '#6B7280',
              borderRadius: 12,
              padding: 16,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Ionicons name="arrow-back" size={20} color="white" />
            <Text style={{
              color: 'white',
              fontSize: 16,
              fontWeight: '600',
              marginLeft: 8,
            }}>
              Back to Customer App
            </Text>
          </Pressable>
        </View>

      </ScrollView>
    </View>
  );
}

function DesktopDashboardCard({ 
  title, 
  subtitle, 
  icon, 
  color, 
  description, 
  features, 
  credentials, 
  onPress 
}: { 
  title: string;
  subtitle: string;
  icon: any;
  color: string;
  description: string;
  features: string[];
  credentials: string;
  onPress: () => void;
}) {
  const [showDetails, setShowDetails] = useState(false);

  return (
    <View style={{
      backgroundColor: 'white',
      borderRadius: 16,
      marginBottom: 20,
      elevation: 2,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
    }}>
      <View style={{ padding: 20 }}>
        
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
          <View style={{
            width: 56,
            height: 56,
            backgroundColor: `${color}20`,
            borderRadius: 28,
            alignItems: 'center',
            justifyContent: 'center',
            marginRight: 16,
          }}>
            <Ionicons name={icon} size={28} color={color} />
          </View>
          
          <View style={{ flex: 1 }}>
            <Text style={{
              fontSize: 18,
              fontWeight: 'bold',
              color: '#111827',
              marginBottom: 4,
            }}>
              {title}
            </Text>
            <Text style={{
              fontSize: 14,
              color: '#6B7280',
            }}>
              {subtitle}
            </Text>
          </View>

          <Pressable
            onPress={() => setShowDetails(!showDetails)}
            style={{ padding: 4 }}
          >
            <Ionicons 
              name={showDetails ? "chevron-up" : "chevron-down"} 
              size={20} 
              color="#9CA3AF" 
            />
          </Pressable>
        </View>

        <Text style={{
          fontSize: 14,
          color: '#4B5563',
          lineHeight: 20,
          marginBottom: 16,
        }}>
          {description}
        </Text>

        {showDetails && (
          <View style={{ marginBottom: 16 }}>
            <Text style={{
              fontSize: 14,
              fontWeight: '600',
              color: '#374151',
              marginBottom: 8,
            }}>
              Desktop Features:
            </Text>
            {features.map((feature, index) => (
              <View key={index} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 4 }}>
                <View style={{
                  width: 4,
                  height: 4,
                  backgroundColor: color,
                  borderRadius: 2,
                  marginRight: 8,
                }} />
                <Text style={{
                  fontSize: 13,
                  color: '#6B7280',
                }}>
                  {feature}
                </Text>
              </View>
            ))}
            
            <View style={{
              backgroundColor: '#F9FAFB',
              borderRadius: 8,
              padding: 12,
              marginTop: 12,
            }}>
              <Text style={{
                fontSize: 12,
                color: '#6B7280',
                fontWeight: '600',
                marginBottom: 2,
              }}>
                Auto-Login Credentials:
              </Text>
              <Text style={{
                fontSize: 12,
                color: '#374151',
                fontFamily: 'monospace',
              }}>
                {credentials}
              </Text>
            </View>
          </View>
        )}

        <Pressable
          onPress={onPress}
          style={{
            backgroundColor: color,
            borderRadius: 8,
            paddingVertical: 12,
            alignItems: 'center',
          }}
        >
          <Text style={{
            color: 'white',
            fontSize: 16,
            fontWeight: '600',
          }}>
            Load Desktop Dashboard
          </Text>
        </Pressable>

      </View>
    </View>
  );
}