import React, { useState } from 'react';
import { View, Text, Pressable, ScrollView, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

interface CompletePricingScreenProps {
  navigation?: any;
}

export default function CompletePricingScreen({ navigation }: CompletePricingScreenProps) {
  const insets = useSafeAreaInsets();
  const [selectedCategory, setSelectedCategory] = useState('documents');

  const pricingCategories = {
    documents: {
      title: 'Document Printing',
      icon: 'document-text',
      color: '#3B82F6',
      items: [
        { name: 'Letter (8.5" x 11")', bw: '₱1.00', color: '₱2.00', notes: 'Most popular' },
        { name: 'A4 (8.3" x 11.7")', bw: '₱1.00', color: '₱2.00', notes: 'International standard' },
        { name: 'Legal (8.5" x 14")', bw: '₱1.50', color: '₱3.00', notes: 'Extended length' },
        { name: 'A3 (11.7" x 16.5")', bw: '₱2.00', color: '₱4.00', notes: 'Large format' },
        { name: 'Double-sided surcharge', bw: '+₱0.50', color: '+₱0.50', notes: 'Per page' },
      ]
    },
    photos: {
      title: 'Photo Printing',
      icon: 'camera',
      color: '#8B5CF6',
      items: [
        { name: 'Wallet (1.75" x 2.5")', bw: '₱0.50', color: '₱0.50', notes: 'ID photos' },
        { name: '2R (2" x 3")', bw: '₱1.00', color: '₱1.00', notes: 'Mini prints' },
        { name: '3R (3.5" x 5")', bw: '₱1.50', color: '₱1.50', notes: 'Standard size' },
        { name: '4R (4" x 6")', bw: '₱2.00', color: '₱2.00', notes: 'Most popular' },
        { name: '5R (5" x 7")', bw: '₱3.50', color: '₱3.50', notes: 'Medium size' },
        { name: '6R (6" x 8")', bw: '₱4.50', color: '₱4.50', notes: 'Large prints' },
        { name: '8R (8" x 10")', bw: '₱6.50', color: '₱6.50', notes: 'Extra large' },
        { name: 'A4 Photo', bw: '₱8.00', color: '₱8.00', notes: 'Document size' },
        { name: 'A3 Photo', bw: '₱12.00', color: '₱12.00', notes: 'Poster size' },
      ]
    },
    business: {
      title: 'Business Services',
      icon: 'briefcase',
      color: '#84CC16',
      items: [
        { name: 'Business Cards (100pcs)', bw: '₱150', color: '₱250', notes: 'Premium quality' },
        { name: 'Flyers A4 (50pcs)', bw: '₱200', color: '₱350', notes: 'Marketing materials' },
        { name: 'Brochures A4 (25pcs)', bw: '₱300', color: '₱500', notes: 'Tri-fold design' },
        { name: 'Tarpaulin (2x3 ft)', bw: '₱180', color: '₱280', notes: 'Weather resistant' },
        { name: 'Tarpaulin (3x6 ft)', bw: '₱350', color: '₱500', notes: 'Large format' },
        { name: 'ID Cards (10pcs)', bw: '₱100', color: '₱150', notes: 'Plastic cards' },
        { name: 'Letterhead (100pcs)', bw: '₱250', color: '₱400', notes: 'Company branded' },
      ]
    },
    binding: {
      title: 'Binding & Finishing',
      icon: 'library',
      color: '#F59E0B',
      items: [
        { name: 'Spiral Binding', bw: '₱15', color: '₱15', notes: 'Per document' },
        { name: 'Perfect Binding', bw: '₱25', color: '₱25', notes: 'Book-style' },
        { name: 'Saddle Stitch', bw: '₱8', color: '₱8', notes: 'Stapled center' },
        { name: 'Lamination (Letter)', bw: '₱10', color: '₱12', notes: 'Per page' },
        { name: 'Lamination (A4)', bw: '₱10', color: '₱12', notes: 'Per page' },
        { name: 'Lamination (Legal)', bw: '₱12', color: '₱15', notes: 'Per page' },
        { name: 'Lamination (A3)', bw: '₱18', color: '₱22', notes: 'Per page' },
      ]
    }
  };

  const categories = Object.keys(pricingCategories);
  const currentCategory = pricingCategories[selectedCategory as keyof typeof pricingCategories];

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 20 }]}>
        <View style={styles.headerContent}>
          <Pressable onPress={() => navigation?.goBack()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color="white" />
          </Pressable>
          
          <View style={styles.headerInfo}>
            <View style={styles.headerIcon}>
              <Ionicons name="pricetag" size={24} color="white" />
            </View>
            <View style={styles.headerText}>
              <Text style={styles.headerTitle}>Complete Pricing Guide</Text>
              <Text style={styles.headerSubtitle}>Transparent pricing for all services</Text>
            </View>
          </View>
        </View>
      </View>

      {/* Category Tabs */}
      <View style={styles.tabsContainer}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.tabsScroll}>
          {categories.map((category) => {
            const categoryData = pricingCategories[category as keyof typeof pricingCategories];
            const isSelected = selectedCategory === category;
            
            return (
              <Pressable
                key={category}
                style={[styles.categoryTab, isSelected && { backgroundColor: categoryData.color }]}
                onPress={() => setSelectedCategory(category)}
              >
                <Ionicons 
                  name={categoryData.icon} 
                  size={20} 
                  color={isSelected ? 'white' : categoryData.color} 
                />
                <Text style={[
                  styles.categoryText,
                  { color: isSelected ? 'white' : categoryData.color }
                ]}>
                  {categoryData.title}
                </Text>
              </Pressable>
            );
          })}
        </ScrollView>
      </View>

      {/* Pricing Content */}
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.pricingSection}>
          <Text style={styles.sectionTitle}>{currentCategory.title}</Text>
          
          {/* Pricing Table */}
          <View style={styles.pricingTable}>
            <View style={styles.tableHeader}>
              <Text style={[styles.headerCell, { flex: 2 }]}>Service</Text>
              <Text style={styles.headerCell}>B&W</Text>
              <Text style={styles.headerCell}>Color</Text>
              <Text style={[styles.headerCell, { flex: 1.5 }]}>Notes</Text>
            </View>
            
            {currentCategory.items.map((item, index) => (
              <View key={index} style={[styles.tableRow, index % 2 === 0 && styles.evenRow]}>
                <Text style={[styles.tableCell, { flex: 2 }]}>{item.name}</Text>
                <Text style={[styles.tableCell, styles.priceCell]}>{item.bw}</Text>
                <Text style={[styles.tableCell, styles.priceCell]}>{item.color}</Text>
                <Text style={[styles.tableCell, styles.notesCell, { flex: 1.5 }]}>{item.notes}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Additional Information */}
        <View style={styles.infoSection}>
          <Text style={styles.infoTitle}>Additional Information</Text>
          
          <View style={styles.infoCards}>
            <View style={styles.infoCard}>
              <Ionicons name="card" size={24} color="#10B981" />
              <View style={styles.infoContent}>
                <Text style={styles.infoCardTitle}>Payment Methods</Text>
                <Text style={styles.infoCardText}>Cash, GCash, Credit/Debit Cards</Text>
              </View>
            </View>

            <View style={styles.infoCard}>
              <Ionicons name="gift" size={24} color="#EC4899" />
              <View style={styles.infoContent}>
                <Text style={styles.infoCardTitle}>Loyalty Program</Text>
                <Text style={styles.infoCardText}>Earn 1 point per ₱1 spent, redeem for discounts</Text>
              </View>
            </View>

            <View style={styles.infoCard}>
              <Ionicons name="bicycle" size={24} color="#3B82F6" />
              <View style={styles.infoContent}>
                <Text style={styles.infoCardTitle}>Free Delivery</Text>
                <Text style={styles.infoCardText}>Orders over ₱50 within 5km radius</Text>
              </View>
            </View>

            <View style={styles.infoCard}>
              <Ionicons name="school" size={24} color="#F59E0B" />
              <View style={styles.infoContent}>
                <Text style={styles.infoCardTitle}>Student Discount</Text>
                <Text style={styles.infoCardText}>10% off with valid student ID</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Contact Info */}
        <View style={styles.contactSection}>
          <Text style={styles.contactTitle}>Questions About Pricing?</Text>
          <Text style={styles.contactText}>
            Contact us for bulk orders, custom pricing, or special requirements
          </Text>
          
          <View style={styles.contactButtons}>
            <Pressable style={[styles.contactButton, { backgroundColor: '#10B981' }]}>
              <Ionicons name="call" size={20} color="white" />
              <Text style={styles.contactButtonText}>Call Us</Text>
            </Pressable>
            
            <Pressable style={[styles.contactButton, { backgroundColor: '#3B82F6' }]}>
              <Ionicons name="chatbubble" size={20} color="white" />
              <Text style={styles.contactButtonText}>Message</Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    backgroundColor: '#7C3AED',
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButton: {
    padding: 8,
    marginRight: 12,
  },
  headerInfo: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerIcon: {
    width: 48,
    height: 48,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  headerText: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  headerSubtitle: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    marginTop: 2,
  },
  tabsContainer: {
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  tabsScroll: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  categoryTab: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 12,
    backgroundColor: '#F3F4F6',
  },
  categoryText: {
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 8,
  },
  content: {
    flex: 1,
  },
  pricingSection: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 16,
  },
  pricingTable: {
    backgroundColor: 'white',
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#F3F4F6',
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  headerCell: {
    flex: 1,
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
  },
  tableRow: {
    flexDirection: 'row',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  evenRow: {
    backgroundColor: '#FAFAFA',
  },
  tableCell: {
    flex: 1,
    fontSize: 14,
    color: '#374151',
  },
  priceCell: {
    fontWeight: '600',
    color: '#111827',
  },
  notesCell: {
    fontSize: 12,
    color: '#6B7280',
  },
  infoSection: {
    padding: 20,
  },
  infoTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 16,
  },
  infoCards: {
    gap: 12,
  },
  infoCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  infoContent: {
    flex: 1,
    marginLeft: 12,
  },
  infoCardTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 2,
  },
  infoCardText: {
    fontSize: 14,
    color: '#6B7280',
  },
  contactSection: {
    padding: 20,
    backgroundColor: 'white',
    margin: 20,
    borderRadius: 12,
    alignItems: 'center',
  },
  contactTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 8,
  },
  contactText: {
    fontSize: 14,
    color: '#6B7280',
    textAlign: 'center',
    marginBottom: 20,
  },
  contactButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  contactButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
  },
  contactButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: 'white',
    marginLeft: 8,
  },
});