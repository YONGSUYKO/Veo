import React, { useState } from 'react';
import { View, Text, Pressable, ScrollView, StyleSheet, Alert, TextInput } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

interface FranchisingScreenProps {
  navigation?: any;
}

export default function FranchisingScreen({ navigation }: FranchisingScreenProps) {
  const insets = useSafeAreaInsets();
  const [selectedPackage, setSelectedPackage] = useState('');
  const [showInquiryForm, setShowInquiryForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    city: '',
    budget: '',
    message: ''
  });

  const franchisePackages = [
    {
      id: 'small',
      title: 'Small Town Package',
      price: '₱150,000',
      location: 'Population 10K-50K',
      color: '#10B981',
      features: [
        'Complete equipment setup',
        '3 months initial supplies',
        '1 week training program',
        'Basic marketing kit',
        'Online system access',
        '6 months business support',
        'Territory protection (5km radius)'
      ],
      includes: [
        'Laser printer (B&W + Color)',
        'Photo printer',
        'Scanner/copier',
        'Computer & software',
        'Point of sale system',
        'Initial paper stock',
        'Branding materials'
      ]
    },
    {
      id: 'city',
      title: 'City Location Package',
      price: '₱300,000',
      location: 'Population 50K-200K',
      color: '#3B82F6',
      features: [
        'Premium equipment package',
        '6 months initial supplies',
        '2 weeks intensive training',
        'Complete marketing kit',
        'Online system access',
        '12 months business support',
        'Territory protection (3km radius)',
        'Grand opening campaign support'
      ],
      includes: [
        'High-speed laser printers',
        'Professional photo printer',
        'Large format printer',
        'Multiple computers',
        'Advanced POS system',
        'Extensive paper inventory',
        'Premium store fixtures',
        'Digital marketing setup'
      ]
    },
    {
      id: 'premium',
      title: 'Premium Mall Package',
      price: '₱500,000',
      location: 'High-traffic locations',
      color: '#8B5CF6',
      features: [
        'Top-tier equipment package',
        '12 months initial supplies',
        '1 month comprehensive training',
        'Premium marketing package',
        'Full online integration',
        '24 months business support',
        'Exclusive territory rights',
        'Dedicated account manager',
        'Priority new product access'
      ],
      includes: [
        'Industrial-grade printers',
        'Wide format capabilities',
        'Professional photo lab setup',
        'Multiple workstations',
        'Enterprise POS system',
        'Complete inventory package',
        'Luxury store design',
        'Staff training program'
      ]
    },
    {
      id: 'master',
      title: 'Master Franchise',
      price: '₱1,000,000',
      location: 'Regional development rights',
      color: '#DC2626',
      features: [
        'Regional territory rights',
        'Sub-franchise development',
        'Complete business package',
        'Ongoing royalty sharing',
        'Master training certification',
        'Unlimited business support',
        'Brand development rights',
        'Technology licensing',
        'Marketing fund contribution'
      ],
      includes: [
        'Multi-location setup rights',
        'Training center establishment',
        'Regional marketing control',
        'Supply chain management',
        'Technology platform access',
        'Brand licensing rights',
        'Operations manual',
        'Continuous innovation access'
      ]
    }
  ];

  const businessHighlights = [
    {
      icon: 'trending-up',
      title: 'Growing Market',
      description: '₱2.5B printing industry in Philippines with 15% annual growth',
      color: '#10B981'
    },
    {
      icon: 'people',
      title: 'Proven Model',
      description: '200+ successful franchisees across the country',
      color: '#3B82F6'
    },
    {
      icon: 'cash',
      title: 'Quick ROI',
      description: 'Average 18-month payback period for investment',
      color: '#F59E0B'
    },
    {
      icon: 'shield-checkmark',
      title: 'Full Support',
      description: 'Complete training, marketing, and operational support',
      color: '#8B5CF6'
    }
  ];

  const handleInquiry = () => {
    if (!formData.name || !formData.email || !formData.phone) {
      Alert.alert('Required Fields', 'Please fill in your name, email, and phone number');
      return;
    }

    Alert.alert(
      'Inquiry Submitted',
      'Thank you for your interest! Our franchise team will contact you within 24 hours.',
      [{ text: 'OK', onPress: () => setShowInquiryForm(false) }]
    );
  };

  if (showInquiryForm) {
    return (
      <View style={styles.container}>
        <View style={[styles.header, { paddingTop: insets.top + 20 }]}>
          <View style={styles.headerContent}>
            <Pressable onPress={() => setShowInquiryForm(false)} style={styles.backButton}>
              <Ionicons name="arrow-back" size={24} color="white" />
            </Pressable>
            <Text style={styles.headerTitle}>Franchise Inquiry</Text>
          </View>
        </View>

        <ScrollView style={styles.formContainer}>
          <View style={styles.formContent}>
            <Text style={styles.formTitle}>Start Your Franchise Journey</Text>
            <Text style={styles.formSubtitle}>Fill out the form below and we'll get back to you soon</Text>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Full Name *</Text>
              <TextInput
                style={styles.textInput}
                value={formData.name}
                onChangeText={(text) => setFormData({...formData, name: text})}
                placeholder="Enter your full name"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Email Address *</Text>
              <TextInput
                style={styles.textInput}
                value={formData.email}
                onChangeText={(text) => setFormData({...formData, email: text})}
                placeholder="Enter your email"
                keyboardType="email-address"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Phone Number *</Text>
              <TextInput
                style={styles.textInput}
                value={formData.phone}
                onChangeText={(text) => setFormData({...formData, phone: text})}
                placeholder="Enter your phone number"
                keyboardType="phone-pad"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Target City/Location</Text>
              <TextInput
                style={styles.textInput}
                value={formData.city}
                onChangeText={(text) => setFormData({...formData, city: text})}
                placeholder="Where do you plan to open?"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Investment Budget</Text>
              <TextInput
                style={styles.textInput}
                value={formData.budget}
                onChangeText={(text) => setFormData({...formData, budget: text})}
                placeholder="Your available investment amount"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Additional Message</Text>
              <TextInput
                style={[styles.textInput, styles.textArea]}
                value={formData.message}
                onChangeText={(text) => setFormData({...formData, message: text})}
                placeholder="Tell us about your business experience or questions"
                multiline
                numberOfLines={4}
              />
            </View>

            <Pressable style={styles.submitButton} onPress={handleInquiry}>
              <Text style={styles.submitButtonText}>Submit Inquiry</Text>
              <Ionicons name="send" size={20} color="white" />
            </Pressable>
          </View>
        </ScrollView>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 20 }]}>
        <View style={styles.headerContent}>
          <Pressable onPress={() => navigation?.goBack()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color="white" />
          </Pressable>
          
          <View style={styles.headerInfo}>
            <View style={styles.headerIcon}>
              <Ionicons name="business" size={24} color="white" />
            </View>
            <View style={styles.headerText}>
              <Text style={styles.headerTitle}>Franchise Opportunity</Text>
              <Text style={styles.headerSubtitle}>Join the PISO Print Express family</Text>
            </View>
          </View>
        </View>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Business Highlights */}
        <View style={styles.highlightsSection}>
          <Text style={styles.sectionTitle}>Why Choose Our Franchise?</Text>
          <View style={styles.highlightsGrid}>
            {businessHighlights.map((highlight, index) => (
              <View key={index} style={styles.highlightCard}>
                <View style={[styles.highlightIcon, { backgroundColor: `${highlight.color}20` }]}>
                  <Ionicons name={highlight.icon} size={24} color={highlight.color} />
                </View>
                <Text style={styles.highlightTitle}>{highlight.title}</Text>
                <Text style={styles.highlightDescription}>{highlight.description}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Franchise Packages */}
        <View style={styles.packagesSection}>
          <Text style={styles.sectionTitle}>Franchise Packages</Text>
          
          {franchisePackages.map((pkg) => (
            <View key={pkg.id} style={styles.packageCard}>
              <View style={[styles.packageHeader, { backgroundColor: pkg.color }]}>
                <View style={styles.packageHeaderContent}>
                  <View>
                    <Text style={styles.packageTitle}>{pkg.title}</Text>
                    <Text style={styles.packageLocation}>{pkg.location}</Text>
                  </View>
                  <Text style={styles.packagePrice}>{pkg.price}</Text>
                </View>
              </View>

              <View style={styles.packageContent}>
                <Text style={styles.packageSectionTitle}>Features Included:</Text>
                {pkg.features.map((feature, index) => (
                  <View key={index} style={styles.featureItem}>
                    <Ionicons name="checkmark-circle" size={16} color={pkg.color} />
                    <Text style={styles.featureText}>{feature}</Text>
                  </View>
                ))}

                <Text style={[styles.packageSectionTitle, { marginTop: 16 }]}>Equipment & Setup:</Text>
                {pkg.includes.map((item, index) => (
                  <View key={index} style={styles.featureItem}>
                    <Ionicons name="hardware-chip" size={16} color="#6B7280" />
                    <Text style={styles.includeText}>{item}</Text>
                  </View>
                ))}

                <Pressable 
                  style={[styles.selectPackageButton, { backgroundColor: pkg.color }]}
                  onPress={() => {
                    setSelectedPackage(pkg.id);
                    setShowInquiryForm(true);
                  }}
                >
                  <Text style={styles.selectPackageText}>Inquire About This Package</Text>
                </Pressable>
              </View>
            </View>
          ))}
        </View>

        {/* Contact Section */}
        <View style={styles.contactSection}>
          <Text style={styles.contactTitle}>Ready to Start Your Business?</Text>
          <Text style={styles.contactText}>
            Join hundreds of successful PISO Print Express franchisees across the Philippines
          </Text>
          
          <Pressable 
            style={styles.inquiryButton}
            onPress={() => setShowInquiryForm(true)}
          >
            <Ionicons name="business" size={20} color="white" />
            <Text style={styles.inquiryButtonText}>Start Franchise Inquiry</Text>
          </Pressable>

          <View style={styles.contactOptions}>
            <Pressable style={styles.contactOption}>
              <Ionicons name="call" size={20} color="#10B981" />
              <Text style={styles.contactOptionText}>Call: (02) 8123-4567</Text>
            </Pressable>
            
            <Pressable style={styles.contactOption}>
              <Ionicons name="mail" size={20} color="#3B82F6" />
              <Text style={styles.contactOptionText}>franchise@pisoprint.com</Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    backgroundColor: '#DC2626',
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButton: {
    padding: 8,
    marginRight: 12,
  },
  headerInfo: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerIcon: {
    width: 48,
    height: 48,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  headerText: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  headerSubtitle: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    marginTop: 2,
  },
  content: {
    flex: 1,
  },
  highlightsSection: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 16,
  },
  highlightsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  highlightCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    width: '47%',
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  highlightIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  highlightTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 8,
    textAlign: 'center',
  },
  highlightDescription: {
    fontSize: 12,
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 16,
  },
  packagesSection: {
    padding: 20,
  },
  packageCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    marginBottom: 20,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  packageHeader: {
    padding: 20,
  },
  packageHeaderContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  packageTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  packageLocation: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.9)',
    marginTop: 2,
  },
  packagePrice: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  packageContent: {
    padding: 20,
  },
  packageSectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 8,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  featureText: {
    fontSize: 14,
    color: '#374151',
    marginLeft: 8,
    flex: 1,
  },
  includeText: {
    fontSize: 14,
    color: '#6B7280',
    marginLeft: 8,
    flex: 1,
  },
  selectPackageButton: {
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: 'center',
    marginTop: 16,
  },
  selectPackageText: {
    fontSize: 16,
    fontWeight: '600',
    color: 'white',
  },
  contactSection: {
    padding: 20,
    backgroundColor: 'white',
    margin: 20,
    borderRadius: 16,
    alignItems: 'center',
  },
  contactTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 8,
    textAlign: 'center',
  },
  contactText: {
    fontSize: 14,
    color: '#6B7280',
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 20,
  },
  inquiryButton: {
    backgroundColor: '#DC2626',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
    marginBottom: 20,
  },
  inquiryButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: 'white',
    marginLeft: 8,
  },
  contactOptions: {
    gap: 12,
    alignItems: 'center',
  },
  contactOption: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  contactOptionText: {
    fontSize: 14,
    color: '#374151',
    marginLeft: 8,
  },
  formContainer: {
    flex: 1,
  },
  formContent: {
    padding: 20,
  },
  formTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 8,
  },
  formSubtitle: {
    fontSize: 16,
    color: '#6B7280',
    marginBottom: 24,
  },
  inputGroup: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: 'white',
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  submitButton: {
    backgroundColor: '#DC2626',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 8,
    marginTop: 8,
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: 'white',
    marginRight: 8,
  },
});