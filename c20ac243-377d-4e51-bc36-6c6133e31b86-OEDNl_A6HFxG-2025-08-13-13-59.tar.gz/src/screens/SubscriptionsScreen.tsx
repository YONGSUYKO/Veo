import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, Pressable, RefreshControl, Modal, TextInput, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAppStore, Subscription } from '../state/appStore';
import { apiClient } from '../api/pisoprint-api';
import { cn } from '../utils/cn';

interface SubscriptionPlan {
  id: string;
  name: string;
  description: string;
  price: number;
  maxCredits: number;
  features: string[];
  icon: keyof typeof Ionicons.glyphMap;
  popular?: boolean;
}

const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: "basic",
    name: "Basic Plan",
    description: "Perfect for occasional printing needs",
    price: 29900, // 299 pesos
    maxCredits: 100,
    features: [
      "100 print credits per month",
      "Basic document printing",
      "Standard photo sizes",
      "Email support",
      "Basic templates"
    ],
    icon: "star"
  },
  {
    id: "student",
    name: "Student Plan",
    description: "Discounted plan for students",
    price: 19900, // 199 pesos
    maxCredits: 75,
    features: [
      "75 print credits per month",
      "Student discount pricing",
      "Research document templates",
      "Thesis formatting tools",
      "Priority email support"
    ],
    icon: "school"
  },
  {
    id: "business",
    name: "Business Plan",
    description: "For small businesses and professionals",
    price: 59900, // 599 pesos
    maxCredits: 300,
    features: [
      "300 print credits per month",
      "Business card templates",
      "Letterhead printing",
      "Bulk printing discounts",
      "Priority processing",
      "Phone support"
    ],
    icon: "briefcase",
    popular: true
  },
  {
    id: "premium",
    name: "Premium Plan",
    description: "Unlimited printing for power users",
    price: 99900, // 999 pesos
    maxCredits: 1000,
    features: [
      "1000 print credits per month",
      "All premium features",
      "Custom templates",
      "Design consultation",
      "Rush service included",
      "24/7 priority support",
      "Exclusive materials"
    ],
    icon: "diamond"
  }
];

export default function SubscriptionsScreen() {
  const insets = useSafeAreaInsets();
  const { subscriptions, setSubscriptions } = useAppStore();
  const [refreshing, setRefreshing] = useState(false);
  const [showSubscribeModal, setShowSubscribeModal] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null);

  useEffect(() => {
    loadSubscriptions();
  }, []);

  const loadSubscriptions = async () => {
    try {
      const subs = await apiClient.getSubscriptions();
      setSubscriptions(subs);
    } catch (error) {
      console.error('Failed to load subscriptions:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadSubscriptions();
    setRefreshing(false);
  };

  const handlePlanSelect = (plan: SubscriptionPlan) => {
    setSelectedPlan(plan);
    setShowSubscribeModal(true);
  };

  return (
    <View className="flex-1 bg-gray-50">
      <ScrollView 
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        <View style={{ paddingTop: insets.top }} className="px-4 pb-6">
          
          {/* Header */}
          <View className="mb-6">
            <Text className="text-3xl font-bold text-gray-900 mb-2">
              Subscription Plans
            </Text>
            <Text className="text-lg text-gray-600">
              Choose the perfect plan for your printing needs and save with monthly credits.
            </Text>
          </View>

          {/* Active Subscriptions */}
          {subscriptions.length > 0 && (
            <View className="mb-6">
              <Text className="text-xl font-semibold text-gray-900 mb-4">
                Active Subscriptions
              </Text>
              <View className="space-y-3">
                {subscriptions.map((sub) => (
                  <ActiveSubscriptionCard key={sub.id} subscription={sub} />
                ))}
              </View>
            </View>
          )}

          {/* Benefits */}
          <View className="mb-6">
            <Text className="text-xl font-semibold text-gray-900 mb-4">Why Subscribe?</Text>
            <View className="space-y-4">
              <BenefitCard 
                icon="cash"
                title="Save Money"
                description="Get more value with monthly credits compared to pay-per-print"
                color="bg-green-500"
              />
              <BenefitCard 
                icon="flash"
                title="Priority Service"
                description="Subscribers get faster processing and priority support"
                color="bg-blue-500"
              />
              <BenefitCard 
                icon="diamond"
                title="Exclusive Features"
                description="Access premium templates, materials, and design services"
                color="bg-purple-500"
              />
            </View>
          </View>

          {/* Subscription Plans */}
          <View>
            <Text className="text-xl font-semibold text-gray-900 mb-4">Available Plans</Text>
            <View className="space-y-4">
              {subscriptionPlans.map((plan) => (
                <PlanCard 
                  key={plan.id} 
                  plan={plan} 
                  onSelect={() => handlePlanSelect(plan)}
                />
              ))}
            </View>
          </View>

        </View>
      </ScrollView>

      <SubscribeModal 
        visible={showSubscribeModal} 
        onClose={() => {
          setShowSubscribeModal(false);
          setSelectedPlan(null);
        }}
        plan={selectedPlan}
        onSubscribed={loadSubscriptions}
      />
    </View>
  );
}

function ActiveSubscriptionCard({ subscription }: { subscription: Subscription }) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      case 'expired': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const creditPercentage = (subscription.credits / subscription.maxCredits) * 100;

  return (
    <View className="bg-white rounded-xl p-4 border-2 border-blue-100">
      <View className="flex-row items-center justify-between mb-3">
        <View>
          <Text className="text-lg font-semibold text-gray-900">
            {subscription.plan.charAt(0).toUpperCase() + subscription.plan.slice(1)} Plan
          </Text>
          <Text className="text-sm text-gray-600">
            {subscription.customerName}
          </Text>
        </View>
        <Text className={cn("px-2 py-1 rounded-full text-xs font-medium", getStatusColor(subscription.status))}>
          {subscription.status.charAt(0).toUpperCase() + subscription.status.slice(1)}
        </Text>
      </View>

      {/* Credits Progress */}
      <View className="mb-3">
        <View className="flex-row items-center justify-between mb-2">
          <Text className="text-sm font-medium text-gray-700">Credits Remaining</Text>
          <Text className="text-sm font-medium text-gray-900">
            {subscription.credits} / {subscription.maxCredits}
          </Text>
        </View>
        <View className="h-2 bg-gray-200 rounded-full">
          <View 
            className="h-2 bg-blue-500 rounded-full"
            style={{ width: `${Math.max(0, creditPercentage)}%` }}
          />
        </View>
      </View>

      <View className="flex-row items-center justify-between">
        <Text className="text-sm text-gray-600">
          Next billing: {new Date(subscription.endDate).toLocaleDateString()}
        </Text>
        <Text className="text-lg font-bold text-gray-900">
          ₱{(subscription.price / 100).toFixed(2)}/month
        </Text>
      </View>
    </View>
  );
}

function BenefitCard({ icon, title, description, color }: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  description: string;
  color: string;
}) {
  return (
    <View className="bg-white rounded-xl p-4">
      <View className="flex-row items-start">
        <View className={cn("w-12 h-12 rounded-lg items-center justify-center mr-4", color)}>
          <Ionicons name={icon} size={24} color="white" />
        </View>
        <View className="flex-1">
          <Text className="text-base font-semibold text-gray-900 mb-1">{title}</Text>
          <Text className="text-sm text-gray-600">{description}</Text>
        </View>
      </View>
    </View>
  );
}

function PlanCard({ plan, onSelect }: { plan: SubscriptionPlan; onSelect: () => void }) {
  return (
    <View className={cn(
      "bg-white rounded-xl p-6 border-2",
      plan.popular ? "border-blue-500 relative" : "border-gray-200"
    )}>
      {plan.popular && (
        <View className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-500 px-3 py-1 rounded-full">
          <Text className="text-white text-sm font-medium">Most Popular</Text>
        </View>
      )}

      {/* Header */}
      <View className="items-center mb-6">
        <View className="w-16 h-16 bg-blue-50 rounded-full items-center justify-center mb-4">
          <Ionicons name={plan.icon} size={32} color="#3B82F6" />
        </View>
        <Text className="text-xl font-bold text-gray-900 mb-1">{plan.name}</Text>
        <Text className="text-sm text-gray-600 text-center mb-4">{plan.description}</Text>
        <View className="items-center">
          <Text className="text-3xl font-bold text-gray-900">
            ₱{(plan.price / 100).toFixed(0)}
          </Text>
          <Text className="text-sm text-gray-600">/month</Text>
        </View>
      </View>

      {/* Features */}
      <View className="space-y-2 mb-6">
        {plan.features.map((feature, index) => (
          <View key={index} className="flex-row items-center">
            <Ionicons name="checkmark-circle" size={16} color="#10B981" />
            <Text className="text-sm text-gray-700 ml-2 flex-1">{feature}</Text>
          </View>
        ))}
      </View>

      {/* Subscribe Button */}
      <Pressable 
        className={cn(
          "py-3 rounded-lg items-center",
          plan.popular ? "bg-blue-500" : "bg-gray-100"
        )}
        onPress={onSelect}
      >
        <Text className={cn(
          "font-semibold",
          plan.popular ? "text-white" : "text-gray-700"
        )}>
          Subscribe Now
        </Text>
      </Pressable>
    </View>
  );
}

function SubscribeModal({ visible, onClose, plan, onSubscribed }: {
  visible: boolean;
  onClose: () => void;
  plan: SubscriptionPlan | null;
  onSubscribed: () => void;
}) {
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubscribe = async () => {
    if (!plan) return;

    if (!customerName.trim() || !customerEmail.trim()) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    if (!customerEmail.includes('@')) {
      Alert.alert('Error', 'Please enter a valid email address');
      return;
    }

    setLoading(true);
    try {
      const subscriptionData = {
        customerEmail: customerEmail.trim(),
        customerName: customerName.trim(),
        plan: plan.id as any,
        status: 'active' as const,
        price: plan.price,
        credits: plan.maxCredits,
        maxCredits: plan.maxCredits,
        startDate: new Date(),
        endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
      };

      await apiClient.createSubscription(subscriptionData);
      
      Alert.alert(
        'Subscription Created!',
        'Your subscription has been successfully activated. You can now enjoy all the benefits of your plan.',
        [{ text: 'OK', onPress: () => {
          onSubscribed();
          onClose();
          setCustomerName('');
          setCustomerEmail('');
        }}]
      );
    } catch (error) {
      Alert.alert('Error', 'Failed to create subscription. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (!plan) return null;

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View className="flex-1 bg-white">
        <View className="flex-row items-center justify-between p-4 border-b border-gray-200">
          <Pressable onPress={onClose}>
            <Text className="text-blue-500 text-lg">Cancel</Text>
          </Pressable>
          <Text className="text-lg font-semibold">Complete Subscription</Text>
          <Pressable onPress={handleSubscribe} disabled={loading}>
            <Text className={cn("text-lg", loading ? "text-gray-400" : "text-blue-500 font-semibold")}>
              {loading ? 'Processing...' : 'Subscribe'}
            </Text>
          </Pressable>
        </View>

        <ScrollView className="flex-1 p-4">
          <View className="space-y-6">
            
            {/* Selected Plan Summary */}
            <View className="bg-blue-50 rounded-xl p-4">
              <View className="flex-row items-center mb-3">
                <View className="w-12 h-12 bg-blue-500 rounded-full items-center justify-center mr-3">
                  <Ionicons name={plan.icon} size={24} color="white" />
                </View>
                <View>
                  <Text className="text-lg font-semibold text-gray-900">{plan.name}</Text>
                  <Text className="text-sm text-gray-600">{plan.maxCredits} credits per month</Text>
                </View>
              </View>
              <View className="flex-row items-center justify-between">
                <Text className="text-2xl font-bold text-gray-900">
                  ₱{(plan.price / 100).toFixed(0)}
                </Text>
                <Text className="text-sm text-gray-600">per month</Text>
              </View>
            </View>

            {/* Customer Information */}
            <View>
              <Text className="text-base font-semibold text-gray-900 mb-4">Your Information</Text>
              <View className="space-y-4">
                <View>
                  <Text className="text-sm font-medium text-gray-700 mb-2">Full Name</Text>
                  <TextInput
                    className="border border-gray-300 rounded-lg px-4 py-3 text-base"
                    value={customerName}
                    onChangeText={setCustomerName}
                    placeholder="Enter your full name"
                    autoCapitalize="words"
                  />
                </View>
                <View>
                  <Text className="text-sm font-medium text-gray-700 mb-2">Email Address</Text>
                  <TextInput
                    className="border border-gray-300 rounded-lg px-4 py-3 text-base"
                    value={customerEmail}
                    onChangeText={setCustomerEmail}
                    placeholder="Enter your email address"
                    keyboardType="email-address"
                    autoCapitalize="none"
                  />
                </View>
              </View>
            </View>

            {/* Features Included */}
            <View>
              <Text className="text-base font-semibold text-gray-900 mb-3">What's Included</Text>
              <View className="space-y-2">
                {plan.features.map((feature, index) => (
                  <View key={index} className="flex-row items-center">
                    <Ionicons name="checkmark-circle" size={20} color="#10B981" />
                    <Text className="text-sm text-gray-700 ml-3 flex-1">{feature}</Text>
                  </View>
                ))}
              </View>
            </View>

            {/* Terms */}
            <View className="bg-gray-50 rounded-xl p-4">
              <Text className="text-sm text-gray-600 text-center">
                By subscribing, you agree to our terms of service. Your subscription will automatically renew monthly unless cancelled. You can cancel anytime in your account settings.
              </Text>
            </View>

          </View>
        </ScrollView>
      </View>
    </Modal>
  );
}