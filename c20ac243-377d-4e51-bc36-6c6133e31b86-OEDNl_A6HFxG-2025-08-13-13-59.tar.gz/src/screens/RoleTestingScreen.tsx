import React, { useState } from 'react';
import { View, Text, Pressable, ScrollView, Alert, Modal } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore, UserRole } from '../state/authStore';
import { useNewAppStore } from '../state/newAppStore';
import { newApiClient } from '../api/newPisoAPI';
import { cn } from '../utils/cn';

interface RoleTestingScreenProps {
  onRoleSelected: (role: UserRole) => void;
  onExit: () => void;
}

export default function RoleTestingScreen({ onRoleSelected, onExit }: RoleTestingScreenProps) {
  const insets = useSafeAreaInsets();
  const { currentUser, login, logout } = useAuthStore();
  const { systemSettings, setSystemSettings } = useNewAppStore();
  const [showSettings, setShowSettings] = useState(false);

  const testUsers = [
    {
      role: 'customer' as const,
      users: [
        {
          id: 'customer-1',
          name: 'John Doe',
          email: 'john@example.com',
          phone: '+639123456789',
          loyaltyPoints: 150,
        },
        {
          id: 'customer-2', 
          name: 'Maria Santos',
          email: 'maria@example.com',
          phone: '+639987654321',
          loyaltyPoints: 0,
        },
        {
          id: 'guest-1',
          name: 'Guest User',
          email: 'guest@example.com',
          loyaltyPoints: 0,
        }
      ]
    },
    {
      role: 'operator' as const,
      users: [
        {
          id: 'operator-1',
          name: 'Store Operator',
          email: 'operator@pisoprint.com',
          loyaltyPoints: 0,
        },
        {
          id: 'operator-2',
          name: 'Lisa Garcia',
          email: 'lisa@pisoprint.com', 
          loyaltyPoints: 0,
        }
      ]
    },
    {
      role: 'admin' as const,
      users: [
        {
          id: 'admin-1',
          name: 'Admin User',
          email: 'admin@pisoprint.com',
          loyaltyPoints: 0,
        },
        {
          id: 'admin-2',
          name: 'Store Owner',
          email: 'owner@pisoprint.com',
          loyaltyPoints: 0,
        }
      ]
    }
  ];

  const handleUserLogin = async (userData: any, role: UserRole) => {
    try {
      const user = {
        ...userData,
        role,
        isLoggedIn: true,
      };
      
      await login(user);
      onRoleSelected(role);
      
      Alert.alert(
        'Login Successful',
        `Logged in as ${userData.name} (${role.toUpperCase()})`,
        [{ text: 'OK' }]
      );
    } catch (error) {
      Alert.alert('Error', 'Failed to login. Please try again.');
    }
  };

  const resetAllData = () => {
    Alert.alert(
      'Reset Data',
      'This will clear all app data and reset to defaults. Continue?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Reset', 
          style: 'destructive',
          onPress: () => {
            // Reset to default settings
            setSystemSettings({
              allowColorToggle: true,
              allowSidednessToggle: true,
              allowOrientationToggle: true,
              allowCopiesToggle: true,
              maxCopies: 1000,
              deliveryFee: 2000,
              defaultDocumentPaperSize: 'Letter',
              defaultPhotoPaperSize: '4R',
              defaultPageColor: 'auto',
              defaultPageSidedness: 'single',
              defaultPageOrientation: 'portrait',
            });
            
            logout();
            Alert.alert('Reset Complete', 'All data has been reset to defaults.');
          }
        }
      ]
    );
  };

  return (
    <View className="flex-1 bg-white">
      <ScrollView>
        <View style={{ paddingTop: insets.top + 20 }} className="px-6 pb-8">
          
          {/* Header */}
          <View className="flex-row items-center justify-between mb-8">
            <View className="flex-1">
              <Text className="text-3xl font-bold text-gray-900 mb-2">
                🧪 Role Testing Mode
              </Text>
              <Text className="text-lg text-gray-600">
                Test all user roles and features
              </Text>
            </View>
            
            <Pressable 
              className="w-12 h-12 bg-red-100 rounded-full items-center justify-center"
              onPress={onExit}
            >
              <Ionicons name="close" size={24} color="#EF4444" />
            </Pressable>
          </View>

          {/* Current User */}
          {currentUser && (
            <View className="bg-blue-50 rounded-xl p-4 mb-6">
              <View className="flex-row items-center justify-between">
                <View>
                  <Text className="font-semibold text-blue-900">
                    Currently logged in as:
                  </Text>
                  <Text className="text-blue-800">
                    {currentUser.name} ({currentUser.role.toUpperCase()})
                  </Text>
                  {currentUser.loyaltyPoints > 0 && (
                    <Text className="text-blue-700 text-sm mt-1">
                      {currentUser.loyaltyPoints} loyalty points
                    </Text>
                  )}
                </View>
                <Pressable 
                  className="bg-blue-500 px-4 py-2 rounded-lg"
                  onPress={logout}
                >
                  <Text className="text-white font-medium">Logout</Text>
                </Pressable>
              </View>
            </View>
          )}

          {/* Test Users by Role */}
          {testUsers.map((roleGroup) => (
            <View key={roleGroup.role} className="mb-8">
              <Text className="text-xl font-semibold text-gray-900 mb-4 capitalize">
                👤 {roleGroup.role} Accounts
              </Text>
              
              <View className="space-y-3">
                {roleGroup.users.map((user) => (
                  <TestUserCard 
                    key={user.id}
                    user={user}
                    role={roleGroup.role}
                    onLogin={handleUserLogin}
                    isActive={currentUser?.id === user.id}
                  />
                ))}
              </View>
            </View>
          ))}

          {/* Testing Tools */}
          <View className="mb-8">
            <Text className="text-xl font-semibold text-gray-900 mb-4">
              🛠️ Testing Tools
            </Text>
            
            <View className="space-y-3">
              <ToolCard
                icon="settings"
                title="System Settings"
                description="Test admin controls & customer toggles"
                color="bg-gray-600"
                onPress={() => setShowSettings(true)}
              />
              
              <ToolCard
                icon="refresh"
                title="Reset All Data"
                description="Clear app data and start fresh"
                color="bg-red-500"
                onPress={resetAllData}
              />
              
              <ToolCard
                icon="information-circle"
                title="Feature Checklist"
                description="Systematic testing guide"
                color="bg-green-500"
                onPress={() => Alert.alert(
                  'Feature Testing Checklist',
                  '📋 CUSTOMER FEATURES:\n✓ Role selection\n✓ Welcome screen with greetings\n✓ Document/Scan/Photo upload\n✓ File settings configuration\n✓ Payment options (Cash/GCash/Card)\n✓ Customer info forms\n✓ Loyalty points system\n✓ Pickup/Delivery selection\n✓ Order tracking\n\n👨‍💼 OPERATOR FEATURES:\n✓ Operator dashboard\n✓ Job queue management\n✓ Status updates (Queue→Ongoing→Ready)\n✓ Customer assistance mode\n✓ Job details view\n✓ Status controls\n\n👩‍💻 ADMIN FEATURES:\n✓ Admin dashboard\n✓ System settings management\n✓ Toggle controls for customers\n✓ Business metrics\n✓ Staff management\n✓ Analytics overview',
                  [{ text: 'OK' }]
                )}
              />
              
              <ToolCard
                icon="bug"
                title="Known Issues"
                description="Current limitations & workarounds"
                color="bg-orange-500"
                onPress={() => Alert.alert(
                  'Known Issues & Workarounds',
                  '⚠️ CURRENT LIMITATIONS:\n\n📱 MOBILE TESTING:\n• Some desktop features limited on mobile\n• Admin dashboard optimized for larger screens\n• File upload simulated (no actual printing)\n\n🔧 WORKAROUNDS:\n• Use tablet mode for better admin experience\n• Test core workflows on mobile\n• Desktop features work in responsive mode\n\n🚀 TESTING PRIORITY:\n1. Customer flow (Document→Payment→Order)\n2. Operator job management\n3. Admin settings controls\n4. Role switching functionality',
                  [{ text: 'OK' }]
                )}
              />
            </View>
          </View>

          {/* Instructions */}
          <View className="bg-yellow-50 rounded-xl p-6">
            <Text className="text-lg font-semibold text-yellow-900 mb-3">
              📱 iPhone Testing Instructions
            </Text>
            
            <View className="space-y-2">
              <InstructionItem text="1. Choose a test user above to login automatically" />
              <InstructionItem text="2. Test the complete workflow for each role" />
              <InstructionItem text="3. Use 'System Settings' to test admin controls" />
              <InstructionItem text="4. Switch between roles to test interactions" />
              <InstructionItem text="5. Check responsive design across orientations" />
              <InstructionItem text="6. Verify all buttons, forms, and navigation work" />
            </View>
            
            <View className="bg-yellow-100 rounded-lg p-3 mt-4">
              <Text className="text-yellow-800 text-sm font-medium">
                💡 Pro Tip: Rotate your iPhone to test tablet-like experience for operator/admin dashboards!
              </Text>
            </View>
          </View>

        </View>
      </ScrollView>

      {/* System Settings Modal */}
      <SystemSettingsModal 
        visible={showSettings}
        onClose={() => setShowSettings(false)}
        settings={systemSettings}
        onUpdateSettings={setSystemSettings}
      />
    </View>
  );
}

interface TestUserCardProps {
  user: any;
  role: UserRole;
  onLogin: (user: any, role: UserRole) => void;
  isActive: boolean;
}

function TestUserCard({ user, role, onLogin, isActive }: TestUserCardProps) {
  const getRoleColor = (role: UserRole) => {
    switch (role) {
      case 'customer': return 'bg-blue-500';
      case 'operator': return 'bg-green-500';
      case 'admin': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getRoleIcon = (role: UserRole) => {
    switch (role) {
      case 'customer': return 'person';
      case 'operator': return 'construct';
      case 'admin': return 'settings';
      default: return 'person';
    }
  };

  return (
    <Pressable
      className={cn(
        "bg-white rounded-xl p-4 border-2",
        isActive ? "border-blue-500 bg-blue-50" : "border-gray-200"
      )}
      onPress={() => onLogin(user, role)}
    >
      <View className="flex-row items-center">
        <View className={cn("w-12 h-12 rounded-full items-center justify-center mr-4", getRoleColor(role))}>
          <Ionicons name={getRoleIcon(role) as any} size={24} color="white" />
        </View>
        
        <View className="flex-1">
          <Text className={cn(
            "font-semibold mb-1",
            isActive ? "text-blue-900" : "text-gray-900"
          )}>
            {user.name}
          </Text>
          <Text className={cn(
            "text-sm",
            isActive ? "text-blue-700" : "text-gray-600"
          )}>
            {user.email}
          </Text>
          {user.loyaltyPoints > 0 && (
            <Text className={cn(
              "text-xs mt-1",
              isActive ? "text-blue-600" : "text-gray-500"
            )}>
              ⭐ {user.loyaltyPoints} points
            </Text>
          )}
        </View>
        
        {isActive && (
          <View className="bg-blue-500 px-3 py-1 rounded-full">
            <Text className="text-white text-xs font-medium">ACTIVE</Text>
          </View>
        )}
      </View>
    </Pressable>
  );
}

function ToolCard({ icon, title, description, color, onPress }: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  description: string;
  color: string;
  onPress: () => void;
}) {
  return (
    <Pressable 
      className="bg-white rounded-xl p-4 border border-gray-200 active:bg-gray-50"
      onPress={onPress}
    >
      <View className="flex-row items-center">
        <View className={cn("w-12 h-12 rounded-xl items-center justify-center mr-4", color)}>
          <Ionicons name={icon} size={24} color="white" />
        </View>
        
        <View className="flex-1">
          <Text className="text-base font-semibold text-gray-900 mb-1">
            {title}
          </Text>
          <Text className="text-sm text-gray-600">
            {description}
          </Text>
        </View>
        
        <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
      </View>
    </Pressable>
  );
}

function InstructionItem({ text }: { text: string }) {
  return (
    <Text className="text-yellow-800 text-sm leading-relaxed">
      {text}
    </Text>
  );
}

function SystemSettingsModal({ visible, onClose, settings, onUpdateSettings }: {
  visible: boolean;
  onClose: () => void;
  settings: any;
  onUpdateSettings: (newSettings: any) => void;
}) {
  const toggleSetting = (key: string, value: boolean) => {
    onUpdateSettings({ [key]: value });
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View className="flex-1 bg-white">
        <View className="flex-row items-center justify-between p-4 border-b border-gray-200">
          <Text className="text-lg font-semibold">System Settings Test</Text>
          <Pressable onPress={onClose}>
            <Text className="text-blue-500 text-lg">Done</Text>
          </Pressable>
        </View>

        <ScrollView className="flex-1 p-4">
          <View className="space-y-6">
            
            <View>
              <Text className="text-lg font-semibold text-gray-900 mb-4">
                Customer Print Controls
              </Text>
              <Text className="text-gray-600 mb-4">
                Toggle which settings customers can modify:
              </Text>
              
              <View className="space-y-4">
                <SettingToggle
                  title="Allow Color Mode Toggle"
                  value={settings.allowColorToggle}
                  onToggle={(value) => toggleSetting('allowColorToggle', value)}
                />
                <SettingToggle
                  title="Allow Page Sidedness Toggle"
                  value={settings.allowSidednessToggle}
                  onToggle={(value) => toggleSetting('allowSidednessToggle', value)}
                />
                <SettingToggle
                  title="Allow Orientation Toggle"
                  value={settings.allowOrientationToggle}
                  onToggle={(value) => toggleSetting('allowOrientationToggle', value)}
                />
                <SettingToggle
                  title="Allow Copies Adjustment"
                  value={settings.allowCopiesToggle}
                  onToggle={(value) => toggleSetting('allowCopiesToggle', value)}
                />
              </View>
            </View>

            <View className="bg-blue-50 rounded-xl p-4">
              <Text className="text-blue-900 font-medium mb-2">
                💡 Testing Instructions:
              </Text>
              <Text className="text-blue-800 text-sm leading-relaxed">
                1. Toggle settings above\n2. Login as a customer\n3. Go through file upload → settings\n4. Verify toggles work as expected\n5. Disabled settings should show locked icons
              </Text>
            </View>

          </View>
        </ScrollView>
      </View>
    </Modal>
  );
}

function SettingToggle({ title, value, onToggle }: {
  title: string;
  value: boolean;
  onToggle: (value: boolean) => void;
}) {
  return (
    <View className="flex-row items-center justify-between bg-gray-50 rounded-lg p-4">
      <Text className="text-gray-900 font-medium flex-1">
        {title}
      </Text>
      <Pressable
        className={cn(
          "w-12 h-6 rounded-full p-1",
          value ? "bg-blue-500" : "bg-gray-300"
        )}
        onPress={() => onToggle(!value)}
      >
        <View className={cn(
          "w-4 h-4 rounded-full bg-white transition-transform",
          value ? "translate-x-6" : "translate-x-0"
        )} />
      </Pressable>
    </View>
  );
}