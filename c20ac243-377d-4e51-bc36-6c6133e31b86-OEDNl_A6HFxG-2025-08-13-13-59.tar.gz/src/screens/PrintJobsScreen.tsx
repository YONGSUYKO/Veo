import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, Pressable, RefreshControl, Modal, TextInput, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as DocumentPicker from 'expo-document-picker';
import { useAppStore, PrintJob } from '../state/appStore';
import { apiClient } from '../api/pisoprint-api';
import { cn } from '../utils/cn';

export default function PrintJobsScreen() {
  const insets = useSafeAreaInsets();
  const { printJobs, setPrintJobs, addPrintJob } = useAppStore();
  const [refreshing, setRefreshing] = useState(false);
  const [showNewJobModal, setShowNewJobModal] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'queue' | 'printing' | 'ready' | 'completed'>('all');

  useEffect(() => {
    loadPrintJobs();
  }, []);

  const loadPrintJobs = async () => {
    try {
      const jobs = await apiClient.getPrintJobs();
      setPrintJobs(jobs);
    } catch (error) {
      console.error('Failed to load print jobs:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadPrintJobs();
    setRefreshing(false);
  };

  const filteredJobs = printJobs.filter(job => 
    selectedFilter === 'all' || job.status === selectedFilter
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'printing': return 'bg-blue-100 text-blue-800';
      case 'ready': return 'bg-purple-100 text-purple-800';
      case 'queue': return 'bg-orange-100 text-orange-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <View className="flex-1 bg-gray-50">
      <ScrollView 
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        <View style={{ paddingTop: insets.top }} className="px-4 pb-6">
          
          {/* Header */}
          <View className="flex-row items-center justify-between mb-6">
            <View>
              <Text className="text-3xl font-bold text-gray-900 mb-2">
                Print Jobs
              </Text>
              <Text className="text-lg text-gray-600">
                Manage and track all printing requests
              </Text>
            </View>
            <Pressable 
              className="bg-blue-500 w-12 h-12 rounded-full items-center justify-center"
              onPress={() => setShowNewJobModal(true)}
            >
              <Ionicons name="add" size={24} color="white" />
            </Pressable>
          </View>

          {/* Filter Pills */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} className="mb-6">
            <View className="flex-row space-x-3 px-1">
              {[
                { key: 'all', label: 'All Jobs', count: printJobs.length },
                { key: 'queue', label: 'In Queue', count: printJobs.filter(j => j.status === 'queue').length },
                { key: 'printing', label: 'Printing', count: printJobs.filter(j => j.status === 'printing').length },
                { key: 'ready', label: 'Ready', count: printJobs.filter(j => j.status === 'ready').length },
                { key: 'completed', label: 'Completed', count: printJobs.filter(j => j.status === 'completed').length },
              ].map((filter) => (
                <Pressable
                  key={filter.key}
                  onPress={() => setSelectedFilter(filter.key as any)}
                  className={cn(
                    "px-4 py-2 rounded-full border-2",
                    selectedFilter === filter.key 
                      ? "bg-blue-500 border-blue-500" 
                      : "bg-white border-gray-200"
                  )}
                >
                  <Text className={cn(
                    "font-medium",
                    selectedFilter === filter.key ? "text-white" : "text-gray-700"
                  )}>
                    {filter.label} ({filter.count})
                  </Text>
                </Pressable>
              ))}
            </View>
          </ScrollView>

          {/* Jobs List */}
          {filteredJobs.length > 0 ? (
            <View className="space-y-3">
              {filteredJobs.map((job) => (
                <JobCard key={job.id} job={job} onStatusUpdate={loadPrintJobs} />
              ))}
            </View>
          ) : (
            <View className="bg-white rounded-xl p-8 items-center">
              <Ionicons name="document-text-outline" size={64} color="#9CA3AF" />
              <Text className="text-xl font-semibold text-gray-900 mt-4 mb-2">
                No print jobs found
              </Text>
              <Text className="text-gray-600 text-center mb-6">
                {selectedFilter === 'all' 
                  ? "Start by creating a new print job"
                  : `No jobs with status "${selectedFilter}"`
                }
              </Text>
              <Pressable 
                className="bg-blue-500 px-6 py-3 rounded-lg"
                onPress={() => setShowNewJobModal(true)}
              >
                <Text className="text-white font-medium">Create New Job</Text>
              </Pressable>
            </View>
          )}

        </View>
      </ScrollView>

      <NewJobModal 
        visible={showNewJobModal} 
        onClose={() => setShowNewJobModal(false)}
        onJobCreated={loadPrintJobs}
      />
    </View>
  );
}

function JobCard({ job, onStatusUpdate }: { job: PrintJob; onStatusUpdate: () => void }) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'printing': return 'bg-blue-100 text-blue-800';
      case 'ready': return 'bg-purple-100 text-purple-800';
      case 'queue': return 'bg-orange-100 text-orange-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const nextStatusMap: Record<string, string> = {
    queue: 'printing',
    printing: 'ready',
    ready: 'completed',
  };

  const updateJobStatus = async () => {
    const nextStatus = nextStatusMap[job.status];
    if (!nextStatus) return;

    try {
      await apiClient.updatePrintJob(job.id, { status: nextStatus as any });
      onStatusUpdate();
    } catch (error) {
      Alert.alert('Error', 'Failed to update job status');
    }
  };

  return (
    <View className="bg-white rounded-xl p-4">
      <View className="flex-row items-start justify-between mb-3">
        <View className="flex-1">
          <View className="flex-row items-center mb-2">
            <Ionicons 
              name={job.type === 'photo' ? 'camera' : 'document-text'} 
              size={20} 
              color="#6B7280" 
            />
            <Text className="text-base font-medium text-gray-900 ml-2 flex-1">
              {job.files[0]?.name || 'Unknown file'}
            </Text>
          </View>
          
          <View className="flex-row items-center space-x-4 mb-2">
            <Text className="text-sm text-gray-600">
              {job.copies} {job.copies === 1 ? 'copy' : 'copies'}
            </Text>
            <Text className="text-sm text-gray-600">
              {job.paperSize}
            </Text>
            <Text className="text-sm text-gray-600">
              {job.colorMode === 'color' ? 'Color' : 'B&W'}
            </Text>
          </View>

          {job.notes && (
            <Text className="text-sm text-gray-600 mb-2">
              Note: {job.notes}
            </Text>
          )}
        </View>

        <View className="items-end">
          <Text className={cn("px-2 py-1 rounded-full text-xs font-medium mb-2", getStatusColor(job.status))}>
            {job.status.charAt(0).toUpperCase() + job.status.slice(1)}
          </Text>
          <Text className="text-lg font-bold text-gray-900">
            ₱{(job.total / 100).toFixed(2)}
          </Text>
        </View>
      </View>

      <View className="flex-row items-center justify-between pt-3 border-t border-gray-100">
        <Text className="text-xs text-gray-500">
          {new Date(job.createdAt).toLocaleDateString()} at {new Date(job.createdAt).toLocaleTimeString()}
        </Text>
        
        {nextStatusMap[job.status] && (
          <Pressable 
            className="bg-blue-500 px-3 py-1.5 rounded-lg"
            onPress={updateJobStatus}
          >
            <Text className="text-white text-sm font-medium">
              Mark as {nextStatusMap[job.status]}
            </Text>
          </Pressable>
        )}
      </View>
    </View>
  );
}

function NewJobModal({ visible, onClose, onJobCreated }: { 
  visible: boolean; 
  onClose: () => void; 
  onJobCreated: () => void; 
}) {
  const [files, setFiles] = useState<any[]>([]);
  const [copies, setCopies] = useState('1');
  const [paperSize, setPaperSize] = useState('Letter');
  const [colorMode, setColorMode] = useState<'black_white' | 'color'>('black_white');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  const pickDocument = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ['application/pdf', 'image/*', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
        multiple: true,
      });

      if (!result.canceled) {
        setFiles(result.assets);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to pick document');
    }
  };

  const createJob = async () => {
    if (files.length === 0) {
      Alert.alert('Error', 'Please select at least one file');
      return;
    }

    setLoading(true);
    try {
      const jobData = {
        type: files.some(f => f.mimeType?.startsWith('image/')) ? 'photo' as const : 'document' as const,
        files: files.map(f => ({
          name: f.name,
          size: f.size || 0,
          type: f.mimeType || 'application/octet-stream',
          uri: f.uri
        })),
        copies: parseInt(copies),
        paperSize,
        colorMode,
        notes: notes.trim() || undefined,
        total: parseInt(copies) * (colorMode === 'color' ? 1000 : 500), // Basic pricing
        paymentStatus: 'pending' as const,
        status: 'queue' as const,
      };

      await apiClient.createPrintJob(jobData);
      onJobCreated();
      onClose();
      
      // Reset form
      setFiles([]);
      setCopies('1');
      setPaperSize('A4');
      setColorMode('black_white');
      setNotes('');
    } catch (error) {
      Alert.alert('Error', 'Failed to create print job');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View className="flex-1 bg-white">
        <View className="flex-row items-center justify-between p-4 border-b border-gray-200">
          <Pressable onPress={onClose}>
            <Text className="text-blue-500 text-lg">Cancel</Text>
          </Pressable>
          <Text className="text-lg font-semibold">New Print Job</Text>
          <Pressable onPress={createJob} disabled={loading}>
            <Text className={cn("text-lg", loading ? "text-gray-400" : "text-blue-500 font-semibold")}>
              {loading ? 'Creating...' : 'Create'}
            </Text>
          </Pressable>
        </View>

        <ScrollView className="flex-1 p-4">
          <View className="space-y-6">
            
            {/* File Selection */}
            <View>
              <Text className="text-base font-semibold text-gray-900 mb-3">Files to Print</Text>
              <Pressable 
                className="border-2 border-dashed border-gray-300 rounded-xl p-6 items-center"
                onPress={pickDocument}
              >
                <Ionicons name="cloud-upload-outline" size={48} color="#9CA3AF" />
                <Text className="text-gray-600 text-center mt-2">
                  Tap to select documents or images
                </Text>
              </Pressable>
              
              {files.length > 0 && (
                <View className="mt-3 space-y-2">
                  {files.map((file, index) => (
                    <View key={index} className="flex-row items-center bg-gray-50 rounded-lg p-3">
                      <Ionicons name="document" size={20} color="#6B7280" />
                      <Text className="text-gray-900 ml-3 flex-1">{file.name}</Text>
                      <Pressable onPress={() => setFiles(files.filter((_, i) => i !== index))}>
                        <Ionicons name="close-circle" size={20} color="#EF4444" />
                      </Pressable>
                    </View>
                  ))}
                </View>
              )}
            </View>

            {/* Print Settings */}
            <View>
              <Text className="text-base font-semibold text-gray-900 mb-3">Print Settings</Text>
              
              <View className="space-y-4">
                <View>
                  <Text className="text-sm font-medium text-gray-700 mb-2">Number of Copies</Text>
                  <TextInput
                    className="border border-gray-300 rounded-lg px-4 py-3 text-base"
                    value={copies}
                    onChangeText={setCopies}
                    keyboardType="numeric"
                    placeholder="1"
                  />
                </View>

                <View>
                  <Text className="text-sm font-medium text-gray-700 mb-2">Paper Size</Text>
                  <View className="flex-row space-x-2">
                    {['A4', 'A3', 'Letter', '4x6'].map((size) => (
                      <Pressable
                        key={size}
                        onPress={() => setPaperSize(size)}
                        className={cn(
                          "flex-1 py-3 rounded-lg border-2",
                          paperSize === size 
                            ? "bg-blue-500 border-blue-500" 
                            : "bg-white border-gray-300"
                        )}
                      >
                        <Text className={cn(
                          "text-center font-medium",
                          paperSize === size ? "text-white" : "text-gray-700"
                        )}>
                          {size}
                        </Text>
                      </Pressable>
                    ))}
                  </View>
                </View>

                <View>
                  <Text className="text-sm font-medium text-gray-700 mb-2">Color Mode</Text>
                  <View className="flex-row space-x-2">
                    <Pressable
                      onPress={() => setColorMode('black_white')}
                      className={cn(
                        "flex-1 py-3 rounded-lg border-2",
                        colorMode === 'black_white' 
                          ? "bg-blue-500 border-blue-500" 
                          : "bg-white border-gray-300"
                      )}
                    >
                      <Text className={cn(
                        "text-center font-medium",
                        colorMode === 'black_white' ? "text-white" : "text-gray-700"
                      )}>
                        Black & White
                      </Text>
                    </Pressable>
                    <Pressable
                      onPress={() => setColorMode('color')}
                      className={cn(
                        "flex-1 py-3 rounded-lg border-2",
                        colorMode === 'color' 
                          ? "bg-blue-500 border-blue-500" 
                          : "bg-white border-gray-300"
                      )}
                    >
                      <Text className={cn(
                        "text-center font-medium",
                        colorMode === 'color' ? "text-white" : "text-gray-700"
                      )}>
                        Color
                      </Text>
                    </Pressable>
                  </View>
                </View>

                <View>
                  <Text className="text-sm font-medium text-gray-700 mb-2">Notes (Optional)</Text>
                  <TextInput
                    className="border border-gray-300 rounded-lg px-4 py-3 text-base"
                    value={notes}
                    onChangeText={setNotes}
                    placeholder="Special instructions or notes"
                    multiline
                    numberOfLines={3}
                  />
                </View>
              </View>
            </View>

          </View>
        </ScrollView>
      </View>
    </Modal>
  );
}