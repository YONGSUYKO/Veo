import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, ScrollView, Pressable, Alert } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useAuthStore } from "../../state/authStore";
import { useNewAppStore } from "../../state/newAppStore";
import { newApiClient } from "../../api/newPisoAPI";

// Simplified mobile operator interface - monitoring and attendance only
export default function OperatorMobileMonitor() {
  const insets = useSafeAreaInsets();
  const { currentUser } = useAuthStore();
  const { printJobs, setPrintJobs } = useNewAppStore();
  const [isCheckedIn, setIsCheckedIn] = useState(false);
  const [shiftStart, setShiftStart] = useState<Date | null>(null);

  useEffect(() => {
    loadJobs();
    // Auto-refresh every 30 seconds for monitoring
    const interval = setInterval(loadJobs, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadJobs = async () => {
    try {
      const jobs = await newApiClient.getPrintJobs();
      setPrintJobs(jobs);
    } catch (error) {
      console.error("Failed to load jobs:", error);
    }
  };

  const handleCheckIn = () => {
    if (!isCheckedIn) {
      setIsCheckedIn(true);
      setShiftStart(new Date());
      Alert.alert("Checked In", "Your shift has started. Have a great day!");
    } else {
      Alert.alert("Check Out", "Are you sure you want to end your shift?", [
        { text: "Cancel", style: "cancel" },
        {
          text: "Check Out",
          onPress: () => {
            setIsCheckedIn(false);
            setShiftStart(null);
            Alert.alert("Checked Out", "Your shift has ended. Thank you!");
          },
        },
      ]);
    }
  };

  const getShiftDuration = () => {
    if (!shiftStart) return "Not started";
    const now = new Date();
    const diff = now.getTime() - shiftStart.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  const queueJobs = printJobs.filter(job => job.status === "queue");
  const activeJobs = printJobs.filter(job => job.status === "ongoing");
  const completedToday = printJobs.filter(job => {
    const today = new Date().toISOString().split('T')[0];
    return job.status === "completed" && job.createdAt.toISOString().split('T')[0] === today;
  });

  return (
    <ScrollView contentContainerStyle={[styles.container, { paddingTop: insets.top + 20 }]}>
      
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerIcon}>
          <Ionicons name="person-circle" size={32} color="#3B82F6" />
        </View>
        <View>
          <Text style={styles.title}>📋 Operator Monitor</Text>
          <Text style={styles.subtitle}>Welcome, {currentUser?.name || "Operator"}</Text>
        </View>
      </View>

      {/* Attendance Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>🕒 Attendance</Text>
        <View style={styles.attendanceCard}>
          <View style={styles.attendanceInfo}>
            <Text style={styles.attendanceStatus}>
              Status: {isCheckedIn ? "✅ Checked In" : "❌ Not Checked In"}
            </Text>
            {isCheckedIn && (
              <Text style={styles.shiftDuration}>
                Shift Duration: {getShiftDuration()}
              </Text>
            )}
          </View>
          <Pressable
            style={[
              styles.checkInButton,
              { backgroundColor: isCheckedIn ? "#EF4444" : "#10B981" }
            ]}
            onPress={handleCheckIn}
          >
            <Text style={styles.checkInButtonText}>
              {isCheckedIn ? "Check Out" : "Check In"}
            </Text>
          </Pressable>
        </View>
      </View>

      {/* Print Queue Overview */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>🖨 Print Queue Status</Text>
        
        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: "#FEF3C7" }]}>
            <Text style={styles.statNumber}>{queueJobs.length}</Text>
            <Text style={styles.statLabel}>In Queue</Text>
            <Ionicons name="list" size={24} color="#D97706" />
          </View>

          <View style={[styles.statCard, { backgroundColor: "#DBEAFE" }]}>
            <Text style={styles.statNumber}>{activeJobs.length}</Text>
            <Text style={styles.statLabel}>Printing</Text>
            <Ionicons name="print" size={24} color="#2563EB" />
          </View>

          <View style={[styles.statCard, { backgroundColor: "#D1FAE5" }]}>
            <Text style={styles.statNumber}>{completedToday.length}</Text>
            <Text style={styles.statLabel}>Completed Today</Text>
            <Ionicons name="checkmark-circle" size={24} color="#059669" />
          </View>
        </View>
      </View>

      {/* Recent Jobs */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>📄 Recent Jobs</Text>
        {printJobs.slice(0, 5).map((job) => (
          <View key={job.id} style={styles.jobCard}>
            <View style={styles.jobInfo}>
              <Text style={styles.jobId}>#{job.id.slice(-6)}</Text>
              <Text style={styles.jobCustomer}>{job.customerInfo.name}</Text>
            </View>
            <View style={styles.jobStatus}>
              <Text style={[
                styles.statusText,
                {
                  color: job.status === "completed" ? "#059669" :
                         job.status === "ongoing" ? "#2563EB" :
                         job.status === "ready" ? "#7C3AED" : "#D97706"
                }
              ]}>
                {job.status.charAt(0).toUpperCase() + job.status.slice(1)}
              </Text>
            </View>
          </View>
        ))}
      </View>

      {/* Note */}
      <View style={styles.noteSection}>
        <Text style={styles.noteText}>
          📱 This is a monitoring interface for mobile operators. 
          Full management features are available on desktop/kiosk systems.
        </Text>
      </View>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: "#F9FAFB",
    minHeight: "100%",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 24,
    backgroundColor: "white",
    padding: 16,
    borderRadius: 12,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  headerIcon: {
    marginRight: 12,
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#111827",
  },
  subtitle: {
    fontSize: 14,
    color: "#6B7280",
    marginTop: 2,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "600",
    color: "#374151",
    marginBottom: 12,
  },
  attendanceCard: {
    backgroundColor: "white",
    padding: 16,
    borderRadius: 12,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  attendanceInfo: {
    marginBottom: 12,
  },
  attendanceStatus: {
    fontSize: 16,
    fontWeight: "600",
    color: "#374151",
  },
  shiftDuration: {
    fontSize: 14,
    color: "#6B7280",
    marginTop: 4,
  },
  checkInButton: {
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: "center",
  },
  checkInButtonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "600",
  },
  statsGrid: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
  statCard: {
    flex: 1,
    padding: 16,
    borderRadius: 12,
    alignItems: "center",
    position: "relative",
  },
  statNumber: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#111827",
  },
  statLabel: {
    fontSize: 12,
    color: "#6B7280",
    marginTop: 4,
    textAlign: "center",
  },
  jobCard: {
    backgroundColor: "white",
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    elevation: 1,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
  },
  jobInfo: {
    flex: 1,
  },
  jobId: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#111827",
  },
  jobCustomer: {
    fontSize: 12,
    color: "#6B7280",
    marginTop: 2,
  },
  jobStatus: {
    alignItems: "flex-end",
  },
  statusText: {
    fontSize: 12,
    fontWeight: "600",
  },
  noteSection: {
    backgroundColor: "#EFF6FF",
    padding: 12,
    borderRadius: 8,
    marginTop: 12,
  },
  noteText: {
    fontSize: 12,
    color: "#1E40AF",
    textAlign: "center",
    lineHeight: 16,
  },
});