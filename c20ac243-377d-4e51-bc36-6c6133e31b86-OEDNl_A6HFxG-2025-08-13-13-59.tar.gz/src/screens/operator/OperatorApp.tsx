import React from "react";
import { Platform } from "react-native";
import OperatorDesktopDashboardFull from "../OperatorDesktopDashboardFull";
import OperatorMobileScreen from "../mobile/OperatorMobileScreen";
import { useDeviceInfo } from "../../utils/deviceDetection";

// OperatorApp provides full operator interface for desktop/kiosk
export default function OperatorApp() {
  const deviceInfo = useDeviceInfo();
  const isWeb = Platform.OS === "web";
  const isMobile = Platform.OS === "ios" || Platform.OS === "android";
  const isDesktop = isWeb && typeof navigator !== "undefined" && !/Mobile|Android|iP(ad|hone)/i.test(navigator.userAgent);
  const isKiosk = typeof window !== "undefined" && window.innerWidth >= 1024 && window.innerHeight <= 800;

  // Mobile gets mobile operator interface
  if (isMobile || deviceInfo.isMobile) {
    return <OperatorMobileScreen />;
  }

  // Desktop/Kiosk gets FULL desktop interface with all features
  return (
    <OperatorDesktopDashboardFull 
      onSwitchToCustomer={() => {
        // In kiosk mode, this would switch to customer interface
        console.log("Switch to customer interface requested");
      }}
    />
  );
}