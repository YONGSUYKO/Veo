import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, ScrollView, TextInput, Alert, Animated, Dimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuthStore, UserRole } from '../state/authStore';
import { newApiClient } from '../api/newPisoAPI';
import { cn } from '../utils/cn';

interface ModernRoleSelectionScreenProps {
  onRoleSelected: () => void;
}

const { width } = Dimensions.get('window');

export default function ModernRoleSelectionScreen({ onRoleSelected }: ModernRoleSelectionScreenProps) {
  const insets = useSafeAreaInsets();
  const { login } = useAuthStore();
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState<'role' | 'email' | 'loading'>('role');
  
  // Animations
  const [fadeAnim] = useState(new Animated.Value(0));
  const [slideAnim] = useState(new Animated.Value(50));
  const [logoAnim] = useState(new Animated.Value(0));

  useEffect(() => {
    // Smooth entrance animation
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();

    // Logo pulse animation
    const pulseAnimation = () => {
      Animated.sequence([
        Animated.timing(logoAnim, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true,
        }),
        Animated.timing(logoAnim, {
          toValue: 0,
          duration: 2000,
          useNativeDriver: true,
        }),
      ]).start(() => pulseAnimation());
    };
    pulseAnimation();
  }, []);

  const roles: Array<{
    id: UserRole;
    title: string;
    description: string;
    icon: keyof typeof Ionicons.glyphMap;
    gradient: string[];
    defaultEmail: string;
    features: string[];
  }> = [
    {
      id: 'customer',
      title: "I'm a Customer",
      description: 'I want to print documents, photos, and more',
      icon: 'person',
      gradient: ['#667eea', '#764ba2'],
      defaultEmail: 'customer@example.com',
      features: ['Place orders', 'Track printing', 'Loyalty rewards', 'Multiple payment options'],
    },
    {
      id: 'operator',
      title: 'Store Staff',
      description: 'I work here and help customers',
      icon: 'construct',
      gradient: ['#4facfe', '#00f2fe'],
      defaultEmail: 'staff@pisoprint.com',
      features: ['Process orders', 'Manage queue', 'Customer support', 'Quality control'],
    },
    {
      id: 'admin',
      title: 'Administrator',
      description: 'I manage the store operations',
      icon: 'shield-checkmark',
      gradient: ['#fa709a', '#fee140'],
      defaultEmail: 'admin@pisoprint.com',
      features: ['Full access', 'Settings control', 'Analytics', 'Staff management'],
    },
  ];

  const handleRoleSelect = (role: UserRole) => {
    setSelectedRole(role);
    const roleData = roles.find(r => r.id === role);
    if (roleData) {
      setEmail(roleData.defaultEmail);
    }
    
    // Smooth transition to email step
    Animated.timing(slideAnim, {
      toValue: -30,
      duration: 300,
      useNativeDriver: true,
    }).start(() => {
      setStep('email');
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }).start();
    });
  };

  const handleLogin = async () => {
    if (!selectedRole) {
      Alert.alert('Role Required', 'Please select your role to continue');
      return;
    }

    if (!email.trim()) {
      Alert.alert('Email Required', 'Please enter an email address');
      return;
    }

    if (!email.includes('@')) {
      Alert.alert('Invalid Email', 'Please enter a valid email address');
      return;
    }

    setLoading(true);
    setStep('loading');
    
    // Show loading animation
    Animated.timing(slideAnim, {
      toValue: -50,
      duration: 400,
      useNativeDriver: true,
    }).start();

    try {
      const user = await newApiClient.authenticateUser(email.trim(), selectedRole);
      
      // Success animation
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      login(user);
      onRoleSelected();
    } catch (error) {
      setStep('email');
      setLoading(false);
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }).start();
      Alert.alert('Authentication Error', 'Failed to authenticate. Please try again.');
    }
  };

  const goBack = () => {
    Animated.timing(slideAnim, {
      toValue: 30,
      duration: 300,
      useNativeDriver: true,
    }).start(() => {
      setStep('role');
      setSelectedRole(null);
      setEmail('');
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }).start();
    });
  };

  return (
    <View className="flex-1" style={{ backgroundColor: '#0F0F23' }}>
      {/* Dynamic Background */}
      <LinearGradient
        colors={['#667eea', '#764ba2', '#f093fb']}
        locations={[0, 0.5, 1]}
        className="absolute inset-0"
      />
      
      {/* Glassmorphism Overlay */}
      <View className="absolute inset-0" style={{ backgroundColor: 'rgba(0,0,0,0.1)' }} />

      <Animated.ScrollView
        style={{ 
          opacity: fadeAnim,
          transform: [{ translateY: slideAnim }]
        }}
        className="flex-1"
        showsVerticalScrollIndicator={false}
      >
        <View style={{ paddingTop: insets.top + 60 }} className="px-6 pb-12">
          
          {/* Animated Logo */}
          <Animated.View 
            className="items-center mb-12"
            style={{
              transform: [{
                scale: logoAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [1, 1.05],
                })
              }]
            }}
          >
            <LinearGradient
              colors={['#FF6B6B', '#4ECDC4', '#45B7D1']}
              className="w-28 h-28 rounded-3xl items-center justify-center mb-6"
              style={{
                shadowColor: '#FFFFFF',
                shadowOffset: { width: 0, height: 0 },
                shadowOpacity: 0.3,
                shadowRadius: 20,
                elevation: 15,
              }}
            >
              <Ionicons name="print" size={56} color="white" />
            </LinearGradient>
            
            <Text className="text-5xl font-black text-white mb-2" style={{ fontFamily: 'System' }}>
              PISO Print
            </Text>
            <Text className="text-3xl font-light text-white/90" style={{ fontFamily: 'System' }}>
              Express
            </Text>
            <Text className="text-white/70 text-lg mt-2 font-medium">
              Print • Scan • Deliver • Repeat
            </Text>
          </Animated.View>

          {/* Role Selection Step */}
          {step === 'role' && (
            <Animated.View style={{ opacity: fadeAnim }}>
              <View className="text-center mb-8">
                <Text className="text-3xl font-black text-white mb-3 text-center">
                  Welcome! ✨
                </Text>
                <Text className="text-white/80 text-xl leading-relaxed text-center">
                  Who are you today?
                </Text>
              </View>

              <View className="space-y-6">
                {roles.map((role, index) => (
                  <ModernRoleCard
                    key={role.id}
                    role={role}
                    selected={selectedRole === role.id}
                    delay={index * 200}
                    onPress={() => handleRoleSelect(role.id)}
                  />
                ))}
              </View>

              {/* Demo Badge */}
              <View 
                className="mt-8 p-4 rounded-2xl border border-yellow-400/30"
                style={{ backgroundColor: 'rgba(252,211,77,0.15)' }}
              >
                <View className="flex-row items-center">
                  <Text className="text-2xl mr-3">🚀</Text>
                  <View className="flex-1">
                    <Text className="text-yellow-200 font-bold mb-1">
                      Demo Mode Active
                    </Text>
                    <Text className="text-yellow-100/80 text-sm">
                      Full-featured demonstration • All features available • Safe to test
                    </Text>
                  </View>
                </View>
              </View>
            </Animated.View>
          )}

          {/* Email Input Step */}
          {step === 'email' && selectedRole && (
            <Animated.View style={{ opacity: fadeAnim }}>
              <View className="mb-8">
                <Pressable onPress={goBack} className="flex-row items-center mb-6">
                  <Ionicons name="arrow-back" size={24} color="white" />
                  <Text className="text-white font-semibold ml-3 text-lg">Back</Text>
                </Pressable>

                <Text className="text-3xl font-black text-white mb-3 text-center">
                  Almost there! 🎉
                </Text>
                <Text className="text-white/80 text-xl leading-relaxed text-center mb-8">
                  Enter your email to continue
                </Text>

                {/* Selected Role Display */}
                <View 
                  className="rounded-2xl p-5 mb-8 border border-white/20"
                  style={{ backgroundColor: 'rgba(255,255,255,0.15)' }}
                >
                  <View className="flex-row items-center">
                    <LinearGradient
                      colors={(roles.find(r => r.id === selectedRole)?.gradient || ['#667eea', '#764ba2']) as any}
                      className="w-16 h-16 rounded-2xl items-center justify-center mr-4"
                    >
                      <Ionicons 
                        name={roles.find(r => r.id === selectedRole)?.icon || 'person'} 
                        size={28} 
                        color="white" 
                      />
                    </LinearGradient>
                    <View className="flex-1">
                      <Text className="text-white font-bold text-xl">
                        {roles.find(r => r.id === selectedRole)?.title}
                      </Text>
                      <Text className="text-white/70 font-medium">
                        {roles.find(r => r.id === selectedRole)?.description}
                      </Text>
                    </View>
                  </View>
                </View>

                {/* Email Input */}
                <View className="space-y-6">
                  <View>
                    <Text className="text-white font-bold text-lg mb-4">
                      📧 Email Address
                    </Text>
                    <View 
                      className="rounded-2xl border border-white/30 overflow-hidden"
                      style={{ backgroundColor: 'rgba(255,255,255,0.1)' }}
                    >
                      <TextInput
                        className="px-6 py-5 text-white text-lg font-medium"
                        value={email}
                        onChangeText={setEmail}
                        placeholder="Enter your email address"
                        placeholderTextColor="rgba(255,255,255,0.6)"
                        keyboardType="email-address"
                        autoCapitalize="none"
                        autoComplete="email"
                        accessibilityLabel="Email address input"
                        accessibilityHint="Enter your email to continue"
                      />
                    </View>
                    <Text className="text-white/60 text-sm mt-2 leading-relaxed">
                      {selectedRole === 'customer' 
                        ? '✨ Use any email for demo • All features unlocked'
                        : '🔑 Demo credentials pre-filled • Ready to test'
                      }
                    </Text>
                  </View>

                  {/* Continue Button */}
                  <Pressable 
                    onPress={handleLogin}
                    className="rounded-2xl overflow-hidden"
                    accessibilityRole="button"
                    accessibilityLabel="Continue to app"
                  >
                    <LinearGradient
                      colors={['#4facfe', '#00f2fe']}
                      className="py-5 items-center"
                    >
                      <Text className="text-white font-black text-xl">
                        Continue as {roles.find(r => r.id === selectedRole)?.title.split(' ')[0]} ✨
                      </Text>
                    </LinearGradient>
                  </Pressable>
                </View>
              </View>
            </Animated.View>
          )}

          {/* Loading Step */}
          {step === 'loading' && (
            <Animated.View 
              className="items-center justify-center py-20"
              style={{ opacity: fadeAnim }}
            >
              <Animated.View
                style={{
                  transform: [{
                    rotate: logoAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: ['0deg', '360deg'],
                    })
                  }]
                }}
              >
                <LinearGradient
                  colors={['#4facfe', '#00f2fe']}
                  className="w-24 h-24 rounded-full items-center justify-center mb-8"
                >
                  <Ionicons name="flash" size={48} color="white" />
                </LinearGradient>
              </Animated.View>
              
              <Text className="text-white font-black text-2xl mb-2">
                Setting up your experience...
              </Text>
              <Text className="text-white/70 text-lg text-center">
                Just a moment! ✨
              </Text>
            </Animated.View>
          )}

        </View>
      </Animated.ScrollView>
    </View>
  );
}

interface ModernRoleCardProps {
  role: {
    id: UserRole;
    title: string;
    description: string;
    icon: keyof typeof Ionicons.glyphMap;
    gradient: string[];
    features: string[];
  };
  selected: boolean;
  delay: number;
  onPress: () => void;
}

function ModernRoleCard({ role, selected, delay, onPress }: ModernRoleCardProps) {
  const [animValue] = useState(new Animated.Value(0));
  const [pressAnim] = useState(new Animated.Value(1));

  useEffect(() => {
    setTimeout(() => {
      Animated.timing(animValue, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }).start();
    }, delay);
  }, []);

  const handlePress = () => {
    Animated.sequence([
      Animated.timing(pressAnim, {
        toValue: 0.96,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(pressAnim, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();
    
    setTimeout(onPress, 150);
  };

  return (
    <Animated.View
      style={{
        opacity: animValue,
        transform: [
          { scale: pressAnim },
          { 
            translateY: animValue.interpolate({
              inputRange: [0, 1],
              outputRange: [50, 0],
            })
          }
        ],
      }}
    >
      <Pressable 
        onPress={handlePress}
        accessibilityRole="button"
        accessibilityLabel={`${role.title}: ${role.description}`}
        accessibilityHint="Tap to select this role"
      >
        <LinearGradient
          colors={[role.gradient[0], role.gradient[1], role.gradient[0]] as any}
          locations={[0, 0.8, 1]}
          className="rounded-3xl p-6 border border-white/20"
        >
          <View className="flex-row items-center mb-4">
            <View className="w-20 h-20 bg-white/20 rounded-3xl items-center justify-center mr-5">
              <Ionicons name={role.icon} size={36} color="white" />
            </View>
            
            <View className="flex-1">
              <Text className="text-white font-black text-2xl mb-1">
                {role.title}
              </Text>
              <Text className="text-white/80 font-medium text-base leading-relaxed">
                {role.description}
              </Text>
            </View>
          </View>

          {/* Features */}
          <View className="flex-row flex-wrap">
            {role.features.slice(0, 2).map((feature, index) => (
              <View 
                key={index}
                className="bg-white/20 rounded-full px-3 py-1 mr-2 mb-2"
              >
                <Text className="text-white/90 text-sm font-semibold">
                  {feature}
                </Text>
              </View>
            ))}
            <View className="bg-white/10 rounded-full px-3 py-1">
              <Text className="text-white/70 text-sm font-medium">
                +{role.features.length - 2} more
              </Text>
            </View>
          </View>

          {/* Arrow */}
          <View className="absolute top-6 right-6">
            <View className="w-10 h-10 bg-white/20 rounded-xl items-center justify-center">
              <Ionicons name="arrow-forward" size={20} color="white" />
            </View>
          </View>
        </LinearGradient>
      </Pressable>
    </Animated.View>
  );
}