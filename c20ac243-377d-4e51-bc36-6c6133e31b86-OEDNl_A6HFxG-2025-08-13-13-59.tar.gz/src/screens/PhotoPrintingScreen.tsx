import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, Pressable, RefreshControl, Modal, Alert, Image } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { useAppStore, PhotoSize } from '../state/appStore';
import { apiClient } from '../api/pisoprint-api';
import { cn } from '../utils/cn';

export default function PhotoPrintingScreen() {
  const insets = useSafeAreaInsets();
  const { photoSizes, setPhotoSizes, addPrintJob } = useAppStore();
  const [refreshing, setRefreshing] = useState(false);
  const [showOrderModal, setShowOrderModal] = useState(false);

  useEffect(() => {
    loadPhotoSizes();
  }, []);

  const loadPhotoSizes = async () => {
    try {
      const sizes = await apiClient.getPhotoSizes();
      setPhotoSizes(sizes);
    } catch (error) {
      console.error('Failed to load photo sizes:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadPhotoSizes();
    setRefreshing(false);
  };

  return (
    <View className="flex-1 bg-gray-50">
      <ScrollView 
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        <View style={{ paddingTop: insets.top }} className="px-4 pb-6">
          
          {/* Header */}
          <View className="flex-row items-center justify-between mb-6">
            <View>
              <Text className="text-3xl font-bold text-gray-900 mb-2">
                Photo Printing
              </Text>
              <Text className="text-lg text-gray-600">
                Professional photo printing in various sizes
              </Text>
            </View>
            <Pressable 
              className="bg-blue-500 w-12 h-12 rounded-full items-center justify-center"
              onPress={() => setShowOrderModal(true)}
            >
              <Ionicons name="camera" size={24} color="white" />
            </Pressable>
          </View>

          {/* Quick Actions */}
          <View className="mb-6">
            <Text className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</Text>
            <View className="flex-row space-x-3">
              <QuickActionCard 
                title="Take Photo"
                subtitle="Use camera to capture"
                icon="camera"
                color="bg-blue-500"
                onPress={() => setShowOrderModal(true)}
              />
              <QuickActionCard 
                title="From Gallery"
                subtitle="Select from photos"
                icon="images"
                color="bg-green-500"
                onPress={() => setShowOrderModal(true)}
              />
            </View>
          </View>

          {/* Photo Sizes */}
          <View>
            <Text className="text-xl font-semibold text-gray-900 mb-4">Available Sizes & Prices</Text>
            <View className="space-y-3">
              {photoSizes.map((size) => (
                <PhotoSizeCard 
                  key={size.id} 
                  size={size} 
                  onOrder={() => setShowOrderModal(true)}
                />
              ))}
            </View>
          </View>

        </View>
      </ScrollView>

      <PhotoOrderModal 
        visible={showOrderModal} 
        onClose={() => setShowOrderModal(false)}
        photoSizes={photoSizes}
      />
    </View>
  );
}

interface QuickActionCardProps {
  title: string;
  subtitle: string;
  icon: keyof typeof Ionicons.glyphMap;
  color: string;
  onPress: () => void;
}

function QuickActionCard({ title, subtitle, icon, color, onPress }: QuickActionCardProps) {
  return (
    <Pressable className="flex-1" onPress={onPress}>
      <View className="bg-white rounded-xl p-4">
        <View className={cn("w-12 h-12 rounded-lg items-center justify-center mb-3", color)}>
          <Ionicons name={icon} size={24} color="white" />
        </View>
        <Text className="text-base font-semibold text-gray-900 mb-1">{title}</Text>
        <Text className="text-sm text-gray-600">{subtitle}</Text>
      </View>
    </Pressable>
  );
}

function PhotoSizeCard({ size, onOrder }: { size: PhotoSize; onOrder: () => void }) {
  return (
    <View className="bg-white rounded-xl p-4">
      <View className="flex-row items-center justify-between">
        <View className="flex-1">
          <Text className="text-lg font-semibold text-gray-900 mb-1">
            {size.name}
          </Text>
          <Text className="text-sm text-gray-600 mb-2">
            {size.width}" × {size.height}" {size.unit}
          </Text>
          <Text className="text-sm text-gray-500">
            Perfect for {size.name.toLowerCase().includes('id') ? 'identification documents' : 'memories and framing'}
          </Text>
        </View>
        
        <View className="items-end">
          <Text className="text-2xl font-bold text-gray-900 mb-2">
            ₱{(size.price / 100).toFixed(2)}
          </Text>
          <Pressable 
            className="bg-blue-500 px-4 py-2 rounded-lg"
            onPress={onOrder}
          >
            <Text className="text-white font-medium">Order Now</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}

function PhotoOrderModal({ visible, onClose, photoSizes }: { 
  visible: boolean; 
  onClose: () => void; 
  photoSizes: PhotoSize[];
}) {
  const [selectedPhotos, setSelectedPhotos] = useState<any[]>([]);
  const [selectedSize, setSelectedSize] = useState<PhotoSize | null>(null);
  const [copies, setCopies] = useState(1);
  const [loading, setLoading] = useState(false);
  const { addPrintJob } = useAppStore();

  const pickImage = async (fromCamera: boolean = false) => {
    try {
      const result = fromCamera 
        ? await ImagePicker.launchCameraAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            allowsEditing: true,
            quality: 1,
          })
        : await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            allowsMultipleSelection: true,
            quality: 1,
          });

      if (!result.canceled) {
        setSelectedPhotos(result.assets);
        if (photoSizes.length > 0 && !selectedSize) {
          setSelectedSize(photoSizes[0]);
        }
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to select image');
    }
  };

  const createOrder = async () => {
    if (selectedPhotos.length === 0) {
      Alert.alert('Error', 'Please select at least one photo');
      return;
    }

    if (!selectedSize) {
      Alert.alert('Error', 'Please select a photo size');
      return;
    }

    setLoading(true);
    try {
      const jobData = {
        type: 'photo' as const,
        files: selectedPhotos.map(photo => ({
          name: `photo_${Date.now()}.jpg`,
          size: 0,
          type: 'image/jpeg',
          uri: photo.uri
        })),
        copies,
        paperSize: selectedSize.name,
        colorMode: 'color' as const,
        total: selectedSize.price * copies * selectedPhotos.length,
        paymentStatus: 'pending' as const,
        status: 'queue' as const,
      };

      await apiClient.createPrintJob(jobData);
      
      Alert.alert('Success', 'Photo print order created successfully!');
      onClose();
      
      // Reset form
      setSelectedPhotos([]);
      setSelectedSize(null);
      setCopies(1);
    } catch (error) {
      Alert.alert('Error', 'Failed to create photo order');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View className="flex-1 bg-white">
        <View className="flex-row items-center justify-between p-4 border-b border-gray-200">
          <Pressable onPress={onClose}>
            <Text className="text-blue-500 text-lg">Cancel</Text>
          </Pressable>
          <Text className="text-lg font-semibold">Photo Order</Text>
          <Pressable onPress={createOrder} disabled={loading}>
            <Text className={cn("text-lg", loading ? "text-gray-400" : "text-blue-500 font-semibold")}>
              {loading ? 'Creating...' : 'Order'}
            </Text>
          </Pressable>
        </View>

        <ScrollView className="flex-1 p-4">
          <View className="space-y-6">
            
            {/* Photo Selection */}
            <View>
              <Text className="text-base font-semibold text-gray-900 mb-3">Select Photos</Text>
              
              {selectedPhotos.length === 0 ? (
                <View className="space-y-3">
                  <Pressable 
                    className="border-2 border-dashed border-gray-300 rounded-xl p-6 items-center"
                    onPress={() => pickImage(true)}
                  >
                    <Ionicons name="camera-outline" size={48} color="#9CA3AF" />
                    <Text className="text-gray-600 text-center mt-2 font-medium">
                      Take Photo with Camera
                    </Text>
                  </Pressable>
                  
                  <Pressable 
                    className="border-2 border-dashed border-gray-300 rounded-xl p-6 items-center"
                    onPress={() => pickImage(false)}
                  >
                    <Ionicons name="images-outline" size={48} color="#9CA3AF" />
                    <Text className="text-gray-600 text-center mt-2 font-medium">
                      Choose from Gallery
                    </Text>
                  </Pressable>
                </View>
              ) : (
                <View>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false} className="mb-3">
                    <View className="flex-row space-x-3">
                      {selectedPhotos.map((photo, index) => (
                        <View key={index} className="relative">
                          <Image 
                            source={{ uri: photo.uri }}
                            className="w-20 h-20 rounded-lg"
                          />
                          <Pressable 
                            className="absolute -top-2 -right-2 bg-red-500 w-6 h-6 rounded-full items-center justify-center"
                            onPress={() => setSelectedPhotos(selectedPhotos.filter((_, i) => i !== index))}
                          >
                            <Ionicons name="close" size={14} color="white" />
                          </Pressable>
                        </View>
                      ))}
                    </View>
                  </ScrollView>
                  
                  <Pressable 
                    className="bg-blue-50 border border-blue-200 rounded-lg p-3 flex-row items-center justify-center"
                    onPress={() => pickImage(false)}
                  >
                    <Ionicons name="add" size={20} color="#3B82F6" />
                    <Text className="text-blue-600 font-medium ml-2">Add More Photos</Text>
                  </Pressable>
                </View>
              )}
            </View>

            {/* Size Selection */}
            {selectedPhotos.length > 0 && (
              <View>
                <Text className="text-base font-semibold text-gray-900 mb-3">Select Size</Text>
                <View className="space-y-2">
                  {photoSizes.map((size) => (
                    <Pressable
                      key={size.id}
                      onPress={() => setSelectedSize(size)}
                      className={cn(
                        "border-2 rounded-xl p-4",
                        selectedSize?.id === size.id
                          ? "bg-blue-50 border-blue-500"
                          : "bg-white border-gray-200"
                      )}
                    >
                      <View className="flex-row items-center justify-between">
                        <View>
                          <Text className={cn(
                            "font-semibold",
                            selectedSize?.id === size.id ? "text-blue-900" : "text-gray-900"
                          )}>
                            {size.name}
                          </Text>
                          <Text className={cn(
                            "text-sm",
                            selectedSize?.id === size.id ? "text-blue-700" : "text-gray-600"
                          )}>
                            {size.width}" × {size.height}"
                          </Text>
                        </View>
                        <Text className={cn(
                          "text-lg font-bold",
                          selectedSize?.id === size.id ? "text-blue-900" : "text-gray-900"
                        )}>
                          ₱{(size.price / 100).toFixed(2)}
                        </Text>
                      </View>
                    </Pressable>
                  ))}
                </View>
              </View>
            )}

            {/* Copies */}
            {selectedSize && (
              <View>
                <Text className="text-base font-semibold text-gray-900 mb-3">
                  Copies per Photo
                </Text>
                <View className="flex-row items-center space-x-4">
                  <Pressable 
                    className="w-12 h-12 bg-gray-100 rounded-full items-center justify-center"
                    onPress={() => setCopies(Math.max(1, copies - 1))}
                  >
                    <Ionicons name="remove" size={20} color="#374151" />
                  </Pressable>
                  
                  <Text className="text-2xl font-bold text-gray-900 min-w-12 text-center">
                    {copies}
                  </Text>
                  
                  <Pressable 
                    className="w-12 h-12 bg-gray-100 rounded-full items-center justify-center"
                    onPress={() => setCopies(copies + 1)}
                  >
                    <Ionicons name="add" size={20} color="#374151" />
                  </Pressable>
                </View>
              </View>
            )}

            {/* Order Summary */}
            {selectedSize && selectedPhotos.length > 0 && (
              <View className="bg-gray-50 rounded-xl p-4">
                <Text className="text-base font-semibold text-gray-900 mb-3">Order Summary</Text>
                <View className="space-y-2">
                  <View className="flex-row justify-between">
                    <Text className="text-gray-600">{selectedPhotos.length} photo(s)</Text>
                    <Text className="text-gray-900">₱{((selectedSize.price * selectedPhotos.length) / 100).toFixed(2)}</Text>
                  </View>
                  <View className="flex-row justify-between">
                    <Text className="text-gray-600">{copies} copies each</Text>
                    <Text className="text-gray-900">×{copies}</Text>
                  </View>
                  <View className="h-px bg-gray-200 my-2" />
                  <View className="flex-row justify-between">
                    <Text className="text-lg font-semibold text-gray-900">Total</Text>
                    <Text className="text-lg font-bold text-gray-900">
                      ₱{((selectedSize.price * copies * selectedPhotos.length) / 100).toFixed(2)}
                    </Text>
                  </View>
                </View>
              </View>
            )}

          </View>
        </ScrollView>
      </View>
    </Modal>
  );
}