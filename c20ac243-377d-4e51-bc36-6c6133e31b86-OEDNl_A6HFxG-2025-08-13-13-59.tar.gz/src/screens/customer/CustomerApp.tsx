import React from "react";
import { Platform } from "react-native";
import CustomerMobileApp from "../../apps/CustomerMobileApp";
import CustomerDesktopApp from "../CustomerDesktopApp"; // Would need to create this
import { useDeviceInfo } from "../../utils/deviceDetection";

// CustomerApp routes to appropriate interface based on platform
export default function CustomerApp() {
  const deviceInfo = useDeviceInfo();
  const isWeb = Platform.OS === "web";
  const isMobile = Platform.OS === "ios" || Platform.OS === "android";
  const isDesktop = isWeb && typeof navigator !== "undefined" && !/Mobile|Android|iP(ad|hone)/i.test(navigator.userAgent);
  const isKiosk = typeof window !== "undefined" && window.innerWidth >= 1024 && window.innerHeight <= 800;

  // Mobile platforms get mobile app
  if (isMobile || deviceInfo.isMobile) {
    return <CustomerMobileApp />;
  }

  // Desktop/Web gets kiosk interface for now
  // In the future, could have separate desktop interface
  return <CustomerMobileApp />;
}