import React, { useState } from 'react';
import { View, Text, Pressable, ScrollView, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';

interface TempDashboardTesterProps {
  onDashboardSelect?: (dashboardType: 'customer' | 'operator' | 'admin') => void;
  navigation?: any;
}

export default function TempDashboardTester({ onDashboardSelect, navigation }: TempDashboardTesterProps) {
  const insets = useSafeAreaInsets();
  const { login } = useAuthStore();

  const mockUsers = {
    customer: {
      id: 'customer-1',
      email: 'customer@gmail.com',
      name: 'John Customer',
      role: 'customer' as const,
      loyaltyPoints: 250,
    },
    operator: {
      id: 'operator-1',
      email: 'staff@pisoprint.com',
      name: 'Store Operator',
      role: 'operator' as const,
      loyaltyPoints: 0,
    },
    admin: {
      id: 'admin-1',
      email: 'admin@pisoprint.com',
      name: 'Admin User',
      role: 'admin' as const,
      loyaltyPoints: 0,
    },
  };

  const handleDashboardAccess = (type: 'customer' | 'operator' | 'admin') => {
    const user = mockUsers[type];
    login(user);
    
    // Navigate to appropriate screen based on type
    if (type === 'customer') {
      navigation?.navigate('HomeMain');
    } else if (type === 'operator') {
      navigation?.navigate('OperatorMobile');
    } else if (type === 'admin') {
      navigation?.navigate('AdminMobile');
    }
    
    if (onDashboardSelect) {
      onDashboardSelect(type);
    }
  };

  const dashboards = [
    {
      id: 'customer',
      title: 'Customer Mobile App',
      subtitle: 'Browse & order services',
      icon: 'phone-portrait',
      color: '#3B82F6',
      description: 'Mobile customer experience with service browsing, file upload, and order tracking',
      features: ['Service Browser', 'File Upload', 'Order Tracking', 'Payment System', 'Loyalty Points']
    },
    {
      id: 'operator',
      title: 'Operator Dashboard',
      subtitle: 'Store management',
      icon: 'storefront',
      color: '#10B981',
      description: 'Store operator interface for managing orders, customers, and day-to-day operations',
      features: ['Order Management', 'Customer Chat', 'Payment Processing', 'Inventory', 'Reports']
    },
    {
      id: 'admin',
      title: 'Admin Dashboard',
      subtitle: 'System administration',
      icon: 'settings',
      color: '#7C3AED',
      description: 'System administrator panel for managing users, settings, and business analytics',
      features: ['User Management', 'System Settings', 'Analytics', 'Franchise Management', 'Financial Reports']
    }
  ];

  return (
    <View style={{ flex: 1, backgroundColor: '#F3F4F6' }}>
      <ScrollView contentContainerStyle={{ paddingBottom: 20 }}>
        
        {/* Header */}
        <View style={{
          backgroundColor: '#1F2937',
          paddingTop: insets.top + 20,
          paddingHorizontal: 24,
          paddingBottom: 32,
        }}>
          <View style={{ alignItems: 'center', marginBottom: 20 }}>
            <View style={{
              width: 80,
              height: 80,
              backgroundColor: 'rgba(255,255,255,0.1)',
              borderRadius: 40,
              alignItems: 'center',
              justifyContent: 'center',
              marginBottom: 16,
            }}>
              <Ionicons name="build" size={40} color="white" />
            </View>
            <Text style={{
              fontSize: 24,
              fontWeight: 'bold',
              color: 'white',
              textAlign: 'center',
              marginBottom: 8,
            }}>
              Dashboard Tester
            </Text>
            <Text style={{
              fontSize: 14,
              color: 'rgba(255,255,255,0.8)',
              textAlign: 'center',
              lineHeight: 20,
            }}>
              Temporary access to test all dashboards on mobile device
            </Text>
          </View>

          <View style={{
            backgroundColor: 'rgba(239, 68, 68, 0.1)',
            borderWidth: 1,
            borderColor: 'rgba(239, 68, 68, 0.3)',
            borderRadius: 8,
            padding: 12,
          }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 4 }}>
              <Ionicons name="warning" size={16} color="#EF4444" />
              <Text style={{ 
                fontSize: 12, 
                color: '#EF4444', 
                fontWeight: '600',
                marginLeft: 6,
              }}>
                TESTING ONLY
              </Text>
            </View>
            <Text style={{
              fontSize: 11,
              color: 'rgba(255,255,255,0.7)',
              lineHeight: 16,
            }}>
              This bypasses normal authentication. Remove before production deployment.
            </Text>
          </View>
        </View>

        {/* Dashboard Options */}
        <View style={{ paddingHorizontal: 24, marginTop: 24 }}>
          <Text style={{
            fontSize: 18,
            fontWeight: 'bold',
            color: '#111827',
            marginBottom: 16,
          }}>
            Select Dashboard to Test
          </Text>

          {dashboards.map((dashboard) => (
            <DashboardCard
              key={dashboard.id}
              dashboard={dashboard}
              onPress={() => handleDashboardAccess(dashboard.id as any)}
            />
          ))}
        </View>

        {/* Instructions */}
        <View style={{ 
          paddingHorizontal: 24, 
          marginTop: 32,
        }}>
          <View style={{
            backgroundColor: '#EFF6FF',
            borderRadius: 12,
            padding: 16,
          }}>
            <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
              <Ionicons name="information-circle" size={20} color="#3B82F6" />
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={{
                  fontSize: 14,
                  fontWeight: '600',
                  color: '#1E40AF',
                  marginBottom: 4,
                }}>
                  How to Test
                </Text>
                <Text style={{
                  fontSize: 12,
                  color: '#1D4ED8',
                  lineHeight: 18,
                }}>
                  1. Select any dashboard above{'\n'}
                  2. You'll be auto-logged in with test credentials{'\n'}
                  3. The interface will adapt to your phone screen{'\n'}
                  4. All features will be functional for testing{'\n'}
                  5. Return here to switch dashboards
                </Text>
              </View>
            </View>
          </View>
        </View>

        {/* Return Button */}
        <View style={{ paddingHorizontal: 24, marginTop: 20 }}>
          <Pressable
            onPress={() => navigation?.navigate('HomeMain')}
            style={{
              backgroundColor: '#6B7280',
              borderRadius: 12,
              padding: 16,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Ionicons name="arrow-back" size={20} color="white" />
            <Text style={{
              color: 'white',
              fontSize: 16,
              fontWeight: '600',
              marginLeft: 8,
            }}>
              Back to Customer App
            </Text>
          </Pressable>
        </View>

      </ScrollView>
    </View>
  );
}

function DashboardCard({ dashboard, onPress }: { 
  dashboard: any; 
  onPress: () => void;
}) {
  const [showDetails, setShowDetails] = useState(false);

  return (
    <View style={{
      backgroundColor: 'white',
      borderRadius: 16,
      marginBottom: 16,
      elevation: 2,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
    }}>
      <Pressable
        onPress={onPress}
        style={({ pressed }) => ({
          padding: 20,
          opacity: pressed ? 0.95 : 1,
          transform: pressed ? [{ scale: 0.98 }] : [{ scale: 1 }],
        })}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
          <View style={{
            width: 56,
            height: 56,
            backgroundColor: `${dashboard.color}20`,
            borderRadius: 28,
            alignItems: 'center',
            justifyContent: 'center',
            marginRight: 16,
          }}>
            <Ionicons name={dashboard.icon} size={28} color={dashboard.color} />
          </View>
          
          <View style={{ flex: 1 }}>
            <Text style={{
              fontSize: 18,
              fontWeight: 'bold',
              color: '#111827',
              marginBottom: 4,
            }}>
              {dashboard.title}
            </Text>
            <Text style={{
              fontSize: 14,
              color: '#6B7280',
            }}>
              {dashboard.subtitle}
            </Text>
          </View>

          <Pressable
            onPress={(e) => {
              e.stopPropagation();
              setShowDetails(!showDetails);
            }}
            style={{ padding: 4 }}
          >
            <Ionicons 
              name={showDetails ? "chevron-up" : "chevron-down"} 
              size={20} 
              color="#9CA3AF" 
            />
          </Pressable>
        </View>

        <Text style={{
          fontSize: 14,
          color: '#4B5563',
          lineHeight: 20,
          marginBottom: 16,
        }}>
          {dashboard.description}
        </Text>

        {showDetails && (
          <View style={{ marginBottom: 16 }}>
            <Text style={{
              fontSize: 14,
              fontWeight: '600',
              color: '#374151',
              marginBottom: 8,
            }}>
              Key Features:
            </Text>
            {dashboard.features.map((feature: string, index: number) => (
              <View key={index} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 4 }}>
                <View style={{
                  width: 4,
                  height: 4,
                  backgroundColor: dashboard.color,
                  borderRadius: 2,
                  marginRight: 8,
                }} />
                <Text style={{
                  fontSize: 13,
                  color: '#6B7280',
                }}>
                  {feature}
                </Text>
              </View>
            ))}
          </View>
        )}

        <View style={{
          backgroundColor: dashboard.color,
          borderRadius: 8,
          paddingVertical: 12,
          alignItems: 'center',
        }}>
          <Text style={{
            color: 'white',
            fontSize: 16,
            fontWeight: '600',
          }}>
            Access Dashboard
          </Text>
        </View>
      </Pressable>
    </View>
  );
}