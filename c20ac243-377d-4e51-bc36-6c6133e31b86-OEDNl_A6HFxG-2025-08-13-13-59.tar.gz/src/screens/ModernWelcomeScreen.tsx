import React, { useEffect, useState } from 'react';
import { View, Text, Pressable, ScrollView, Animated, Dimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuthStore } from '../state/authStore';
import { useNewAppStore } from '../state/newAppStore';
import { newApiClient } from '../api/newPisoAPI';
import { cn } from '../utils/cn';

interface ModernWelcomeScreenProps {
  onServiceSelect: (service: 'document' | 'scan' | 'photo') => void;
}

const { width, height } = Dimensions.get('window');

export default function ModernWelcomeScreen({ onServiceSelect }: ModernWelcomeScreenProps) {
  const insets = useSafeAreaInsets();
  const { currentUser } = useAuthStore();
  const { questionOfTheDay, setQuestionOfTheDay } = useNewAppStore();
  
  const [fadeAnim] = useState(new Animated.Value(0));
  const [slideAnim] = useState(new Animated.Value(50));
  const [scaleAnim] = useState(new Animated.Value(0.9));

  useEffect(() => {
    loadQuestionOfTheDay();
    
    // Modern entrance animation
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 700,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const loadQuestionOfTheDay = async () => {
    try {
      const question = await newApiClient.getQuestionOfTheDay();
      setQuestionOfTheDay(question);
    } catch (error) {
      console.error('Failed to load question of the day:', error);
    }
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    let timeGreeting = '';
    let emoji = '';
    
    if (hour >= 5 && hour < 12) {
      timeGreeting = 'Good Morning';
      emoji = '☀️';
    } else if (hour >= 12 && hour < 17) {
      timeGreeting = 'Good Afternoon';
      emoji = '🌤️';
    } else if (hour >= 17 && hour < 21) {
      timeGreeting = 'Good Evening';
      emoji = '🌆';
    } else {
      timeGreeting = 'Good Night';
      emoji = '🌙';
    }

    const userName = currentUser?.name?.split(' ')[0] || 'Friend';
    return { greeting: `${timeGreeting}, ${userName}!`, emoji };
  };

  const handleServicePress = (service: 'document' | 'scan' | 'photo') => {
    // Haptic feedback simulation
    const buttonScale = new Animated.Value(1);
    
    Animated.sequence([
      Animated.timing(buttonScale, {
        toValue: 0.95,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(buttonScale, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start(() => {
      onServiceSelect(service);
    });
  };

  const { greeting, emoji } = getGreeting();

  return (
    <View className="flex-1" style={{ backgroundColor: '#0F0F23' }}>
      {/* Animated Background Gradient */}
      <LinearGradient
        colors={['#667eea', '#764ba2', '#f093fb']}
        locations={[0, 0.5, 1]}
        className="absolute inset-0"
      />
      
      {/* Glassmorphism Overlay */}
      <View className="absolute inset-0" style={{ backgroundColor: 'rgba(0,0,0,0.1)' }} />

      <Animated.ScrollView
        style={{ 
          opacity: fadeAnim,
          transform: [{ translateY: slideAnim }]
        }}
        className="flex-1"
        showsVerticalScrollIndicator={false}
      >
        <View style={{ paddingTop: insets.top + 40 }} className="px-6 pb-12">
          
          {/* Modern Header with Floating Logo */}
          <Animated.View 
            style={{ transform: [{ scale: scaleAnim }] }}
            className="items-center mb-8"
          >
            <View className="relative">
              {/* Glow effect */}
              <View 
                className="absolute inset-0 rounded-3xl" 
                style={{
                  backgroundColor: 'rgba(255,255,255,0.2)',
                  shadowColor: '#FFFFFF',
                  shadowOffset: { width: 0, height: 0 },
                  shadowOpacity: 0.3,
                  shadowRadius: 20,
                  elevation: 10,
                }}
              />
              <LinearGradient
                colors={['#FF6B6B', '#4ECDC4', '#45B7D1']}
                className="w-24 h-24 rounded-3xl items-center justify-center mb-6"
              >
                <Ionicons name="print" size={48} color="white" />
              </LinearGradient>
            </View>
            
            <Text className="text-4xl font-black text-white mb-2" style={{ fontFamily: 'System' }}>
              PISO Print
            </Text>
            <Text className="text-2xl font-light text-white/80" style={{ fontFamily: 'System' }}>
              Express
            </Text>
            <View className="flex-row items-center mt-2">
              <View className="w-2 h-2 bg-green-400 rounded-full mr-2" />
              <Text className="text-white/70 text-sm font-medium">Available 24/7</Text>
            </View>
          </Animated.View>

          {/* Dynamic Greeting Card */}
          <Animated.View 
            style={{ transform: [{ scale: scaleAnim }] }}
            className="mb-8"
          >
            <View 
              className="rounded-3xl p-6 border border-white/20"
              style={{ backgroundColor: 'rgba(255,255,255,0.15)' }}
            >
              <View className="flex-row items-center justify-between mb-4">
                <View className="flex-row items-center">
                  <Text className="text-3xl mr-3">{emoji}</Text>
                  <View>
                    <Text className="text-2xl font-bold text-white">
                      {greeting}
                    </Text>
                    <Text className="text-white/80 font-medium">
                      Ready to print something awesome?
                    </Text>
                  </View>
                </View>
                
                {/* Role Badge */}
                <View 
                  className="px-3 py-2 rounded-full border"
                  style={{ 
                    backgroundColor: currentUser?.role === 'admin' ? 'rgba(239,68,68,0.2)' :
                                   currentUser?.role === 'operator' ? 'rgba(16,185,129,0.2)' : 'rgba(59,130,246,0.2)',
                    borderColor: currentUser?.role === 'admin' ? '#EF4444' :
                                currentUser?.role === 'operator' ? '#10B981' : '#3B82F6'
                  }}
                >
                  <Text 
                    className="text-xs font-black uppercase tracking-widest"
                    style={{ 
                      color: currentUser?.role === 'admin' ? '#FEE2E2' :
                            currentUser?.role === 'operator' ? '#D1FAE5' : '#DBEAFE'
                    }}
                  >
                    {currentUser?.role || 'user'}
                  </Text>
                </View>
              </View>
              
              {/* Loyalty Points for Customers */}
              {currentUser?.role === 'customer' && currentUser.loyaltyPoints > 0 && (
                <View className="flex-row items-center">
                  <Ionicons name="star" size={20} color="#FCD34D" />
                  <Text className="text-yellow-200 font-bold ml-2">
                    {currentUser.loyaltyPoints} loyalty points
                  </Text>
                  <Text className="text-white/60 ml-2">available</Text>
                </View>
              )}
            </View>
          </Animated.View>

          {/* Question of the Day - Modern Card */}
          {questionOfTheDay && (
            <Animated.View 
              style={{ transform: [{ scale: scaleAnim }] }}
              className="mb-8"
            >
              <View 
                className="rounded-3xl p-6 border border-yellow-400/30"
                style={{ backgroundColor: 'rgba(252,211,77,0.15)' }}
              >
                <View className="flex-row items-start">
                  <View className="w-12 h-12 bg-yellow-400/20 rounded-2xl items-center justify-center mr-4">
                    <Text className="text-2xl">💡</Text>
                  </View>
                  <View className="flex-1">
                    <Text className="text-yellow-200 font-bold mb-2 text-lg">
                      💡 Pro Tip
                    </Text>
                    <Text className="text-white/90 leading-relaxed text-base">
                      {questionOfTheDay.question}
                    </Text>
                  </View>
                </View>
              </View>
            </Animated.View>
          )}

          {/* Service Gateway - Modern 3D Cards */}
          <View className="mb-8">
            <Text className="text-white font-black text-2xl mb-2">
              What's on your mind? ✨
            </Text>
            <Text className="text-white/70 mb-8 text-lg leading-relaxed">
              Choose your printing adventure
            </Text>
            
            <View className="space-y-6">
              <ModernServiceCard
                icon="document-text"
                title="Documents"
                subtitle="PDFs, Word, PowerPoint"
                description="Professional document printing with smart settings"
                gradient={['#667eea', '#764ba2']}
                delay={0}
                onPress={() => handleServicePress('document')}
              />
              
              <ModernServiceCard
                icon="scan"
                title="Scan & Print"
                subtitle="Camera capture"
                description="Scan anything and print it instantly"
                gradient={['#f093fb', '#f5576c']}
                delay={200}
                onPress={() => handleServicePress('scan')}
              />
              
              <ModernServiceCard
                icon="camera"
                title="Photos"
                subtitle="Memories & moments"
                description="High-quality photo printing in all sizes"
                gradient={['#4facfe', '#00f2fe']}
                delay={400}
                onPress={() => handleServicePress('photo')}
              />
            </View>
          </View>

          {/* Quick Stats for Staff */}
          {(currentUser?.role === 'admin' || currentUser?.role === 'operator') && (
            <Animated.View 
              style={{ transform: [{ scale: scaleAnim }] }}
              className="mb-8"
            >
              <View 
                className="rounded-3xl p-6 border border-white/10"
                style={{ backgroundColor: 'rgba(255,255,255,0.08)' }}
              >
                <Text className="text-white font-bold text-xl mb-4">
                  📊 Today's Overview
                </Text>
                <View className="flex-row justify-between">
                  <StatBubble icon="print" label="Queue" value="5" color="#FF6B6B" />
                  <StatBubble icon="checkmark-circle" label="Done" value="23" color="#4ECDC4" />
                  <StatBubble icon="trending-up" label="Revenue" value="₱1.2K" color="#45B7D1" />
                </View>
              </View>
            </Animated.View>
          )}

        </View>
      </Animated.ScrollView>

      {/* Floating Action Button for Accessibility */}
      <View className="absolute bottom-8 right-6">
        <Pressable 
          className="w-16 h-16 rounded-full items-center justify-center"
          style={{ 
            backgroundColor: 'rgba(255,255,255,0.2)',
            borderWidth: 1,
            borderColor: 'rgba(255,255,255,0.3)'
          }}
          accessibilityRole="button"
          accessibilityLabel="Voice assistance and accessibility options"
        >
          <Ionicons name="accessibility" size={28} color="white" />
        </Pressable>
      </View>
    </View>
  );
}

interface ModernServiceCardProps {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  subtitle: string;
  description: string;
  gradient: string[];
  delay: number;
  onPress: () => void;
}

function ModernServiceCard({ icon, title, subtitle, description, gradient, delay, onPress }: ModernServiceCardProps) {
  const [animValue] = useState(new Animated.Value(0));
  const [pressAnim] = useState(new Animated.Value(1));

  useEffect(() => {
    setTimeout(() => {
      Animated.timing(animValue, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }).start();
    }, delay);
  }, []);

  const handlePress = () => {
    Animated.sequence([
      Animated.timing(pressAnim, {
        toValue: 0.96,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(pressAnim, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();
    
    setTimeout(onPress, 150);
  };

  return (
    <Animated.View
      style={{
        opacity: animValue,
        transform: [
          { scale: pressAnim },
          { 
            translateY: animValue.interpolate({
              inputRange: [0, 1],
              outputRange: [50, 0],
            })
          }
        ],
      }}
    >
      <Pressable 
        onPress={handlePress}
        accessibilityRole="button"
        accessibilityLabel={`${title}: ${description}`}
        accessibilityHint="Tap to start printing"
      >
        <LinearGradient
          colors={[gradient[0], gradient[1], gradient[0]] as any}
          locations={[0, 0.6, 1]}
          className="rounded-3xl p-6 border border-white/20"
        >
          <View className="flex-row items-center">
            <View className="w-16 h-16 bg-white/20 rounded-2xl items-center justify-center mr-5">
              <Ionicons name={icon} size={32} color="white" />
            </View>
            
            <View className="flex-1">
              <Text className="text-white font-black text-xl mb-1">
                {title}
              </Text>
              <Text className="text-white/80 font-semibold text-sm mb-2">
                {subtitle}
              </Text>
              <Text className="text-white/70 text-sm leading-relaxed">
                {description}
              </Text>
            </View>
            
            <View className="w-10 h-10 bg-white/20 rounded-xl items-center justify-center">
              <Ionicons name="arrow-forward" size={20} color="white" />
            </View>
          </View>
        </LinearGradient>
      </Pressable>
    </Animated.View>
  );
}

function StatBubble({ icon, label, value, color }: { 
  icon: keyof typeof Ionicons.glyphMap; 
  label: string; 
  value: string; 
  color: string;
}) {
  return (
    <View className="items-center">
      <View 
        className="w-12 h-12 rounded-2xl items-center justify-center mb-2"
        style={{ backgroundColor: `${color}20` }}
      >
        <Ionicons name={icon} size={20} color={color} />
      </View>
      <Text className="text-white font-bold text-lg">{value}</Text>
      <Text className="text-white/60 text-xs font-medium">{label}</Text>
    </View>
  );
}