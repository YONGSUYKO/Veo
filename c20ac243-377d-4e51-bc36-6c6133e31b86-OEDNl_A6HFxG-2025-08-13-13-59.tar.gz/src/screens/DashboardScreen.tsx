import React, { useEffect } from 'react';
import { View, Text, ScrollView, Pressable, RefreshControl } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAppStore } from '../state/appStore';
import { apiClient } from '../api/pisoprint-api';
import { cn } from '../utils/cn';

export default function DashboardScreen() {
  const insets = useSafeAreaInsets();
  const { dashboardStats, setDashboardStats, printJobs, setPrintJobs } = useAppStore();
  const [refreshing, setRefreshing] = React.useState(false);

  const loadData = async () => {
    try {
      const [stats, jobs] = await Promise.all([
        apiClient.getDashboardStats(),
        apiClient.getPrintJobs()
      ]);
      setDashboardStats(stats);
      setPrintJobs(jobs);
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const formatCurrency = (amount: number) => {
    return `₱${(amount / 100).toFixed(2)}`;
  };

  const recentJobs = printJobs.slice(0, 3);

  return (
    <ScrollView 
      className="flex-1 bg-gray-50"
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }
    >
      <View style={{ paddingTop: insets.top }} className="px-4 pb-6">
        
        {/* Header */}
        <View className="mb-6">
          <Text className="text-3xl font-bold text-gray-900 mb-2">
            Dashboard
          </Text>
          <Text className="text-lg text-gray-600">
            Welcome back! Here's your business overview.
          </Text>
        </View>

        {/* Stats Cards */}
        <View className="mb-6">
          <View className="flex-row mb-4">
            <StatCard 
              title="Jobs Today"
              value={dashboardStats?.jobsToday.toString() || "0"}
              icon="document-text"
              color="bg-blue-500"
              className="mr-2 flex-1"
            />
            <StatCard 
              title="Revenue Today"
              value={formatCurrency(dashboardStats?.revenueToday || 0)}
              icon="cash"
              color="bg-green-500"
              className="ml-2 flex-1"
            />
          </View>
          
          <View className="flex-row">
            <StatCard 
              title="Queue Length"
              value={dashboardStats?.queueLength.toString() || "0"}
              icon="time"
              color="bg-orange-500"
              className="mr-2 flex-1"
            />
            <StatCard 
              title="Active Staff"
              value={`${dashboardStats?.activeOperators || 0}/${dashboardStats?.totalOperators || 0}`}
              icon="people"
              color="bg-purple-500"
              className="ml-2 flex-1"
            />
          </View>
        </View>

        {/* Recent Jobs */}
        <View className="mb-6">
          <View className="flex-row justify-between items-center mb-4">
            <Text className="text-xl font-semibold text-gray-900">
              Recent Jobs
            </Text>
            <Pressable>
              <Text className="text-blue-500 font-medium">View All</Text>
            </Pressable>
          </View>

          {recentJobs.length > 0 ? (
            <View className="space-y-3">
              {recentJobs.map((job) => (
                <JobCard key={job.id} job={job} />
              ))}
            </View>
          ) : (
            <View className="bg-white rounded-xl p-6 items-center">
              <Ionicons name="document-text-outline" size={48} color="#9CA3AF" />
              <Text className="text-gray-500 text-center mt-2">
                No recent jobs
              </Text>
            </View>
          )}
        </View>

        {/* Quick Actions */}
        <View>
          <Text className="text-xl font-semibold text-gray-900 mb-4">
            Quick Actions
          </Text>
          <View className="flex-row space-x-3">
            <ActionButton 
              title="New Print Job"
              icon="add"
              color="bg-blue-500"
            />
            <ActionButton 
              title="Photo Print"
              icon="camera"
              color="bg-green-500"
            />
            <ActionButton 
              title="View Queue"
              icon="list"
              color="bg-orange-500"
            />
          </View>
        </View>

      </View>
    </ScrollView>
  );
}

interface StatCardProps {
  title: string;
  value: string;
  icon: keyof typeof Ionicons.glyphMap;
  color: string;
  className?: string;
}

function StatCard({ title, value, icon, color, className }: StatCardProps) {
  return (
    <View className={cn("bg-white rounded-xl p-4", className)}>
      <View className="flex-row items-center justify-between mb-2">
        <View className={cn("w-10 h-10 rounded-lg items-center justify-center", color)}>
          <Ionicons name={icon} size={20} color="white" />
        </View>
      </View>
      <Text className="text-2xl font-bold text-gray-900 mb-1">{value}</Text>
      <Text className="text-sm text-gray-600">{title}</Text>
    </View>
  );
}

function JobCard({ job }: { job: any }) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'printing': return 'bg-blue-100 text-blue-800';
      case 'queue': return 'bg-orange-100 text-orange-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <View className="bg-white rounded-xl p-4">
      <View className="flex-row items-center justify-between mb-2">
        <View className="flex-row items-center">
          <Ionicons 
            name={job.type === 'photo' ? 'camera' : 'document-text'} 
            size={20} 
            color="#6B7280" 
          />
          <Text className="text-base font-medium text-gray-900 ml-2">
            {job.files[0]?.name || 'Unknown file'}
          </Text>
        </View>
        <Text className={cn("px-2 py-1 rounded-full text-xs font-medium", getStatusColor(job.status))}>
          {job.status.charAt(0).toUpperCase() + job.status.slice(1)}
        </Text>
      </View>
      
      <View className="flex-row items-center justify-between">
        <Text className="text-sm text-gray-600">
          {job.copies} {job.copies === 1 ? 'copy' : 'copies'} • {job.paperSize}
        </Text>
        <Text className="text-base font-semibold text-gray-900">
          ₱{(job.total / 100).toFixed(2)}
        </Text>
      </View>
    </View>
  );
}

function ActionButton({ title, icon, color }: { title: string; icon: keyof typeof Ionicons.glyphMap; color: string }) {
  return (
    <Pressable className="flex-1">
      <View className={cn("rounded-xl p-4 items-center", color)}>
        <Ionicons name={icon} size={24} color="white" />
        <Text className="text-white text-sm font-medium mt-2 text-center">
          {title}
        </Text>
      </View>
    </Pressable>
  );
}