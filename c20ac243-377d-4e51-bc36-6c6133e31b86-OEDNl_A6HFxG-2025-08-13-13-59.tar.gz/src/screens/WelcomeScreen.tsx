import React, { useEffect, useState } from 'react';
import { View, Text, Pressable, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';
import { useNewAppStore } from '../state/newAppStore';
import { newApiClient } from '../api/newPisoAPI';
import { cn } from '../utils/cn';

interface WelcomeScreenProps {
  onServiceSelect: (service: 'document' | 'scan' | 'photo') => void;
  onBackToDashboard?: () => void;
}

export default function WelcomeScreen({ onServiceSelect, onBackToDashboard }: WelcomeScreenProps) {
  const insets = useSafeAreaInsets();
  const { currentUser } = useAuthStore();
  const { questionOfTheDay, setQuestionOfTheDay } = useNewAppStore();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadQuestionOfTheDay();
  }, []);

  const loadQuestionOfTheDay = async () => {
    try {
      const question = await newApiClient.getQuestionOfTheDay();
      setQuestionOfTheDay(question);
    } catch (error) {
      console.error('Failed to load question of the day:', error);
    }
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    let timeGreeting = '';
    
    if (hour >= 5 && hour < 12) {
      timeGreeting = 'Good Morning';
    } else if (hour >= 12 && hour < 17) {
      timeGreeting = 'Good Afternoon';
    } else if (hour >= 17 && hour < 21) {
      timeGreeting = 'Good Evening';
    } else {
      timeGreeting = 'Good Night';
    }

    const userName = currentUser?.name || 'Customer';
    return `${timeGreeting}, ${userName}!`;
  };

  const getRoleBasedWelcome = () => {
    switch (currentUser?.role) {
      case 'admin':
        return 'Welcome to your PISO Print Express dashboard. Manage your store efficiently.';
      case 'operator':
        return 'Ready to serve customers today. Let\'s make their printing experience excellent!';
      default:
        return 'Welcome to PISO Print Express. Your one-stop solution for all printing needs.';
    }
  };

  return (
    <ScrollView className="flex-1 bg-white">
      <View style={{ paddingTop: insets.top + 20 }} className="px-6 pb-8">
        
        {/* Header with Logo */}
        <View className="mb-8">
          {/* Back button for admin/operator */}
          {onBackToDashboard && (currentUser?.role === 'admin' || currentUser?.role === 'operator') && (
            <View className="flex-row items-center mb-6">
              <Pressable 
                className="flex-row items-center"
                onPress={onBackToDashboard}
              >
                <Ionicons name="arrow-back" size={24} color="#374151" />
                <Text className="text-gray-700 font-medium ml-2">
                  Back to {currentUser.role === 'admin' ? 'Admin' : 'Operator'} Dashboard
                </Text>
              </Pressable>
            </View>
          )}
          
          <View className="items-center">
            <View className="w-20 h-20 bg-blue-500 rounded-2xl items-center justify-center mb-4">
              <Ionicons name="print" size={40} color="white" />
            </View>
            <Text className="text-3xl font-bold text-gray-900">PISO Print Express</Text>
            <Text className="text-sm text-gray-600 text-center mt-1">
              Professional Printing Services
            </Text>
          </View>
        </View>

        {/* Dynamic Greeting */}
        <View className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-6 mb-6">
          <Text className="text-2xl font-bold text-gray-900 mb-2">
            {getGreeting()}
          </Text>
          <Text className="text-base text-gray-700 leading-relaxed">
            {getRoleBasedWelcome()}
          </Text>
          
          {/* User role indicator */}
          {currentUser?.role && (
            <View className="flex-row items-center mt-3">
              <View className={cn(
                "px-3 py-1 rounded-full",
                currentUser.role === 'admin' ? 'bg-red-100' :
                currentUser.role === 'operator' ? 'bg-green-100' : 'bg-blue-100'
              )}>
                <Text className={cn(
                  "text-xs font-semibold uppercase tracking-wide",
                  currentUser.role === 'admin' ? 'text-red-700' :
                  currentUser.role === 'operator' ? 'text-green-700' : 'text-blue-700'
                )}>
                  {currentUser.role}
                </Text>
              </View>
              
              {currentUser.role === 'customer' && currentUser.loyaltyPoints > 0 && (
                <View className="flex-row items-center ml-3">
                  <Ionicons name="star" size={16} color="#F59E0B" />
                  <Text className="text-sm font-medium text-yellow-700 ml-1">
                    {currentUser.loyaltyPoints} pts
                  </Text>
                </View>
              )}
            </View>
          )}
        </View>

        {/* Question of the Day */}
        {questionOfTheDay && (
          <View className="bg-yellow-50 border-l-4 border-yellow-400 rounded-r-xl p-4 mb-8">
            <View className="flex-row items-start">
              <View className="w-8 h-8 bg-yellow-400 rounded-full items-center justify-center mr-3 mt-1">
                <Ionicons name="bulb" size={16} color="white" />
              </View>
              <View className="flex-1">
                <Text className="text-sm font-semibold text-yellow-800 mb-1">
                  Tip of the Day
                </Text>
                <Text className="text-sm text-yellow-700 leading-relaxed">
                  {questionOfTheDay.question}
                </Text>
              </View>
            </View>
          </View>
        )}

        {/* Service Selection */}
        <View className="mb-6">
          <Text className="text-xl font-bold text-gray-900 mb-4">
            What would you like to print today?
          </Text>
          
          <View className="space-y-4">
            <ServiceCard
              icon="document-text"
              title="Documents"
              description="Print PDFs, Word docs, presentations, and more"
              color="bg-blue-500"
              onPress={() => onServiceSelect('document')}
            />
            
            <ServiceCard
              icon="scan"
              title="Scan & Print"
              description="Capture documents with camera and print instantly"
              color="bg-green-500"
              onPress={() => onServiceSelect('scan')}
            />
            
            <ServiceCard
              icon="camera"
              title="Photos"
              description="Print your memories in various sizes and formats"
              color="bg-purple-500"
              onPress={() => onServiceSelect('photo')}
            />
          </View>
        </View>

        {/* Quick Stats for Admin/Operator */}
        {(currentUser?.role === 'admin' || currentUser?.role === 'operator') && (
          <View className="bg-gray-50 rounded-2xl p-4">
            <Text className="text-lg font-semibold text-gray-900 mb-3">
              Quick Overview
            </Text>
            <View className="flex-row justify-between">
              <StatItem icon="print" label="Queue" value="5" />
              <StatItem icon="checkmark-circle" label="Today" value="23" />
              <StatItem icon="cash" label="Revenue" value="₱1,240" />
            </View>
          </View>
        )}

      </View>
    </ScrollView>
  );
}

interface ServiceCardProps {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  description: string;
  color: string;
  onPress: () => void;
}

function ServiceCard({ icon, title, description, color, onPress }: ServiceCardProps) {
  return (
    <Pressable 
      className="bg-white rounded-xl p-6 border border-gray-200 active:bg-gray-50"
      onPress={onPress}
    >
      <View className="flex-row items-center">
        <View className={cn("w-16 h-16 rounded-2xl items-center justify-center mr-4", color)}>
          <Ionicons name={icon} size={28} color="white" />
        </View>
        
        <View className="flex-1">
          <Text className="text-lg font-semibold text-gray-900 mb-1">
            {title}
          </Text>
          <Text className="text-sm text-gray-600 leading-relaxed">
            {description}
          </Text>
        </View>
        
        <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
      </View>
    </Pressable>
  );
}

function StatItem({ icon, label, value }: { 
  icon: keyof typeof Ionicons.glyphMap; 
  label: string; 
  value: string; 
}) {
  return (
    <View className="items-center">
      <View className="w-10 h-10 bg-white rounded-full items-center justify-center mb-2">
        <Ionicons name={icon} size={18} color="#6B7280" />
      </View>
      <Text className="text-xs text-gray-600 mb-1">{label}</Text>
      <Text className="text-sm font-semibold text-gray-900">{value}</Text>
    </View>
  );
}