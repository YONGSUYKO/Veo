import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, ScrollView, ActivityIndicator } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { EmailUpload, EmailFile, emailRetrievalService } from '../services/emailRetrievalService';
import { useAuthStore } from '../state/authStore';
import { newApiClient } from '../api/newPisoAPI';
import { cn } from '../utils/cn';

interface EmailOrderConfirmationScreenProps {
  emailUpload: EmailUpload;
  onBack: () => void;
  onOrderCreated: (orderId: string) => void;
}

interface ProcessedFile extends EmailFile {
  configuration: {
    paperSize: string;
    orientation: string;
    colorMode: string;
    copies: number;
    duplex: boolean;
  };
  estimatedPrice: number;
  estimatedPages?: number;
}

export default function EmailOrderConfirmationScreen({ 
  emailUpload, 
  onBack, 
  onOrderCreated 
}: EmailOrderConfirmationScreenProps) {
  const insets = useSafeAreaInsets();
  const { currentUser } = useAuthStore();
  const [processedFiles, setProcessedFiles] = useState<ProcessedFile[]>([]);
  const [totalPrice, setTotalPrice] = useState(0);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    processFiles();
  }, []);

  const processFiles = async () => {
    try {
      const processed = emailUpload.files.map(file => {
        const configuration = emailRetrievalService.detectFileDefaults(file);
        const estimatedPrice = calculateIndividualPrice(file);
        const estimatedPages = estimatePages(file);
        
        return {
          ...file,
          configuration,
          estimatedPrice,
          estimatedPages
        };
      });

      setProcessedFiles(processed);
      
      const total = processed.reduce((sum, file) => sum + file.estimatedPrice, 0);
      setTotalPrice(total);
      
    } catch (error) {
      console.error('Failed to process files:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateIndividualPrice = (file: EmailFile): number => {
    const sizeInMB = file.size / (1024 * 1024);
    
    if (file.type.includes('pdf') || file.type.includes('document')) {
      const estimatedPages = Math.max(1, Math.ceil(file.size / (1024 * 50)));
      return estimatedPages * 2; // ₱2 per page
    } else if (file.type.includes('image')) {
      return 10; // ₱10 per photo
    } else if (file.type.includes('presentation')) {
      const estimatedSlides = Math.max(1, Math.ceil(file.size / (1024 * 100)));
      return estimatedSlides * 3; // ₱3 per slide
    } else {
      return Math.ceil(sizeInMB) * 5; // ₱5 per MB
    }
  };

  const estimatePages = (file: EmailFile): number => {
    if (file.type.includes('pdf') || file.type.includes('document')) {
      return Math.max(1, Math.ceil(file.size / (1024 * 50)));
    } else if (file.type.includes('presentation')) {
      return Math.max(1, Math.ceil(file.size / (1024 * 100)));
    } else if (file.type.includes('image')) {
      return 1;
    }
    return 1;
  };



  const createOrder = async () => {
    if (!currentUser) return;

    setCreating(true);
    try {
      // Create order with email files
      const orderData = {
        customerInfo: {
          name: currentUser.name,
          email: currentUser.email,
          phone: currentUser.phone || ''
        },
        files: processedFiles.map(file => ({
          id: file.id,
          name: file.name,
          uri: `email://${file.id}`,
          size: file.size,
          type: file.type,
          pages: file.estimatedPages || 1,
          paperSize: file.configuration.paperSize as any,
          pageColor: file.configuration.colorMode === 'color' ? 'color' : 'blackwhite' as any,
          pageSidedness: file.configuration.duplex ? 'double' : 'single' as any,
          pageOrientation: file.configuration.orientation as any,
          copies: file.configuration.copies,
          binding: 'none' as any,
          lamination: 'none' as any
        })),
        totalPrice: totalPrice * 100, // Convert to centavos
        loyaltyPointsUsed: 0,
        paymentMethod: 'cash' as any,
        fulfillmentMethod: 'pickup' as any,
        status: 'queue' as any
      };

      const order = await newApiClient.createPrintJob(orderData);
      
      // Mark email upload as processed
      await emailRetrievalService.processEmailUpload(emailUpload.id);
      
      onOrderCreated(order.id);
      
    } catch (error) {
      console.error('Failed to create order:', error);
    } finally {
      setCreating(false);
    }
  };

  if (loading) {
    return (
      <View className="flex-1 bg-white justify-center items-center">
        <ActivityIndicator size="large" color="#3B82F6" />
        <Text className="text-gray-600 mt-4">Processing your files...</Text>
      </View>
    );
  }

  return (
    <ScrollView className="flex-1 bg-white">
      <View style={{ paddingTop: insets.top + 20 }} className="px-6 pb-8">
        
        {/* Header */}
        <View className="flex-row items-center mb-6">
          <Pressable 
            className="w-10 h-10 bg-gray-100 rounded-full items-center justify-center mr-4"
            onPress={onBack}
          >
            <Ionicons name="arrow-back" size={20} color="#374151" />
          </Pressable>
          <View className="flex-1">
            <Text className="text-2xl font-bold text-gray-900">
              Confirm Your Order
            </Text>
            <Text className="text-gray-600 mt-1">
              Review files and pricing
            </Text>
          </View>
        </View>

        {/* Order Summary */}
        <View className="bg-green-50 border border-green-200 rounded-xl p-4 mb-6">
          <View className="flex-row items-center justify-between mb-3">
            <Text className="text-green-900 font-semibold text-lg">
              Order Total
            </Text>
            <Text className="text-2xl font-bold text-green-800">
              ₱{totalPrice.toFixed(2)}
            </Text>
          </View>
          <Text className="text-green-700 text-sm">
            {processedFiles.length} file(s) • Auto-configured with optimal settings
          </Text>
        </View>

        {/* Customer Info */}
        <View className="bg-white border border-gray-200 rounded-xl p-4 mb-6">
          <Text className="font-semibold text-gray-900 mb-3">Customer Information</Text>
          <View className="space-y-2">
            <View className="flex-row justify-between">
              <Text className="text-gray-600">Email:</Text>
              <Text className="text-gray-900 font-medium">{emailUpload.customerEmail}</Text>
            </View>
            <View className="flex-row justify-between">
              <Text className="text-gray-600">Name:</Text>
              <Text className="text-gray-900 font-medium">{currentUser?.name || 'Not provided'}</Text>
            </View>
            <View className="flex-row justify-between">
              <Text className="text-gray-600">Fulfillment:</Text>
              <Text className="text-gray-900 font-medium">Pickup</Text>
            </View>
          </View>
        </View>

        {/* Files List */}
        <View className="mb-6">
          <Text className="text-lg font-semibold text-gray-900 mb-4">
            Files to Print ({processedFiles.length})
          </Text>
          
          <View className="space-y-3">
            {processedFiles.map((file) => (
              <FileCard key={file.id} file={file} />
            ))}
          </View>
        </View>

        {/* Auto Configuration Notice */}
        <View className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
          <View className="flex-row items-start">
            <View className="w-8 h-8 bg-blue-500 rounded-full items-center justify-center mr-3 mt-1">
              <Ionicons name="settings" size={16} color="white" />
            </View>
            <View className="flex-1">
              <Text className="text-blue-900 font-semibold mb-2">
                Automatic Configuration
              </Text>
              <Text className="text-blue-800 text-sm leading-relaxed">
                Your files have been automatically configured with optimal print settings. 
                No manual configuration required - our system detects the best options for each file type.
              </Text>
            </View>
          </View>
        </View>

        {/* Total Breakdown */}
        <View className="bg-gray-50 rounded-xl p-4 mb-6">
          <Text className="font-semibold text-gray-900 mb-3">Price Breakdown</Text>
          {processedFiles.map((file) => (
            <View key={file.id} className="flex-row justify-between items-center py-2">
              <Text className="text-gray-700 flex-1 mr-2" numberOfLines={1}>
                {file.name}
              </Text>
              <Text className="text-gray-900 font-medium">
                ₱{file.estimatedPrice.toFixed(2)}
              </Text>
            </View>
          ))}
          <View className="border-t border-gray-200 mt-2 pt-2">
            <View className="flex-row justify-between items-center">
              <Text className="font-semibold text-gray-900">Total</Text>
              <Text className="font-bold text-gray-900 text-lg">
                ₱{totalPrice.toFixed(2)}
              </Text>
            </View>
          </View>
        </View>

        {/* Confirm Button */}
        <Pressable
          className={cn(
            "rounded-xl py-4 px-6 items-center mb-4",
            creating ? "bg-gray-300" : "bg-green-500 active:bg-green-600"
          )}
          onPress={createOrder}
          disabled={creating}
        >
          {creating ? (
            <View className="flex-row items-center">
              <ActivityIndicator size="small" color="white" />
              <Text className="text-white font-semibold ml-2">
                Creating Order...
              </Text>
            </View>
          ) : (
            <Text className="text-white font-semibold text-base">
              Confirm Order - ₱{totalPrice.toFixed(2)}
            </Text>
          )}
        </Pressable>

        {/* Cancel Button */}
        <Pressable
          className="rounded-xl py-3 px-6 items-center border border-gray-300"
          onPress={onBack}
          disabled={creating}
        >
          <Text className="text-gray-700 font-medium">
            Go Back
          </Text>
        </Pressable>

      </View>
    </ScrollView>
  );
}

function FileCard({ file }: { file: ProcessedFile }) {
  const getFileIcon = (type: string) => {
    if (type.includes('pdf')) return 'document-text';
    if (type.includes('image')) return 'image';
    if (type.includes('presentation')) return 'easel';
    if (type.includes('document')) return 'document';
    return 'document-outline';
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <View className="bg-white border border-gray-200 rounded-xl p-4">
      <View className="flex-row items-start">
        <View className="w-12 h-12 bg-blue-100 rounded-lg items-center justify-center mr-3">
          <Ionicons name={getFileIcon(file.type)} size={24} color="#3B82F6" />
        </View>
        
        <View className="flex-1">
          <Text className="font-medium text-gray-900 mb-1" numberOfLines={1}>
            {file.name}
          </Text>
          <Text className="text-sm text-gray-600 mb-2">
            {formatFileSize(file.size)} • {file.estimatedPages} page(s)
          </Text>
          
          {/* Configuration */}
          <View className="flex-row flex-wrap gap-2 mb-2">
            <ConfigBadge label={file.configuration.paperSize} />
            <ConfigBadge label={file.configuration.orientation} />
            <ConfigBadge label={file.configuration.colorMode.replace('_', ' ')} />
          </View>
          
          <View className="flex-row justify-between items-center">
            <Text className="text-xs text-gray-500">
              Auto-configured
            </Text>
            <Text className="font-semibold text-green-600">
              ₱{file.estimatedPrice.toFixed(2)}
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
}

function ConfigBadge({ label }: { label: string }) {
  return (
    <View className="bg-gray-100 px-2 py-1 rounded">
      <Text className="text-xs text-gray-700 capitalize">{label}</Text>
    </View>
  );
}