import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, StyleSheet, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { StaffSupportOrder } from '../types/staffSupportOrder';
import { staffSupportService } from '../services/staffSupportService';
import { useAuthStore } from '../state/authStore';
import { cn } from '../utils/cn';
import ChatComponent from '../components/ChatComponent';
import PickupQRCodeDisplay from '../components/PickupQRCodeDisplay';

interface CustomerOrderStatusScreenProps {
  navigation?: any;
  route?: {
    params?: {
      orderId: string;
    };
  };
  orderId?: string;
}

export default function CustomerOrderStatusScreenFixed({ 
  navigation, 
  route, 
  orderId: propOrderId 
}: CustomerOrderStatusScreenProps) {
  const insets = useSafeAreaInsets();
  const { currentUser } = useAuthStore();
  const orderId = propOrderId || route?.params?.orderId;
  
  const [orderDetails, setOrderDetails] = useState<StaffSupportOrder | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orderId) {
      setLoading(false);
      return;
    }

    // Subscribe to order changes
    const unsubscribe = staffSupportService.subscribeToOrder(orderId, (order) => {
      setOrderDetails(order);
      setLoading(false);
    });

    return unsubscribe;
  }, [orderId]);

  const getStatusInfo = (status: string) => {
    const statusConfig = {
      uploaded: { color: '#F59E0B', bg: '#FEF3C7', label: 'Files Uploaded', icon: 'cloud-upload' },
      under_review: { color: '#3B82F6', bg: '#DBEAFE', label: 'Under Review', icon: 'eye' },
      approved_for_payment: { color: '#10B981', bg: '#D1FAE5', label: 'Ready for Payment', icon: 'checkmark-circle' },
      paid: { color: '#8B5CF6', bg: '#EDE9FE', label: 'Paid', icon: 'card' },
      printing: { color: '#F59E0B', bg: '#FEF3C7', label: 'Printing', icon: 'print' },
      ready: { color: '#10B981', bg: '#D1FAE5', label: 'Ready for Pickup', icon: 'checkmark-done' },
      completed: { color: '#6B7280', bg: '#F3F4F6', label: 'Completed', icon: 'checkmark-done-circle' },
    };
    return statusConfig[status as keyof typeof statusConfig] || statusConfig.uploaded;
  };

  if (loading) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <View style={styles.loadingContainer}>
          <Ionicons name="hourglass" size={48} color="#6B7280" />
          <Text style={styles.loadingText}>Loading order details...</Text>
        </View>
      </View>
    );
  }

  if (!orderDetails) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <View style={styles.errorContainer}>
          <Ionicons name="alert-circle" size={48} color="#EF4444" />
          <Text style={styles.errorText}>Order not found</Text>
          {navigation && (
            <Pressable style={styles.backButton} onPress={() => navigation.goBack()}>
              <Text style={styles.backButtonText}>Go Back</Text>
            </Pressable>
          )}
        </View>
      </View>
    );
  }

  const statusInfo = getStatusInfo(orderDetails.status);

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        {navigation && (
          <Pressable onPress={() => navigation.goBack()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color="#374151" />
          </Pressable>
        )}
        <Text style={styles.headerTitle}>Order Status</Text>
        <View style={styles.placeholder} />
      </View>

      {/* Quick Status Summary */}
      <View style={styles.statusCard}>
        <View style={styles.orderInfo}>
          <Text style={styles.orderTitle}>Order #{orderDetails.id.slice(-6)}</Text>
          <Text style={styles.orderDate}>
            {orderDetails.createdAt.toLocaleDateString()}
          </Text>
        </View>
        <View style={[styles.statusChip, { backgroundColor: statusInfo.bg }]}>
          <Ionicons name={statusInfo.icon as any} size={16} color={statusInfo.color} />
          <Text style={[styles.statusText, { color: statusInfo.color }]}>
            {statusInfo.label}
          </Text>
        </View>
      </View>

      {/* Files Count Summary */}
      <View style={styles.summarySection}>
        <View style={styles.summaryItem}>
          <Ionicons name="document" size={20} color="#6B7280" />
          <Text style={styles.summaryText}>{orderDetails.files.length} files uploaded</Text>
        </View>
        {orderDetails.totalAmount > 0 && (
          <View style={styles.summaryItem}>
            <Ionicons name="cash" size={20} color="#10B981" />
            <Text style={styles.summaryText}>₱{orderDetails.totalAmount} total</Text>
          </View>
        )}
      </View>

      {/* Status Message */}
      {orderDetails.operatorMessage && (
        <View style={styles.messageSection}>
          <Text style={styles.messageTitle}>📢 Latest Update</Text>
          <Text style={styles.messageText}>{orderDetails.operatorMessage}</Text>
        </View>
      )}

      {/* Payment Section */}
      {orderDetails.status === 'approved_for_payment' && (
        <View style={styles.paymentSection}>
          <Text style={styles.paymentTitle}>💳 Ready for Payment</Text>
          <Text style={styles.paymentAmount}>₱{orderDetails.totalAmount}</Text>
          {orderDetails.paymentCode && (
            <Text style={styles.paymentCode}>Code: {orderDetails.paymentCode}</Text>
          )}
        </View>
      )}

      {/* Pickup QR Code Section */}
      {(orderDetails.status === 'ready' || orderDetails.status === 'completed') && (
        <View style={styles.pickupSection}>
          <PickupQRCodeDisplay order={orderDetails} />
        </View>
      )}

      {/* Chat Section - No ScrollView nesting */}
      <View style={styles.chatSection}>
        <View style={styles.chatHeader}>
          <Ionicons name="chatbubbles" size={20} color="#3B82F6" />
          <Text style={styles.chatTitle}>Chat with Print Shop</Text>
        </View>
        <View style={styles.chatContainer}>
          {orderId ? (
            <ChatComponent orderId={orderId} />
          ) : (
            <View style={styles.chatError}>
              <Text style={styles.chatErrorText}>Chat unavailable - Order ID missing</Text>
            </View>
          )}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    flex: 1,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#111827',
  },
  placeholder: {
    width: 40,
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  loadingText: {
    fontSize: 16,
    color: '#6B7280',
    marginTop: 16,
  },
  errorContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  errorText: {
    fontSize: 18,
    color: '#EF4444',
    marginTop: 16,
    marginBottom: 24,
  },
  backButtonText: {
    color: '#3B82F6',
    fontSize: 16,
    fontWeight: '600',
  },
  statusCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'white',
    padding: 20,
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  orderInfo: {
    flex: 1,
  },
  orderTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
  },
  orderDate: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 2,
  },
  statusChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 4,
  },
  summarySection: {
    flexDirection: 'row',
    backgroundColor: 'white',
    padding: 16,
    marginHorizontal: 16,
    marginTop: 8,
    borderRadius: 12,
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
  },
  summaryItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 20,
  },
  summaryText: {
    marginLeft: 8,
    fontSize: 14,
    color: '#6B7280',
  },
  messageSection: {
    backgroundColor: 'white',
    padding: 16,
    marginHorizontal: 16,
    marginTop: 8,
    borderRadius: 12,
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
  },
  messageTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 8,
  },
  messageText: {
    fontSize: 14,
    color: '#374151',
    lineHeight: 20,
  },
  paymentSection: {
    backgroundColor: '#10B981',
    padding: 16,
    marginHorizontal: 16,
    marginTop: 8,
    borderRadius: 12,
    alignItems: 'center',
  },
  paymentTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 4,
  },
  paymentAmount: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  paymentCode: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    marginTop: 4,
  },
  pickupSection: {
    marginHorizontal: 16,
    marginTop: 8,
    marginBottom: 16,
  },
  chatSection: {
    flex: 1,
    backgroundColor: 'white',
    marginHorizontal: 16,
    marginTop: 8,
    marginBottom: 16,
    borderRadius: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  chatHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  chatTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginLeft: 8,
  },
  chatContainer: {
    flex: 1,
  },
  chatError: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  chatErrorText: {
    color: '#6B7280',
    textAlign: 'center',
  },
});