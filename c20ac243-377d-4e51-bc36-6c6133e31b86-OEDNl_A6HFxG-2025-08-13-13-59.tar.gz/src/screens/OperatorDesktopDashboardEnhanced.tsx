import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, ScrollView, RefreshControl, Alert, FlatList } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';
import { useNewAppStore } from '../state/newAppStore';
import { newApiClient } from '../api/newPisoAPI';
import { useDeviceInfo } from '../utils/deviceDetection';
import DesktopLayout from '../components/desktop/DesktopLayout';
import PickupQRScanner from '../components/PickupQRScanner';

interface OperatorDesktopDashboardProps {
  onSwitchToCustomer: () => void;
}

interface PrinterStatus {
  id: string;
  name: string;
  status: 'online' | 'offline' | 'busy' | 'error' | 'paper_low' | 'ink_low';
  type: 'laser' | 'inkjet' | 'photo';
  location: string;
  jobsInQueue: number;
  lastActivity: string;
  capabilities: string[];
}

interface PrintJob {
  id: string;
  customerName: string;
  files: any[];
  status: 'queue' | 'printing' | 'printed' | 'ready' | 'completed';
  printSpecs: any;
  assignedPrinter?: string;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  estimatedTime: number; // minutes
}

export default function OperatorDesktopDashboardEnhanced({ onSwitchToCustomer }: OperatorDesktopDashboardProps) {
  const deviceInfo = useDeviceInfo();
  const { currentUser, logout } = useAuthStore();
  const { printJobs, setPrintJobs } = useNewAppStore();
  const [refreshing, setRefreshing] = useState(false);
  const [currentView, setCurrentView] = useState<'queue' | 'printing' | 'printers' | 'history' | 'reports'>('queue');
  const [selectedJob, setSelectedJob] = useState<PrintJob | null>(null);
  const [selectedPrinter, setSelectedPrinter] = useState<string | null>(null);
  const [showQRScanner, setShowQRScanner] = useState(false);

  // Mock printer statuses (in production, this would come from actual printer API)
  const [printers, setPrinters] = useState<PrinterStatus[]>([
    {
      id: 'laser_01',
      name: 'HP LaserJet Pro M404n',
      status: 'online',
      type: 'laser',
      location: 'Station A',
      jobsInQueue: 3,
      lastActivity: '2 min ago',
      capabilities: ['B&W', 'A4', 'A3', 'Duplex']
    },
    {
      id: 'inkjet_01',
      name: 'Canon PIXMA G7020',
      status: 'busy',
      type: 'inkjet',
      location: 'Station B',
      jobsInQueue: 1,
      lastActivity: 'Now',
      capabilities: ['Color', 'A4', 'Photo']
    },
    {
      id: 'photo_01',
      name: 'Epson SureColor P800',
      status: 'ink_low',
      type: 'photo',
      location: 'Photo Station',
      jobsInQueue: 0,
      lastActivity: '15 min ago',
      capabilities: ['Photo', '4x6', '5x7', '8x10', '11x14']
    },
    {
      id: 'laser_02',
      name: 'Brother HL-L3270CDW',
      status: 'paper_low',
      type: 'laser',
      location: 'Station C',
      jobsInQueue: 2,
      lastActivity: '5 min ago',
      capabilities: ['Color', 'B&W', 'A4', 'Duplex']
    }
  ]);

  useEffect(() => {
    loadJobs();
    // Set up periodic refresh for real-time updates
    const interval = setInterval(() => {
      loadJobs();
      updatePrinterStatuses();
    }, 10000); // Refresh every 10 seconds
    return () => clearInterval(interval);
  }, []);

  const loadJobs = async () => {
    try {
      const jobs = await newApiClient.getPrintJobs();
      setPrintJobs(jobs);
    } catch (error) {
      console.error('Failed to load jobs:', error);
    }
  };

  const updatePrinterStatuses = () => {
    // In production, this would fetch real printer statuses
    setPrinters(prev => prev.map(printer => ({
      ...printer,
      lastActivity: Math.random() > 0.7 ? 'Just now' : printer.lastActivity
    })));
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadJobs();
    updatePrinterStatuses();
    setRefreshing(false);
  };

  const getStatusIcon = (status: string) => {
    const icons = {
      online: 'checkmark-circle',
      offline: 'close-circle',
      busy: 'time',
      error: 'warning',
      paper_low: 'document-outline',
      ink_low: 'color-palette-outline'
    };
    return icons[status as keyof typeof icons] || 'help-circle';
  };

  const getStatusColor = (status: string) => {
    const colors = {
      online: '#10B981',
      offline: '#6B7280',
      busy: '#F59E0B',
      error: '#EF4444',
      paper_low: '#F59E0B',
      ink_low: '#8B5CF6'
    };
    return colors[status as keyof typeof colors] || '#6B7280';
  };

  const assignJobToPrinter = async (jobId: string, printerId: string) => {
    try {
      // In production, this would call the actual printer API
      Alert.alert(
        'Job Assigned',
        `Job #${jobId.slice(-6)} has been assigned to ${printers.find(p => p.id === printerId)?.name}`,
        [
          {
            text: 'Print Now',
            onPress: () => startPrinting(jobId, printerId)
          },
          {
            text: 'Queue for Later',
            style: 'cancel'
          }
        ]
      );
    } catch (error) {
      Alert.alert('Error', 'Failed to assign job to printer');
    }
  };

  const startPrinting = async (jobId: string, printerId: string) => {
    try {
      // Update printer status
      setPrinters(prev => prev.map(printer => 
        printer.id === printerId 
          ? { ...printer, status: 'busy', jobsInQueue: printer.jobsInQueue + 1 }
          : printer
      ));

      // Update job status
      await newApiClient.updatePrintJobStatus(jobId, 'ongoing');
      await loadJobs();

      Alert.alert(
        'Printing Started',
        `Job #${jobId.slice(-6)} is now printing on ${printers.find(p => p.id === printerId)?.name}`,
        [{ text: 'OK' }]
      );

      // Simulate printing completion after some time
      setTimeout(() => {
        completePrintJob(jobId, printerId);
      }, 30000); // 30 seconds simulation

    } catch (error) {
      Alert.alert('Error', 'Failed to start printing');
    }
  };

  const completePrintJob = async (jobId: string, printerId: string) => {
    try {
      // Update printer status
      setPrinters(prev => prev.map(printer => 
        printer.id === printerId 
          ? { 
              ...printer, 
              status: 'online', 
              jobsInQueue: Math.max(0, printer.jobsInQueue - 1),
              lastActivity: 'Just now'
            }
          : printer
      ));

      // Update job status
      await newApiClient.updatePrintJobStatus(jobId, 'ready');
      await loadJobs();

      Alert.alert(
        'Print Complete',
        `Job #${jobId.slice(-6)} has finished printing and is ready for pickup!`
      );

    } catch (error) {
      console.error('Error completing print job:', error);
    }
  };

  const pausePrinter = (printerId: string) => {
    setPrinters(prev => prev.map(printer => 
      printer.id === printerId 
        ? { ...printer, status: 'offline' }
        : printer
    ));
    Alert.alert('Printer Paused', `${printers.find(p => p.id === printerId)?.name} has been paused.`);
  };

  const resumePrinter = (printerId: string) => {
    setPrinters(prev => prev.map(printer => 
      printer.id === printerId 
        ? { ...printer, status: 'online' }
        : printer
    ));
    Alert.alert('Printer Resumed', `${printers.find(p => p.id === printerId)?.name} is now online.`);
  };

  const renderPrinterCard = ({ item: printer }: { item: PrinterStatus }) => (
    <View style={{ 
      backgroundColor: 'white', 
      borderRadius: 12, 
      padding: 16, 
      marginBottom: 12,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
      elevation: 3
    }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#111827', marginBottom: 4 }}>
            {printer.name}
          </Text>
          <Text style={{ fontSize: 14, color: '#6B7280', marginBottom: 2 }}>
            📍 {printer.location} • {printer.type.toUpperCase()}
          </Text>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Ionicons 
              name={getStatusIcon(printer.status)} 
              size={16} 
              color={getStatusColor(printer.status)} 
            />
            <Text style={{ fontSize: 14, color: getStatusColor(printer.status), marginLeft: 4, fontWeight: '600' }}>
              {printer.status.replace('_', ' ').toUpperCase()}
            </Text>
          </View>
        </View>

        <View style={{ alignItems: 'flex-end' }}>
          <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#F59E0B' }}>
            {printer.jobsInQueue}
          </Text>
          <Text style={{ fontSize: 12, color: '#6B7280' }}>
            in queue
          </Text>
        </View>
      </View>

      <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 12 }}>
        {printer.capabilities.map((cap, index) => (
          <View key={index} style={{ 
            backgroundColor: '#F3F4F6', 
            paddingHorizontal: 8, 
            paddingVertical: 4, 
            borderRadius: 12, 
            marginRight: 6, 
            marginBottom: 4 
          }}>
            <Text style={{ fontSize: 10, color: '#6B7280', fontWeight: '600' }}>
              {cap}
            </Text>
          </View>
        ))}
      </View>

      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Text style={{ fontSize: 12, color: '#9CA3AF' }}>
          Last activity: {printer.lastActivity}
        </Text>
        
        <View style={{ flexDirection: 'row', gap: 8 }}>
          {printer.status === 'online' ? (
            <Pressable
              onPress={() => pausePrinter(printer.id)}
              style={{ backgroundColor: '#F59E0B', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6 }}
            >
              <Text style={{ color: 'white', fontSize: 12, fontWeight: '600' }}>
                Pause
              </Text>
            </Pressable>
          ) : (
            <Pressable
              onPress={() => resumePrinter(printer.id)}
              style={{ backgroundColor: '#10B981', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6 }}
            >
              <Text style={{ color: 'white', fontSize: 12, fontWeight: '600' }}>
                Resume
              </Text>
            </Pressable>
          )}
          
          <Pressable
            onPress={() => setSelectedPrinter(printer.id)}
            style={{ backgroundColor: '#3B82F6', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6 }}
          >
            <Text style={{ color: 'white', fontSize: 12, fontWeight: '600' }}>
              Manage
            </Text>
          </Pressable>
        </View>
      </View>
    </View>
  );

  const renderPrintJobCard = ({ item: job }: { item: any }) => (
    <View style={{ 
      backgroundColor: 'white', 
      borderRadius: 12, 
      padding: 16, 
      marginBottom: 12,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
      elevation: 3
    }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#111827', marginBottom: 4 }}>
            #{job.id.slice(-6)} - {job.customerInfo?.name || 'Customer'}
          </Text>
          <Text style={{ fontSize: 14, color: '#6B7280', marginBottom: 4 }}>
            📄 {job.files.length} file(s) • ₱{(job.totalPrice / 100).toFixed(2)}
          </Text>
          <Text style={{ fontSize: 12, color: '#9CA3AF' }}>
            Created: {new Date(job.createdAt).toLocaleString()}
          </Text>
        </View>

        <View style={{ 
          backgroundColor: '#F59E0B20', 
          paddingHorizontal: 8, 
          paddingVertical: 4, 
          borderRadius: 12 
        }}>
          <Text style={{ fontSize: 10, fontWeight: '600', color: '#F59E0B' }}>
            PRIORITY: NORMAL
          </Text>
        </View>
      </View>

      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <View>
          <Text style={{ fontSize: 12, color: '#6B7280', marginBottom: 4 }}>
            📋 {job.printSpecs || 'Standard print specs'}
          </Text>
          <Text style={{ fontSize: 12, color: '#6B7280' }}>
            ⏱️ Est. {Math.ceil(job.files.length * 2)} min
          </Text>
        </View>

        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Pressable
            onPress={() => setSelectedJob(job)}
            style={{ backgroundColor: '#6B7280', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6 }}
          >
            <Text style={{ color: 'white', fontSize: 12, fontWeight: '600' }}>
              View Details
            </Text>
          </Pressable>
          
          <Pressable
            onPress={() => {
              Alert.alert(
                'Select Printer',
                'Choose a printer for this job:',
                printers
                  .filter(p => p.status === 'online')
                  .map(printer => ({
                    text: `${printer.name} (${printer.jobsInQueue} queued)`,
                    onPress: () => assignJobToPrinter(job.id, printer.id)
                  }))
                  .concat([{ text: 'Cancel', style: 'cancel' }])
              );
            }}
            style={{ backgroundColor: '#10B981', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6 }}
          >
            <Text style={{ color: 'white', fontSize: 12, fontWeight: '600' }}>
              Print Now
            </Text>
          </Pressable>
        </View>
      </View>
    </View>
  );

  const renderContent = () => {
    const queueJobs = printJobs.filter(job => job.status === 'queue');
    const activeJobs = printJobs.filter(job => job.status === 'ongoing');
    const readyJobs = printJobs.filter(job => job.status === 'ready');

    switch (currentView) {
      case 'printers':
        return (
          <View style={{ flex: 1, padding: 20 }}>
            <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 20, color: '#111827' }}>
              Printer Management
            </Text>
            <FlatList
              data={printers}
              renderItem={renderPrinterCard}
              keyExtractor={item => item.id}
              refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
              showsVerticalScrollIndicator={false}
            />
          </View>
        );

      case 'queue':
        return (
          <View style={{ flex: 1, padding: 20 }}>
            <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 20, color: '#111827' }}>
              Print Queue ({queueJobs.length})
            </Text>
            <FlatList
              data={queueJobs}
              renderItem={renderPrintJobCard}
              keyExtractor={item => item.id}
              refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
              showsVerticalScrollIndicator={false}
              ListEmptyComponent={
                <View style={{ padding: 40, alignItems: 'center' }}>
                  <Ionicons name="print-outline" size={64} color="#D1D5DB" />
                  <Text style={{ fontSize: 16, color: '#6B7280', marginTop: 12, textAlign: 'center' }}>
                    No jobs in queue
                  </Text>
                </View>
              }
            />
          </View>
        );

      case 'printing':
        return (
          <View style={{ flex: 1, padding: 20 }}>
            <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 20, color: '#111827' }}>
              Currently Printing ({activeJobs.length})
            </Text>
            <FlatList
              data={activeJobs}
              renderItem={renderPrintJobCard}
              keyExtractor={item => item.id}
              refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
              showsVerticalScrollIndicator={false}
            />
          </View>
        );

      default:
        return (
          <View style={{ flex: 1, padding: 20 }}>
            <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 20, color: '#111827' }}>
              Operator Dashboard
            </Text>
            {/* Dashboard content */}
          </View>
        );
    }
  };

  const handleOrderPickup = (order: StaffSupportOrder) => {
    Alert.alert('Order Picked Up', `Order #${order.id.slice(-6)} has been successfully picked up!`);
    loadJobs(); // Refresh the job list
  };

  const menuItems = [
    { id: 'queue', label: 'Print Queue', icon: 'list', count: printJobs.filter(j => j.status === 'queue').length },
    { id: 'printing', label: 'Printing Now', icon: 'print', count: printJobs.filter(j => j.status === 'ongoing').length },
    { id: 'printers', label: 'Printer Status', icon: 'hardware-chip', count: printers.filter(p => p.status === 'online').length },
    { id: 'history', label: 'Job History', icon: 'time', count: 0 },
    { id: 'reports', label: 'Reports', icon: 'stats-chart', count: 0 }
  ];

  return (
    <DesktopLayout
      title="Operator Control Center"
      subtitle={`Welcome back, ${currentUser?.name}!`}
      currentUser={currentUser}
      onLogout={logout}
      onSwitchToCustomer={onSwitchToCustomer}
      menuItems={menuItems}
      currentView={currentView}
      onViewChange={setCurrentView}
    >
      {renderContent()}
    </DesktopLayout>
  );
}