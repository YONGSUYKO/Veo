import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, Image, Pressable, StyleSheet, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { StaffSupportOrder } from '../types/staffSupportOrder';
import { staffSupportService } from '../services/staffSupportService';
import { useAuthStore } from '../state/authStore';
import { cn } from '../utils/cn';
import ChatComponent from '../components/ChatComponent';

interface CustomerOrderStatusScreenProps {
  navigation?: any;
  route?: {
    params?: {
      orderId: string;
    };
  };
  orderId?: string;
}

export default function CustomerOrderStatusScreen({ 
  navigation, 
  route, 
  orderId: propOrderId 
}: CustomerOrderStatusScreenProps) {
  const insets = useSafeAreaInsets();
  const { currentUser } = useAuthStore();
  const orderId = propOrderId || route?.params?.orderId;
  
  const [orderDetails, setOrderDetails] = useState<StaffSupportOrder | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!orderId) {
      setLoading(false);
      return;
    }

    // Subscribe to order changes
    const unsubscribe = staffSupportService.subscribeToOrder(orderId, (order) => {
      setOrderDetails(order);
      setLoading(false);
    });

    return unsubscribe;
  }, [orderId]);

  const getStatusInfo = (status: string) => {
    const statusConfig = {
      uploaded: { color: '#F59E0B', bg: '#FEF3C7', label: 'Files Uploaded', icon: 'cloud-upload' },
      under_review: { color: '#3B82F6', bg: '#DBEAFE', label: 'Under Review', icon: 'eye' },
      approved_for_payment: { color: '#10B981', bg: '#D1FAE5', label: 'Approved for Payment', icon: 'checkmark-circle' },
      paid: { color: '#8B5CF6', bg: '#EDE9FE', label: 'Payment Received', icon: 'card' },
      printing: { color: '#F59E0B', bg: '#FEF3C7', label: 'Printing', icon: 'print' },
      ready: { color: '#10B981', bg: '#D1FAE5', label: 'Ready for Pickup', icon: 'checkmark-done' },
      completed: { color: '#6B7280', bg: '#F3F4F6', label: 'Completed', icon: 'checkmark-done-circle' },
    };
    return statusConfig[status as keyof typeof statusConfig] || statusConfig.uploaded;
  };

  const processPayment = async () => {
    if (!orderDetails) return;

    try {
      Alert.alert(
        'Payment Options',
        `Total: ₱${orderDetails.totalAmount}\nPayment Code: ${orderDetails.paymentCode}`,
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'Pay with Cash', 
            onPress: () => completePayment('cash') 
          },
          { 
            text: 'Pay with GCash', 
            onPress: () => completePayment('gcash') 
          },
          { 
            text: 'Pay with Card', 
            onPress: () => completePayment('card') 
          },
        ]
      );
    } catch (error) {
      console.error('Payment failed:', error);
      Alert.alert('Payment Error', 'Failed to process payment. Please try again.');
    }
  };

  const completePayment = async (method: string) => {
    if (!orderDetails) return;

    try {
      await staffSupportService.updateOrderStatus(orderDetails.id, 'paid');
      
      Alert.alert(
        'Payment Successful!',
        `Your order has been paid using ${method}. We'll start printing shortly!`,
        [{ text: 'OK' }]
      );
    } catch (error) {
      Alert.alert('Error', 'Failed to update payment status');
    }
  };

  if (loading) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <View style={styles.loadingContainer}>
          <Ionicons name="hourglass" size={48} color="#6B7280" />
          <Text style={styles.loadingText}>Loading order details...</Text>
        </View>
      </View>
    );
  }

  if (!orderDetails) {
    return (
      <View style={[styles.container, { paddingTop: insets.top }]}>
        <View style={styles.errorContainer}>
          <Ionicons name="alert-circle" size={48} color="#EF4444" />
          <Text style={styles.errorText}>Order not found</Text>
          {navigation && (
            <Pressable style={styles.backButton} onPress={() => navigation.goBack()}>
              <Text style={styles.backButtonText}>Go Back</Text>
            </Pressable>
          )}
        </View>
      </View>
    );
  }

  const statusInfo = getStatusInfo(orderDetails.status);

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        {navigation && (
          <Pressable onPress={() => navigation.goBack()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color="#374151" />
          </Pressable>
        )}
        <Text style={styles.headerTitle}>Staff Support Order</Text>
        <View style={styles.placeholder} />
      </View>

      {/* Content Container */}
      <View style={styles.contentContainer}>

      {/* Order Status Header */}
      <View style={styles.statusCard}>
        <View style={styles.orderInfo}>
          <Text style={styles.orderTitle}>Order #{orderDetails.id.slice(-6)}</Text>
          <Text style={styles.orderDate}>
            {orderDetails.createdAt.toLocaleDateString()}
          </Text>
        </View>
        <View style={[styles.statusChip, { backgroundColor: statusInfo.bg }]}>
          <Ionicons name={statusInfo.icon as any} size={16} color={statusInfo.color} />
          <Text style={[styles.statusText, { color: statusInfo.color }]}>
            {statusInfo.label}
          </Text>
        </View>
      </View>

      {/* Files Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>📁 Your Files</Text>
        {orderDetails.files?.map(file => (
          <View key={file.id} style={styles.fileCard}>
            <View style={styles.fileIcon}>
              <Ionicons 
                name={file.type === 'photo' ? 'image' : 'document-text'} 
                size={24} 
                color="#6B7280" 
              />
            </View>
            <View style={styles.fileInfo}>
              <Text style={styles.fileName}>📄 {file.name}</Text>
              
              {/* Operator Comments */}
              {file.operatorComments && (
                <View style={styles.operatorNotes}>
                  <Text style={styles.noteTitle}>✓ Print Review:</Text>
                  <Text style={styles.noteText}>"{file.operatorComments}"</Text>
                </View>
              )}
              
              {/* Print Specifications */}
              {file.printSpecs && (
                <View style={styles.printSpecs}>
                  <Text style={styles.specTitle}>Print Settings:</Text>
                  <Text style={styles.specText}>Size: {file.printSpecs.size}</Text>
                  <Text style={styles.specText}>Color: {file.printSpecs.color.replace('_', ' ')}</Text>
                  <Text style={styles.specText}>Copies: {file.printSpecs.copies}</Text>
                </View>
              )}
            </View>
          </View>
        ))}
      </View>

      {/* Print Specifications */}
      {orderDetails.printSpecs && orderDetails.printSpecs.length > 0 && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>📊 Print Details</Text>
          <Text style={styles.subTitle}>What we'll print for you:</Text>
          {orderDetails.printSpecs.map(spec => (
            <View key={spec.id} style={styles.specItem}>
              <Text style={styles.specDescription}>• {spec.description}</Text>
              <Text style={styles.specPrice}>₱{spec.totalPrice}</Text>
            </View>
          ))}
          
          <View style={styles.totalSection}>
            <Text style={styles.totalText}>💰 Total Cost: ₱{orderDetails.totalAmount}</Text>
            {orderDetails.completionTime && (
              <Text style={styles.timeText}>⏰ Ready by: {orderDetails.completionTime}</Text>
            )}
          </View>
        </View>
      )}

      {/* Operator Message */}
      {orderDetails.operatorMessage && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>💬 Status Update</Text>
          <View style={styles.approvalMessage}>
            <Text style={styles.operatorText}>{orderDetails.operatorMessage}</Text>
          </View>
        </View>
      )}

      {/* Payment Section */}
      {orderDetails.status === 'approved_for_payment' && (
        <View style={styles.paymentSection}>
          <Text style={styles.sectionTitle}>💳 Payment</Text>
          {orderDetails.paymentCode && (
            <Text style={styles.paymentCode}>
              Payment Code: {orderDetails.paymentCode}
            </Text>
          )}
          <Pressable style={styles.payButton} onPress={processPayment}>
            <Text style={styles.payButtonText}>
              Pay Now - ₱{orderDetails.totalAmount}
            </Text>
          </Pressable>
        </View>
      )}

        {/* Chat Section */}
        <View style={styles.chatSection}>
          <Text style={styles.sectionTitle}>💭 Chat with Print Shop</Text>
          <View style={styles.chatContainer}>
            {orderId ? (
              <ChatComponent orderId={orderId} />
            ) : (
              <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 }}>
                <Text style={{ color: '#6B7280', textAlign: 'center' }}>
                  Chat unavailable - Order ID missing
                </Text>
              </View>
            )}
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    flex: 1,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#111827',
  },
  placeholder: {
    width: 40,
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  loadingText: {
    fontSize: 16,
    color: '#6B7280',
    marginTop: 16,
  },
  errorContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  errorText: {
    fontSize: 18,
    color: '#EF4444',
    marginTop: 16,
    marginBottom: 24,
  },
  statusCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'white',
    padding: 20,
    marginHorizontal: 16,
    marginVertical: 16,
    borderRadius: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  orderInfo: {
    flex: 1,
  },
  orderTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
  },
  orderDate: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 2,
  },
  statusChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 4,
  },
  section: {
    backgroundColor: 'white',
    padding: 20,
    marginHorizontal: 16,
    marginBottom: 16,
    borderRadius: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 12,
  },
  subTitle: {
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 8,
  },
  fileCard: {
    flexDirection: 'row',
    marginBottom: 16,
    backgroundColor: '#F9FAFB',
    borderRadius: 8,
    padding: 12,
  },
  fileIcon: {
    width: 48,
    height: 48,
    backgroundColor: 'white',
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  fileInfo: {
    flex: 1,
    marginLeft: 12,
  },
  fileName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 8,
  },
  operatorNotes: {
    backgroundColor: '#D1FAE5',
    padding: 8,
    borderRadius: 6,
    marginBottom: 8,
  },
  noteTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: '#065F46',
  },
  noteText: {
    fontSize: 12,
    color: '#065F46',
    fontStyle: 'italic',
    marginTop: 2,
  },
  printSpecs: {
    backgroundColor: '#EFF6FF',
    padding: 8,
    borderRadius: 6,
  },
  specTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: '#1E40AF',
    marginBottom: 4,
  },
  specText: {
    fontSize: 12,
    color: '#1E40AF',
  },
  specItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 4,
  },
  specDescription: {
    flex: 1,
    fontSize: 14,
    color: '#374151',
  },
  specPrice: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#059669',
  },
  totalSection: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
  },
  totalText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#059669',
  },
  timeText: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 4,
  },
  approvalMessage: {
    backgroundColor: '#D1FAE5',
    padding: 12,
    borderRadius: 8,
  },
  operatorText: {
    fontSize: 14,
    color: '#065F46',
    lineHeight: 20,
  },
  paymentSection: {
    backgroundColor: '#FFFBEB',
    padding: 20,
    marginHorizontal: 16,
    marginBottom: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#FDE68A',
  },
  paymentCode: {
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
    color: '#92400E',
    marginBottom: 16,
  },
  payButton: {
    backgroundColor: '#059669',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    alignItems: 'center',
  },
  payButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  backButtonText: {
    color: '#3B82F6',
    fontSize: 16,
    fontWeight: '600',
  },
  chatContainer: {
    height: 400,
    borderRadius: 8,
    overflow: 'hidden',
    backgroundColor: '#F9FAFB',
  },
});