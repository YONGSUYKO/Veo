import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, ScrollView, RefreshControl, Alert, TextInput, Modal, Switch } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';
import { useNewAppStore } from '../state/newAppStore';
import { newApiClient } from '../api/newPisoAPI';
import DesktopLayout from '../components/desktop/DesktopLayout';

interface AdminDesktopDashboardFullProps {
  onSwitchToCustomer?: () => void;
}

export default function AdminDesktopDashboardFull({ onSwitchToCustomer }: AdminDesktopDashboardFullProps) {
  const { currentUser, logout } = useAuthStore();
  const { printJobs, setPrintJobs, systemSettings, setSystemSettings } = useNewAppStore();
  const [refreshing, setRefreshing] = useState(false);
  const [currentView, setCurrentView] = useState<'dashboard' | 'analytics' | 'users' | 'pricing' | 'system' | 'franchise' | 'reports'>('dashboard');
  const [users, setUsers] = useState([
    { id: 1, name: 'John Doe', email: 'john@customer.com', role: 'customer', status: 'active', orders: 15, totalSpent: 2500 },
    { id: 2, name: 'Jane Smith', email: 'jane@operator.com', role: 'operator', status: 'active', shift: 'Morning', performance: 95 },
    { id: 3, name: 'Bob Wilson', email: 'bob@customer.com', role: 'customer', status: 'active', orders: 8, totalSpent: 1200 },
  ]);
  const [pricingSettings, setPricingSettings] = useState({
    documentPrinting: { bw: 100, color: 200 }, // in cents
    photoSizes: {
      '4R': 200,
      '5R': 350,
      '8R': 650
    },
    deliveryFee: 2000,
    loyaltyPointsRate: 100, // 1 point per 100 pesos spent
  });

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const jobs = await newApiClient.getPrintJobs();
      setPrintJobs(jobs);
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadDashboardData();
    setRefreshing(false);
  };

  const getComprehensiveStats = () => {
    const today = new Date().toISOString().split('T')[0];
    const thisWeek = new Date();
    thisWeek.setDate(thisWeek.getDate() - 7);
    const thisMonth = new Date();
    thisMonth.setDate(thisMonth.getDate() - 30);

    const todayJobs = printJobs.filter(job => job.createdAt.toISOString().split('T')[0] === today);
    const weeklyJobs = printJobs.filter(job => new Date(job.createdAt) >= thisWeek);
    const monthlyJobs = printJobs.filter(job => new Date(job.createdAt) >= thisMonth);

    const todayRevenue = todayJobs.reduce((sum, job) => sum + job.totalPrice, 0);
    const weeklyRevenue = weeklyJobs.reduce((sum, job) => sum + job.totalPrice, 0);
    const monthlyRevenue = monthlyJobs.reduce((sum, job) => sum + job.totalPrice, 0);

    return {
      totalJobs: printJobs.length,
      todayJobs: todayJobs.length,
      weeklyJobs: weeklyJobs.length,
      monthlyJobs: monthlyJobs.length,
      todayRevenue,
      weeklyRevenue,
      monthlyRevenue,
      activeUsers: users.filter(u => u.status === 'active' && u.role === 'customer').length,
      operators: users.filter(u => u.role === 'operator').length,
      avgOrderValue: printJobs.length > 0 ? printJobs.reduce((sum, job) => sum + job.totalPrice, 0) / printJobs.length : 0,
      successRate: printJobs.length > 0 ? (printJobs.filter(job => job.status === 'completed').length / printJobs.length) * 100 : 0,
    };
  };

  const navigation = [
    { id: 'dashboard', label: 'Dashboard', icon: 'speedometer' as const, active: currentView === 'dashboard', onPress: () => setCurrentView('dashboard') },
    { id: 'analytics', label: 'Business Analytics', icon: 'bar-chart' as const, active: currentView === 'analytics', onPress: () => setCurrentView('analytics') },
    { id: 'users', label: 'User Management', icon: 'people' as const, active: currentView === 'users', onPress: () => setCurrentView('users') },
    { id: 'pricing', label: 'Pricing Management', icon: 'pricetag' as const, active: currentView === 'pricing', onPress: () => setCurrentView('pricing') },
    { id: 'system', label: 'System Settings', icon: 'settings' as const, active: currentView === 'system', onPress: () => setCurrentView('system') },
    { id: 'franchise', label: 'Franchise Management', icon: 'business' as const, active: currentView === 'franchise', onPress: () => setCurrentView('franchise') },
    { id: 'reports', label: 'Financial Reports', icon: 'document-text' as const, active: currentView === 'reports', onPress: () => setCurrentView('reports') },
  ];

  const actions = [
    { id: 'refresh', label: 'Refresh Data', icon: 'refresh' as const, variant: 'secondary' as const, onPress: onRefresh },
    { id: 'backup', label: 'Backup System', icon: 'cloud-upload' as const, variant: 'primary' as const, onPress: () => Alert.alert('Backup', 'System backup initiated') },
  ];

  const renderDashboardView = () => {
    const stats = getComprehensiveStats();

    return (
      <ScrollView style={{ flex: 1 }} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}>
        {/* Key Metrics */}
        <View style={{ flexDirection: 'row', gap: 16, marginBottom: 24 }}>
          <MetricCard title="Monthly Revenue" value={`₱${(stats.monthlyRevenue / 100).toLocaleString()}`} change="+12.5%" changeType="positive" icon="cash" color="#10B981" />
          <MetricCard title="Total Orders" value={stats.totalJobs.toLocaleString()} change="+8.2%" changeType="positive" icon="receipt" color="#3B82F6" />
          <MetricCard title="Active Customers" value={stats.activeUsers.toString()} change="+15%" changeType="positive" icon="people" color="#8B5CF6" />
          <MetricCard title="Success Rate" value={`${stats.successRate.toFixed(1)}%`} change="+2.1%" changeType="positive" icon="checkmark-circle" color="#F59E0B" />
        </View>

        {/* System Status */}
        <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 24, marginBottom: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
          <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginBottom: 16 }}>System Status</Text>
          <View style={{ flexDirection: 'row', gap: 24 }}>
            <SystemStatusItem label="Print Servers" status="online" color="#10B981" />
            <SystemStatusItem label="Payment Gateway" status="online" color="#10B981" />
            <SystemStatusItem label="Database" status="online" color="#10B981" />
            <SystemStatusItem label="File Storage" status="warning" color="#F59E0B" />
          </View>
        </View>

        {/* Recent Activity */}
        <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
          <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginBottom: 16 }}>Recent System Activity</Text>
          {printJobs.slice(0, 6).map((job) => (
            <ActivityRow key={job.id} job={job} />
          ))}
        </View>
      </ScrollView>
    );
  };

  const renderAnalyticsView = () => {
    const stats = getComprehensiveStats();

    return (
      <ScrollView style={{ flex: 1 }}>
        {/* Revenue Analytics */}
        <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 24, marginBottom: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
          <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginBottom: 16 }}>Revenue Analytics</Text>
          <View style={{ flexDirection: 'row', gap: 16, marginBottom: 20 }}>
            <AnalyticsCard title="Today" value={`₱${(stats.todayRevenue / 100).toFixed(2)}`} />
            <AnalyticsCard title="This Week" value={`₱${(stats.weeklyRevenue / 100).toFixed(2)}`} />
            <AnalyticsCard title="This Month" value={`₱${(stats.monthlyRevenue / 100).toFixed(2)}`} />
          </View>
          <Text style={{ fontSize: 14, color: '#6B7280', marginBottom: 8 }}>Average Order Value: ₱{(stats.avgOrderValue / 100).toFixed(2)}</Text>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>Peak Hours: 2:00 PM - 4:00 PM (based on historical data)</Text>
        </View>

        {/* Service Performance */}
        <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 24, marginBottom: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
          <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginBottom: 16 }}>Service Performance</Text>
          <ServicePerformanceRow service="Document Printing" percentage={65} revenue={45000} />
          <ServicePerformanceRow service="Photo Printing" percentage={25} revenue={18000} />
          <ServicePerformanceRow service="Business Services" percentage={10} revenue={8000} />
        </View>

        {/* Customer Analytics */}
        <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
          <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginBottom: 16 }}>Customer Analytics</Text>
          <View style={{ gap: 12 }}>
            <AnalyticsRow label="Total Registered Users" value={users.filter(u => u.role === 'customer').length.toString()} />
            <AnalyticsRow label="New Users This Month" value="28" />
            <AnalyticsRow label="Returning Customers" value="78%" />
            <AnalyticsRow label="Customer Satisfaction" value="4.8/5" />
          </View>
        </View>
      </ScrollView>
    );
  };

  const renderUsersView = () => (
    <ScrollView style={{ flex: 1 }}>
      <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 24, marginBottom: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827' }}>User Management</Text>
          <View style={{ flexDirection: 'row', gap: 12 }}>
            <Pressable style={{ backgroundColor: '#10B981', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8 }}>
              <Text style={{ color: 'white', fontWeight: '600' }}>Add User</Text>
            </Pressable>
            <Pressable style={{ backgroundColor: '#3B82F6', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8 }}>
              <Text style={{ color: 'white', fontWeight: '600' }}>Export Data</Text>
            </Pressable>
          </View>
        </View>

        {/* User Table */}
        <View style={{ borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8 }}>
          <View style={{ backgroundColor: '#F9FAFB', padding: 16, flexDirection: 'row' }}>
            <Text style={{ flex: 1, fontWeight: '600', color: '#374151' }}>Name</Text>
            <Text style={{ flex: 1, fontWeight: '600', color: '#374151' }}>Email</Text>
            <Text style={{ flex: 0.8, fontWeight: '600', color: '#374151' }}>Role</Text>
            <Text style={{ flex: 0.8, fontWeight: '600', color: '#374151' }}>Status</Text>
            <Text style={{ flex: 1, fontWeight: '600', color: '#374151' }}>Details</Text>
          </View>
          {users.map((user) => (
            <UserRow key={user.id} user={user} />
          ))}
        </View>
      </View>
    </ScrollView>
  );

  const renderPricingView = () => (
    <ScrollView style={{ flex: 1 }}>
      <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 24, marginBottom: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
        <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginBottom: 16 }}>Pricing Management</Text>
        
        <View style={{ marginBottom: 24 }}>
          <Text style={{ fontSize: 16, fontWeight: '600', color: '#374151', marginBottom: 12 }}>Document Printing</Text>
          <PricingRow label="Black & White (per page)" value={pricingSettings.documentPrinting.bw} onUpdate={(value) => setPricingSettings(prev => ({...prev, documentPrinting: {...prev.documentPrinting, bw: value}}))} />
          <PricingRow label="Color (per page)" value={pricingSettings.documentPrinting.color} onUpdate={(value) => setPricingSettings(prev => ({...prev, documentPrinting: {...prev.documentPrinting, color: value}}))} />
        </View>

        <View style={{ marginBottom: 24 }}>
          <Text style={{ fontSize: 16, fontWeight: '600', color: '#374151', marginBottom: 12 }}>Photo Printing</Text>
          <PricingRow label="4R (4\" x 6\")" value={pricingSettings.photoSizes['4R']} onUpdate={(value) => setPricingSettings(prev => ({...prev, photoSizes: {...prev.photoSizes, '4R': value}}))} />
          <PricingRow label="5R (5\" x 7\")" value={pricingSettings.photoSizes['5R']} onUpdate={(value) => setPricingSettings(prev => ({...prev, photoSizes: {...prev.photoSizes, '5R': value}}))} />
          <PricingRow label="8R (8\" x 10\")" value={pricingSettings.photoSizes['8R']} onUpdate={(value) => setPricingSettings(prev => ({...prev, photoSizes: {...prev.photoSizes, '8R': value}}))} />
        </View>

        <View>
          <Text style={{ fontSize: 16, fontWeight: '600', color: '#374151', marginBottom: 12 }}>Other Settings</Text>
          <PricingRow label="Delivery Fee" value={pricingSettings.deliveryFee} onUpdate={(value) => setPricingSettings(prev => ({...prev, deliveryFee: value}))} />
          <PricingRow label="Loyalty Points Rate (per 100 pesos)" value={pricingSettings.loyaltyPointsRate} onUpdate={(value) => setPricingSettings(prev => ({...prev, loyaltyPointsRate: value}))} />
        </View>
      </View>
    </ScrollView>
  );

  const renderSystemView = () => (
    <ScrollView style={{ flex: 1 }}>
      <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 24, marginBottom: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
        <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginBottom: 16 }}>System Configuration</Text>
        
        <View style={{ gap: 16 }}>
          <SystemSettingRow label="Enable SMS Notifications" value={systemSettings.smsEnabled} onToggle={(value) => setSystemSettings(prev => ({...prev, smsEnabled: value}))} />
          <SystemSettingRow label="Auto-Accept Orders" value={systemSettings.autoAcceptOrders} onToggle={(value) => setSystemSettings(prev => ({...prev, autoAcceptOrders: value}))} />
          <SystemSettingRow label="Allow Guest Orders" value={systemSettings.allowGuestOrders} onToggle={(value) => setSystemSettings(prev => ({...prev, allowGuestOrders: value}))} />
          <SystemSettingRow label="Maintenance Mode" value={systemSettings.maintenanceMode} onToggle={(value) => setSystemSettings(prev => ({...prev, maintenanceMode: value}))} />
        </View>
      </View>

      <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
        <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginBottom: 16 }}>System Actions</Text>
        <View style={{ flexDirection: 'row', gap: 12 }}>
          <Pressable style={{ backgroundColor: '#10B981', paddingHorizontal: 16, paddingVertical: 12, borderRadius: 8 }}>
            <Text style={{ color: 'white', fontWeight: '600' }}>Backup Database</Text>
          </Pressable>
          <Pressable style={{ backgroundColor: '#F59E0B', paddingHorizontal: 16, paddingVertical: 12, borderRadius: 8 }}>
            <Text style={{ color: 'white', fontWeight: '600' }}>Clear Cache</Text>
          </Pressable>
          <Pressable style={{ backgroundColor: '#3B82F6', paddingHorizontal: 16, paddingVertical: 12, borderRadius: 8 }}>
            <Text style={{ color: 'white', fontWeight: '600' }}>Export Logs</Text>
          </Pressable>
        </View>
      </View>
    </ScrollView>
  );

  const renderCurrentView = () => {
    switch (currentView) {
      case 'dashboard': return renderDashboardView();
      case 'analytics': return renderAnalyticsView();
      case 'users': return renderUsersView();
      case 'pricing': return renderPricingView();
      case 'system': return renderSystemView();
      case 'franchise': return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <Text style={{ fontSize: 18, color: '#6B7280' }}>Franchise Management Panel</Text>
        </View>
      );
      case 'reports': return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <Text style={{ fontSize: 18, color: '#6B7280' }}>Financial Reports Panel</Text>
        </View>
      );
      default: return renderDashboardView();
    }
  };

  return (
    <DesktopLayout
      title="Admin Dashboard"
      subtitle="System administration and business management"
      userInfo={{
        name: currentUser?.name || 'Administrator',
        role: 'admin'
      }}
      navigation={navigation}
      actions={actions}
      onLogout={logout}
    >
      {renderCurrentView()}
    </DesktopLayout>
  );
}

// Helper Components
function MetricCard({ title, value, change, changeType, icon, color }: {
  title: string;
  value: string;
  change: string;
  changeType: 'positive' | 'negative';
  icon: any;
  color: string;
}) {
  return (
    <View style={{ flex: 1, backgroundColor: 'white', borderRadius: 12, padding: 20, borderWidth: 1, borderColor: '#E5E7EB' }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <Text style={{ fontSize: 14, color: '#6B7280' }}>{title}</Text>
        <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: color + '20', alignItems: 'center', justifyContent: 'center' }}>
          <Ionicons name={icon} size={20} color={color} />
        </View>
      </View>
      <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#111827', marginBottom: 4 }}>{value}</Text>
      <Text style={{ fontSize: 12, color: changeType === 'positive' ? '#10B981' : '#DC2626' }}>{change} from last month</Text>
    </View>
  );
}

function SystemStatusItem({ label, status, color }: { label: string; status: string; color: string }) {
  return (
    <View style={{ flex: 1, alignItems: 'center' }}>
      <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: color, marginBottom: 8 }} />
      <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827', marginBottom: 2 }}>{label}</Text>
      <Text style={{ fontSize: 12, color: '#6B7280', textTransform: 'capitalize' }}>{status}</Text>
    </View>
  );
}

function ActivityRow({ job }: { job: any }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' }}>
      <View>
        <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827' }}>Order #{job.id.slice(-6)}</Text>
        <Text style={{ fontSize: 12, color: '#6B7280' }}>{job.customerInfo.name} • ₱{(job.totalPrice / 100).toFixed(2)}</Text>
      </View>
      <Text style={{ fontSize: 12, color: '#6B7280' }}>{new Date(job.createdAt).toLocaleDateString()}</Text>
    </View>
  );
}

function AnalyticsCard({ title, value }: { title: string; value: string }) {
  return (
    <View style={{ flex: 1, backgroundColor: '#F9FAFB', borderRadius: 8, padding: 16 }}>
      <Text style={{ fontSize: 12, color: '#6B7280', marginBottom: 4 }}>{title}</Text>
      <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#111827' }}>{value}</Text>
    </View>
  );
}

function ServicePerformanceRow({ service, percentage, revenue }: { service: string; percentage: number; revenue: number }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' }}>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827' }}>{service}</Text>
        <View style={{ backgroundColor: '#E5E7EB', height: 4, borderRadius: 2, marginTop: 4 }}>
          <View style={{ backgroundColor: '#3B82F6', height: 4, borderRadius: 2, width: `${percentage}%` }} />
        </View>
      </View>
      <View style={{ alignItems: 'flex-end', marginLeft: 16 }}>
        <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827' }}>{percentage}%</Text>
        <Text style={{ fontSize: 12, color: '#6B7280' }}>₱{(revenue / 100).toFixed(2)}</Text>
      </View>
    </View>
  );
}

function AnalyticsRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
      <Text style={{ fontSize: 14, color: '#6B7280' }}>{label}</Text>
      <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827' }}>{value}</Text>
    </View>
  );
}

function UserRow({ user }: { user: any }) {
  return (
    <View style={{ padding: 16, flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: '#E5E7EB' }}>
      <Text style={{ flex: 1, fontSize: 14, color: '#111827' }}>{user.name}</Text>
      <Text style={{ flex: 1, fontSize: 14, color: '#6B7280' }}>{user.email}</Text>
      <Text style={{ flex: 0.8, fontSize: 14, color: '#6B7280', textTransform: 'capitalize' }}>{user.role}</Text>
      <View style={{ flex: 0.8 }}>
        <View style={{ paddingHorizontal: 8, paddingVertical: 2, borderRadius: 12, backgroundColor: user.status === 'active' ? '#D1FAE5' : '#FEE2E2', alignSelf: 'flex-start' }}>
          <Text style={{ fontSize: 12, color: user.status === 'active' ? '#065F46' : '#991B1B', textTransform: 'capitalize' }}>{user.status}</Text>
        </View>
      </View>
      <Text style={{ flex: 1, fontSize: 14, color: '#6B7280' }}>
        {user.role === 'customer' ? `${user.orders} orders • ₱${user.totalSpent}` : `${user.shift} • ${user.performance}%`}
      </Text>
    </View>
  );
}

function PricingRow({ label, value, onUpdate }: { label: string; value: number; onUpdate: (value: number) => void }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' }}>
      <Text style={{ fontSize: 14, color: '#374151', flex: 1 }}>{label}</Text>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <Text style={{ fontSize: 14, color: '#6B7280', marginRight: 8 }}>₱</Text>
        <TextInput
          style={{ borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 4, padding: 8, width: 80, textAlign: 'right' }}
          value={(value / 100).toFixed(2)}
          onChangeText={(text) => onUpdate(Math.round(parseFloat(text || '0') * 100))}
          keyboardType="numeric"
        />
      </View>
    </View>
  );
}

function SystemSettingRow({ label, value, onToggle }: { label: string; value: boolean; onToggle: (value: boolean) => void }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12 }}>
      <Text style={{ fontSize: 14, color: '#374151' }}>{label}</Text>
      <Switch value={value} onValueChange={onToggle} />
    </View>
  );
}