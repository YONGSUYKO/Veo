import React, { useState, useEffect } from 'react';
import { View, Alert } from 'react-native';
import { useAuthStore } from '../state/authStore';
import { useNewAppStore, FileInfo } from '../state/newAppStore';
import { newApiClient } from '../api/newPisoAPI';

import WelcomeScreen from './WelcomeScreen';
import FileUploadScreen from './FileUploadScreen';
import FileInfoScreen from './FileInfoScreen';
import PaymentScreen from './PaymentScreen';
import OrderCompleteScreen from './OrderCompleteScreen';
import RoleSelectionScreen from './RoleSelectionScreen';
import AdminDashboard from './AdminDashboard';
import OperatorDashboard from './OperatorDashboard';

type AppFlow = 
  | 'role_selection'
  | 'admin_dashboard'
  | 'operator_dashboard'
  | 'welcome' 
  | 'file_upload' 
  | 'file_info' 
  | 'payment' 
  | 'order_complete';

export default function MainAppScreen() {
  const { currentUser, isAuthenticated } = useAuthStore();
  const { addPrintJob } = useNewAppStore();
  
  const [currentFlow, setCurrentFlow] = useState<AppFlow>('role_selection');
  const [selectedService, setSelectedService] = useState<'document' | 'scan' | 'photo' | null>(null);
  const [processedFiles, setProcessedFiles] = useState<FileInfo[]>([]);
  const [currentOrder, setCurrentOrder] = useState<any>(null);

  useEffect(() => {
    if (isAuthenticated && currentUser) {
      // Determine initial screen based on user role
      switch (currentUser.role) {
        case 'admin':
          setCurrentFlow('admin_dashboard');
          break;
        case 'operator':
          setCurrentFlow('operator_dashboard');
          break;
        case 'customer':
        default:
          setCurrentFlow('welcome');
          break;
      }
    } else {
      setCurrentFlow('role_selection');
    }
  }, [isAuthenticated, currentUser]);

  const handleServiceSelect = (service: 'document' | 'scan' | 'photo') => {
    setSelectedService(service);
    setCurrentFlow('file_upload');
  };

  const handleFilesProcessed = (files: FileInfo[]) => {
    setProcessedFiles(files);
    setCurrentFlow('file_info');
  };

  const handleFilesUpdated = (files: FileInfo[]) => {
    setProcessedFiles(files);
  };

  const handleProceedToPayment = (files: FileInfo[]) => {
    setProcessedFiles(files);
    setCurrentFlow('payment');
  };

  const handlePaymentComplete = async (orderData: any) => {
    try {
      // Create print job
      const printJobData = {
        customerInfo: orderData.customerInfo,
        files: orderData.files,
        totalPrice: orderData.pricing.total,
        loyaltyPointsUsed: orderData.loyaltyPointsUsed,
        paymentMethod: orderData.paymentMethod,
        fulfillmentMethod: orderData.fulfillmentMethod,
        deliveryCourier: orderData.selectedCourier,
        deliveryFee: orderData.pricing.deliveryFee,
        status: 'queue' as const,
      };

      const createdJob = await newApiClient.createPrintJob(printJobData);
      addPrintJob(createdJob);
      
      setCurrentOrder({
        ...orderData,
        printJobId: createdJob.id,
      });
      
      setCurrentFlow('order_complete');

      // Show success alert with job details
      Alert.alert(
        'Order Placed Successfully!',
        `Your print job #${createdJob.id.slice(-6)} has been submitted and is now in queue. You will receive notifications about the progress.`,
        [{ text: 'OK' }]
      );
      
    } catch (error) {
      Alert.alert(
        'Order Failed', 
        'There was an error processing your order. Please try again.',
        [{ text: 'OK' }]
      );
    }
  };

  const handleBackToWelcome = () => {
    setCurrentFlow('welcome');
    setSelectedService(null);
    setProcessedFiles([]);
    setCurrentOrder(null);
  };

  const handleNewOrder = () => {
    setCurrentFlow('welcome');
    setSelectedService(null);
    setProcessedFiles([]);
    setCurrentOrder(null);
  };

  const handleSwitchToCustomer = () => {
    setCurrentFlow('welcome');
    setSelectedService(null);
    setProcessedFiles([]);
    setCurrentOrder(null);
  };

  const renderCurrentScreen = () => {
    switch (currentFlow) {
      case 'role_selection':
        return (
          <RoleSelectionScreen
            onRoleSelected={() => {
              if (currentUser?.role === 'admin') {
                setCurrentFlow('admin_dashboard');
              } else if (currentUser?.role === 'operator') {
                setCurrentFlow('operator_dashboard');
              } else {
                setCurrentFlow('welcome');
              }
            }}
          />
        );

      case 'admin_dashboard':
        return (
          <AdminDashboard
            onSwitchToCustomer={handleSwitchToCustomer}
          />
        );

      case 'operator_dashboard':
        return (
          <OperatorDashboard
            onSwitchToCustomer={handleSwitchToCustomer}
          />
        );

      case 'welcome':
        return (
          <WelcomeScreen
            onServiceSelect={handleServiceSelect}
            onBackToDashboard={
              currentUser?.role === 'admin' 
                ? () => setCurrentFlow('admin_dashboard')
                : currentUser?.role === 'operator'
                ? () => setCurrentFlow('operator_dashboard')
                : undefined
            }
          />
        );

      case 'file_upload':
        return (
          <FileUploadScreen
            serviceType={selectedService!}
            onFilesProcessed={handleFilesProcessed}
            onBack={handleBackToWelcome}
          />
        );

      case 'file_info':
        return (
          <FileInfoScreen
            files={processedFiles}
            onFilesUpdated={handleFilesUpdated}
            onProceedToPayment={handleProceedToPayment}
            onBack={() => setCurrentFlow('file_upload')}
          />
        );

      case 'payment':
        return (
          <PaymentScreen
            files={processedFiles}
            onPaymentComplete={handlePaymentComplete}
            onBack={() => setCurrentFlow('file_info')}
          />
        );

      case 'order_complete':
        return (
          <OrderCompleteScreen
            orderData={currentOrder}
            onNewOrder={handleNewOrder}
            onBackToWelcome={handleBackToWelcome}
          />
        );

      default:
        return (
          <WelcomeScreen
            onServiceSelect={handleServiceSelect}
          />
        );
    }
  };

  return (
    <View className="flex-1">
      {renderCurrentScreen()}
    </View>
  );
}