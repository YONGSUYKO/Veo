import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, ScrollView, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNewAppStore } from '../state/newAppStore';
import { newApiClient } from '../api/newPisoAPI';
import { cn } from '../utils/cn';

interface OrderCompleteScreenProps {
  orderData: any;
  onNewOrder: () => void;
  onBackToWelcome: () => void;
}

export default function OrderCompleteScreen({ orderData, onNewOrder, onBackToWelcome }: OrderCompleteScreenProps) {
  const insets = useSafeAreaInsets();
  const { printJobs, updatePrintJob } = useNewAppStore();
  const [currentStatus, setCurrentStatus] = useState<'queue' | 'ongoing' | 'ready' | 'completed' | 'failed'>('queue');
  const [notifications, setNotifications] = useState<Array<{
    id: string;
    message: string;
    timestamp: Date;
    status: string;
  }>>([]);

  useEffect(() => {
    // Add initial notification
    addNotification('Your print job has been submitted and is now in queue.', 'queue');
    
    // Simulate status updates (in real app this would come from WebSocket or push notifications)
    const statusSequence = [
      { status: 'ongoing', delay: 5000, message: 'Your print job is now being processed.' },
      { status: 'ready', delay: 10000, message: 'Your print job is ready for pickup/delivery!' },
    ];

    statusSequence.forEach(({ status, delay, message }) => {
      setTimeout(() => {
        setCurrentStatus(status as any);
        addNotification(message, status);
        
        // Update in store
        if (orderData.printJobId) {
          updatePrintJob(orderData.printJobId, { status: status as any });
        }
      }, delay);
    });
  }, []);

  const addNotification = (message: string, status: string) => {
    const newNotification = {
      id: Date.now().toString(),
      message,
      timestamp: new Date(),
      status,
    };
    setNotifications(prev => [newNotification, ...prev]);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'queue': return 'text-orange-600';
      case 'ongoing': return 'text-blue-600';
      case 'ready': return 'text-green-600';
      case 'completed': return 'text-green-800';
      case 'failed': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'queue': return 'time';
      case 'ongoing': return 'print';
      case 'ready': return 'checkmark-circle';
      case 'completed': return 'checkmark-done-circle';
      case 'failed': return 'close-circle';
      default: return 'ellipse';
    }
  };

  const getStatusMessage = (status: string) => {
    switch (status) {
      case 'queue': return 'Your order is in the printing queue';
      case 'ongoing': return 'Your order is being printed';
      case 'ready': return `Your order is ready for ${orderData.fulfillmentMethod}!`;
      case 'completed': return 'Order completed successfully';
      case 'failed': return 'There was an issue with your order';
      default: return 'Processing your order';
    }
  };

  return (
    <View className="flex-1 bg-white">
      <ScrollView>
        <View style={{ paddingTop: insets.top + 20 }} className="px-6 pb-8">
          
          {/* Success Header */}
          <View className="items-center mb-8">
            <View className="w-20 h-20 bg-green-100 rounded-full items-center justify-center mb-4">
              <Ionicons name="checkmark" size={48} color="#10B981" />
            </View>
            <Text className="text-2xl font-bold text-gray-900 mb-2">
              Order Placed Successfully!
            </Text>
            <Text className="text-gray-600 text-center">
              Your print job has been submitted and will be processed shortly.
            </Text>
          </View>

          {/* Order Details */}
          <View className="bg-gray-50 rounded-2xl p-6 mb-6">
            <Text className="text-lg font-semibold text-gray-900 mb-4">
              Order Details
            </Text>
            
            <View className="space-y-3">
              <DetailRow 
                label="Order ID" 
                value={`#${orderData.printJobId?.slice(-6) || '000000'}`} 
              />
              <DetailRow 
                label="Customer" 
                value={orderData.customerInfo.name} 
              />
              {orderData.customerInfo.phone && (
                <DetailRow 
                  label="Phone" 
                  value={orderData.customerInfo.phone} 
                />
              )}
              <DetailRow 
                label="Files" 
                value={`${orderData.files.length} file(s)`} 
              />
              <DetailRow 
                label="Payment Method" 
                value={orderData.paymentMethod.toUpperCase()} 
              />
              <DetailRow 
                label="Fulfillment" 
                value={orderData.fulfillmentMethod === 'pickup' ? 'Store Pickup' : `Delivery (${orderData.selectedCourier})`} 
              />
              <DetailRow 
                label="Total Amount" 
                value={`₱${(orderData.pricing.total / 100).toFixed(2)}`}
                highlight 
              />
            </View>
          </View>

          {/* QR Code for Pickup */}
          {orderData.fulfillmentMethod === 'pickup' && (
            <View className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-6 mb-6">
              <View className="items-center">
                <Text className="text-lg font-semibold text-gray-900 mb-4">
                  Store Pickup QR Code
                </Text>
                
                {/* QR Code Placeholder - In production, use react-native-qrcode-svg */}
                <View className="w-48 h-48 bg-white rounded-xl border-2 border-gray-300 items-center justify-center mb-4">
                  <View className="w-40 h-40 bg-gray-900 rounded-lg items-center justify-center">
                    <Text className="text-white text-xs text-center px-2">
                      QR CODE{'\n'}{orderData.printJobId?.slice(-8) || '12345678'}
                    </Text>
                  </View>
                </View>
                
                <Text className="text-center text-gray-700 mb-2 font-medium">
                  Job ID: #{orderData.printJobId?.slice(-8) || '12345678'}
                </Text>
                
                <View className="bg-white rounded-xl p-4 w-full">
                  <Text className="text-sm text-gray-600 text-center mb-2">
                    📱 Show this QR code to staff for pickup
                  </Text>
                  <Text className="text-xs text-gray-500 text-center">
                    Store Location: 123 Print Street, Manila{'\n'}
                    Hours: 8:00 AM - 8:00 PM (Mon-Sat)
                  </Text>
                </View>
                
                <Pressable 
                  className="bg-blue-500 py-3 px-6 rounded-xl mt-4"
                  onPress={() => {
                    // In production, this would share/save the QR code
                    Alert.alert('QR Code', 'QR code saved to your device!');
                  }}
                >
                  <Text className="text-white font-medium">
                    Save QR Code
                  </Text>
                </Pressable>
              </View>
            </View>
          )}

          {/* Current Status */}
          <View className="bg-white border-2 border-gray-200 rounded-2xl p-6 mb-6">
            <Text className="text-lg font-semibold text-gray-900 mb-4">
              Current Status
            </Text>
            
            <View className="flex-row items-center mb-4">
              <View className={cn(
                "w-12 h-12 rounded-full items-center justify-center mr-4",
                currentStatus === 'ready' ? 'bg-green-100' :
                currentStatus === 'ongoing' ? 'bg-blue-100' : 'bg-orange-100'
              )}>
                <Ionicons 
                  name={getStatusIcon(currentStatus)} 
                  size={24} 
                  color={
                    currentStatus === 'ready' ? '#10B981' :
                    currentStatus === 'ongoing' ? '#3B82F6' : '#F59E0B'
                  } 
                />
              </View>
              <View className="flex-1">
                <Text className={cn("text-lg font-semibold capitalize", getStatusColor(currentStatus))}>
                  {currentStatus}
                </Text>
                <Text className="text-gray-600">
                  {getStatusMessage(currentStatus)}
                </Text>
              </View>
            </View>

            {/* Status Timeline */}
            <View className="space-y-3">
              {[
                { key: 'queue', label: 'Order Received', completed: true },
                { key: 'ongoing', label: 'Printing in Progress', completed: ['ongoing', 'ready', 'completed'].includes(currentStatus) },
                { key: 'ready', label: orderData.fulfillmentMethod === 'pickup' ? 'Ready for Pickup' : 'Ready for Delivery', completed: ['ready', 'completed'].includes(currentStatus) },
              ].map((step, index) => (
                <View key={step.key} className="flex-row items-center">
                  <View className={cn(
                    "w-4 h-4 rounded-full border-2 mr-3",
                    step.completed 
                      ? "bg-green-500 border-green-500" 
                      : "border-gray-300"
                  )}>
                    {step.completed && (
                      <View className="w-full h-full items-center justify-center">
                        <Ionicons name="checkmark" size={10} color="white" />
                      </View>
                    )}
                  </View>
                  <Text className={cn(
                    "text-sm",
                    step.completed ? "text-gray-900 font-medium" : "text-gray-500"
                  )}>
                    {step.label}
                  </Text>
                </View>
              ))}
            </View>
          </View>

          {/* Live Notifications */}
          {notifications.length > 0 && (
            <View className="mb-6">
              <Text className="text-lg font-semibold text-gray-900 mb-4">
                Live Updates
              </Text>
              <View className="space-y-3">
                {notifications.map((notification) => (
                  <View key={notification.id} className="bg-blue-50 border-l-4 border-blue-400 rounded-r-xl p-4">
                    <View className="flex-row items-start">
                      <Ionicons name="notifications" size={16} color="#3B82F6" />
                      <View className="ml-3 flex-1">
                        <Text className="text-blue-900 text-sm font-medium">
                          {notification.message}
                        </Text>
                        <Text className="text-blue-700 text-xs mt-1">
                          {notification.timestamp.toLocaleTimeString()}
                        </Text>
                      </View>
                    </View>
                  </View>
                ))}
              </View>
            </View>
          )}

          {/* Contact Information */}
          <View className="bg-yellow-50 border border-yellow-200 rounded-2xl p-6 mb-6">
            <Text className="text-lg font-semibold text-yellow-900 mb-3">
              Need Help?
            </Text>
            <Text className="text-yellow-800 text-sm mb-4">
              If you have any questions about your order or need assistance, feel free to contact us.
            </Text>
            <View className="space-y-2">
              <View className="flex-row items-center">
                <Ionicons name="call" size={16} color="#F59E0B" />
                <Text className="text-yellow-800 ml-2 text-sm">+63 912 345 6789</Text>
              </View>
              <View className="flex-row items-center">
                <Ionicons name="mail" size={16} color="#F59E0B" />
                <Text className="text-yellow-800 ml-2 text-sm">support@pisoprint.com</Text>
              </View>
              <View className="flex-row items-center">
                <Ionicons name="location" size={16} color="#F59E0B" />
                <Text className="text-yellow-800 ml-2 text-sm">123 Print Street, Manila</Text>
              </View>
            </View>
          </View>

        </View>
      </ScrollView>

      {/* Action Buttons */}
      <View className="px-6 pt-4 pb-6 bg-white border-t border-gray-200" style={{ paddingBottom: Math.max(insets.bottom, 24) }}>
        <View className="space-y-3">
          <Pressable 
            className="bg-blue-500 py-4 rounded-xl"
            onPress={onNewOrder}
          >
            <Text className="text-white text-center font-semibold text-lg">
              Place New Order
            </Text>
          </Pressable>
          
          <Pressable 
            className="bg-gray-100 py-4 rounded-xl"
            onPress={onBackToWelcome}
          >
            <Text className="text-gray-700 text-center font-semibold text-lg">
              Back to Home
            </Text>
          </Pressable>
        </View>
      </View>

    </View>
  );
}

function DetailRow({ label, value, highlight = false }: { 
  label: string; 
  value: string; 
  highlight?: boolean; 
}) {
  return (
    <View className="flex-row justify-between items-center">
      <Text className="text-gray-600 text-sm">{label}</Text>
      <Text className={cn(
        "font-medium text-sm",
        highlight ? "text-blue-600 font-bold text-base" : "text-gray-900"
      )}>
        {value}
      </Text>
    </View>
  );
}