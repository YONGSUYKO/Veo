import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, ScrollView, RefreshControl, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';
import { useNewAppStore } from '../state/newAppStore';
import { newApiClient } from '../api/newPisoAPI';
import { useDeviceInfo } from '../utils/deviceDetection';
import DesktopLayout from '../components/desktop/DesktopLayout';
import AdminSettingsScreen from './AdminSettingsScreen';
import AdminPricingManager from '../components/AdminPricingManager';

interface AdminDesktopDashboardProps {
  onSwitchToCustomer: () => void;
}

export default function AdminDesktopDashboard({ onSwitchToCustomer }: AdminDesktopDashboardProps) {
  const deviceInfo = useDeviceInfo();
  const { currentUser, logout } = useAuthStore();
  const { printJobs, setPrintJobs } = useNewAppStore();
  const [refreshing, setRefreshing] = useState(false);
  const [currentView, setCurrentView] = useState<'dashboard' | 'settings' | 'pricing' | 'analytics' | 'staff' | 'payments'>('dashboard');
  const [dashboardStats, setDashboardStats] = useState({
    totalJobs: 0,
    todayRevenue: 0,
    activeOperators: 0,
    queueLength: 0,
    weeklyGrowth: 12.5,
    monthlyRevenue: 125430,
    avgJobValue: 45.50,
    customerSatisfaction: 98.2,
  });

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const jobs = await newApiClient.getPrintJobs();
      setPrintJobs(jobs);
      
      // Calculate comprehensive stats for desktop
      const today = new Date().toISOString().split('T')[0];
      const todayJobs = jobs.filter(job => 
        job.createdAt.toISOString().split('T')[0] === today
      );
      
      const thisWeek = jobs.filter(job => {
        const jobDate = new Date(job.createdAt);
        const weekAgo = new Date();
        weekAgo.setDate(weekAgo.getDate() - 7);
        return jobDate >= weekAgo;
      });
      
      setDashboardStats({
        totalJobs: jobs.length,
        todayRevenue: todayJobs.reduce((sum, job) => sum + job.totalPrice, 0),
        activeOperators: 2,
        queueLength: jobs.filter(job => job.status === 'queue').length,
        weeklyGrowth: 12.5,
        monthlyRevenue: jobs.reduce((sum, job) => sum + job.totalPrice, 0),
        avgJobValue: jobs.length > 0 ? jobs.reduce((sum, job) => sum + job.totalPrice, 0) / jobs.length / 100 : 0,
        customerSatisfaction: 98.2,
      });
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadDashboardData();
    setRefreshing(false);
  };

  const navigation = [
    { id: 'dashboard', label: 'Dashboard', icon: 'speedometer' as const, active: currentView === 'dashboard', onPress: () => setCurrentView('dashboard') },
    { id: 'settings', label: 'System Settings', icon: 'settings' as const, active: currentView === 'settings', onPress: () => setCurrentView('settings') },
    { id: 'pricing', label: 'Pricing Management', icon: 'pricetag' as const, active: currentView === 'pricing', onPress: () => setCurrentView('pricing') },
    { id: 'analytics', label: 'Business Analytics', icon: 'bar-chart' as const, active: currentView === 'analytics', onPress: () => setCurrentView('analytics') },
    { id: 'staff', label: 'Staff Management', icon: 'people' as const, active: currentView === 'staff', onPress: () => setCurrentView('staff') },
    { id: 'payments', label: 'Payment Systems', icon: 'card' as const, active: currentView === 'payments', onPress: () => setCurrentView('payments') },
  ];

  const actions = [
    { id: 'refresh', label: 'Refresh Data', icon: 'refresh' as const, variant: 'secondary' as const, onPress: onRefresh },
    { id: 'customer-view', label: 'Customer View', icon: 'person' as const, variant: 'primary' as const, onPress: onSwitchToCustomer },
  ];

  const renderDashboardContent = () => {
    switch (currentView) {
      case 'settings':
        return <AdminSettingsScreen onBack={() => setCurrentView('dashboard')} />;
      
      case 'pricing':
        return <AdminPricingManager onClose={() => setCurrentView('dashboard')} />;
      
      case 'analytics':
        return renderAnalyticsView();
      
      case 'staff':
        return renderStaffView();
      
      case 'payments':
        return renderPaymentsView();
      
      default:
        return renderMainDashboard();
    }
  };

  const renderMainDashboard = () => (
    <ScrollView 
      style={{ flex: 1 }}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      showsVerticalScrollIndicator={false}
    >
      {/* Key Metrics Grid */}
      <View style={{ flexDirection: 'row', gap: 24, marginBottom: 32 }}>
        <MetricCard
          title="Today's Revenue"
          value={`₱${(dashboardStats.todayRevenue / 100).toFixed(2)}`}
          change="+₱125.50"
          changeType="positive"
          icon="cash"
          color="#10B981"
        />
        <MetricCard
          title="Total Jobs"
          value={dashboardStats.totalJobs.toString()}
          change="+23"
          changeType="positive"
          icon="print"
          color="#3B82F6"
        />
        <MetricCard
          title="Queue Length"
          value={dashboardStats.queueLength.toString()}
          change="-2"
          changeType="negative"
          icon="time"
          color="#F59E0B"
        />
        <MetricCard
          title="Active Staff"
          value={dashboardStats.activeOperators.toString()}
          change="Online"
          changeType="neutral"
          icon="people"
          color="#8B5CF6"
        />
      </View>

      {/* Secondary Metrics */}
      <View style={{ flexDirection: 'row', gap: 24, marginBottom: 32 }}>
        <View style={{ flex: 1, backgroundColor: 'white', borderRadius: 12, padding: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
          <Text style={{ fontSize: 16, fontWeight: '600', color: '#374151', marginBottom: 8 }}>
            Weekly Growth
          </Text>
          <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#10B981', marginBottom: 4 }}>
            +{dashboardStats.weeklyGrowth}%
          </Text>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>
            Compared to last week
          </Text>
        </View>
        
        <View style={{ flex: 1, backgroundColor: 'white', borderRadius: 12, padding: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
          <Text style={{ fontSize: 16, fontWeight: '600', color: '#374151', marginBottom: 8 }}>
            Average Job Value
          </Text>
          <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#3B82F6', marginBottom: 4 }}>
            ₱{dashboardStats.avgJobValue.toFixed(2)}
          </Text>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>
            Per completed job
          </Text>
        </View>
        
        <View style={{ flex: 1, backgroundColor: 'white', borderRadius: 12, padding: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
          <Text style={{ fontSize: 16, fontWeight: '600', color: '#374151', marginBottom: 8 }}>
            Customer Satisfaction
          </Text>
          <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#10B981', marginBottom: 4 }}>
            {dashboardStats.customerSatisfaction}%
          </Text>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>
            Based on feedback
          </Text>
        </View>
      </View>

      {/* Recent Jobs Table */}
      <View style={{ backgroundColor: 'white', borderRadius: 12, borderWidth: 1, borderColor: '#E5E7EB' }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 24, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' }}>
          <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827' }}>
            Recent Print Jobs
          </Text>
          <Pressable onPress={() => Alert.alert('Jobs', 'Full job management interface')}>
            <Text style={{ fontSize: 14, color: '#3B82F6', fontWeight: '500' }}>View All</Text>
          </Pressable>
        </View>
        
        <View style={{ padding: 24 }}>
          {printJobs.slice(0, 5).map((job) => (
            <JobRow key={job.id} job={job} />
          ))}
          
          {printJobs.length === 0 && (
            <View style={{ alignItems: 'center', padding: 32 }}>
              <Ionicons name="document-text-outline" size={48} color="#9CA3AF" />
              <Text style={{ fontSize: 16, color: '#6B7280', marginTop: 16 }}>No recent jobs</Text>
            </View>
          )}
        </View>
      </View>
    </ScrollView>
  );

  const renderAnalyticsView = () => (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <View style={{ alignItems: 'center', maxWidth: 400 }}>
        <View style={{ width: 80, height: 80, backgroundColor: '#EFF6FF', borderRadius: 40, alignItems: 'center', justifyContent: 'center', marginBottom: 24 }}>
          <Ionicons name="bar-chart" size={40} color="#3B82F6" />
        </View>
        <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#111827', marginBottom: 12 }}>
          Advanced Analytics
        </Text>
        <Text style={{ fontSize: 16, color: '#6B7280', textAlign: 'center', marginBottom: 24 }}>
          Comprehensive reporting and analytics dashboard is being developed with charts, trends, and detailed insights.
        </Text>
        <View style={{ backgroundColor: '#F3F4F6', borderRadius: 12, padding: 16, width: '100%' }}>
          <Text style={{ fontSize: 14, fontWeight: '600', color: '#374151', marginBottom: 8 }}>Current Data Preview:</Text>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>• Revenue Trend: +12.5% growth</Text>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>• Top Service: Document Printing (65%)</Text>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>• Peak Hours: 2PM - 4PM</Text>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>• Customer Retention: 89%</Text>
        </View>
      </View>
    </View>
  );

  const renderStaffView = () => (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <View style={{ alignItems: 'center', maxWidth: 400 }}>
        <View style={{ width: 80, height: 80, backgroundColor: '#F0FDF4', borderRadius: 40, alignItems: 'center', justifyContent: 'center', marginBottom: 24 }}>
          <Ionicons name="people" size={40} color="#10B981" />
        </View>
        <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#111827', marginBottom: 12 }}>
          Staff Management
        </Text>
        <Text style={{ fontSize: 16, color: '#6B7280', textAlign: 'center', marginBottom: 24 }}>
          Employee management, shift scheduling, and performance tracking features are in development.
        </Text>
        <View style={{ backgroundColor: '#F3F4F6', borderRadius: 12, padding: 16, width: '100%' }}>
          <Text style={{ fontSize: 14, fontWeight: '600', color: '#374151', marginBottom: 8 }}>Current Staff Status:</Text>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>• Morning Shift: OP001 (Online)</Text>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>• Afternoon Shift: OP002 (Online)</Text>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>• Evening Shift: Available</Text>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>• Performance: Above Average</Text>
        </View>
      </View>
    </View>
  );

  const renderPaymentsView = () => (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <View style={{ alignItems: 'center', maxWidth: 400 }}>
        <View style={{ width: 80, height: 80, backgroundColor: '#ECFDF5', borderRadius: 40, alignItems: 'center', justifyContent: 'center', marginBottom: 24 }}>
          <Ionicons name="card" size={40} color="#059669" />
        </View>
        <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#111827', marginBottom: 12 }}>
          Payment Systems
        </Text>
        <Text style={{ fontSize: 16, color: '#6B7280', textAlign: 'center', marginBottom: 24 }}>
          Advanced payment processing, transaction monitoring, and financial reporting features are in development.
        </Text>
        <View style={{ backgroundColor: '#F3F4F6', borderRadius: 12, padding: 16, width: '100%' }}>
          <Text style={{ fontSize: 14, fontWeight: '600', color: '#374151', marginBottom: 8 }}>Payment Methods Today:</Text>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>• Cash: 70% (₱{(dashboardStats.todayRevenue * 0.7 / 100).toFixed(2)})</Text>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>• GCash: 20% (₱{(dashboardStats.todayRevenue * 0.2 / 100).toFixed(2)})</Text>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>• Card: 10% (₱{(dashboardStats.todayRevenue * 0.1 / 100).toFixed(2)})</Text>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>• Transaction Fee: ₱12.50</Text>
        </View>
      </View>
    </View>
  );

  // Fallback to mobile layout if not desktop
  if (!deviceInfo.isDesktop) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 }}>
        <Ionicons name="desktop" size={64} color="#9CA3AF" />
        <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#111827', marginTop: 16, textAlign: 'center' }}>
          Desktop Interface Required
        </Text>
        <Text style={{ fontSize: 14, color: '#6B7280', marginTop: 8, textAlign: 'center' }}>
          This admin interface is optimized for desktop use. Please use a larger screen.
        </Text>
      </View>
    );
  }

  return (
    <DesktopLayout
      title={currentView === 'dashboard' ? 'Admin Dashboard' : 
             currentView === 'settings' ? 'System Settings' :
             currentView === 'pricing' ? 'Pricing Management' :
             currentView === 'analytics' ? 'Business Analytics' :
             currentView === 'staff' ? 'Staff Management' : 'Payment Systems'}
      subtitle={currentView === 'dashboard' ? 'System overview and management' : undefined}
      userInfo={{
        name: currentUser?.name || 'Administrator',
        role: 'admin'
      }}
      navigation={navigation}
      actions={currentView === 'dashboard' ? actions : undefined}
      onLogout={logout}
    >
      {renderDashboardContent()}
    </DesktopLayout>
  );
}

// Helper Components
function MetricCard({ title, value, change, changeType, icon, color }: {
  title: string;
  value: string;
  change: string;
  changeType: 'positive' | 'negative' | 'neutral';
  icon: keyof typeof Ionicons.glyphMap;
  color: string;
}) {
  return (
    <View style={{ 
      flex: 1, 
      backgroundColor: 'white', 
      borderRadius: 12, 
      padding: 24, 
      borderWidth: 1, 
      borderColor: '#E5E7EB' 
    }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <Text style={{ fontSize: 16, fontWeight: '600', color: '#374151' }}>
          {title}
        </Text>
        <View style={{ 
          width: 40, 
          height: 40, 
          borderRadius: 20, 
          backgroundColor: color + '20',
          alignItems: 'center', 
          justifyContent: 'center' 
        }}>
          <Ionicons name={icon} size={20} color={color} />
        </View>
      </View>
      
      <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#111827', marginBottom: 4 }}>
        {value}
      </Text>
      
      <Text style={{ 
        fontSize: 14, 
        color: changeType === 'positive' ? '#10B981' : 
               changeType === 'negative' ? '#DC2626' : '#6B7280'
      }}>
        {change}
      </Text>
    </View>
  );
}

function JobRow({ job }: { job: any }) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return '#10B981';
      case 'ongoing': return '#3B82F6';
      case 'ready': return '#8B5CF6';
      case 'queue': return '#F59E0B';
      case 'failed': return '#DC2626';
      default: return '#6B7280';
    }
  };

  return (
    <View style={{ 
      flexDirection: 'row', 
      alignItems: 'center', 
      paddingVertical: 12, 
      borderBottomWidth: 1, 
      borderBottomColor: '#F3F4F6' 
    }}>
      <View style={{ flex: 0.2 }}>
        <Text style={{ fontSize: 14, fontWeight: '500', color: '#111827' }}>
          #{job.id.slice(-6)}
        </Text>
      </View>
      
      <View style={{ flex: 0.3 }}>
        <Text style={{ fontSize: 14, color: '#374151' }}>
          {job.customerInfo.name}
        </Text>
      </View>
      
      <View style={{ flex: 0.2 }}>
        <Text style={{ fontSize: 14, color: '#6B7280' }}>
          {job.files.length} file(s)
        </Text>
      </View>
      
      <View style={{ flex: 0.15 }}>
        <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827' }}>
          ₱{(job.totalPrice / 100).toFixed(2)}
        </Text>
      </View>
      
      <View style={{ flex: 0.15 }}>
        <View style={{ 
          paddingHorizontal: 8, 
          paddingVertical: 4, 
          borderRadius: 12, 
          backgroundColor: getStatusColor(job.status) + '20',
          alignItems: 'center'
        }}>
          <Text style={{ 
            fontSize: 12, 
            fontWeight: '500', 
            color: getStatusColor(job.status),
            textTransform: 'capitalize'
          }}>
            {job.status}
          </Text>
        </View>
      </View>
    </View>
  );
}