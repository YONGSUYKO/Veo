import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, ScrollView, RefreshControl, Alert, FlatList } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';
import { useNewAppStore } from '../state/newAppStore';
import { newApiClient } from '../api/newPisoAPI';
import { useDeviceInfo } from '../utils/deviceDetection';
import DesktopLayout from '../components/desktop/DesktopLayout';

interface OperatorDesktopDashboardProps {
  onSwitchToCustomer: () => void;
}

export default function OperatorDesktopDashboard({ onSwitchToCustomer }: OperatorDesktopDashboardProps) {
  const deviceInfo = useDeviceInfo();
  const { currentUser, logout } = useAuthStore();
  const { printJobs, setPrintJobs } = useNewAppStore();
  const [refreshing, setRefreshing] = useState(false);
  const [currentView, setCurrentView] = useState<'queue' | 'active' | 'history' | 'customers' | 'reports'>('queue');
  const [selectedJob, setSelectedJob] = useState<any>(null);

  useEffect(() => {
    loadJobs();
    // Set up periodic refresh for real-time updates
    const interval = setInterval(loadJobs, 10000); // Refresh every 10 seconds
    return () => clearInterval(interval);
  }, []);

  const loadJobs = async () => {
    try {
      const jobs = await newApiClient.getPrintJobs();
      setPrintJobs(jobs);
    } catch (error) {
      console.error('Failed to load jobs:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadJobs();
    setRefreshing(false);
  };

  const updateJobStatus = async (jobId: string, newStatus: 'queue' | 'ongoing' | 'ready' | 'completed' | 'failed') => {
    try {
      await newApiClient.updatePrintJobStatus(jobId, newStatus);
      await loadJobs();
      Alert.alert('Success', `Job status updated to ${newStatus}`);
    } catch (error) {
      Alert.alert('Error', 'Failed to update job status');
    }
  };

  const getJobsByStatus = (status: string) => {
    return printJobs.filter(job => job.status === status);
  };

  const navigation = [
    { id: 'queue', label: 'Print Queue', icon: 'list' as const, active: currentView === 'queue', onPress: () => setCurrentView('queue') },
    { id: 'active', label: 'Active Jobs', icon: 'print' as const, active: currentView === 'active', onPress: () => setCurrentView('active') },
    { id: 'history', label: 'Completed Jobs', icon: 'checkmark-circle' as const, active: currentView === 'history', onPress: () => setCurrentView('history') },
    { id: 'customers', label: 'Customer Service', icon: 'people' as const, active: currentView === 'customers', onPress: () => setCurrentView('customers') },
    { id: 'reports', label: 'Shift Reports', icon: 'document-text' as const, active: currentView === 'reports', onPress: () => setCurrentView('reports') },
  ];

  const actions = [
    { id: 'refresh', label: 'Refresh', icon: 'refresh' as const, variant: 'secondary' as const, onPress: onRefresh },
    { id: 'customer-view', label: 'Customer View', icon: 'person' as const, variant: 'primary' as const, onPress: onSwitchToCustomer },
  ];

  const renderContent = () => {
    switch (currentView) {
      case 'queue':
        return renderQueueView();
      case 'active':
        return renderActiveJobsView();
      case 'history':
        return renderHistoryView();
      case 'customers':
        return renderCustomerServiceView();
      case 'reports':
        return renderReportsView();
      default:
        return renderQueueView();
    }
  };

  const renderQueueView = () => {
    const queueJobs = getJobsByStatus('queue');
    
    return (
      <View style={{ flex: 1, flexDirection: 'row', gap: 24 }}>
        {/* Jobs List */}
        <View style={{ flex: 0.6, backgroundColor: 'white', borderRadius: 12, borderWidth: 1, borderColor: '#E5E7EB' }}>
          <View style={{ padding: 24, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827' }}>
                Print Queue ({queueJobs.length})
              </Text>
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <View style={{ width: 8, height: 8, backgroundColor: '#F59E0B', borderRadius: 4 }} />
                <Text style={{ fontSize: 14, color: '#6B7280' }}>Waiting to print</Text>
              </View>
            </View>
          </View>
          
          <FlatList
            data={queueJobs}
            keyExtractor={(item) => item.id}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
            renderItem={({ item: job }) => (
              <JobQueueCard 
                job={job} 
                isSelected={selectedJob?.id === job.id}
                onSelect={() => setSelectedJob(job)}
                onStartJob={() => updateJobStatus(job.id, 'ongoing')}
              />
            )}
            ListEmptyComponent={
              <View style={{ alignItems: 'center', padding: 48 }}>
                <Ionicons name="checkmark-circle" size={48} color="#10B981" />
                <Text style={{ fontSize: 16, fontWeight: '600', color: '#10B981', marginTop: 16 }}>
                  All caught up!
                </Text>
                <Text style={{ fontSize: 14, color: '#6B7280', marginTop: 8 }}>
                  No jobs in the queue right now
                </Text>
              </View>
            }
          />
        </View>
        
        {/* Job Details Panel */}
        <View style={{ flex: 0.4, backgroundColor: 'white', borderRadius: 12, borderWidth: 1, borderColor: '#E5E7EB' }}>
          {selectedJob ? (
            <JobDetailsPanel 
              job={selectedJob} 
              onUpdateStatus={updateJobStatus}
              onClose={() => setSelectedJob(null)}
            />
          ) : (
            <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 }}>
              <Ionicons name="document-text-outline" size={48} color="#9CA3AF" />
              <Text style={{ fontSize: 16, color: '#6B7280', marginTop: 16, textAlign: 'center' }}>
                Select a job to view details
              </Text>
            </View>
          )}
        </View>
      </View>
    );
  };

  const renderActiveJobsView = () => {
    const activeJobs = getJobsByStatus('ongoing');
    
    return (
      <View style={{ backgroundColor: 'white', borderRadius: 12, borderWidth: 1, borderColor: '#E5E7EB', flex: 1 }}>
        <View style={{ padding: 24, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827' }}>
              Active Jobs ({activeJobs.length})
            </Text>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <View style={{ width: 8, height: 8, backgroundColor: '#3B82F6', borderRadius: 4 }} />
              <Text style={{ fontSize: 14, color: '#6B7280' }}>Currently printing</Text>
            </View>
          </View>
        </View>
        
        <FlatList
          data={activeJobs}
          keyExtractor={(item) => item.id}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
          renderItem={({ item: job }) => (
            <ActiveJobCard 
              job={job} 
              onCompleteJob={() => updateJobStatus(job.id, 'ready')}
              onFailJob={() => updateJobStatus(job.id, 'failed')}
            />
          )}
          ListEmptyComponent={
            <View style={{ alignItems: 'center', padding: 48 }}>
              <Ionicons name="print-outline" size={48} color="#9CA3AF" />
              <Text style={{ fontSize: 16, color: '#6B7280', marginTop: 16 }}>
                No active print jobs
              </Text>
            </View>
          }
        />
      </View>
    );
  };

  const renderHistoryView = () => {
    const completedJobs = [...getJobsByStatus('completed'), ...getJobsByStatus('ready')];
    
    return (
      <View style={{ backgroundColor: 'white', borderRadius: 12, borderWidth: 1, borderColor: '#E5E7EB', flex: 1 }}>
        <View style={{ padding: 24, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' }}>
          <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827' }}>
            Completed Jobs ({completedJobs.length})
          </Text>
        </View>
        
        <FlatList
          data={completedJobs}
          keyExtractor={(item) => item.id}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
          renderItem={({ item: job }) => (
            <CompletedJobCard job={job} />
          )}
          ListEmptyComponent={
            <View style={{ alignItems: 'center', padding: 48 }}>
              <Ionicons name="time-outline" size={48} color="#9CA3AF" />
              <Text style={{ fontSize: 16, color: '#6B7280', marginTop: 16 }}>
                No completed jobs today
              </Text>
            </View>
          }
        />
      </View>
    );
  };

  const renderCustomerServiceView = () => (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <View style={{ alignItems: 'center', maxWidth: 400 }}>
        <View style={{ width: 80, height: 80, backgroundColor: '#F0FDF4', borderRadius: 40, alignItems: 'center', justifyContent: 'center', marginBottom: 24 }}>
          <Ionicons name="people" size={40} color="#10B981" />
        </View>
        <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#111827', marginBottom: 12 }}>
          Customer Service Tools
        </Text>
        <Text style={{ fontSize: 16, color: '#6B7280', textAlign: 'center', marginBottom: 24 }}>
          Customer management, support tickets, and communication tools are being developed.
        </Text>
        <Pressable
          style={{ backgroundColor: '#10B981', paddingHorizontal: 24, paddingVertical: 12, borderRadius: 8 }}
          onPress={() => Alert.alert('Quick Actions', 'Help customer place order\nCheck job status\nProcess payment\nHandle complaint')}
        >
          <Text style={{ color: 'white', fontWeight: '600' }}>Quick Customer Actions</Text>
        </Pressable>
      </View>
    </View>
  );

  const renderReportsView = () => {
    const todayJobs = printJobs.filter(job => {
      const today = new Date().toISOString().split('T')[0];
      return job.createdAt.toISOString().split('T')[0] === today;
    });
    
    const todayRevenue = todayJobs.reduce((sum, job) => sum + job.totalPrice, 0);
    
    return (
      <View style={{ flex: 1 }}>
        <View style={{ flexDirection: 'row', gap: 24, marginBottom: 24 }}>
          <View style={{ flex: 1, backgroundColor: 'white', borderRadius: 12, padding: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
            <Text style={{ fontSize: 16, fontWeight: '600', color: '#374151', marginBottom: 8 }}>
              Today's Jobs
            </Text>
            <Text style={{ fontSize: 32, fontWeight: 'bold', color: '#3B82F6' }}>
              {todayJobs.length}
            </Text>
          </View>
          
          <View style={{ flex: 1, backgroundColor: 'white', borderRadius: 12, padding: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
            <Text style={{ fontSize: 16, fontWeight: '600', color: '#374151', marginBottom: 8 }}>
              Today's Revenue
            </Text>
            <Text style={{ fontSize: 32, fontWeight: 'bold', color: '#10B981' }}>
              ₱{(todayRevenue / 100).toFixed(2)}
            </Text>
          </View>
        </View>
        
        <View style={{ backgroundColor: 'white', borderRadius: 12, borderWidth: 1, borderColor: '#E5E7EB', padding: 24 }}>
          <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginBottom: 16 }}>
            Shift Summary
          </Text>
          <Text style={{ fontSize: 14, color: '#6B7280', lineHeight: 20 }}>
            Operator: {currentUser?.name}{'\n'}
            Shift Start: 8:00 AM{'\n'}
            Current Time: {new Date().toLocaleTimeString()}{'\n'}
            Jobs Processed: {todayJobs.filter(j => j.status === 'completed').length}{'\n'}
            Average Processing Time: 3.2 minutes{'\n'}
            Customer Satisfaction: 98%
          </Text>
        </View>
      </View>
    );
  };

  // Fallback to mobile layout if not desktop
  if (!deviceInfo.isDesktop) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 }}>
        <Ionicons name="desktop" size={64} color="#9CA3AF" />
        <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#111827', marginTop: 16, textAlign: 'center' }}>
          Desktop Interface Required
        </Text>
        <Text style={{ fontSize: 14, color: '#6B7280', marginTop: 8, textAlign: 'center' }}>
          This operator interface is optimized for desktop use. Please use a larger screen.
        </Text>
      </View>
    );
  }

  return (
    <DesktopLayout
      title={currentView === 'queue' ? 'Print Queue' : 
             currentView === 'active' ? 'Active Jobs' :
             currentView === 'history' ? 'Job History' :
             currentView === 'customers' ? 'Customer Service' : 'Shift Reports'}
      subtitle="Operator workstation for job management"
      userInfo={{
        name: currentUser?.name || 'Operator',
        role: 'operator'
      }}
      navigation={navigation}
      actions={actions}
      onLogout={logout}
    >
      {renderContent()}
    </DesktopLayout>
  );
}

// Helper Components
function JobQueueCard({ job, isSelected, onSelect, onStartJob }: {
  job: any;
  isSelected: boolean;
  onSelect: () => void;
  onStartJob: () => void;
}) {
  return (
    <Pressable
      onPress={onSelect}
      style={({ pressed }) => [
        {
          padding: 16,
          borderBottomWidth: 1,
          borderBottomColor: '#F3F4F6',
          backgroundColor: isSelected ? '#EFF6FF' : pressed ? '#F9FAFB' : 'white',
        }
      ]}
    >
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 16, fontWeight: '600', color: '#111827', marginBottom: 4 }}>
            #{job.id.slice(-6)} - {job.customerInfo.name}
          </Text>
          <Text style={{ fontSize: 14, color: '#6B7280', marginBottom: 8 }}>
            {job.files.length} file(s) • ₱{(job.totalPrice / 100).toFixed(2)}
          </Text>
          <Text style={{ fontSize: 12, color: '#9CA3AF' }}>
            {new Date(job.createdAt).toLocaleTimeString()}
          </Text>
        </View>
        
        <Pressable
          onPress={onStartJob}
          style={{ backgroundColor: '#10B981', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 6 }}
        >
          <Text style={{ color: 'white', fontSize: 14, fontWeight: '600' }}>
            Start Print
          </Text>
        </Pressable>
      </View>
    </Pressable>
  );
}

function ActiveJobCard({ job, onCompleteJob, onFailJob }: {
  job: any;
  onCompleteJob: () => void;
  onFailJob: () => void;
}) {
  return (
    <View style={{ padding: 16, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 16, fontWeight: '600', color: '#111827', marginBottom: 4 }}>
            #{job.id.slice(-6)} - {job.customerInfo.name}
          </Text>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>
            {job.files.length} file(s) • ₱{(job.totalPrice / 100).toFixed(2)}
          </Text>
        </View>
        
        <View style={{ flexDirection: 'row', gap: 8 }}>
          <Pressable
            onPress={onFailJob}
            style={{ backgroundColor: '#DC2626', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6 }}
          >
            <Text style={{ color: 'white', fontSize: 12, fontWeight: '600' }}>
              Mark Failed
            </Text>
          </Pressable>
          <Pressable
            onPress={onCompleteJob}
            style={{ backgroundColor: '#10B981', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6 }}
          >
            <Text style={{ color: 'white', fontSize: 12, fontWeight: '600' }}>
              Mark Ready
            </Text>
          </Pressable>
        </View>
      </View>
      
      {/* Progress simulation */}
      <View style={{ backgroundColor: '#F3F4F6', height: 4, borderRadius: 2 }}>
        <View style={{ backgroundColor: '#3B82F6', height: 4, borderRadius: 2, width: '60%' }} />
      </View>
    </View>
  );
}

function CompletedJobCard({ job }: { job: any }) {
  const getStatusColor = (status: string) => {
    return status === 'completed' ? '#10B981' : '#8B5CF6';
  };

  return (
    <View style={{ padding: 16, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 16, fontWeight: '600', color: '#111827', marginBottom: 4 }}>
            #{job.id.slice(-6)} - {job.customerInfo.name}
          </Text>
          <Text style={{ fontSize: 14, color: '#6B7280', marginBottom: 4 }}>
            {job.files.length} file(s) • ₱{(job.totalPrice / 100).toFixed(2)}
          </Text>
          <Text style={{ fontSize: 12, color: '#9CA3AF' }}>
            Completed at {new Date(job.updatedAt).toLocaleTimeString()}
          </Text>
        </View>
        
        <View style={{ 
          paddingHorizontal: 12, 
          paddingVertical: 6, 
          borderRadius: 12, 
          backgroundColor: getStatusColor(job.status) + '20'
        }}>
          <Text style={{ 
            fontSize: 12, 
            fontWeight: '600', 
            color: getStatusColor(job.status),
            textTransform: 'capitalize'
          }}>
            {job.status}
          </Text>
        </View>
      </View>
    </View>
  );
}

function JobDetailsPanel({ job, onUpdateStatus, onClose }: {
  job: any;
  onUpdateStatus: (jobId: string, status: any) => void;
  onClose: () => void;
}) {
  return (
    <View style={{ flex: 1 }}>
      <View style={{ padding: 24, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827' }}>
            Job Details
          </Text>
          <Pressable onPress={onClose}>
            <Ionicons name="close" size={24} color="#6B7280" />
          </Pressable>
        </View>
      </View>
      
      <ScrollView style={{ flex: 1, padding: 24 }}>
        <View style={{ marginBottom: 24 }}>
          <Text style={{ fontSize: 16, fontWeight: '600', color: '#111827', marginBottom: 8 }}>
            #{job.id.slice(-6)}
          </Text>
          <Text style={{ fontSize: 14, color: '#6B7280', marginBottom: 16 }}>
            {job.customerInfo.name} • {job.customerInfo.phone}
          </Text>
          
          <View style={{ backgroundColor: '#F9FAFB', borderRadius: 8, padding: 16, marginBottom: 16 }}>
            <Text style={{ fontSize: 14, fontWeight: '600', color: '#374151', marginBottom: 8 }}>
              Files ({job.files.length})
            </Text>
            {job.files.map((file: any, index: number) => (
              <Text key={index} style={{ fontSize: 14, color: '#6B7280', marginBottom: 4 }}>
                • {file.name} ({file.pages} pages)
              </Text>
            ))}
          </View>
          
          <View style={{ backgroundColor: '#F9FAFB', borderRadius: 8, padding: 16 }}>
            <Text style={{ fontSize: 14, fontWeight: '600', color: '#374151', marginBottom: 8 }}>
              Order Summary
            </Text>
            <Text style={{ fontSize: 14, color: '#6B7280', marginBottom: 4 }}>
              Total: ₱{(job.totalPrice / 100).toFixed(2)}
            </Text>
            <Text style={{ fontSize: 14, color: '#6B7280', marginBottom: 4 }}>
              Payment: {job.paymentMethod}
            </Text>
            <Text style={{ fontSize: 14, color: '#6B7280' }}>
              Fulfillment: {job.fulfillmentMethod}
            </Text>
          </View>
        </View>
      </ScrollView>
      
      <View style={{ padding: 24, borderTopWidth: 1, borderTopColor: '#E5E7EB' }}>
        <Pressable
          onPress={() => onUpdateStatus(job.id, 'ongoing')}
          style={{ backgroundColor: '#10B981', paddingVertical: 12, borderRadius: 8, alignItems: 'center' }}
        >
          <Text style={{ color: 'white', fontSize: 16, fontWeight: '600' }}>
            Start Printing
          </Text>
        </Pressable>
      </View>
    </View>
  );
}