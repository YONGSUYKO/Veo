import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, Pressable, RefreshControl, Modal, TextInput, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as DocumentPicker from 'expo-document-picker';
import { useAppStore, MarketplaceItem } from '../state/appStore';
import { apiClient } from '../api/pisoprint-api';
import { cn } from '../utils/cn';

const categories = [
  { id: 'all', name: 'All Categories', icon: 'grid' },
  { id: 'templates', name: 'Templates', icon: 'document-text' },
  { id: 'designs', name: 'Designs', icon: 'color-palette' },
  { id: 'fonts', name: 'Fonts', icon: 'text' },
  { id: 'clipart', name: 'Clipart', icon: 'image' },
] as const;

export default function MarketplaceScreen() {
  const insets = useSafeAreaInsets();
  const { marketplaceItems, setMarketplaceItems } = useAppStore();
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showCreateModal, setShowCreateModal] = useState(false);

  useEffect(() => {
    loadMarketplaceItems();
  }, [selectedCategory, searchQuery]);

  const loadMarketplaceItems = async () => {
    try {
      const items = await apiClient.getMarketplaceItems(
        selectedCategory === 'all' ? undefined : selectedCategory,
        searchQuery || undefined
      );
      setMarketplaceItems(items);
    } catch (error) {
      console.error('Failed to load marketplace items:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadMarketplaceItems();
    setRefreshing(false);
  };

  const filteredItems = marketplaceItems;

  return (
    <View className="flex-1 bg-gray-50">
      <ScrollView 
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        stickyHeaderIndices={[1]}
      >
        <View style={{ paddingTop: insets.top }} className="px-4 pb-6">
          
          {/* Header */}
          <View className="flex-row items-center justify-between mb-6">
            <View>
              <Text className="text-3xl font-bold text-gray-900 mb-2">
                Digital Marketplace
              </Text>
              <Text className="text-lg text-gray-600">
                Discover templates and designs created by our community
              </Text>
            </View>
            <Pressable 
              className="bg-blue-500 w-12 h-12 rounded-full items-center justify-center"
              onPress={() => setShowCreateModal(true)}
            >
              <Ionicons name="add" size={24} color="white" />
            </Pressable>
          </View>

        </View>

        {/* Search and Categories - Sticky Header */}
        <View className="bg-gray-50 px-4 pb-4">
          {/* Search */}
          <View className="relative mb-4">
            <View className="absolute left-3 top-1/2 transform -translate-y-1/2 z-10">
              <Ionicons name="search" size={20} color="#6B7280" />
            </View>
            <TextInput
              className="bg-white border border-gray-300 rounded-xl pl-10 pr-4 py-3 text-base"
              placeholder="Search templates, designs, and more..."
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </View>

          {/* Categories */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View className="flex-row space-x-3">
              {categories.map((category) => (
                <Pressable
                  key={category.id}
                  onPress={() => setSelectedCategory(category.id)}
                  className={cn(
                    "flex-row items-center px-4 py-2 rounded-full",
                    selectedCategory === category.id
                      ? "bg-blue-500"
                      : "bg-white border border-gray-300"
                  )}
                >
                  <Ionicons 
                    name={category.icon as any} 
                    size={16} 
                    color={selectedCategory === category.id ? "white" : "#6B7280"} 
                  />
                  <Text className={cn(
                    "ml-2 font-medium",
                    selectedCategory === category.id ? "text-white" : "text-gray-700"
                  )}>
                    {category.name}
                  </Text>
                </Pressable>
              ))}
            </View>
          </ScrollView>
        </View>

        <View className="px-4">
          {/* Trending Section */}
          {searchQuery === '' && selectedCategory === 'all' && (
            <View className="mb-6">
              <Text className="text-xl font-semibold text-gray-900 mb-4">Trending This Week</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                <View className="flex-row space-x-4">
                  {filteredItems.slice(0, 3).map((item) => (
                    <TrendingItemCard key={item.id} item={item} />
                  ))}
                </View>
              </ScrollView>
            </View>
          )}

          {/* Items Grid */}
          <View className="mb-6">
            <View className="flex-row items-center justify-between mb-4">
              <Text className="text-xl font-semibold text-gray-900">
                {searchQuery ? 'Search Results' : selectedCategory === 'all' ? 'All Items' : categories.find(c => c.id === selectedCategory)?.name}
              </Text>
              <Text className="text-sm text-gray-600">
                {filteredItems.length} items
              </Text>
            </View>

            {filteredItems.length > 0 ? (
              <View className="space-y-3">
                {filteredItems.map((item) => (
                  <MarketplaceItemCard key={item.id} item={item} />
                ))}
              </View>
            ) : (
              <View className="bg-white rounded-xl p-8 items-center">
                <Ionicons name="search-outline" size={64} color="#9CA3AF" />
                <Text className="text-xl font-semibold text-gray-900 mt-4 mb-2">
                  No items found
                </Text>
                <Text className="text-gray-600 text-center mb-6">
                  {searchQuery 
                    ? `No results found for "${searchQuery}"`
                    : `No items in ${selectedCategory === 'all' ? 'marketplace' : categories.find(c => c.id === selectedCategory)?.name.toLowerCase()}`
                  }
                </Text>
                <Pressable 
                  className="bg-blue-500 px-6 py-3 rounded-lg"
                  onPress={() => setShowCreateModal(true)}
                >
                  <Text className="text-white font-medium">Create First Item</Text>
                </Pressable>
              </View>
            )}
          </View>

          {/* Creator Info */}
          <View className="bg-blue-50 rounded-xl p-6 mb-6">
            <View className="items-center">
              <View className="w-16 h-16 bg-blue-500 rounded-full items-center justify-center mb-4">
                <Ionicons name="brush" size={32} color="white" />
              </View>
              <Text className="text-lg font-semibold text-gray-900 mb-2">
                Become a Creator
              </Text>
              <Text className="text-gray-600 text-center mb-4">
                Share your designs with the community and earn up to 70% commission on every sale.
              </Text>
              <Pressable 
                className="bg-blue-500 px-6 py-3 rounded-lg"
                onPress={() => setShowCreateModal(true)}
              >
                <Text className="text-white font-semibold">Start Creating</Text>
              </Pressable>
            </View>
          </View>

        </View>
      </ScrollView>

      <CreateItemModal 
        visible={showCreateModal} 
        onClose={() => setShowCreateModal(false)}
        onItemCreated={loadMarketplaceItems}
      />
    </View>
  );
}

function TrendingItemCard({ item }: { item: MarketplaceItem }) {
  const formatRating = (rating: number) => (rating / 100).toFixed(1);

  return (
    <View className="bg-white rounded-xl p-4 w-48">
      <View className="w-full h-24 bg-gray-200 rounded-lg mb-3 items-center justify-center">
        <Ionicons name="image-outline" size={32} color="#9CA3AF" />
      </View>
      <Text className="font-semibold text-gray-900 mb-1" numberOfLines={2}>
        {item.title}
      </Text>
      <View className="flex-row items-center justify-between">
        <Text className="text-lg font-bold text-blue-600">
          ₱{(item.price / 100).toFixed(2)}
        </Text>
        <View className="flex-row items-center">
          <Ionicons name="star" size={12} color="#F59E0B" />
          <Text className="text-xs text-gray-600 ml-1">
            {formatRating(item.rating)}
          </Text>
        </View>
      </View>
    </View>
  );
}

function MarketplaceItemCard({ item }: { item: MarketplaceItem }) {
  const formatRating = (rating: number) => (rating / 100).toFixed(1);
  
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'templates': return 'document-text';
      case 'designs': return 'color-palette';
      case 'fonts': return 'text';
      case 'clipart': return 'image';
      default: return 'folder';
    }
  };

  return (
    <Pressable className="bg-white rounded-xl p-4">
      <View className="flex-row">
        {/* Thumbnail */}
        <View className="w-20 h-20 bg-gray-200 rounded-lg mr-4 items-center justify-center">
          <Ionicons 
            name={getCategoryIcon(item.category) as any} 
            size={24} 
            color="#9CA3AF" 
          />
        </View>

        {/* Content */}
        <View className="flex-1">
          <View className="flex-row items-start justify-between mb-2">
            <Text className="text-base font-semibold text-gray-900 flex-1 mr-2" numberOfLines={2}>
              {item.title}
            </Text>
            <Text className="text-lg font-bold text-blue-600">
              ₱{(item.price / 100).toFixed(2)}
            </Text>
          </View>

          <Text className="text-sm text-gray-600 mb-3" numberOfLines={2}>
            {item.description}
          </Text>

          <View className="flex-row items-center justify-between">
            <View className="flex-row items-center space-x-4">
              <View className="flex-row items-center">
                <Ionicons name="download" size={14} color="#6B7280" />
                <Text className="text-xs text-gray-600 ml-1">
                  {item.downloads}
                </Text>
              </View>
              <View className="flex-row items-center">
                <Ionicons name="star" size={14} color="#F59E0B" />
                <Text className="text-xs text-gray-600 ml-1">
                  {formatRating(item.rating)}
                </Text>
              </View>
            </View>

            <View className="flex-row items-center">
              <View className="w-6 h-6 bg-gray-300 rounded-full mr-2" />
              <Text className="text-xs text-gray-600">
                {item.creatorName}
              </Text>
            </View>
          </View>
        </View>
      </View>
    </Pressable>
  );
}

function CreateItemModal({ visible, onClose, onItemCreated }: {
  visible: boolean;
  onClose: () => void;
  onItemCreated: () => void;
}) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [type, setType] = useState('');
  const [price, setPrice] = useState('');
  const [creatorName, setCreatorName] = useState('');
  const [creatorEmail, setCreatorEmail] = useState('');
  const [file, setFile] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const productTypes = [
    { id: 'document_template', name: 'Document Template' },
    { id: 'photo_frame', name: 'Photo Frame' },
    { id: 'business_card', name: 'Business Card Template' },
    { id: 'shirt_design', name: 'T-Shirt Design' },
    { id: 'mug_design', name: 'Mug Design' },
  ];

  const pickFile = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: '*/*',
      });

      if (!result.canceled) {
        setFile(result.assets[0]);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to pick file');
    }
  };

  const createItem = async () => {
    if (!title.trim() || !category || !type || !price || !creatorName.trim() || !creatorEmail.trim()) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    if (!creatorEmail.includes('@')) {
      Alert.alert('Error', 'Please enter a valid email address');
      return;
    }

    const priceValue = parseFloat(price);
    if (isNaN(priceValue) || priceValue <= 0) {
      Alert.alert('Error', 'Please enter a valid price');
      return;
    }

    setLoading(true);
    try {
      const itemData = {
        title: title.trim(),
        description: description.trim() || undefined,
        category: category as 'templates' | 'designs' | 'fonts' | 'clipart',
        type,
        price: Math.round(priceValue * 100), // Convert to centavos
        commission: 70,
        creatorEmail: creatorEmail.trim(),
        creatorName: creatorName.trim(),
        filePath: file ? `/uploads/${file.name}` : undefined,
        status: 'pending' as const,
        downloads: 0,
        rating: 0,
      };

      await apiClient.createMarketplaceItem(itemData);
      
      Alert.alert(
        'Item Submitted!',
        'Your item has been submitted for review. You will be notified once it is approved.',
        [{ text: 'OK', onPress: () => {
          onItemCreated();
          onClose();
          // Reset form
          setTitle('');
          setDescription('');
          setCategory('');
          setType('');
          setPrice('');
          setCreatorName('');
          setCreatorEmail('');
          setFile(null);
        }}]
      );
    } catch (error) {
      Alert.alert('Error', 'Failed to submit item. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View className="flex-1 bg-white">
        <View className="flex-row items-center justify-between p-4 border-b border-gray-200">
          <Pressable onPress={onClose}>
            <Text className="text-blue-500 text-lg">Cancel</Text>
          </Pressable>
          <Text className="text-lg font-semibold">Create New Item</Text>
          <Pressable onPress={createItem} disabled={loading}>
            <Text className={cn("text-lg", loading ? "text-gray-400" : "text-blue-500 font-semibold")}>
              {loading ? 'Submitting...' : 'Submit'}
            </Text>
          </Pressable>
        </View>

        <ScrollView className="flex-1 p-4">
          <View className="space-y-6">
            
            {/* Basic Information */}
            <View>
              <Text className="text-base font-semibold text-gray-900 mb-4">Item Details</Text>
              
              <View className="space-y-4">
                <View>
                  <Text className="text-sm font-medium text-gray-700 mb-2">Title</Text>
                  <TextInput
                    className="border border-gray-300 rounded-lg px-4 py-3 text-base"
                    value={title}
                    onChangeText={setTitle}
                    placeholder="Enter item title"
                  />
                </View>

                <View>
                  <Text className="text-sm font-medium text-gray-700 mb-2">Description</Text>
                  <TextInput
                    className="border border-gray-300 rounded-lg px-4 py-3 text-base"
                    value={description}
                    onChangeText={setDescription}
                    placeholder="Describe your item"
                    multiline
                    numberOfLines={3}
                  />
                </View>

                <View>
                  <Text className="text-sm font-medium text-gray-700 mb-2">Category</Text>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                    <View className="flex-row space-x-2">
                      {categories.slice(1).map((cat) => (
                        <Pressable
                          key={cat.id}
                          onPress={() => setCategory(cat.id)}
                          className={cn(
                            "px-4 py-2 rounded-lg border-2",
                            category === cat.id
                              ? "bg-blue-500 border-blue-500"
                              : "bg-white border-gray-300"
                          )}
                        >
                          <Text className={cn(
                            "font-medium",
                            category === cat.id ? "text-white" : "text-gray-700"
                          )}>
                            {cat.name}
                          </Text>
                        </Pressable>
                      ))}
                    </View>
                  </ScrollView>
                </View>

                <View>
                  <Text className="text-sm font-medium text-gray-700 mb-2">Product Type</Text>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                    <View className="flex-row space-x-2">
                      {productTypes.map((productType) => (
                        <Pressable
                          key={productType.id}
                          onPress={() => setType(productType.id)}
                          className={cn(
                            "px-4 py-2 rounded-lg border-2 whitespace-nowrap",
                            type === productType.id
                              ? "bg-blue-500 border-blue-500"
                              : "bg-white border-gray-300"
                          )}
                        >
                          <Text className={cn(
                            "font-medium",
                            type === productType.id ? "text-white" : "text-gray-700"
                          )}>
                            {productType.name}
                          </Text>
                        </Pressable>
                      ))}
                    </View>
                  </ScrollView>
                </View>

                <View>
                  <Text className="text-sm font-medium text-gray-700 mb-2">Price (₱)</Text>
                  <TextInput
                    className="border border-gray-300 rounded-lg px-4 py-3 text-base"
                    value={price}
                    onChangeText={setPrice}
                    placeholder="0.00"
                    keyboardType="decimal-pad"
                  />
                </View>
              </View>
            </View>

            {/* File Upload */}
            <View>
              <Text className="text-base font-semibold text-gray-900 mb-3">Upload File</Text>
              {!file ? (
                <Pressable 
                  className="border-2 border-dashed border-gray-300 rounded-xl p-6 items-center"
                  onPress={pickFile}
                >
                  <Ionicons name="cloud-upload-outline" size={48} color="#9CA3AF" />
                  <Text className="text-gray-600 text-center mt-2">
                    Tap to upload your design file
                  </Text>
                  <Text className="text-xs text-gray-500 text-center mt-1">
                    Supports all file types
                  </Text>
                </Pressable>
              ) : (
                <View className="flex-row items-center bg-gray-50 rounded-lg p-3">
                  <Ionicons name="document" size={20} color="#6B7280" />
                  <Text className="text-gray-900 ml-3 flex-1">{file.name}</Text>
                  <Pressable onPress={() => setFile(null)}>
                    <Ionicons name="close-circle" size={20} color="#EF4444" />
                  </Pressable>
                </View>
              )}
            </View>

            {/* Creator Information */}
            <View>
              <Text className="text-base font-semibold text-gray-900 mb-4">Creator Information</Text>
              
              <View className="space-y-4">
                <View>
                  <Text className="text-sm font-medium text-gray-700 mb-2">Your Name</Text>
                  <TextInput
                    className="border border-gray-300 rounded-lg px-4 py-3 text-base"
                    value={creatorName}
                    onChangeText={setCreatorName}
                    placeholder="Enter your name or studio name"
                    autoCapitalize="words"
                  />
                </View>

                <View>
                  <Text className="text-sm font-medium text-gray-700 mb-2">Email Address</Text>
                  <TextInput
                    className="border border-gray-300 rounded-lg px-4 py-3 text-base"
                    value={creatorEmail}
                    onChangeText={setCreatorEmail}
                    placeholder="Enter your email address"
                    keyboardType="email-address"
                    autoCapitalize="none"
                  />
                </View>
              </View>
            </View>

            {/* Commission Info */}
            <View className="bg-green-50 rounded-xl p-4">
              <View className="flex-row items-center mb-2">
                <Ionicons name="cash" size={20} color="#10B981" />
                <Text className="text-base font-semibold text-green-900 ml-2">
                  70% Commission Rate
                </Text>
              </View>
              <Text className="text-sm text-green-700">
                You will earn 70% of every sale. For a ₱{price || '0.00'} item, you will earn ₱{((parseFloat(price || '0') * 0.7) || 0).toFixed(2)} per sale.
              </Text>
            </View>

          </View>
        </ScrollView>
      </View>
    </Modal>
  );
}