import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  Image,
  TextInput,
  Pressable,
  Alert,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { cn } from '../utils/cn';
import OperatorChatComponent from '../components/OperatorChatComponent';

interface OperatorReviewScreenProps {
  route: {
    params: {
      orderId: string;
    };
  };
  navigation: {
    goBack: () => void;
    navigate: (screen: string, params?: any) => void;
  };
}

interface FileItem {
  id: string;
  name: string;
  url: string;
  preview?: string;
  type: string;
  operatorComments?: string;
}

interface PrintSpec {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
}

interface OrderDetails {
  id: string;
  customerId: string;
  customerName?: string;
  customerEmail?: string;
  files: FileItem[];
  status: string;
  printSpecs?: PrintSpec[];
  operatorMessage?: string;
  totalAmount?: number;
  completionTime?: string;
}

const OperatorReviewScreen: React.FC<OperatorReviewScreenProps> = ({ route, navigation }) => {
  const { orderId } = route.params;
  const insets = useSafeAreaInsets();
  
  const [orderDetails, setOrderDetails] = useState<OrderDetails | null>(null);
  const [fileComments, setFileComments] = useState<Record<string, string>>({});
  const [printSpecs, setPrintSpecs] = useState<PrintSpec[]>([]);
  const [operatorMessage, setOperatorMessage] = useState('');
  const [totalAmount, setTotalAmount] = useState(0);
  const [completionTime, setCompletionTime] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadOrderDetails();
  }, [orderId]);

  const loadOrderDetails = async () => {
    try {
      setLoading(true);
      // Import the staff support service
      const { staffSupportService } = await import('../services/staffSupportService');
      
      const order = await staffSupportService.getOrderById(orderId);
      if (order) {
        setOrderDetails(order);
        
        // Pre-fill existing data if any
        if (order.files) {
          const comments: Record<string, string> = {};
          order.files.forEach((file: FileItem) => {
            if (file.operatorComments) {
              comments[file.id] = file.operatorComments;
            }
          });
          setFileComments(comments);
        }
        
        if (order.printSpecs) setPrintSpecs(order.printSpecs);
        if (order.operatorMessage) setOperatorMessage(order.operatorMessage);
        if (order.totalAmount) setTotalAmount(order.totalAmount);
        if (order.completionTime) setCompletionTime(order.completionTime);
      }
    } catch (error) {
      console.error('Error loading order:', error);
      Alert.alert('Error', 'Failed to load order details.');
    } finally {
      setLoading(false);
    }
  };

  const updateFileComment = (fileId: string, comment: string) => {
    setFileComments(prev => ({
      ...prev,
      [fileId]: comment
    }));
  };

  const addPrintSpec = () => {
    const newSpec: PrintSpec = {
      id: Date.now().toString(),
      description: '',
      quantity: 1,
      unitPrice: 0,
      totalPrice: 0
    };
    setPrintSpecs(prev => [...prev, newSpec]);
  };

  const updatePrintSpec = (specId: string, field: keyof PrintSpec, value: string | number) => {
    setPrintSpecs(prev => prev.map(spec => {
      if (spec.id === specId) {
        const updated = { ...spec, [field]: value };
        if (field === 'quantity' || field === 'unitPrice') {
          updated.totalPrice = Number(updated.quantity) * Number(updated.unitPrice);
        }
        return updated;
      }
      return spec;
    }));
  };

  const removePrintSpec = (specId: string) => {
    setPrintSpecs(prev => prev.filter(spec => spec.id !== specId));
  };

  const calculateTotalAmount = () => {
    const total = printSpecs.reduce((sum, spec) => sum + spec.totalPrice, 0);
    setTotalAmount(total);
  };

  useEffect(() => {
    calculateTotalAmount();
  }, [printSpecs]);

  const generatePaymentCode = () => {
    const prefix = 'PRT';
    const timestamp = Date.now().toString().slice(-6);
    return `${prefix}${timestamp}`;
  };

  const approveForPayment = async () => {
    if (printSpecs.length === 0) {
      Alert.alert('Error', 'Please add at least one print specification.');
      return;
    }

    if (totalAmount <= 0) {
      Alert.alert('Error', 'Please set valid pricing.');
      return;
    }

    try {
      const paymentCode = generatePaymentCode();
      
      // Import the staff support service
      const { staffSupportService } = await import('../services/staffSupportService');
      
      // Update files with operator comments
      const updatedFiles = orderDetails?.files.map(file => ({
        ...file,
        operatorComments: fileComments[file.id] || ''
      })) || [];

      // Update order
      await staffSupportService.updateOrder(orderId, {
        status: 'approved_for_payment',
        files: updatedFiles,
        printSpecs: printSpecs,
        operatorMessage: operatorMessage,
        paymentCode: paymentCode,
        totalAmount: totalAmount,
        completionTime: completionTime,
        approvedAt: new Date().toISOString()
      });

      Alert.alert(
        'Success', 
        'Order approved for payment! Customer has been notified.',
        [{ text: 'OK', onPress: () => navigation.goBack() }]
      );
    } catch (error) {
      console.error('Error approving order:', error);
      Alert.alert('Error', 'Failed to approve order. Please try again.');
    }
  };

  const markAsUnderReview = async () => {
    try {
      const { staffSupportService } = await import('../services/staffSupportService');
      await staffSupportService.updateOrder(orderId, { status: 'under_review' });
      Alert.alert('Status Updated', 'Order marked as under review.');
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  if (loading) {
    return (
      <SafeAreaView className="flex-1 bg-gray-50">
        <View className="flex-1 justify-center items-center">
          <Text className="text-lg text-gray-600">Loading order details...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!orderDetails) {
    return (
      <SafeAreaView className="flex-1 bg-gray-50">
        <View className="flex-1 justify-center items-center">
          <Text className="text-lg text-gray-600">Order not found</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView className="flex-1 bg-gray-50">
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        className="flex-1"
      >
        {/* Header */}
        <View className="flex-row items-center justify-between p-4 bg-white border-b border-gray-200">
          <Pressable onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color="#374151" />
          </Pressable>
          <Text className="text-lg font-semibold">Review Order</Text>
          <View style={{ width: 24 }} />
        </View>

        <ScrollView className="flex-1 p-4">
          {/* Order Header */}
          <View className="bg-white rounded-xl p-4 mb-4 shadow-sm">
            <Text className="text-xl font-bold text-gray-900 mb-2">
              Order #{orderDetails.id.slice(-6)}
            </Text>
            <Text className="text-gray-600 mb-1">
              Customer: {orderDetails.customerName || orderDetails.customerId}
            </Text>
            {orderDetails.customerEmail && (
              <Text className="text-gray-600 mb-3">
                Email: {orderDetails.customerEmail}
              </Text>
            )}
            <Pressable
              onPress={markAsUnderReview}
              className="bg-blue-50 border border-blue-200 rounded-lg p-3"
            >
              <Text className="text-blue-700 font-medium text-center">
                Mark as Under Review
              </Text>
            </Pressable>
          </View>

          {/* File Review Section */}
          <View className="bg-white rounded-xl p-4 mb-4 shadow-sm">
            <Text className="text-lg font-semibold text-gray-900 mb-4">
              📁 File Review & Comments
            </Text>
            {orderDetails.files?.map((file) => (
              <View key={file.id} className="mb-4 p-3 bg-gray-50 rounded-lg">
                <View className="flex-row mb-3">
                  {file.preview || file.url ? (
                    <Image
                      source={{ uri: file.preview || file.url }}
                      className="w-20 h-20 rounded-lg bg-gray-200"
                      resizeMode="cover"
                    />
                  ) : (
                    <View className="w-20 h-20 rounded-lg bg-gray-200 justify-center items-center">
                      <Ionicons name="document" size={32} color="#6B7280" />
                    </View>
                  )}
                  <View className="flex-1 ml-3">
                    <Text className="font-semibold text-gray-900 mb-1">
                      {file.name}
                    </Text>
                    <Text className="text-sm text-gray-600 mb-2">
                      Type: {file.type}
                    </Text>
                    <Text className="text-xs font-medium text-gray-700 mb-1">
                      Review Comments:
                    </Text>
                  </View>
                </View>
                <TextInput
                  className="border border-gray-300 rounded-lg p-3 text-sm"
                  value={fileComments[file.id] || ''}
                  onChangeText={(text) => updateFileComment(file.id, text)}
                  placeholder="e.g., Excellent quality, ready for 4x6 print..."
                  multiline
                  numberOfLines={3}
                />
              </View>
            ))}
          </View>

          {/* Print Specifications */}
          <View className="bg-white rounded-xl p-4 mb-4 shadow-sm">
            <Text className="text-lg font-semibold text-gray-900 mb-4">
              📊 Print Specifications
            </Text>
            {printSpecs.map((spec) => (
              <View key={spec.id} className="mb-4 p-3 bg-gray-50 rounded-lg">
                <TextInput
                  className="border border-gray-300 rounded-lg p-3 mb-3"
                  value={spec.description}
                  onChangeText={(text) => updatePrintSpec(spec.id, 'description', text)}
                  placeholder="e.g., 5 photos: 4x6 glossy finish"
                />
                <View className="flex-row items-center justify-between">
                  <View className="flex-row items-center flex-1">
                    <TextInput
                      className="border border-gray-300 rounded-lg p-2 w-16 text-center mr-2"
                      value={spec.quantity.toString()}
                      onChangeText={(text) => updatePrintSpec(spec.id, 'quantity', parseInt(text) || 0)}
                      placeholder="Qty"
                      keyboardType="numeric"
                    />
                    <Text className="text-gray-600 mx-2">×</Text>
                    <TextInput
                      className="border border-gray-300 rounded-lg p-2 w-20 text-center mr-2"
                      value={spec.unitPrice.toString()}
                      onChangeText={(text) => updatePrintSpec(spec.id, 'unitPrice', parseFloat(text) || 0)}
                      placeholder="Price"
                      keyboardType="numeric"
                    />
                    <Text className="text-gray-600 mr-2">=</Text>
                    <Text className="font-semibold text-green-600">₱{spec.totalPrice}</Text>
                  </View>
                  <Pressable
                    onPress={() => removePrintSpec(spec.id)}
                    className="bg-red-500 rounded-full w-8 h-8 justify-center items-center ml-2"
                  >
                    <Text className="text-white font-bold text-lg">×</Text>
                  </Pressable>
                </View>
              </View>
            ))}
            <Pressable
              onPress={addPrintSpec}
              className="border border-blue-500 rounded-lg p-3 mb-4"
            >
              <Text className="text-blue-500 font-medium text-center">Add Print Item</Text>
            </Pressable>
            
            <Text className="text-xl font-bold text-center text-green-600">
              Total Amount: ₱{totalAmount.toFixed(2)}
            </Text>
          </View>

          {/* Operator Message */}
          <View className="bg-white rounded-xl p-4 mb-4 shadow-sm">
            <Text className="text-lg font-semibold text-gray-900 mb-4">
              💬 Message to Customer
            </Text>
            <TextInput
              className="border border-gray-300 rounded-lg p-3"
              value={operatorMessage}
              onChangeText={setOperatorMessage}
              placeholder="e.g., Your files look perfect! Everything is ready for high-quality printing."
              multiline
              numberOfLines={4}
            />
          </View>

          {/* Completion Time */}
          <View className="bg-white rounded-xl p-4 mb-4 shadow-sm">
            <Text className="text-lg font-semibold text-gray-900 mb-4">
              ⏰ Completion Time
            </Text>
            <TextInput
              className="border border-gray-300 rounded-lg p-3"
              value={completionTime}
              onChangeText={setCompletionTime}
              placeholder="e.g., Tomorrow 2:00 PM"
            />
          </View>

          {/* Chat with Customer */}
          <View className="bg-white rounded-xl p-4 mb-4 shadow-sm">
            <Text className="text-lg font-semibold text-gray-900 mb-4">
              💭 Chat with Customer
            </Text>
            <OperatorChatComponent orderId={orderId} />
          </View>

          {/* Approve Button */}
          <Pressable
            onPress={approveForPayment}
            disabled={printSpecs.length === 0 || totalAmount <= 0}
            className={cn(
              "rounded-xl p-4 mb-8",
              printSpecs.length === 0 || totalAmount <= 0
                ? "bg-gray-300"
                : "bg-blue-500"
            )}
          >
            <Text className="text-white font-semibold text-lg text-center">
              Approve for Payment (₱{totalAmount.toFixed(2)})
            </Text>
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

export default OperatorReviewScreen;