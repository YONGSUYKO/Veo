import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, StyleSheet, Alert, Modal } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';
import DocumentScanner from '../components/DocumentScanner';
import EmailUploadScreen from './EmailUploadScreen';
import EmailOrderConfirmationScreen from './EmailOrderConfirmationScreen';
import { EmailUpload } from '../services/emailRetrievalService';

interface FileUploadScreenProps {
  navigation?: any;
  route?: {
    params?: {
      serviceType?: 'document' | 'scan' | 'photo';
    };
  };
  serviceType?: 'document' | 'scan' | 'photo';
  onFilesProcessed?: (files: any[]) => void;
  onBack?: () => void;
}

export default function FileUploadScreen({ 
  navigation, 
  route, 
  serviceType: propServiceType,
  onFilesProcessed,
  onBack 
}: FileUploadScreenProps) {
  const insets = useSafeAreaInsets();
  const serviceType = propServiceType || route?.params?.serviceType || 'document';
  const [selectedFiles, setSelectedFiles] = useState<any[]>([]);
  const [showDocumentScanner, setShowDocumentScanner] = useState(false);
  const [showEmailUpload, setShowEmailUpload] = useState(false);
  const [showEmailConfirmation, setShowEmailConfirmation] = useState(false);
  const [emailUpload, setEmailUpload] = useState<EmailUpload | null>(null);

  // Debug file count and handle camera return
  useEffect(() => {
    console.log('🔍 FileUpload State Update:', {
      serviceType,
      arrayLength: selectedFiles.length,
      files: selectedFiles.map(f => ({ 
        name: f.name || f.fileName, 
        pages: f.pages,
        type: f.mimeType || f.type,
        uri: f.uri?.substring(0, 30) 
      }))
    });
  }, [selectedFiles, serviceType]);

  // Handle returning from camera with photo
  useEffect(() => {
    if (navigation) {
      const unsubscribe = navigation.addListener('focus', () => {
        if (route?.params?.capturedPhoto) {
          const photo = route.params.capturedPhoto;
          const newFile = {
            name: `Camera_${Date.now()}.jpg`,
            uri: photo.uri,
            size: photo.fileSize || 0,
            mimeType: 'image/jpeg',
          };
          setSelectedFiles(prev => {
            // Check if photo already exists to prevent duplicates
            if (prev.find(f => f.uri === photo.uri)) {
              return prev;
            }
            const updated = [...prev, newFile];
            console.log('📸 Added camera photo, total files:', updated.length);
            return updated;
          });
          // Clear the params
          navigation.setParams({ capturedPhoto: undefined });
        }
      });
      return unsubscribe;
    }
  }, [navigation]);

  const getTitle = () => {
    switch (serviceType) {
      case 'document': return 'Upload Documents';
      case 'photo': return 'Select Photos';
      case 'scan': return 'Scan Documents';
      default: return 'Upload Files';
    }
  };

  const getDescription = () => {
    switch (serviceType) {
      case 'document': return 'Select documents from your device';
      case 'photo': return 'Choose photos to print';
      case 'scan': return 'Scan documents with your camera';
      default: return 'Select files to upload';
    }
  };

  const handleDocumentPick = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: '*/*',
        multiple: true,
      });

      if (!result.canceled && result.assets) {
        setSelectedFiles([...selectedFiles, ...result.assets]);
        Alert.alert('Success', `${result.assets.length} files selected`);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to select files');
    }
  };

  const handleImagePick = async () => {
    try {
      // Request permission first
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Required', 'Please allow access to your photo library');
        return;
      }

      // Try multiple selection first
      let result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsMultipleSelection: true,
        quality: 0.8,
        allowsEditing: false,
        selectionLimit: 0, // 0 means no limit
      });

      // Log detailed picker results
      if (!result.canceled && result.assets) {
        console.log('📷 DETAILED ImagePicker result:', {
          canceled: result.canceled,
          assetsCount: result.assets.length,
          currentSelectedFiles: selectedFiles.length,
          pickerAssets: result.assets.map((a, i) => ({ 
            index: i,
            name: a.fileName, 
            uri: a.uri?.substring(a.uri.length - 30),
            size: a.fileSize,
            width: a.width,
            height: a.height
          }))
        });

        // Always add all returned assets regardless of count
        const newFiles = [...selectedFiles, ...result.assets];
        console.log('📷 Setting new files array:', {
          previousCount: selectedFiles.length,
          addingCount: result.assets.length,
          newTotalCount: newFiles.length,
          newFilesPreview: newFiles.map((f, i) => ({
            index: i,
            name: f.name || f.fileName,
            uri: f.uri?.substring(f.uri.length - 20)
          }))
        });
        
        setSelectedFiles(newFiles);
        
        // Show picker limitation info
        if (result.assets.length < 6 && selectedFiles.length === 0) {
          Alert.alert(
            'Photos Selected',
            `${result.assets.length} photos selected. Some devices limit photo selection.\n\nTo select more photos, tap "Add More Photos" again.`,
            [{ text: 'OK' }]
          );
        } else {
          Alert.alert('Success', `${result.assets.length} photos added! Total: ${newFiles.length} photos`);
        }
      }
    } catch (error) {
      console.error('Image picker error:', error);
      Alert.alert('Error', 'Failed to select photos. Please try again.');
    }
  };

  const handleCameraScan = () => {
    if (serviceType === 'scan') {
      console.log('🔍 Opening document scanner');
      setShowDocumentScanner(true);
    } else {
      // For photo service, use camera to take new photos
      ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 1,
        allowsEditing: true,
      }).then((result) => {
        if (!result.canceled && result.assets) {
          setSelectedFiles([...selectedFiles, ...result.assets]);
        }
      }).catch(() => {
        Alert.alert('Error', 'Failed to take photo');
      });
    }
  };

  const handleScanComplete = (pdfInfo: { uri: string; pages: number; name: string }) => {
    console.log('📄 Document scan completed:', pdfInfo);
    const newFile = {
      name: pdfInfo.name,
      uri: pdfInfo.uri,
      size: 0, // Will be calculated later
      mimeType: 'application/pdf',
      pages: pdfInfo.pages, // This is the actual page count from scanner
      copies: 1,
      paperSize: 'A4',
      printType: 'color',
      pricePerPage: 300, // 3 pesos per page for scanned documents
    };
    
    console.log('📄 BEFORE adding PDF - selectedFiles.length:', selectedFiles.length);
    console.log('📄 BEFORE adding PDF - selectedFiles:', selectedFiles);
    
    // Force update with functional setState to ensure proper state update
    setSelectedFiles(currentFiles => {
      console.log('📄 INSIDE setState - currentFiles.length:', currentFiles.length);
      const updatedFiles = [...currentFiles, newFile];
      console.log('📄 INSIDE setState - updatedFiles.length:', updatedFiles.length);
      console.log('📄 INSIDE setState - newFile:', newFile);
      return updatedFiles;
    });
    
    setShowDocumentScanner(false);
    
    // Force a re-render and show success
    setTimeout(() => {
      Alert.alert(
        'Document Scanned',
        `PDF created with ${pdfInfo.pages} page${pdfInfo.pages !== 1 ? 's' : ''}.\n\nFile added to your selection. You can scan more documents or continue to settings.`
      );
    }, 100);
  };

  const handleContinue = () => {
    if (selectedFiles.length === 0) {
      Alert.alert('No Files', 'Please select at least one file');
      return;
    }

    // Convert files to FileInfo format
    const processedFiles = selectedFiles.map((file, index) => ({
      id: `file_${Date.now()}_${index}`,
      name: file.name || file.fileName || `${serviceType === 'photo' ? 'Photo' : serviceType === 'scan' ? 'Scanned Document' : 'File'} ${index + 1}`,
      uri: file.uri,
      type: file.mimeType || file.type || (serviceType === 'photo' ? 'image/jpeg' : serviceType === 'scan' ? 'application/pdf' : 'application/octet-stream'),
      size: file.fileSize || file.size || 0,
      pages: file.pages || (serviceType === 'photo' ? 1 : Math.max(1, Math.floor((file.fileSize || file.size || 50000) / 50000))),
      copies: 1,
      paperSize: serviceType === 'photo' ? '4R' : 'A4',
      pageColor: serviceType === 'photo' ? 'color' : 'auto',
      pageSidedness: 'single',
      pageOrientation: 'portrait',
      binding: 'none',
      lamination: 'none',
    }));

    console.log('🚀 About to navigate/callback with', processedFiles.length, 'files');
    console.log('🚀 onFilesProcessed exists?', !!onFilesProcessed);
    console.log('🚀 navigation exists?', !!navigation);

    if (onFilesProcessed) {
      console.log('🔄 Using callback');
      onFilesProcessed(processedFiles);
    } else {
      console.log('🧭 Navigating to FileInfo');
      navigation?.navigate('FileInfo', { files: processedFiles });
    }
    
    console.log('✅ Navigate/callback completed');
  };

  return (
    <View style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + 20 }]}>
        <View style={styles.headerContent}>
          <Pressable onPress={onBack || (() => navigation?.goBack())} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color="#374151" />
          </Pressable>
          <View style={styles.titleContainer}>
            <Text style={styles.title}>{getTitle()}</Text>
            <Text style={styles.description}>{getDescription()}</Text>
          </View>
        </View>
      </View>

      <View style={styles.content}>
        {/* Upload Options */}
        <View style={styles.optionsContainer}>
          {serviceType === 'document' && (
            <>
              <Pressable style={styles.optionButton} onPress={handleDocumentPick}>
                <View style={styles.optionIcon}>
                  <Ionicons name="folder-open" size={32} color="#3B82F6" />
                </View>
                <Text style={styles.optionTitle}>Browse Files</Text>
                <Text style={styles.optionDescription}>Select from device storage</Text>
              </Pressable>
              
              <Pressable style={styles.optionButton} onPress={() => setShowEmailUpload(true)}>
                <View style={styles.optionIcon}>
                  <Ionicons name="mail" size={32} color="#10B981" />
                </View>
                <Text style={styles.optionTitle}>Upload via Email</Text>
                <Text style={styles.optionDescription}>Retrieve files sent to our email</Text>
              </Pressable>
            </>
          )}

          {serviceType === 'photo' && (
            <>
              <Pressable style={styles.optionButton} onPress={handleImagePick}>
                <View style={[styles.optionIcon, selectedFiles.length > 0 && { backgroundColor: '#EFF6FF' }]}>
                  <Ionicons name="images" size={32} color="#8B5CF6" />
                  {selectedFiles.length > 0 && (
                    <View style={styles.addMoreBadge}>
                      <Text style={styles.addMoreBadgeText}>+</Text>
                    </View>
                  )}
                </View>
                <Text style={styles.optionTitle}>
                  {selectedFiles.length > 0 ? `Add More Photos (${selectedFiles.length} selected)` : 'Choose from Gallery'}
                </Text>
                <Text style={styles.optionDescription}>
                  {selectedFiles.length > 0 
                    ? 'Select additional photos (device may limit to 3 at a time)' 
                    : 'Select photos from gallery'
                  }
                </Text>
              </Pressable>

              <Pressable style={styles.optionButton} onPress={handleCameraScan}>
                <View style={styles.optionIcon}>
                  <Ionicons name="camera" size={32} color="#10B981" />
                </View>
                <Text style={styles.optionTitle}>Take Photo</Text>
                <Text style={styles.optionDescription}>Capture new photos</Text>
              </Pressable>
            </>
          )}

          {serviceType === 'scan' && (
            <Pressable style={styles.optionButton} onPress={handleCameraScan}>
              <View style={styles.optionIcon}>
                <Ionicons name="scan" size={32} color="#10B981" />
              </View>
              <Text style={styles.optionTitle}>Scan Document</Text>
              <Text style={styles.optionDescription}>Multi-page PDF scanning with camera</Text>
            </Pressable>
          )}
        </View>

        {/* Selected Files Display */}
        {selectedFiles.length > 0 && (
          <View style={styles.selectedContainer}>
            <Text style={styles.selectedTitle}>
              Selected {serviceType === 'photo' ? 'Photos' : serviceType === 'scan' ? 'Documents' : 'Files'} ({selectedFiles.length})
            </Text>
            {selectedFiles.map((file, index) => (
              <View key={`${file.uri}-${index}`} style={styles.fileItem}>
                <Ionicons 
                  name={serviceType === 'photo' ? "image" : "document"} 
                  size={20} 
                  color={serviceType === 'photo' ? "#8B5CF6" : "#6B7280"} 
                />
                <View style={styles.fileInfo}>
                  <Text style={styles.fileName}>
                    {file.name || file.fileName || `${serviceType === 'photo' ? 'Photo' : 'File'} ${index + 1}`}
                  </Text>
                  {file.fileSize || file.size ? (
                    <Text style={styles.fileSize}>
                      {((file.fileSize || file.size) / 1024 / 1024).toFixed(1)} MB
                    </Text>
                  ) : null}

                </View>
                <Pressable
                  onPress={() => {
                    const filtered = selectedFiles.filter((_, i) => i !== index);
                    setSelectedFiles(filtered);
                    console.log('🗑️ Removed file, remaining:', filtered.length);
                  }}
                  style={styles.removeButton}
                >
                  <Ionicons name="close" size={16} color="#EF4444" />
                </Pressable>
              </View>
            ))}
          </View>
        )}



        {/* Empty State */}
        {selectedFiles.length === 0 && (
          <View style={styles.emptyState}>
            <Ionicons name="cloud-upload-outline" size={64} color="#9CA3AF" />
            <Text style={styles.emptyTitle}>No files selected</Text>
            <Text style={styles.emptyDescription}>Choose an option above to get started</Text>
          </View>
        )}


      </View>

      {/* Continue Button - Only shows when files are selected */}
      {selectedFiles.length > 0 && (
        <View style={styles.fixedBottomBar}>
          <Pressable 
            style={styles.fixedContinueButton}
            onPress={handleContinue}
          >
            <Text style={styles.fixedContinueText}>
              Continue with {selectedFiles.length} {serviceType === 'photo' ? 'photos' : serviceType === 'scan' ? 'documents' : 'files'} →
            </Text>
          </Pressable>
        </View>
      )}

      {/* Email Upload Modal */}
      <Modal visible={showEmailUpload} animationType="slide" presentationStyle="fullScreen">
        <EmailUploadScreen
          onBack={() => setShowEmailUpload(false)}
          onFilesRetrieved={(upload) => {
            setEmailUpload(upload);
            setShowEmailUpload(false);
            setShowEmailConfirmation(true);
          }}
        />
      </Modal>

      {/* Email Confirmation Modal */}
      {emailUpload && (
        <Modal visible={showEmailConfirmation} animationType="slide" presentationStyle="fullScreen">
          <EmailOrderConfirmationScreen
            emailUpload={emailUpload}
            onBack={() => {
              setShowEmailConfirmation(false);
              setEmailUpload(null);
            }}
            onOrderCreated={(orderId) => {
              setShowEmailConfirmation(false);
              setEmailUpload(null);
              // Navigate to order status or success screen
              if (navigation) {
                navigation.navigate('OrderComplete', { orderId });
              }
            }}
          />
        </Modal>
      )}

      {/* Document Scanner Modal */}
      <Modal visible={showDocumentScanner} animationType="slide" presentationStyle="fullScreen">
        <DocumentScanner
          onScanComplete={handleScanComplete}
          onClose={() => setShowDocumentScanner(false)}
        />
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    backgroundColor: 'white',
    paddingHorizontal: 20,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButton: {
    padding: 8,
    marginRight: 12,
  },
  titleContainer: {
    flex: 1,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#111827',
  },
  description: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 2,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  optionsContainer: {
    marginBottom: 24,
  },
  optionButton: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 20,
    marginBottom: 16,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#E5E7EB',
    borderStyle: 'dashed',
  },
  optionIcon: {
    width: 64,
    height: 64,
    backgroundColor: '#F3F4F6',
    borderRadius: 32,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  optionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 4,
  },
  optionDescription: {
    fontSize: 14,
    color: '#6B7280',
    textAlign: 'center',
  },
  selectedContainer: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  selectedTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 12,
  },
  fileItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  fileInfo: {
    flex: 1,
    marginLeft: 12,
  },
  fileName: {
    fontSize: 14,
    color: '#374151',
    fontWeight: '500',
  },
  fileSize: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 2,
  },
  removeButton: {
    padding: 4,
  },
  continueContainer: {
    marginTop: 16,
  },
  continueButton: {
    backgroundColor: '#3B82F6',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  continueIcon: {
    marginRight: 8,
  },
  continueText: {
    fontSize: 16,
    fontWeight: '600',
    color: 'white',
  },
  fileCountBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EFF6FF',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    marginBottom: 12,
  },
  fileCountText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#3B82F6',
    marginLeft: 6,
  },
  debugText: {
    fontSize: 10,
    color: '#EF4444',
    marginBottom: 8,
    fontFamily: 'monospace',
  },
  debugUri: {
    fontSize: 10,
    color: '#6B7280',
    marginTop: 2,
    fontFamily: 'monospace',
  },
  debugContainer: {
    backgroundColor: '#FEF3C7',
    padding: 8,
    borderRadius: 6,
    marginVertical: 8,
  },
  forcedContinueSection: {
    backgroundColor: '#F0FDF4',
    margin: 16,
    borderRadius: 12,
    padding: 16,
    borderWidth: 2,
    borderColor: '#10B981',
  },
  guaranteedButton: {
    alignItems: 'center',
  },
  readyText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#10B981',
    marginBottom: 12,
    textAlign: 'center',
  },
  bigContinueButton: {
    backgroundColor: '#10B981',
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 12,
    minWidth: '100%',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  bigContinueText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  forcedContinueSection: {
    marginTop: 20,
    paddingBottom: 100, // Extra space at bottom
  },
  guaranteedButton: {
    backgroundColor: '#DCFCE7',
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#10B981',
  },
  readyText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#166534',
    marginBottom: 12,
    textAlign: 'center',
  },
  bigContinueButton: {
    backgroundColor: '#10B981',
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 12,
    minWidth: 280,
    alignItems: 'center',
  },
  bigContinueText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  addMoreBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#10B981',
    alignItems: 'center',
    justifyContent: 'center',
  },
  addMoreBadgeText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  debugContainer: {
    backgroundColor: '#FEF2F2',
    padding: 8,
    borderRadius: 8,
    marginBottom: 16,
  },
  debugContinue: {
    fontSize: 12,
    color: '#DC2626',
    fontWeight: 'bold',
  },

  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 40,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#374151',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyDescription: {
    fontSize: 14,
    color: '#6B7280',
    textAlign: 'center',
  },
  fixedBottomBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  fixedContinueButton: {
    backgroundColor: '#10B981',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  fixedContinueText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});