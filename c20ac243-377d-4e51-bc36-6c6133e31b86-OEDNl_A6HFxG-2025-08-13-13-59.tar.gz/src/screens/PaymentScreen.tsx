import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, ScrollView, TextInput, Alert, Modal } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';
import { useNewAppStore, FileInfo } from '../state/newAppStore';
import { newApiClient } from '../api/newPisoAPI';
import { cn } from '../utils/cn';
import AuthPromptModal from '../components/AuthPromptModal';
import GuestSmsApprovalModal from '../components/GuestSmsApprovalModal';
import QuickCheckoutRegistration from '../components/QuickCheckoutRegistration';

interface PaymentScreenProps {
  files: FileInfo[];
  onPaymentComplete: (orderData: any) => void;
  onBack: () => void;
}

export default function PaymentScreen({ files: propFiles, onPaymentComplete, onBack, navigation, route }: PaymentScreenProps & {navigation?: any; route?: any}) {
  const files = propFiles || route?.params?.files || [];
  const insets = useSafeAreaInsets();
  const { currentUser, updateUser, isGuestMode, login, convertGuestToUser } = useAuthStore();
  const { systemSettings } = useNewAppStore();
  
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'gcash' | 'card' | null>(null);
  const [customerInfo, setCustomerInfo] = useState({
    name: currentUser?.name || '',
    phone: currentUser?.phone || '',
    email: currentUser?.email || '',
  });
  const [loyaltyPoints, setLoyaltyPoints] = useState(0);
  const [usePoints, setUsePoints] = useState(false);
  const [showSmsApproval, setShowSmsApproval] = useState(false);
  const [showQuickRegistration, setShowQuickRegistration] = useState(false);
  const [smsApproved, setSmsApproved] = useState(false);
  const [smsPhoneNumber, setSmsPhoneNumber] = useState('');
  const [pointsToUse, setPointsToUse] = useState(0);
  const [fulfillmentMethod, setFulfillmentMethod] = useState<'pickup' | 'delivery' | null>(null);
  const [selectedCourier, setSelectedCourier] = useState<string | null>(null);
  const [couriers, setCouriers] = useState<any[]>([]);
  const [showDeliveryModal, setShowDeliveryModal] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (currentUser) {
      loadLoyaltyPoints();
    }
    
    // Show auth modal immediately for guest users when they reach payment
    if (isGuestMode && !showAuthModal) {
      setShowAuthModal(true);
    }
  }, [currentUser, isGuestMode]);

  const loadLoyaltyPoints = async () => {
    if (currentUser?.id) {
      try {
        const points = await newApiClient.getLoyaltyPoints(currentUser.id);
        setLoyaltyPoints(points);
      } catch (error) {
        console.error('Failed to load loyalty points:', error);
      }
    }
  };

  const loadCouriers = async () => {
    try {
      const availableCouriers = await newApiClient.getAvailableCouriers();
      setCouriers(availableCouriers);
    } catch (error) {
      console.error('Failed to load couriers:', error);
    }
  };

  const calculatePricing = () => {
    const pricing = newApiClient.calculatePricing(files);
    const deliveryFee = fulfillmentMethod === 'delivery' ? systemSettings.deliveryFee : 0;
    const pointsDiscount = usePoints ? Math.min(pointsToUse * 100, pricing.subtotal) : 0; // 1 point = 1 peso
    
    return {
      subtotal: pricing.subtotal,
      deliveryFee,
      pointsDiscount,
      total: pricing.subtotal + deliveryFee - pointsDiscount,
    };
  };

  const handlePaymentMethodSelect = (method: 'cash' | 'gcash' | 'card') => {
    setPaymentMethod(method);
    
    // If guest mode and not cash payment, prompt for authentication
    if (isGuestMode && (method === 'gcash' || method === 'card')) {
      setShowAuthModal(true);
      return;
    }
    
    // For GCash and Card with logged in users, simulate payment processing
    if (method === 'gcash' || method === 'card') {
      Alert.alert(
        `${method.toUpperCase()} Payment`,
        `This will redirect to ${method === 'gcash' ? 'GCash' : 'card payment'} processing. Proceed?`,
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Proceed', onPress: () => processPayment(method) },
        ]
      );
    }
  };

  const handleGuestCheckout = (guestInfo: {name: string; phone?: string; email?: string}) => {
    convertGuestToUser(guestInfo);
    setCustomerInfo(guestInfo);
    setShowAuthModal(false);
    // Continue with selected payment method
    if (paymentMethod === 'gcash' || paymentMethod === 'card') {
      processPayment(paymentMethod);
    }
  };

  const handleLogin = async (email: string, password: string) => {
    try {
      const user = await newApiClient.authenticateUser(email, 'customer');
      login(user);
      setCustomerInfo({
        name: user.name,
        email: user.email,
        phone: user.phone || '',
      });
      setShowAuthModal(false);
      if (paymentMethod === 'gcash' || paymentMethod === 'card') {
        processPayment(paymentMethod);
      }
    } catch (error) {
      Alert.alert('Login Failed', 'Invalid email or password');
    }
  };

  const handleSignup = async (signupInfo: {name: string; email: string; phone?: string; password: string}) => {
    try {
      const user = await newApiClient.createUser(signupInfo);
      login(user);
      setCustomerInfo({
        name: user.name,
        email: user.email,
        phone: user.phone || '',
      });
      setShowAuthModal(false);
      if (paymentMethod === 'gcash' || paymentMethod === 'card') {
        processPayment(paymentMethod);
      }
    } catch (error) {
      Alert.alert('Signup Failed', 'Failed to create account. Please try again.');
    }
  };

  const handleDeliverySelect = () => {
    setFulfillmentMethod('delivery');
    loadCouriers();
    setShowDeliveryModal(true);
  };

  const processPayment = async (method: 'cash' | 'gcash' | 'card') => {
    if (!customerInfo.name.trim()) {
      Alert.alert('Missing Information', 'Please enter your name');
      return;
    }

    if (customerInfo.email && !customerInfo.email.includes('@')) {
      Alert.alert('Invalid Email', 'Please enter a valid email address');
      return;
    }

    if (!fulfillmentMethod) {
      Alert.alert('Fulfillment Method', 'Please select pickup or delivery');
      return;
    }

    if (fulfillmentMethod === 'delivery' && !selectedCourier) {
      Alert.alert('Delivery Courier', 'Please select a delivery courier');
      return;
    }

    // For guests, show SMS approval or quick registration flow
    if (!currentUser || isGuestMode) {
      const pricing = calculatePricing();
      setShowQuickRegistration(true);
      return;
    }

    await completePayment(method);
  };

  const completePayment = async (method: 'cash' | 'gcash' | 'card') => {
    setLoading(true);
    try {
      const pricing = calculatePricing();
      
      // Add SMS cost if approved for guests/unregistered users
      const finalPricing = {
        ...pricing,
        smsCharge: smsApproved ? 5 : 0,
        total: pricing.total + (smsApproved ? 5 : 0),
      };
      
      // Redeem loyalty points if used
      if (usePoints && pointsToUse > 0 && currentUser?.id) {
        await newApiClient.redeemLoyaltyPoints(currentUser.id, pointsToUse);
        updateUser({ loyaltyPoints: loyaltyPoints - pointsToUse });
      }

      const orderData = {
        customerInfo: {
          ...customerInfo,
          phone: smsApproved ? smsPhoneNumber : customerInfo.phone,
        },
        files,
        paymentMethod: method,
        fulfillmentMethod,
        selectedCourier,
        pricing: finalPricing,
        loyaltyPointsUsed: usePoints ? pointsToUse : 0,
        smsNotificationsEnabled: smsApproved,
        smsPhoneNumber: smsApproved ? smsPhoneNumber : null,
      };

      // Send notifications based on customer type
      try {
        const { notificationManager } = await import('../services/notificationManager');
        
        if (currentUser) {
          // Registered user - use notification manager
          await notificationManager.sendOrderUpdate(
            currentUser.id,
            `temp_${Date.now()}`,
            'uploaded',
            'Your order has been placed successfully! We will process it shortly.'
          );
        } else if (smsApproved && smsPhoneNumber) {
          // Guest with SMS - send direct SMS
          const { smsService } = await import('../services/smsService');
          await smsService.sendSms({
            to: smsPhoneNumber,
            message: `PISO Print: Order placed successfully! Total: ₱${finalPricing.total}. We'll update you on progress.`,
          });
        }
      } catch (error) {
        console.error('Error sending order confirmation:', error);
      }

      if (onPaymentComplete) {
        onPaymentComplete(orderData);
      } else {
        // For mobile navigation, show success and navigate back
        Alert.alert('Order Placed!', 'Your order has been submitted successfully', [
          { text: 'OK', onPress: () => navigation?.navigate('HomeMain') }
        ]);
      }
    } catch (error) {
      Alert.alert('Payment Error', 'Failed to process payment. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSmsApproval = (phoneNumber: string) => {
    setSmsApproved(true);
    setSmsPhoneNumber(phoneNumber);
    setShowSmsApproval(false);
    if (paymentMethod) {
      completePayment(paymentMethod);
    }
  };

  const handleSmsDecline = () => {
    setSmsApproved(false);
    setSmsPhoneNumber('');
    setShowSmsApproval(false);
    if (paymentMethod) {
      completePayment(paymentMethod);
    }
  };

  const handleQuickRegistrationComplete = (userData: any) => {
    setShowQuickRegistration(false);
    // User is now registered, proceed with payment
    if (paymentMethod) {
      completePayment(paymentMethod);
    }
  };

  const handleContinueAsGuest = () => {
    setShowQuickRegistration(false);
    const pricing = calculatePricing();
    setShowSmsApproval(true);
  };

  const pricing = calculatePricing();
  const maxPointsToUse = Math.floor(Math.min(loyaltyPoints, pricing.subtotal / 100));

  return (
    <View className="flex-1 bg-white">
      <View style={{ paddingTop: insets.top }} className="px-4 flex-1">
        
        {/* Header */}
        <View className="flex-row items-center mb-6 pt-4">
          <Pressable onPress={onBack} className="mr-4">
            <Ionicons name="arrow-back" size={24} color="#374151" />
          </Pressable>
          <View className="flex-1">
            <Text className="text-2xl font-bold text-gray-900">
              Payment & Delivery
            </Text>
            <Text className="text-sm text-gray-600 mt-1">
              Complete your order
            </Text>
          </View>
        </View>

        <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
          
          {/* Payment Method Selection */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 mb-4">
              Choose Payment Method
            </Text>
            <View className="space-y-3">
              <PaymentMethodCard
                icon="cash"
                title="Cash"
                description="Pay at pickup or to delivery courier"
                selected={paymentMethod === 'cash'}
                onPress={() => handlePaymentMethodSelect('cash')}
              />
              <PaymentMethodCard
                icon="phone-portrait"
                title="GCash"
                description="Pay securely with GCash"
                selected={paymentMethod === 'gcash'}
                onPress={() => handlePaymentMethodSelect('gcash')}
              />
              <PaymentMethodCard
                icon="card"
                title="Card"
                description="Credit or Debit card"
                selected={paymentMethod === 'card'}
                onPress={() => handlePaymentMethodSelect('card')}
              />
            </View>
          </View>

          {/* Customer Information - Show for cash or if user is guest */}
          {paymentMethod === 'cash' && isGuestMode && (
            <View className="mb-6">
              <Text className="text-lg font-semibold text-gray-900 mb-4">
                Customer Information
              </Text>
              <View className="space-y-4">
                <View>
                  <Text className="text-sm font-medium text-gray-700 mb-2">
                    Full Name <Text className="text-red-500">*</Text>
                  </Text>
                  <TextInput
                    className="border border-gray-300 rounded-xl px-4 py-3 text-base"
                    value={customerInfo.name}
                    onChangeText={(text) => setCustomerInfo({...customerInfo, name: text})}
                    placeholder="Enter your full name"
                    autoCapitalize="words"
                  />
                </View>
                
                <View>
                  <Text className="text-sm font-medium text-gray-700 mb-2">
                    Phone Number
                  </Text>
                  <TextInput
                    className="border border-gray-300 rounded-xl px-4 py-3 text-base"
                    value={customerInfo.phone}
                    onChangeText={(text) => setCustomerInfo({...customerInfo, phone: text})}
                    placeholder="+639123456789 (optional)"
                    keyboardType="phone-pad"
                  />
                </View>
                
                <View>
                  <Text className="text-sm font-medium text-gray-700 mb-2">
                    Email Address
                  </Text>
                  <TextInput
                    className="border border-gray-300 rounded-xl px-4 py-3 text-base"
                    value={customerInfo.email}
                    onChangeText={(text) => setCustomerInfo({...customerInfo, email: text})}
                    placeholder="email@example.com (optional)"
                    keyboardType="email-address"
                    autoCapitalize="none"
                  />
                </View>
              </View>
            </View>
          )}

          {/* Loyalty Points */}
          {loyaltyPoints > 0 && paymentMethod && (
            <View className="mb-6">
              <Text className="text-lg font-semibold text-gray-900 mb-4">
                Loyalty Points
              </Text>
              <View className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
                <View className="flex-row items-center justify-between mb-3">
                  <View className="flex-row items-center">
                    <Ionicons name="star" size={20} color="#F59E0B" />
                    <Text className="text-base font-medium text-gray-900 ml-2">
                      Available: {loyaltyPoints} points
                    </Text>
                  </View>
                  <Pressable 
                    onPress={() => setUsePoints(!usePoints)}
                    className="flex-row items-center"
                  >
                    <View className={cn(
                      "w-5 h-5 rounded border-2 items-center justify-center mr-2",
                      usePoints ? "bg-blue-500 border-blue-500" : "border-gray-300"
                    )}>
                      {usePoints && <Ionicons name="checkmark" size={12} color="white" />}
                    </View>
                    <Text className="text-sm font-medium text-gray-700">
                      Use points
                    </Text>
                  </Pressable>
                </View>
                
                {usePoints && (
                  <View className="flex-row items-center">
                    <Text className="text-sm text-gray-700 mr-3">Points to use:</Text>
                    <TextInput
                      className="border border-gray-300 rounded-lg px-3 py-2 text-center min-w-20"
                      value={pointsToUse.toString()}
                      onChangeText={(text) => {
                        const points = Math.min(parseInt(text) || 0, maxPointsToUse);
                        setPointsToUse(points);
                      }}
                      keyboardType="numeric"
                    />
                    <Text className="text-sm text-gray-600 ml-3">
                      Max: {maxPointsToUse}
                    </Text>
                  </View>
                )}
                
                <Text className="text-xs text-gray-600 mt-2">
                  1 point = ₱1.00 discount
                </Text>
              </View>
            </View>
          )}

          {/* Fulfillment Method */}
          {paymentMethod && (
            <View className="mb-6">
              <Text className="text-lg font-semibold text-gray-900 mb-4">
                How would you like to receive your order?
              </Text>
              <View className="space-y-3">
                <FulfillmentCard
                  icon="storefront"
                  title="Pickup"
                  description="Collect from our store"
                  fee="Free"
                  selected={fulfillmentMethod === 'pickup'}
                  onPress={() => setFulfillmentMethod('pickup')}
                />
                <FulfillmentCard
                  icon="bicycle"
                  title="Delivery"
                  description="Delivered to your location"
                  fee={`₱${(systemSettings.deliveryFee / 100).toFixed(2)}`}
                  selected={fulfillmentMethod === 'delivery'}
                  onPress={handleDeliverySelect}
                />
              </View>
              
              {selectedCourier && (
                <View className="mt-3 bg-blue-50 rounded-xl p-4">
                  <Text className="text-sm font-medium text-blue-900">
                    Selected Courier: {couriers.find(c => c.id === selectedCourier)?.name}
                  </Text>
                  <Text className="text-xs text-blue-700 mt-1">
                    Estimated delivery: {couriers.find(c => c.id === selectedCourier)?.estimatedTime}
                  </Text>
                </View>
              )}
            </View>
          )}

          {/* Order Summary */}
          {paymentMethod && fulfillmentMethod && (
            <View className="bg-gray-50 rounded-2xl p-6 mb-6">
              <Text className="text-lg font-semibold text-gray-900 mb-4">
                Order Summary
              </Text>
              
              <View className="space-y-2">
                <View className="flex-row justify-between">
                  <Text className="text-gray-700">Subtotal</Text>
                  <Text className="font-medium">₱{(pricing.subtotal / 100).toFixed(2)}</Text>
                </View>
                
                {fulfillmentMethod === 'delivery' && (
                  <View className="flex-row justify-between">
                    <Text className="text-gray-700">Delivery Fee</Text>
                    <Text className="font-medium">₱{(pricing.deliveryFee / 100).toFixed(2)}</Text>
                  </View>
                )}
                
                {usePoints && pointsToUse > 0 && (
                  <View className="flex-row justify-between text-green-600">
                    <Text className="text-green-700">Points Discount (-{pointsToUse} pts)</Text>
                    <Text className="font-medium text-green-700">-₱{(pricing.pointsDiscount / 100).toFixed(2)}</Text>
                  </View>
                )}
                
                <View className="h-px bg-gray-200 my-3" />
                
                <View className="flex-row justify-between">
                  <Text className="text-lg font-bold text-gray-900">Total</Text>
                  <Text className="text-xl font-bold text-blue-600">
                    ₱{(pricing.total / 100).toFixed(2)}
                  </Text>
                </View>
              </View>
            </View>
          )}

        </ScrollView>

        {/* Complete Order Button */}
        {paymentMethod && fulfillmentMethod && (
          <View className="pt-4 pb-6 border-t border-gray-200">
            <Pressable 
              className={cn(
                "py-4 rounded-xl",
                loading ? "bg-gray-400" : "bg-blue-500"
              )}
              onPress={() => processPayment(paymentMethod)}
              disabled={loading}
            >
              <Text className="text-white text-center font-semibold text-lg">
                {loading ? 'Processing...' : `Complete Order - ₱${(pricing.total / 100).toFixed(2)}`}
              </Text>
            </Pressable>
          </View>
        )}

      </View>

      {/* Auth Prompt Modal */}
      <AuthPromptModal
        visible={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onGuestCheckout={handleGuestCheckout}
        onLogin={handleLogin}
        onSignup={handleSignup}
      />

      {/* Delivery Courier Modal */}
      <Modal visible={showDeliveryModal} animationType="slide" presentationStyle="pageSheet">
        <View className="flex-1 bg-white">
          <View className="flex-row items-center justify-between p-4 border-b border-gray-200">
            <Pressable onPress={() => setShowDeliveryModal(false)}>
              <Text className="text-blue-500 text-lg">Cancel</Text>
            </Pressable>
            <Text className="text-lg font-semibold">Select Courier</Text>
            <Pressable onPress={() => setShowDeliveryModal(false)}>
              <Text className="text-blue-500 text-lg font-semibold">Done</Text>
            </Pressable>
          </View>

          <ScrollView className="flex-1 p-4">
            <View className="bg-orange-50 border border-orange-200 rounded-xl p-4 mb-6">
              <View className="flex-row items-center">
                <Ionicons name="information-circle" size={20} color="#F97316" />
                <Text className="text-orange-800 font-medium ml-2">
                  Delivery Fee: ₱{(systemSettings.deliveryFee / 100).toFixed(2)}
                </Text>
              </View>
              <Text className="text-orange-700 text-sm mt-1">
                Additional delivery charge applies for all courier options
              </Text>
            </View>

            <View className="space-y-3">
              {couriers.map((courier) => (
                <Pressable
                  key={courier.id}
                  onPress={() => setSelectedCourier(courier.id)}
                  className={cn(
                    "border-2 rounded-xl p-4",
                    selectedCourier === courier.id 
                      ? "bg-blue-50 border-blue-500" 
                      : "bg-white border-gray-200"
                  )}
                >
                  <View className="flex-row items-center justify-between">
                    <View>
                      <Text className={cn(
                        "text-base font-semibold",
                        selectedCourier === courier.id ? "text-blue-900" : "text-gray-900"
                      )}>
                        {courier.name}
                      </Text>
                      <Text className={cn(
                        "text-sm",
                        selectedCourier === courier.id ? "text-blue-700" : "text-gray-600"
                      )}>
                        ETA: {courier.estimatedTime}
                      </Text>
                    </View>
                    {selectedCourier === courier.id && (
                      <Ionicons name="checkmark-circle" size={24} color="#3B82F6" />
                    )}
                  </View>
                </Pressable>
              ))}
            </View>
          </ScrollView>
        </View>
      </Modal>

      {/* SMS Approval Modal for Guests */}
      <GuestSmsApprovalModal
        visible={showSmsApproval}
        onClose={() => setShowSmsApproval(false)}
        onApprove={handleSmsApproval}
        onDecline={handleSmsDecline}
        orderAmount={calculatePricing().total}
        orderId="temp_order"
      />

      {/* Quick Registration Modal */}
      <QuickCheckoutRegistration
        visible={showQuickRegistration}
        onClose={() => setShowQuickRegistration(false)}
        onRegistrationComplete={handleQuickRegistrationComplete}
        onContinueAsGuest={handleContinueAsGuest}
        orderAmount={calculatePricing().total}
        prefilledPhone={customerInfo.phone}
      />

    </View>
  );
}

interface PaymentMethodCardProps {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  description: string;
  selected: boolean;
  onPress: () => void;
}

function PaymentMethodCard({ icon, title, description, selected, onPress }: PaymentMethodCardProps) {
  return (
    <Pressable 
      onPress={onPress}
      className={cn(
        "border-2 rounded-xl p-4",
        selected ? "bg-blue-50 border-blue-500" : "bg-white border-gray-200"
      )}
    >
      <View className="flex-row items-center">
        <View className={cn(
          "w-12 h-12 rounded-xl items-center justify-center mr-4",
          selected ? "bg-blue-500" : "bg-gray-100"
        )}>
          <Ionicons 
            name={icon} 
            size={24} 
            color={selected ? "white" : "#6B7280"} 
          />
        </View>
        <View className="flex-1">
          <Text className={cn(
            "text-base font-semibold",
            selected ? "text-blue-900" : "text-gray-900"
          )}>
            {title}
          </Text>
          <Text className={cn(
            "text-sm",
            selected ? "text-blue-700" : "text-gray-600"
          )}>
            {description}
          </Text>
        </View>
        {selected && (
          <Ionicons name="checkmark-circle" size={24} color="#3B82F6" />
        )}
      </View>
    </Pressable>
  );
}

interface FulfillmentCardProps {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  description: string;
  fee: string;
  selected: boolean;
  onPress: () => void;
}

function FulfillmentCard({ icon, title, description, fee, selected, onPress }: FulfillmentCardProps) {
  return (
    <Pressable 
      onPress={onPress}
      className={cn(
        "border-2 rounded-xl p-4",
        selected ? "bg-green-50 border-green-500" : "bg-white border-gray-200"
      )}
    >
      <View className="flex-row items-center justify-between">
        <View className="flex-row items-center flex-1">
          <View className={cn(
            "w-12 h-12 rounded-xl items-center justify-center mr-4",
            selected ? "bg-green-500" : "bg-gray-100"
          )}>
            <Ionicons 
              name={icon} 
              size={24} 
              color={selected ? "white" : "#6B7280"} 
            />
          </View>
          <View className="flex-1">
            <Text className={cn(
              "text-base font-semibold",
              selected ? "text-green-900" : "text-gray-900"
            )}>
              {title}
            </Text>
            <Text className={cn(
              "text-sm",
              selected ? "text-green-700" : "text-gray-600"
            )}>
              {description}
            </Text>
          </View>
        </View>
        <View className="items-end">
          <Text className={cn(
            "text-base font-bold",
            selected ? "text-green-900" : "text-gray-900"
          )}>
            {fee}
          </Text>
          {selected && (
            <Ionicons name="checkmark-circle" size={20} color="#10B981" />
          )}
        </View>
      </View>
    </Pressable>
  );
}