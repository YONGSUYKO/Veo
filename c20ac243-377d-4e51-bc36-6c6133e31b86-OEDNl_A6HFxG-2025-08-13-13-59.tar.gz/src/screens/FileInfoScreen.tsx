import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, ScrollView, TextInput } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';
import { useNewAppStore, FileInfo } from '../state/newAppStore';
import { newApiClient } from '../api/newPisoAPI';
import { cn } from '../utils/cn';

interface FileInfoScreenProps {
  navigation?: any;
  route?: {
    params?: {
      files?: FileInfo[];
      onFilesUpdated?: (files: FileInfo[]) => void;
      onProceedToPayment?: (files: FileInfo[]) => void;
    };
  };
  files?: FileInfo[];
  onFilesUpdated?: (files: FileInfo[]) => void;
  onProceedToPayment?: (files: FileInfo[]) => void;
  onBack?: () => void;
}

export default function FileInfoScreen({ 
  navigation, 
  route, 
  files: propFiles,
  onFilesUpdated: propOnFilesUpdated,
  onProceedToPayment: propOnProceedToPayment,
  onBack: propOnBack 
}: FileInfoScreenProps) {
  const files = propFiles || route?.params?.files || [];
  const onFilesUpdated = propOnFilesUpdated || route?.params?.onFilesUpdated || (() => {});
  const onProceedToPayment = propOnProceedToPayment || route?.params?.onProceedToPayment || (() => {});
  const onBack = propOnBack || (() => navigation?.goBack());
  const insets = useSafeAreaInsets();
  const { currentUser } = useAuthStore();
  const { systemSettings } = useNewAppStore();
  const [updatedFiles, setUpdatedFiles] = useState<FileInfo[]>([...files]);
  const [showBookbindingUpsell, setShowBookbindingUpsell] = useState(false);

  const isAdmin = currentUser?.role === 'admin';

  // Check for bookbinding upsell
  useEffect(() => {
    const totalPages = updatedFiles.reduce((sum, file) => sum + file.pages, 0);
    if (totalPages >= 35) {
      setShowBookbindingUpsell(true);
    }
  }, [updatedFiles]);

  const updateFileProperty = (fileIndex: number, property: keyof FileInfo, value: any) => {
    const newFiles = [...updatedFiles];
    newFiles[fileIndex] = { ...newFiles[fileIndex], [property]: value };
    setUpdatedFiles(newFiles);
    onFilesUpdated(newFiles);
  };

  const calculateTotal = () => {
    const pricing = newApiClient.calculatePricing(updatedFiles);
    return pricing.total;
  };

  const handleProceed = () => {
    if (propOnProceedToPayment) {
      onProceedToPayment(updatedFiles);
    } else {
      navigation?.navigate('Payment', { files: updatedFiles });
    }
  };

  return (
    <View className="flex-1 bg-white">
      <View style={{ paddingTop: insets.top }} className="px-4 flex-1">
        
        {/* Header */}
        <View className="flex-row items-center mb-6 pt-4">
          <Pressable onPress={onBack} className="mr-4">
            <Ionicons name="arrow-back" size={24} color="#374151" />
          </Pressable>
          <View className="flex-1">
            <Text className="text-2xl font-bold text-gray-900">
              Print Settings
            </Text>
            <Text className="text-sm text-gray-600 mt-1">
              Configure your print options for each file
            </Text>
          </View>
        </View>

        <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
          {/* Files List */}
          <View className="space-y-6 mb-6">
            {updatedFiles.map((file, index) => (
              <FileInfoCard 
                key={file.id}
                file={file}
                fileIndex={index}
                systemSettings={systemSettings}
                isAdmin={isAdmin}
                onUpdateProperty={updateFileProperty}
              />
            ))}
          </View>

          {/* Pricing Summary */}
          <View className="bg-blue-50 rounded-2xl p-6 mb-6">
            <Text className="text-lg font-semibold text-gray-900 mb-4">
              Pricing Summary
            </Text>
            
            {updatedFiles.map((file, index) => {
              const pricing = newApiClient.calculatePricing([file]);
              return (
                <View key={file.id} className="flex-row justify-between items-center mb-2">
                  <Text className="text-sm text-gray-700" numberOfLines={1}>
                    {file.name} ({file.pages} pages × {file.copies} copies)
                  </Text>
                  <Text className="text-sm font-medium text-gray-900">
                    ₱{(pricing.total / 100).toFixed(2)}
                  </Text>
                </View>
              );
            })}
            
            <View className="h-px bg-gray-200 my-3" />
            <View className="flex-row justify-between items-center">
              <Text className="text-lg font-bold text-gray-900">Total</Text>
              <Text className="text-xl font-bold text-blue-600">
                ₱{(calculateTotal() / 100).toFixed(2)}
              </Text>
            </View>
          </View>
        </ScrollView>

        {/* Proceed Button */}
        <View className="pt-4 pb-6 border-t border-gray-200">
          <Pressable 
            className="bg-blue-500 py-4 rounded-xl"
            onPress={handleProceed}
          >
            <Text className="text-white text-center font-semibold text-lg">
              Proceed to Payment - ₱{(calculateTotal() / 100).toFixed(2)}
            </Text>
          </Pressable>
        </View>

      </View>

      {/* Bookbinding Reminder - Information Only */}
      {showBookbindingUpsell && (
        <View className="absolute inset-0 bg-black bg-opacity-50 items-center justify-center px-6">
          <View className="bg-white rounded-2xl p-6 max-w-sm w-full">
            <View className="items-center mb-4">
              <View className="w-16 h-16 bg-blue-100 rounded-full items-center justify-center mb-4">
                <Ionicons name="information-circle" size={32} color="#3B82F6" />
              </View>
              <Text className="text-xl font-bold text-gray-900 text-center mb-2">
                Bookbinding Available
              </Text>
              <Text className="text-gray-600 text-center">
                With {updatedFiles.reduce((sum, file) => sum + file.pages, 0)} pages total, you may want to consider bookbinding for a professional finish.
              </Text>
            </View>

            <View className="bg-blue-50 rounded-xl p-4 mb-6">
              <Text className="text-sm font-semibold text-blue-800 mb-2">
                💡 Bookbinding Options Available:
              </Text>
              <Text className="text-sm text-blue-700">
                • Spiral Binding: +₱15 (Easy to flip pages)
                {'\n'}• Perfect Binding: +₱25 (Professional look)
                {'\n'}• Lamination: Extra protection available
                {'\n\n'}Ask our staff for bookbinding when you pickup or during delivery.
              </Text>
            </View>

            <Pressable 
              className="bg-blue-500 py-4 rounded-xl"
              onPress={() => {
                setShowBookbindingUpsell(false);
              }}
            >
              <Text className="text-white text-center font-semibold text-lg">
                Continue
              </Text>
            </Pressable>
          </View>
        </View>
      )}
    </View>
  );
}

interface FileInfoCardProps {
  file: FileInfo;
  fileIndex: number;
  systemSettings: any;
  isAdmin: boolean;
  onUpdateProperty: (fileIndex: number, property: keyof FileInfo, value: any) => void;
}

function FileInfoCard({ file, fileIndex, systemSettings, isAdmin, onUpdateProperty }: FileInfoCardProps) {
  const getFileIcon = (file: FileInfo) => {
    if (file.type?.includes('pdf')) return 'document-text';
    if (file.type?.includes('image')) return 'image';
    if (file.type?.includes('word')) return 'document';
    return 'document-outline';
  };

  // Helper function to check if file is a photo
  const isPhotoFile = (file: FileInfo) => {
    return file.type?.includes('image') || 
           file.name?.toLowerCase().includes('.jpg') ||
           file.name?.toLowerCase().includes('.jpeg') ||
           file.name?.toLowerCase().includes('.png') ||
           file.name?.toLowerCase().includes('.gif') ||
           file.name?.toLowerCase().includes('.bmp') ||
           file.name?.toLowerCase().includes('.webp');
  };

  // Helper function to check if lamination should be available for photo sizes
  const isLaminationAvailable = (file: FileInfo) => {
    if (!isPhotoFile(file)) return true; // Always available for documents
    
    // For photos, lamination not available for Wallet and 2R sizes
    return file.paperSize !== 'Wallet' && file.paperSize !== '2R';
  };

  const getAvailablePaperSizes = (file: FileInfo) => {
    const isPhoto = isPhotoFile(file);
    
    if (isPhoto) {
      return [
        { id: 'Wallet', name: 'Wallet', description: '1.75" × 2.5"' },
        { id: '2R', name: '2R', description: '2" × 3"' },
        { id: '3R', name: '3R', description: '3.5" × 5"' },
        { id: '4R', name: '4R', description: '4" × 6" (Standard)' },
        { id: '5R', name: '5R', description: '5" × 7"' },
        { id: '6R', name: '6R', description: '6" × 8"' },
        { id: '8R', name: '8R', description: '8" × 10"' },
        { id: 'A4', name: 'A4 Photo', description: '8.3" × 11.7"' },
        { id: 'A3', name: 'A3 Photo', description: '11.7" × 16.5"' },
      ];
    } else {
      return [
        { id: 'Letter', name: 'Letter', description: '8.5" × 11" (Default)' },
        { id: 'A4', name: 'A4', description: '8.3" × 11.7"' },
        { id: 'Legal', name: 'Legal', description: '8.5" × 13"' },
        { id: 'A3', name: 'A3', description: '11.7" × 16.5"' },
      ];
    }
  };
  const pageColors = [
    { value: 'auto', label: 'Auto' },
    { value: 'color', label: 'Color' },
    { value: 'blackwhite', label: 'Black & White' },
  ];
  
  const bindingOptions = [
    { value: 'none', label: 'No Binding' },
    { value: 'spiral', label: 'Spiral Binding' },
    { value: 'perfect', label: 'Perfect Binding' },
    { value: 'saddle', label: 'Saddle Stitch' },
  ];
  
  const laminationOptions = [
    { value: 'none', label: 'No Lamination' },
    { value: 'matte', label: 'Matte Lamination' },
    { value: 'glossy', label: 'Glossy Lamination' },
  ];

  return (
    <View className="bg-white border border-gray-200 rounded-2xl p-6">
      {/* File Header */}
      <View className="flex-row items-center mb-4">
        <View className="w-12 h-12 bg-blue-50 rounded-xl items-center justify-center mr-3">
          <Ionicons name={getFileIcon(file)} size={24} color="#3B82F6" />
        </View>
        <View className="flex-1">
          <Text className="text-base font-semibold text-gray-900" numberOfLines={1}>
            {file.name}
          </Text>
          <Text className="text-sm text-gray-600">
            {file.pages} pages detected
          </Text>
        </View>
      </View>

      {/* Settings */}
      <View className="space-y-4">
        
        {/* Paper Size */}
        <SettingRow 
          icon="resize"
          label={file.type?.includes('image') ? "Photo Size" : "Paper Size"}
          isEnabled={isAdmin || true} // Always allow for demo
        >
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View className="flex-row">
              {getAvailablePaperSizes(file).map((size) => (
                <Pressable
                  key={size.id}
                  onPress={() => onUpdateProperty(fileIndex, 'paperSize', size.id)}
                  className={cn(
                    "px-3 py-2 rounded-lg border-2 min-w-[80px] mr-2",
                    file.paperSize === size.id 
                      ? "bg-blue-500 border-blue-500" 
                      : "bg-white border-gray-200"
                  )}
                >
                  <Text className={cn(
                    "font-medium text-xs text-center",
                    file.paperSize === size.id ? "text-white" : "text-gray-700"
                  )}>
                    {size.name}
                  </Text>
                  <Text className={cn(
                    "text-xs text-center mt-1",
                    file.paperSize === size.id ? "text-blue-100" : "text-gray-500"
                  )}>
                    {size.description}
                  </Text>
                </Pressable>
              ))}
            </View>
          </ScrollView>
        </SettingRow>

        {/* Page Color */}
        <SettingRow 
          icon="color-palette"
          label="Page Color"
          isEnabled={systemSettings.allowColorToggle || isAdmin}
          lockIcon={!systemSettings.allowColorToggle && !isAdmin}
        >
          <View className="flex-row space-x-2">
            {pageColors.map((color) => (
              <Pressable
                key={color.value}
                onPress={() => systemSettings.allowColorToggle || isAdmin 
                  ? onUpdateProperty(fileIndex, 'pageColor', color.value)
                  : null
                }
                className={cn(
                  "flex-1 py-3 rounded-lg border-2",
                  file.pageColor === color.value 
                    ? "bg-blue-500 border-blue-500" 
                    : "bg-white border-gray-200",
                  (!systemSettings.allowColorToggle && !isAdmin) ? "opacity-50" : ""
                )}
              >
                <Text className={cn(
                  "text-center font-medium text-sm",
                  file.pageColor === color.value ? "text-white" : "text-gray-700"
                )}>
                  {color.label}
                </Text>
              </Pressable>
            ))}
          </View>
        </SettingRow>

        {/* Page Sidedness - Hidden for photos */}
        {!isPhotoFile(file) && (
          <SettingRow 
            icon="copy"
            label="Page Sidedness"
            isEnabled={systemSettings.allowSidednessToggle || isAdmin}
            lockIcon={!systemSettings.allowSidednessToggle && !isAdmin}
          >
            <View className="flex-row space-x-2">
              {['single', 'double'].map((sidedness) => (
                <Pressable
                  key={sidedness}
                  onPress={() => systemSettings.allowSidednessToggle || isAdmin 
                    ? onUpdateProperty(fileIndex, 'pageSidedness', sidedness)
                    : null
                  }
                  className={cn(
                    "flex-1 py-3 rounded-lg border-2",
                    file.pageSidedness === sidedness 
                      ? "bg-blue-500 border-blue-500" 
                      : "bg-white border-gray-200",
                    (!systemSettings.allowSidednessToggle && !isAdmin) ? "opacity-50" : ""
                  )}
                >
                  <Text className={cn(
                    "text-center font-medium text-sm",
                    file.pageSidedness === sidedness ? "text-white" : "text-gray-700"
                  )}>
                    {sidedness === 'single' ? 'Single Sided' : 'Double Sided'}
                  </Text>
                </Pressable>
              ))}
            </View>
          </SettingRow>
        )}

        {/* Page Orientation */}
        <SettingRow 
          icon="phone-portrait"
          label="Page Orientation"
          isEnabled={systemSettings.allowOrientationToggle || isAdmin}
          lockIcon={!systemSettings.allowOrientationToggle && !isAdmin}
        >
          <View className="flex-row space-x-2">
            {['portrait', 'landscape'].map((orientation) => (
              <Pressable
                key={orientation}
                onPress={() => systemSettings.allowOrientationToggle || isAdmin 
                  ? onUpdateProperty(fileIndex, 'pageOrientation', orientation)
                  : null
                }
                className={cn(
                  "flex-1 py-3 rounded-lg border-2",
                  file.pageOrientation === orientation 
                    ? "bg-blue-500 border-blue-500" 
                    : "bg-white border-gray-200",
                  (!systemSettings.allowOrientationToggle && !isAdmin) ? "opacity-50" : ""
                )}
              >
                <Text className={cn(
                  "text-center font-medium text-sm",
                  file.pageOrientation === orientation ? "text-white" : "text-gray-700"
                )}>
                  {orientation.charAt(0).toUpperCase() + orientation.slice(1)}
                </Text>
              </Pressable>
            ))}
          </View>
        </SettingRow>

        {/* Number of Copies */}
        <SettingRow 
          icon="duplicate"
          label="Number of Copies"
          isEnabled={systemSettings.allowCopiesToggle || isAdmin}
          lockIcon={!systemSettings.allowCopiesToggle && !isAdmin}
        >
          <View className="flex-row items-center space-x-4">
            <Pressable 
              className="w-10 h-10 bg-gray-100 rounded-full items-center justify-center"
              onPress={() => (systemSettings.allowCopiesToggle || isAdmin) && file.copies > 1 
                ? onUpdateProperty(fileIndex, 'copies', file.copies - 1)
                : null
              }
            >
              <Ionicons name="remove" size={20} color="#374151" />
            </Pressable>
            
            <TextInput
              className="text-2xl font-bold text-gray-900 text-center min-w-16"
              value={file.copies.toString()}
              onChangeText={(text) => {
                const num = parseInt(text) || 1;
                const maxCopies = systemSettings.maxCopies || 1000;
                const copies = Math.min(Math.max(1, num), maxCopies);
                if (systemSettings.allowCopiesToggle || isAdmin) {
                  onUpdateProperty(fileIndex, 'copies', copies);
                }
              }}
              keyboardType="numeric"
              editable={systemSettings.allowCopiesToggle || isAdmin}
            />
            
            <Pressable 
              className="w-10 h-10 bg-gray-100 rounded-full items-center justify-center"
              onPress={() => {
                const maxCopies = systemSettings.maxCopies || 1000;
                if ((systemSettings.allowCopiesToggle || isAdmin) && file.copies < maxCopies) {
                  onUpdateProperty(fileIndex, 'copies', file.copies + 1);
                }
              }}
            >
              <Ionicons name="add" size={20} color="#374151" />
            </Pressable>
          </View>
          
          <Text className="text-xs text-gray-500 mt-2">
            Max: {systemSettings.maxCopies || 1000} copies
          </Text>
        </SettingRow>

        {/* Binding Options - Hidden for photos */}
        {!isPhotoFile(file) && (
          <SettingRow 
            icon="library"
            label="Binding"
            isEnabled={true}
          >
            <View className="flex-row flex-wrap">
              {bindingOptions.map((option, index) => (
                <Pressable
                  key={option.value}
                  onPress={() => onUpdateProperty(fileIndex, 'binding', option.value)}
                  className={cn(
                    "px-4 py-2 rounded-lg border-2 mr-2 mb-2",
                    file.binding === option.value 
                      ? "bg-blue-500 border-blue-500" 
                      : "bg-white border-gray-200"
                  )}
                >
                  <Text className={cn(
                    "font-medium text-sm",
                    file.binding === option.value ? "text-white" : "text-gray-700"
                  )}>
                    {option.label}
                  </Text>
                </Pressable>
              ))}
            </View>
            {file.binding !== 'none' && (
              <Text className="text-xs text-green-600 mt-2">
                +₱{file.binding === 'spiral' ? '15' : file.binding === 'perfect' ? '25' : '20'} per document
              </Text>
            )}
          </SettingRow>
        )}

        {/* Lamination Options - Hidden for Wallet and 2R photo sizes */}
        {isLaminationAvailable(file) && (
          <SettingRow 
            icon="shield"
            label="Lamination"
            isEnabled={true}
          >
            <View className="flex-row flex-wrap">
              {laminationOptions.map((option, index) => (
                <Pressable
                  key={option.value}
                  onPress={() => onUpdateProperty(fileIndex, 'lamination', option.value)}
                  className={cn(
                    "px-4 py-2 rounded-lg border-2 mr-2 mb-2",
                    file.lamination === option.value 
                      ? "bg-blue-500 border-blue-500" 
                      : "bg-white border-gray-200"
                  )}
                >
                  <Text className={cn(
                    "font-medium text-sm",
                    file.lamination === option.value ? "text-white" : "text-gray-700"
                  )}>
                    {option.label}
                  </Text>
                </Pressable>
              ))}
            </View>
            {file.lamination !== 'none' && (
              <Text className="text-xs text-green-600 mt-2">
                +₱{file.lamination === 'matte' ? '10' : '15'} per page {isPhotoFile(file) ? '(photo)' : ''}
              </Text>
            )}
            {isPhotoFile(file) && (file.paperSize === 'Wallet' || file.paperSize === '2R') && (
              <Text className="text-xs text-gray-500 mt-2">
                ℹ️ Lamination not available for {file.paperSize} size
              </Text>
            )}
          </SettingRow>
        )}

      </View>
    </View>
  );
}

interface SettingRowProps {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  isEnabled: boolean;
  lockIcon?: boolean;
  children: React.ReactNode;
}

function SettingRow({ icon, label, isEnabled, lockIcon, children }: SettingRowProps) {
  return (
    <View className="space-y-3">
      <View className="flex-row items-center">
        <Ionicons name={icon} size={20} color="#6B7280" />
        <Text className={cn(
          "text-base font-medium ml-3 flex-1",
          isEnabled ? "text-gray-900" : "text-gray-500"
        )}>
          {label}
        </Text>
        {lockIcon && (
          <Ionicons name="lock-closed" size={16} color="#9CA3AF" />
        )}
      </View>
      <View className={cn(isEnabled ? "" : "opacity-50")}>
        {children}
      </View>
    </View>
  );
}