import React from "react";
import { Platform } from "react-native";
import AdminDesktopDashboardFull from "../AdminDesktopDashboardFull";
import AdminMobileScreen from "../mobile/AdminMobileScreen";
import { useDeviceInfo } from "../../utils/deviceDetection";

// AdminApp provides appropriate admin interface based on platform
export default function AdminApp() {
  const deviceInfo = useDeviceInfo();
  const isWeb = Platform.OS === "web";
  const isMobile = Platform.OS === "ios" || Platform.OS === "android";
  const isDesktop = isWeb && typeof navigator !== "undefined" && !/Mobile|Android|iP(ad|hone)/i.test(navigator.userAgent);
  const isKiosk = typeof window !== "undefined" && window.innerWidth >= 1024 && window.innerHeight <= 800;

  // Mobile gets mobile admin interface
  if (isMobile || deviceInfo.isMobile) {
    return <AdminMobileScreen />;
  }

  // Desktop/Web gets FULL desktop interface with all features
  return (
    <AdminDesktopDashboardFull 
      onSwitchToCustomer={() => {
        // In kiosk mode, this would switch to customer interface
        console.log("Switch to customer interface requested");
      }}
    />
  );
}