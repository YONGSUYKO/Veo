import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, ScrollView, ActivityIndicator } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { emailRetrievalService, EmailUpload } from '../services/emailRetrievalService';
import { cn } from '../utils/cn';

interface EmailUploadScreenProps {
  onBack: () => void;
  onFilesRetrieved: (upload: EmailUpload) => void;
}

export default function EmailUploadScreen({ onBack, onFilesRetrieved }: EmailUploadScreenProps) {
  const insets = useSafeAreaInsets();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showInstructions, setShowInstructions] = useState(false);

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleRetrieveFiles = async () => {
    if (!email.trim()) {
      setError('Please enter your email address');
      return;
    }

    if (!validateEmail(email)) {
      setError('Please enter a valid email address');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const upload = await emailRetrievalService.retrieveFilesByEmail(email);
      
      if (upload) {
        onFilesRetrieved(upload);
      } else {
        setError('No files found for this email address. Please make sure you sent your files to ' + emailRetrievalService.getBusinessEmail());
      }
    } catch (err) {
      setError('Failed to retrieve files. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView className="flex-1 bg-white">
      <View style={{ paddingTop: insets.top + 20 }} className="px-6 pb-8">
        
        {/* Header */}
        <View className="flex-row items-center mb-8">
          <Pressable 
            className="w-10 h-10 bg-gray-100 rounded-full items-center justify-center mr-4"
            onPress={onBack}
          >
            <Ionicons name="arrow-back" size={20} color="#374151" />
          </Pressable>
          <View className="flex-1">
            <Text className="text-2xl font-bold text-gray-900">
              Email Upload
            </Text>
            <Text className="text-gray-600 mt-1">
              Retrieve files sent via email
            </Text>
          </View>
        </View>

        {/* Instructions Card */}
        <View className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
          <View className="flex-row items-start">
            <View className="w-8 h-8 bg-blue-500 rounded-full items-center justify-center mr-3 mt-1">
              <Ionicons name="mail" size={16} color="white" />
            </View>
            <View className="flex-1">
              <Text className="text-blue-900 font-semibold mb-2">
                How to Upload via Email
              </Text>
              <Pressable onPress={() => setShowInstructions(!showInstructions)}>
                <Text className="text-blue-700 text-sm underline">
                  {showInstructions ? 'Hide instructions' : 'Show instructions'}
                </Text>
              </Pressable>
            </View>
          </View>
          
          {showInstructions && (
            <View className="mt-4 pl-11">
              <Text className="text-blue-800 text-sm leading-relaxed mb-3">
                1. Send an email to: {emailRetrievalService.getBusinessEmail()}
              </Text>
              <Text className="text-blue-800 text-sm leading-relaxed mb-3">
                2. Attach your files (PDF, Word, PowerPoint, Images)
              </Text>
              <Text className="text-blue-800 text-sm leading-relaxed mb-3">
                3. Use the same email address below to retrieve your files
              </Text>
              <Text className="text-blue-800 text-sm leading-relaxed">
                4. Your files will be automatically processed with default settings
              </Text>
            </View>
          )}
        </View>

        {/* Business Email Display */}
        <View className="bg-gray-50 rounded-xl p-4 mb-6">
          <Text className="text-gray-700 text-sm mb-2">Send your files to:</Text>
          <View className="flex-row items-center">
            <Text className="text-lg font-mono font-semibold text-gray-900 flex-1">
              {emailRetrievalService.getBusinessEmail()}
            </Text>
            <Pressable className="ml-2 p-2">
              <Ionicons name="copy" size={20} color="#6B7280" />
            </Pressable>
          </View>
        </View>

        {/* Email Input */}
        <View className="mb-6">
          <Text className="text-base font-semibold text-gray-900 mb-3">
            Enter Your Email Address
          </Text>
          <Text className="text-sm text-gray-600 mb-4">
            Use the same email address you sent the files from
          </Text>
          
          <View className="relative">
            <TextInput
              className="bg-gray-50 border border-gray-200 rounded-xl px-4 py-4 text-base text-gray-900"
              placeholder="your.email@example.com"
              placeholderTextColor="#9CA3AF"
              value={email}
              onChangeText={(text) => {
                setEmail(text);
                setError('');
              }}
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
              editable={!loading}
            />
            <View className="absolute right-4 top-4">
              <Ionicons name="mail" size={20} color="#9CA3AF" />
            </View>
          </View>
          
          {error ? (
            <Text className="text-red-500 text-sm mt-2">{error}</Text>
          ) : null}
        </View>

        {/* Retrieve Button */}
        <Pressable
          className={cn(
            "rounded-xl py-4 px-6 items-center mb-6",
            loading || !email.trim() 
              ? "bg-gray-300" 
              : "bg-blue-500 active:bg-blue-600"
          )}
          onPress={handleRetrieveFiles}
          disabled={loading || !email.trim()}
        >
          {loading ? (
            <View className="flex-row items-center">
              <ActivityIndicator size="small" color="white" />
              <Text className="text-white font-semibold ml-2">
                Retrieving Files...
              </Text>
            </View>
          ) : (
            <Text className="text-white font-semibold text-base">
              Retrieve My Files
            </Text>
          )}
        </Pressable>

        {/* Features */}
        <View className="space-y-4">
          <Text className="text-lg font-semibold text-gray-900 mb-2">
            Email Upload Features
          </Text>
          
          <FeatureItem
            icon="checkmark-circle"
            title="Automatic Processing"
            description="Files are processed with optimal default settings"
          />
          
          <FeatureItem
            icon="flash"
            title="Instant Pricing"
            description="Get pricing immediately based on file analysis"
          />
          
          <FeatureItem
            icon="shield-checkmark"
            title="Secure Transfer"
            description="Your files are handled securely and privately"
          />
          
          <FeatureItem
            icon="document-text"
            title="Multiple Formats"
            description="Supports PDF, Word, PowerPoint, and image files"
          />
        </View>

        {/* Alternative Options */}
        <View className="mt-8 pt-6 border-t border-gray-200">
          <Text className="text-base font-semibold text-gray-900 mb-4">
            Other Upload Options
          </Text>
          
          <Pressable 
            className="flex-row items-center py-3 px-4 bg-gray-50 rounded-xl"
            onPress={onBack}
          >
            <Ionicons name="cloud-upload" size={24} color="#6B7280" />
            <View className="flex-1 ml-3">
              <Text className="font-medium text-gray-900">Direct Upload</Text>
              <Text className="text-sm text-gray-600">Upload files directly from your device</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
          </Pressable>
        </View>

      </View>
    </ScrollView>
  );
}

function FeatureItem({ icon, title, description }: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  description: string;
}) {
  return (
    <View className="flex-row items-start">
      <View className="w-8 h-8 bg-green-100 rounded-full items-center justify-center mr-3 mt-1">
        <Ionicons name={icon} size={16} color="#10B981" />
      </View>
      <View className="flex-1">
        <Text className="font-medium text-gray-900 mb-1">{title}</Text>
        <Text className="text-sm text-gray-600">{description}</Text>
      </View>
    </View>
  );
}