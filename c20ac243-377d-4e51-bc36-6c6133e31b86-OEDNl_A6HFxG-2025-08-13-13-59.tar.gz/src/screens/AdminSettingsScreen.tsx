import React from 'react';
import { View, Text, Pressable, ScrollView, Switch } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';
import { useNewAppStore } from '../state/newAppStore';
import { cn } from '../utils/cn';

interface AdminSettingsScreenProps {
  onBack: () => void;
}

export default function AdminSettingsScreen({ onBack }: AdminSettingsScreenProps) {
  const insets = useSafeAreaInsets();
  const { currentUser } = useAuthStore();
  const { systemSettings, setSystemSettings } = useNewAppStore();

  // Only allow access to admin users
  if (currentUser?.role !== 'admin') {
    return (
      <View className="flex-1 bg-white items-center justify-center px-8">
        <Ionicons name="shield-checkmark" size={64} color="#EF4444" />
        <Text className="text-xl font-bold text-gray-900 mt-4 mb-2">
          Access Denied
        </Text>
        <Text className="text-gray-600 text-center">
          You need administrator privileges to access this page.
        </Text>
        <Pressable 
          className="bg-blue-500 px-6 py-3 rounded-lg mt-6"
          onPress={onBack}
        >
          <Text className="text-white font-semibold">Go Back</Text>
        </Pressable>
      </View>
    );
  }

  const updateSetting = (key: string, value: any) => {
    setSystemSettings({ [key]: value });
  };

  return (
    <View className="flex-1 bg-white">
      <View style={{ paddingTop: insets.top }} className="px-4 flex-1">
        
        {/* Header */}
        <View className="flex-row items-center mb-6 pt-4">
          <Pressable onPress={onBack} className="mr-4">
            <Ionicons name="arrow-back" size={24} color="#374151" />
          </Pressable>
          <View className="flex-1">
            <Text className="text-2xl font-bold text-gray-900">
              System Settings
            </Text>
            <Text className="text-sm text-gray-600 mt-1">
              Configure customer print options
            </Text>
          </View>
        </View>

        <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
          
          {/* Customer Control Settings */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 mb-4">
              Customer Print Controls
            </Text>
            <Text className="text-gray-600 mb-6 leading-relaxed">
              Toggle which print settings customers can modify. When disabled, customers will use default values only.
            </Text>
            
            <View className="space-y-4">
              <SettingToggle
                icon="color-palette"
                title="Allow Color Mode Toggle"
                description="Let customers choose between auto, color, and black & white printing"
                value={systemSettings.allowColorToggle}
                onValueChange={(value) => updateSetting('allowColorToggle', value)}
              />
              
              <SettingToggle
                icon="copy"
                title="Allow Page Sidedness Toggle"
                description="Let customers choose between single and double-sided printing"
                value={systemSettings.allowSidednessToggle}
                onValueChange={(value) => updateSetting('allowSidednessToggle', value)}
              />
              
              <SettingToggle
                icon="phone-portrait"
                title="Allow Orientation Toggle"
                description="Let customers choose between portrait and landscape orientation"
                value={systemSettings.allowOrientationToggle}
                onValueChange={(value) => updateSetting('allowOrientationToggle', value)}
              />
              
              <SettingToggle
                icon="duplicate"
                title="Allow Copies Adjustment"
                description="Let customers adjust the number of copies"
                value={systemSettings.allowCopiesToggle}
                onValueChange={(value) => updateSetting('allowCopiesToggle', value)}
              />
            </View>
          </View>

          {/* Limits and Defaults */}
          <View className="mb-6">
            <Text className="text-lg font-semibold text-gray-900 mb-4">
              Limits & Defaults
            </Text>
            
            <View className="bg-gray-50 rounded-xl p-6 space-y-4">
              <View className="flex-row items-center justify-between">
                <View className="flex-1">
                  <Text className="font-medium text-gray-900">Maximum Copies</Text>
                  <Text className="text-sm text-gray-600">Per file limit for customers</Text>
                </View>
                <Text className="text-lg font-bold text-gray-900">
                  {systemSettings.maxCopies}
                </Text>
              </View>
              
              <View className="flex-row items-center justify-between">
                <View className="flex-1">
                  <Text className="font-medium text-gray-900">Delivery Fee</Text>
                  <Text className="text-sm text-gray-600">Standard delivery charge</Text>
                </View>
                <Text className="text-lg font-bold text-gray-900">
                  ₱{(systemSettings.deliveryFee / 100).toFixed(2)}
                </Text>
              </View>
              
              <View className="h-px bg-gray-200 my-3" />
              
              <View className="space-y-3">
                <Text className="font-medium text-gray-900">Default Settings</Text>
                
                <View className="grid grid-cols-2 gap-4">
                  <View>
                    <Text className="text-xs text-gray-500 uppercase tracking-wide mb-1">Default Sizes</Text>
                    <Text className="font-medium text-gray-900">Doc: {systemSettings.defaultDocumentPaperSize} | Photo: {systemSettings.defaultPhotoPaperSize}</Text>
                  </View>
                  <View>
                    <Text className="text-xs text-gray-500 uppercase tracking-wide mb-1">Page Color</Text>
                    <Text className="font-medium text-gray-900 capitalize">{systemSettings.defaultPageColor}</Text>
                  </View>
                  <View>
                    <Text className="text-xs text-gray-500 uppercase tracking-wide mb-1">Sidedness</Text>
                    <Text className="font-medium text-gray-900 capitalize">{systemSettings.defaultPageSidedness}</Text>
                  </View>
                  <View>
                    <Text className="text-xs text-gray-500 uppercase tracking-wide mb-1">Orientation</Text>
                    <Text className="font-medium text-gray-900 capitalize">{systemSettings.defaultPageOrientation}</Text>
                  </View>
                </View>
              </View>
            </View>
          </View>

          {/* Quick Actions */}
          <View className="mb-8">
            <Text className="text-lg font-semibold text-gray-900 mb-4">
              Quick Actions
            </Text>
            
            <View className="space-y-3">
              <ActionButton
                icon="checkmark-circle"
                title="Enable All Customer Controls"
                description="Allow customers to modify all print settings"
                color="bg-green-500"
                onPress={() => {
                  setSystemSettings({
                    allowColorToggle: true,
                    allowSidednessToggle: true,
                    allowOrientationToggle: true,
                    allowCopiesToggle: true,
                  });
                }}
              />
              
              <ActionButton
                icon="close-circle"
                title="Disable All Customer Controls"
                description="Lock all settings to default values"
                color="bg-red-500"
                onPress={() => {
                  setSystemSettings({
                    allowColorToggle: false,
                    allowSidednessToggle: false,
                    allowOrientationToggle: false,
                    allowCopiesToggle: false,
                  });
                }}
              />
            </View>
          </View>

        </ScrollView>

      </View>
    </View>
  );
}

interface SettingToggleProps {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  description: string;
  value: boolean;
  onValueChange: (value: boolean) => void;
}

function SettingToggle({ icon, title, description, value, onValueChange }: SettingToggleProps) {
  return (
    <View className="bg-white border border-gray-200 rounded-xl p-4">
      <View className="flex-row items-start">
        <View className={cn(
          "w-10 h-10 rounded-lg items-center justify-center mr-4 mt-1",
          value ? "bg-blue-100" : "bg-gray-100"
        )}>
          <Ionicons 
            name={icon} 
            size={20} 
            color={value ? "#3B82F6" : "#6B7280"} 
          />
        </View>
        
        <View className="flex-1 mr-4">
          <Text className="text-base font-semibold text-gray-900 mb-1">
            {title}
          </Text>
          <Text className="text-sm text-gray-600 leading-relaxed">
            {description}
          </Text>
        </View>
        
        <Switch
          value={value}
          onValueChange={onValueChange}
          trackColor={{ false: '#D1D5DB', true: '#3B82F6' }}
          thumbColor={value ? '#FFFFFF' : '#FFFFFF'}
        />
      </View>
    </View>
  );
}

interface ActionButtonProps {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  description: string;
  color: string;
  onPress: () => void;
}

function ActionButton({ icon, title, description, color, onPress }: ActionButtonProps) {
  return (
    <Pressable 
      className="bg-white border border-gray-200 rounded-xl p-4 active:bg-gray-50"
      onPress={onPress}
    >
      <View className="flex-row items-center">
        <View className={cn("w-12 h-12 rounded-xl items-center justify-center mr-4", color)}>
          <Ionicons name={icon} size={24} color="white" />
        </View>
        
        <View className="flex-1">
          <Text className="text-base font-semibold text-gray-900 mb-1">
            {title}
          </Text>
          <Text className="text-sm text-gray-600">
            {description}
          </Text>
        </View>
        
        <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
      </View>
    </Pressable>
  );
}