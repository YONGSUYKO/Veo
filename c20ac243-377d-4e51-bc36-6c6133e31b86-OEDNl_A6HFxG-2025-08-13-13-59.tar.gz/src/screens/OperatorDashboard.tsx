import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, ScrollView, RefreshControl, Alert, Modal } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';
import { useNewAppStore } from '../state/newAppStore';
import { newApiClient } from '../api/newPisoAPI';
import { cn } from '../utils/cn';

interface OperatorDashboardProps {
  onSwitchToCustomer: () => void;
}

export default function OperatorDashboard({ onSwitchToCustomer }: OperatorDashboardProps) {
  const insets = useSafeAreaInsets();
  const { currentUser, logout } = useAuthStore();
  const { printJobs, setPrintJobs, updatePrintJob } = useNewAppStore();
  const [refreshing, setRefreshing] = useState(false);
  const [selectedJob, setSelectedJob] = useState<any>(null);
  const [showJobDetails, setShowJobDetails] = useState(false);
  const [operatorStatus, setOperatorStatus] = useState<'active' | 'break' | 'offline'>('active');

  useEffect(() => {
    loadJobs();
  }, []);

  const loadJobs = async () => {
    try {
      const jobs = await newApiClient.getPrintJobs();
      setPrintJobs(jobs);
    } catch (error) {
      console.error('Failed to load jobs:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadJobs();
    setRefreshing(false);
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 12) return 'Good Morning';
    if (hour >= 12 && hour < 17) return 'Good Afternoon';
    if (hour >= 17 && hour < 21) return 'Good Evening';
    return 'Good Night';
  };

  const handleJobStatusUpdate = async (jobId: string, newStatus: string) => {
    try {
      await newApiClient.updatePrintJobStatus(jobId, newStatus as any);
      updatePrintJob(jobId, { status: newStatus as any });
      
      Alert.alert(
        'Status Updated',
        `Job #${jobId.slice(-6)} has been marked as ${newStatus}`,
        [{ text: 'OK' }]
      );
      
      if (selectedJob?.id === jobId) {
        setSelectedJob({ ...selectedJob, status: newStatus });
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to update job status');
    }
  };

  const queueJobs = printJobs.filter(job => job.status === 'queue');
  const ongoingJobs = printJobs.filter(job => job.status === 'ongoing');
  const readyJobs = printJobs.filter(job => job.status === 'ready');
  const todayJobs = printJobs.filter(job => {
    const jobDate = job.createdAt instanceof Date ? job.createdAt : new Date(job.createdAt);
    const today = new Date();
    return jobDate.toISOString().split('T')[0] === today.toISOString().split('T')[0];
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return { icon: 'checkmark-circle' as const, color: '#10B981' };
      case 'break': return { icon: 'pause-circle' as const, color: '#F59E0B' };
      case 'offline': return { icon: 'close-circle' as const, color: '#EF4444' };
      default: return { icon: 'ellipse' as const, color: '#6B7280' };
    }
  };

  const statusDisplay = getStatusIcon(operatorStatus);

  return (
    <View className="flex-1 bg-white">
      <ScrollView
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        <View style={{ paddingTop: insets.top + 20 }} className="px-6 pb-8">
          
          {/* Header */}
          <View className="flex-row items-center justify-between mb-8">
            <View className="flex-1">
              <Text className="text-3xl font-bold text-gray-900 mb-2">
                {getGreeting()}, {currentUser?.name}!
              </Text>
              <Text className="text-lg text-gray-600">
                Ready to serve customers today
              </Text>
            </View>
            
            <View className="flex-row space-x-3">
              <Pressable 
                className="w-12 h-12 bg-blue-500 rounded-full items-center justify-center"
                onPress={onSwitchToCustomer}
              >
                <Ionicons name="person" size={24} color="white" />
              </Pressable>
              
              <Pressable 
                className="w-12 h-12 bg-gray-100 rounded-full items-center justify-center"
                onPress={() => {
                  Alert.alert(
                    'Logout',
                    'Are you sure you want to logout?',
                    [
                      { text: 'Cancel', style: 'cancel' },
                      { text: 'Logout', onPress: logout, style: 'destructive' },
                    ]
                  );
                }}
              >
                <Ionicons name="log-out" size={24} color="#374151" />
              </Pressable>
            </View>
          </View>

          {/* Status Control */}
          <View className="bg-white rounded-xl p-6 border border-gray-200 mb-8">
            <View className="flex-row items-center justify-between mb-4">
              <Text className="text-lg font-semibold text-gray-900">
                Operator Status
              </Text>
              <View className="flex-row items-center">
                <Ionicons 
                  name={statusDisplay.icon} 
                  size={20} 
                  color={statusDisplay.color} 
                />
                <Text className={cn(
                  "ml-2 font-medium capitalize",
                  operatorStatus === 'active' ? 'text-green-700' :
                  operatorStatus === 'break' ? 'text-orange-700' : 'text-red-700'
                )}>
                  {operatorStatus}
                </Text>
              </View>
            </View>
            
            <View className="flex-row space-x-3">
              <StatusButton
                title="Active"
                selected={operatorStatus === 'active'}
                color="bg-green-500"
                onPress={() => setOperatorStatus('active')}
              />
              <StatusButton
                title="Break"
                selected={operatorStatus === 'break'}
                color="bg-orange-500"
                onPress={() => setOperatorStatus('break')}
              />
              <StatusButton
                title="Offline"
                selected={operatorStatus === 'offline'}
                color="bg-red-500"
                onPress={() => setOperatorStatus('offline')}
              />
            </View>
          </View>

          {/* Job Metrics */}
          <View className="grid grid-cols-2 gap-4 mb-8">
            <MetricCard
              icon="time"
              title="In Queue"
              value={queueJobs.length.toString()}
              color="bg-orange-500"
            />
            <MetricCard
              icon="print"
              title="Ongoing"
              value={ongoingJobs.length.toString()}
              color="bg-blue-500"
            />
            <MetricCard
              icon="checkmark-circle"
              title="Ready"
              value={readyJobs.length.toString()}
              color="bg-green-500"
            />
            <MetricCard
              icon="calendar"
              title="Today"
              value={todayJobs.length.toString()}
              color="bg-purple-500"
            />
          </View>

          {/* Quick Actions */}
          <View className="mb-8">
            <Text className="text-xl font-semibold text-gray-900 mb-4">
              Quick Actions
            </Text>
            
            <View className="grid grid-cols-2 gap-4">
              <ActionCard
                icon="add"
                title="New Order"
                description="Help customer place order"
                color="bg-blue-600"
                onPress={onSwitchToCustomer}
              />
              <ActionCard
                icon="scan"
                title="Scan Code"
                description="Process order by QR code"
                color="bg-green-600"
                onPress={() => Alert.alert('QR Scanner', 'QR code scanner coming soon!')}
              />
              <ActionCard
                icon="cash"
                title="Process Payment"
                description="Handle cash payments"
                color="bg-emerald-600"
                onPress={() => Alert.alert('Payment', 'Payment processing interface coming soon!')}
              />
              <ActionCard
                icon="notifications"
                title="Notify Customer"
                description="Send job notifications"
                color="bg-indigo-600"
                onPress={() => Alert.alert('Notifications', 'Customer notification system coming soon!')}
              />
            </View>
          </View>

          {/* Job Queue */}
          <View className="mb-8">
            <Text className="text-xl font-semibold text-gray-900 mb-4">
              Print Queue ({queueJobs.length})
            </Text>
            
            {queueJobs.length > 0 ? (
              <View className="space-y-3">
                {queueJobs.map((job) => (
                  <OperatorJobCard
                    key={job.id}
                    job={job}
                    onStatusUpdate={handleJobStatusUpdate}
                    onViewDetails={() => {
                      setSelectedJob(job);
                      setShowJobDetails(true);
                    }}
                  />
                ))}
              </View>
            ) : (
              <View className="bg-gray-50 rounded-xl p-8 items-center">
                <Ionicons name="checkmark-circle" size={48} color="#10B981" />
                <Text className="text-gray-500 mt-2">Queue is empty!</Text>
                <Text className="text-gray-400 text-sm">All caught up with orders</Text>
              </View>
            )}
          </View>

          {/* Ongoing Jobs */}
          {ongoingJobs.length > 0 && (
            <View className="mb-8">
              <Text className="text-xl font-semibold text-gray-900 mb-4">
                Currently Printing ({ongoingJobs.length})
              </Text>
              
              <View className="space-y-3">
                {ongoingJobs.map((job) => (
                  <OperatorJobCard
                    key={job.id}
                    job={job}
                    onStatusUpdate={handleJobStatusUpdate}
                    onViewDetails={() => {
                      setSelectedJob(job);
                      setShowJobDetails(true);
                    }}
                    showProgress
                  />
                ))}
              </View>
            </View>
          )}

          {/* Ready for Pickup/Delivery */}
          {readyJobs.length > 0 && (
            <View>
              <Text className="text-xl font-semibold text-gray-900 mb-4">
                Ready for {readyJobs[0]?.fulfillmentMethod === 'pickup' ? 'Pickup' : 'Delivery'} ({readyJobs.length})
              </Text>
              
              <View className="space-y-3">
                {readyJobs.map((job) => (
                  <OperatorJobCard
                    key={job.id}
                    job={job}
                    onStatusUpdate={handleJobStatusUpdate}
                    onViewDetails={() => {
                      setSelectedJob(job);
                      setShowJobDetails(true);
                    }}
                  />
                ))}
              </View>
            </View>
          )}

        </View>
      </ScrollView>

      {/* Job Details Modal */}
      <Modal visible={showJobDetails} animationType="slide" presentationStyle="pageSheet">
        <JobDetailsModal
          job={selectedJob}
          onClose={() => setShowJobDetails(false)}
          onStatusUpdate={handleJobStatusUpdate}
        />
      </Modal>

    </View>
  );
}

interface MetricCardProps {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  value: string;
  color: string;
}

function MetricCard({ icon, title, value, color }: MetricCardProps) {
  return (
    <View className="bg-white rounded-xl p-4 border border-gray-200">
      <View className="flex-row items-center justify-between mb-3">
        <View className={cn("w-10 h-10 rounded-lg items-center justify-center", color)}>
          <Ionicons name={icon} size={20} color="white" />
        </View>
        <Text className="text-2xl font-bold text-gray-900">{value}</Text>
      </View>
      <Text className="text-sm text-gray-600">{title}</Text>
    </View>
  );
}

interface ActionCardProps {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  description: string;
  color: string;
  onPress: () => void;
}

function ActionCard({ icon, title, description, color, onPress }: ActionCardProps) {
  return (
    <Pressable 
      className="bg-white rounded-xl p-4 border border-gray-200 active:bg-gray-50"
      onPress={onPress}
    >
      <View className={cn("w-12 h-12 rounded-xl items-center justify-center mb-3", color)}>
        <Ionicons name={icon} size={24} color="white" />
      </View>
      <Text className="text-base font-semibold text-gray-900 mb-1">
        {title}
      </Text>
      <Text className="text-sm text-gray-600 leading-relaxed">
        {description}
      </Text>
    </Pressable>
  );
}

function StatusButton({ title, selected, color, onPress }: {
  title: string;
  selected: boolean;
  color: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      className={cn(
        "flex-1 py-2 rounded-lg",
        selected ? color : "bg-gray-100"
      )}
    >
      <Text className={cn(
        "text-center font-medium",
        selected ? "text-white" : "text-gray-600"
      )}>
        {title}
      </Text>
    </Pressable>
  );
}

function OperatorJobCard({ job, onStatusUpdate, onViewDetails, showProgress }: {
  job: any;
  onStatusUpdate: (id: string, status: string) => void;
  onViewDetails: () => void;
  showProgress?: boolean;
}) {
  const getNextStatus = (currentStatus: string) => {
    switch (currentStatus) {
      case 'queue': return 'ongoing';
      case 'ongoing': return 'ready';
      case 'ready': return 'completed';
      default: return null;
    }
  };

  const nextStatus = getNextStatus(job.status);

  return (
    <View className="bg-white rounded-xl p-4 border border-gray-200">
      <View className="flex-row items-start justify-between mb-3">
        <View className="flex-1">
          <View className="flex-row items-center mb-2">
            <Text className="text-lg font-semibold text-gray-900">
              #{job.id.slice(-6)}
            </Text>
            <View className="ml-2 px-2 py-1 bg-blue-100 rounded-full">
              <Text className="text-blue-800 text-xs font-medium">
                {job.status.toUpperCase()}
              </Text>
            </View>
          </View>
          
          <Text className="text-gray-700 font-medium mb-1">
            {job.customerInfo.name}
          </Text>
          
          <View className="flex-row items-center space-x-4 mb-2">
            <Text className="text-sm text-gray-600">
              {job.files.length} file(s)
            </Text>
            <Text className="text-sm text-gray-600">
              {job.fulfillmentMethod}
            </Text>
          </View>
          
          <Text className="text-lg font-bold text-gray-900">
            ₱{(job.totalPrice / 100).toFixed(2)}
          </Text>
        </View>
      </View>

      {showProgress && (
        <View className="mb-3">
          <View className="h-2 bg-gray-200 rounded-full">
            <View className="h-2 bg-blue-500 rounded-full" style={{ width: '60%' }} />
          </View>
          <Text className="text-xs text-gray-500 mt-1">Printing in progress...</Text>
        </View>
      )}

      <View className="flex-row space-x-3">
        <Pressable 
          className="flex-1 bg-gray-100 py-2 rounded-lg"
          onPress={onViewDetails}
        >
          <Text className="text-gray-700 text-center font-medium">
            View Details
          </Text>
        </Pressable>
        
        {nextStatus && (
          <Pressable 
            className="flex-1 bg-blue-500 py-2 rounded-lg"
            onPress={() => onStatusUpdate(job.id, nextStatus)}
          >
            <Text className="text-white text-center font-medium">
              Mark {nextStatus === 'ongoing' ? 'Start' : nextStatus === 'ready' ? 'Ready' : 'Complete'}
            </Text>
          </Pressable>
        )}
      </View>
    </View>
  );
}

function JobDetailsModal({ job, onClose, onStatusUpdate }: {
  job: any;
  onClose: () => void;
  onStatusUpdate: (id: string, status: string) => void;
}) {
  if (!job) return null;

  return (
    <View className="flex-1 bg-white">
      <View className="flex-row items-center justify-between p-4 border-b border-gray-200">
        <Pressable onPress={onClose}>
          <Text className="text-blue-500 text-lg">Close</Text>
        </Pressable>
        <Text className="text-lg font-semibold">Job #{job.id.slice(-6)}</Text>
        <View className="w-12" />
      </View>

      <ScrollView className="flex-1 p-4">
        <View className="space-y-6">
          
          {/* Customer Information */}
          <View>
            <Text className="text-lg font-semibold text-gray-900 mb-3">
              Customer Information
            </Text>
            <View className="bg-gray-50 rounded-xl p-4 space-y-2">
              <View className="flex-row justify-between">
                <Text className="text-gray-600">Name</Text>
                <Text className="font-medium">{job.customerInfo.name}</Text>
              </View>
              {job.customerInfo.phone && (
                <View className="flex-row justify-between">
                  <Text className="text-gray-600">Phone</Text>
                  <Text className="font-medium">{job.customerInfo.phone}</Text>
                </View>
              )}
              {job.customerInfo.email && (
                <View className="flex-row justify-between">
                  <Text className="text-gray-600">Email</Text>
                  <Text className="font-medium">{job.customerInfo.email}</Text>
                </View>
              )}
            </View>
          </View>

          {/* Files */}
          <View>
            <Text className="text-lg font-semibold text-gray-900 mb-3">
              Files ({job.files.length})
            </Text>
            <View className="space-y-2">
              {job.files.map((file: any, index: number) => (
                <View key={index} className="bg-gray-50 rounded-xl p-4">
                  <Text className="font-medium text-gray-900 mb-2">{file.name}</Text>
                  <View className="grid grid-cols-2 gap-4">
                    <View>
                      <Text className="text-xs text-gray-500 mb-1">PAGES</Text>
                      <Text className="font-medium">{file.pages}</Text>
                    </View>
                    <View>
                      <Text className="text-xs text-gray-500 mb-1">COPIES</Text>
                      <Text className="font-medium">{file.copies}</Text>
                    </View>
                    <View>
                      <Text className="text-xs text-gray-500 mb-1">SIZE</Text>
                      <Text className="font-medium">{file.paperSize}</Text>
                    </View>
                    <View>
                      <Text className="text-xs text-gray-500 mb-1">COLOR</Text>
                      <Text className="font-medium capitalize">{file.pageColor}</Text>
                    </View>
                  </View>
                </View>
              ))}
            </View>
          </View>

          {/* Order Summary */}
          <View>
            <Text className="text-lg font-semibold text-gray-900 mb-3">
              Order Summary
            </Text>
            <View className="bg-gray-50 rounded-xl p-4 space-y-2">
              <View className="flex-row justify-between">
                <Text className="text-gray-600">Payment Method</Text>
                <Text className="font-medium uppercase">{job.paymentMethod}</Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-gray-600">Fulfillment</Text>
                <Text className="font-medium capitalize">{job.fulfillmentMethod}</Text>
              </View>
              {job.loyaltyPointsUsed > 0 && (
                <View className="flex-row justify-between">
                  <Text className="text-gray-600">Points Used</Text>
                  <Text className="font-medium">{job.loyaltyPointsUsed} pts</Text>
                </View>
              )}
              <View className="h-px bg-gray-200 my-2" />
              <View className="flex-row justify-between">
                <Text className="text-lg font-bold">Total</Text>
                <Text className="text-lg font-bold">₱{(job.totalPrice / 100).toFixed(2)}</Text>
              </View>
            </View>
          </View>

        </View>
      </ScrollView>
    </View>
  );
}