import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, ScrollView, RefreshControl, Alert, FlatList } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../../state/authStore';
import { useNewAppStore } from '../../state/newAppStore';
import { newApiClient } from '../../api/newPisoAPI';

export default function OperatorMobileScreen() {
  const insets = useSafeAreaInsets();
  const { currentUser, logout } = useAuthStore();
  const { printJobs, setPrintJobs } = useNewAppStore();
  const [refreshing, setRefreshing] = useState(false);
  const [currentView, setCurrentView] = useState<'queue' | 'active' | 'today'>('queue');

  useEffect(() => {
    loadJobs();
    // Auto-refresh every 15 seconds for real-time updates
    const interval = setInterval(loadJobs, 15000);
    return () => clearInterval(interval);
  }, []);

  const loadJobs = async () => {
    try {
      const jobs = await newApiClient.getPrintJobs();
      setPrintJobs(jobs);
    } catch (error) {
      console.error('Failed to load jobs:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadJobs();
    setRefreshing(false);
  };

  const updateJobStatus = async (jobId: string, newStatus: 'queue' | 'ongoing' | 'ready' | 'completed' | 'failed') => {
    try {
      await newApiClient.updatePrintJobStatus(jobId, newStatus);
      await loadJobs();
      
      const statusMessages = {
        ongoing: 'Job started printing',
        ready: 'Job marked as ready for pickup',
        completed: 'Job marked as completed',
        failed: 'Job marked as failed'
      };
      
      Alert.alert('Status Updated', statusMessages[newStatus as keyof typeof statusMessages] || 'Status updated');
    } catch (error) {
      Alert.alert('Error', 'Failed to update job status');
    }
  };

  const getJobsByView = () => {
    const safeJobs = Array.isArray(printJobs) ? printJobs : [];
    
    switch (currentView) {
      case 'queue':
        return safeJobs.filter(job => job.status === 'queue');
      case 'active':
        return safeJobs.filter(job => job.status === 'ongoing');
      case 'today':
        const today = new Date().toISOString().split('T')[0];
        return safeJobs.filter(job => {
          try {
            const jobDate = job.createdAt instanceof Date ? job.createdAt : new Date(job.createdAt);
            return jobDate.toISOString().split('T')[0] === today;
          } catch (error) {
            return false;
          }
        });
      default:
        return [];
    }
  };

  const getShiftStats = () => {
    // Ensure printJobs is an array and handle potential data issues
    const safeJobs = Array.isArray(printJobs) ? printJobs : [];
    const today = new Date().toISOString().split('T')[0];
    
    const todayJobs = safeJobs.filter(job => {
      try {
        // Handle different date formats
        const jobDate = job.createdAt instanceof Date ? job.createdAt : new Date(job.createdAt);
        return jobDate.toISOString().split('T')[0] === today;
      } catch (error) {
        // If date parsing fails, exclude the job
        return false;
      }
    });
    
    return {
      todayJobs: todayJobs.length,
      completedJobs: todayJobs.filter(job => job.status === 'completed').length,
      queueLength: safeJobs.filter(job => job.status === 'queue').length,
      activeJobs: safeJobs.filter(job => job.status === 'ongoing').length,
      revenue: todayJobs.reduce((sum, job) => sum + (job.totalPrice || 0), 0),
    };
  };

  const stats = getShiftStats();
  const filteredJobs = getJobsByView();

  const tabs = [
    { id: 'queue', label: 'Queue', count: stats.queueLength, color: '#F59E0B' },
    { id: 'active', label: 'Active', count: stats.activeJobs, color: '#3B82F6' },
    { id: 'today', label: 'Today', count: stats.todayJobs, color: '#10B981' },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: '#F9FAFB' }}>
      {/* Header */}
      <View style={{ 
        backgroundColor: '#10B981',
        paddingTop: insets.top + 16,
        paddingHorizontal: 24,
        paddingBottom: 24,
        borderBottomLeftRadius: 16,
        borderBottomRightRadius: 16
      }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <View style={{ 
              width: 40, 
              height: 40, 
              backgroundColor: 'rgba(255,255,255,0.2)', 
              borderRadius: 20, 
              alignItems: 'center', 
              justifyContent: 'center',
              marginRight: 12
            }}>
              <Ionicons name="construct" size={20} color="white" />
            </View>
            <View>
              <Text style={{ fontSize: 18, fontWeight: 'bold', color: 'white' }}>
                Operator Mobile
              </Text>
              <Text style={{ fontSize: 12, color: 'rgba(255,255,255,0.8)' }}>
                Job Management
              </Text>
            </View>
          </View>
          
          <Pressable 
            onPress={() => Alert.alert('Logout', 'End your shift?', [
              { text: 'Cancel' },
              { text: 'Logout', onPress: logout }
            ])}
            style={{ 
              width: 36, 
              height: 36, 
              backgroundColor: 'rgba(255,255,255,0.2)', 
              borderRadius: 18, 
              alignItems: 'center', 
              justifyContent: 'center' 
            }}
          >
            <Ionicons name="log-out" size={18} color="white" />
          </Pressable>
        </View>

        <Text style={{ fontSize: 20, fontWeight: 'bold', color: 'white', marginBottom: 4 }}>
          Hello, {currentUser?.name?.split(' ')[0]}!
        </Text>
        <Text style={{ fontSize: 14, color: 'rgba(255,255,255,0.9)' }}>
          Mobile operator dashboard for job management
        </Text>
      </View>

      {/* Shift Summary */}
      <View style={{ 
        backgroundColor: 'white',
        marginHorizontal: 16,
        marginTop: -12,
        borderRadius: 16,
        padding: 20,
        elevation: 4,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
        marginBottom: 16
      }}>
        <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#111827', marginBottom: 12 }}>
          Today's Summary
        </Text>
        
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <View style={{ alignItems: 'center' }}>
            <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#10B981', marginBottom: 2 }}>
              {stats.completedJobs}
            </Text>
            <Text style={{ fontSize: 12, color: '#6B7280' }}>Completed</Text>
          </View>
          <View style={{ alignItems: 'center' }}>
            <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#F59E0B', marginBottom: 2 }}>
              {stats.queueLength}
            </Text>
            <Text style={{ fontSize: 12, color: '#6B7280' }}>In Queue</Text>
          </View>
          <View style={{ alignItems: 'center' }}>
            <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#3B82F6', marginBottom: 2 }}>
              {stats.activeJobs}
            </Text>
            <Text style={{ fontSize: 12, color: '#6B7280' }}>Active</Text>
          </View>
          <View style={{ alignItems: 'center' }}>
            <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#8B5CF6', marginBottom: 2 }}>
              ₱{(stats.revenue / 100).toFixed(0)}
            </Text>
            <Text style={{ fontSize: 12, color: '#6B7280' }}>Revenue</Text>
          </View>
        </View>
      </View>

      {/* Tab Navigation */}
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: 16 }}
        style={{ maxHeight: 60, marginBottom: 16 }}
      >
        {tabs.map((tab) => (
          <Pressable
            key={tab.id}
            onPress={() => setCurrentView(tab.id as any)}
            style={({ pressed }) => [
              {
                paddingHorizontal: 20,
                paddingVertical: 12,
                marginHorizontal: 4,
                borderRadius: 20,
                backgroundColor: currentView === tab.id ? tab.color : 'white',
                borderWidth: 2,
                borderColor: currentView === tab.id ? tab.color : '#E5E7EB',
                flexDirection: 'row',
                alignItems: 'center',
                elevation: currentView === tab.id ? 2 : 0,
              },
              pressed && { opacity: 0.8 }
            ]}
          >
            <Text style={{ 
              fontSize: 14, 
              fontWeight: '600',
              color: currentView === tab.id ? 'white' : '#374151',
              marginRight: tab.count > 0 ? 8 : 0
            }}>
              {tab.label}
            </Text>
            {tab.count > 0 && (
              <View style={{ 
                backgroundColor: currentView === tab.id ? 'rgba(255,255,255,0.3)' : tab.color + '20',
                borderRadius: 10,
                minWidth: 20,
                height: 20,
                alignItems: 'center',
                justifyContent: 'center',
                paddingHorizontal: 6
              }}>
                <Text style={{ 
                  fontSize: 12, 
                  fontWeight: 'bold',
                  color: currentView === tab.id ? 'white' : tab.color
                }}>
                  {tab.count}
                </Text>
              </View>
            )}
          </Pressable>
        ))}
      </ScrollView>

      {/* Job List */}
      <View style={{ flex: 1, paddingHorizontal: 16 }}>
        <FlatList
          data={filteredJobs}
          keyExtractor={(item) => item.id}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
          renderItem={({ item: job }) => (
            <MobileJobCard 
              job={job}
              view={currentView}
              onUpdateStatus={updateJobStatus}
            />
          )}
          ListEmptyComponent={
            <EmptyJobsState view={currentView} onRefresh={onRefresh} />
          }
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 20 }}
        />
      </View>

      {/* Limited Features Notice */}
      <View style={{ 
        backgroundColor: '#FEF3C7',
        marginHorizontal: 16,
        borderRadius: 12,
        padding: 16,
        marginBottom: 16
      }}>
        <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
          <Ionicons name="information-circle" size={18} color="#F59E0B" />
          <View style={{ flex: 1, marginLeft: 8 }}>
            <Text style={{ fontSize: 12, fontWeight: '600', color: '#92400E', marginBottom: 2 }}>
              Mobile Operator Features
            </Text>
            <Text style={{ fontSize: 11, color: '#B45309', lineHeight: 16 }}>
              Essential job management on mobile. For advanced features like customer service tools and detailed reporting, use the desktop interface.
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
}

// Helper Components
function MobileJobCard({ job, view, onUpdateStatus }: {
  job: any;
  view: 'queue' | 'active' | 'today';
  onUpdateStatus: (jobId: string, status: any) => void;
}) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return '#10B981';
      case 'ongoing': return '#3B82F6';
      case 'ready': return '#8B5CF6';
      case 'queue': return '#F59E0B';
      case 'failed': return '#DC2626';
      default: return '#6B7280';
    }
  };

  const getNextAction = () => {
    switch (job.status) {
      case 'queue':
        return { label: 'Start Print', action: () => onUpdateStatus(job.id, 'ongoing'), color: '#10B981' };
      case 'ongoing':
        return { label: 'Mark Ready', action: () => onUpdateStatus(job.id, 'ready'), color: '#8B5CF6' };
      case 'ready':
        return { label: 'Complete', action: () => onUpdateStatus(job.id, 'completed'), color: '#059669' };
      default:
        return null;
    }
  };

  const nextAction = getNextAction();

  return (
    <View style={{ 
      backgroundColor: 'white',
      borderRadius: 16,
      padding: 16,
      marginBottom: 12,
      elevation: 2,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.05,
      shadowRadius: 4,
    }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 16, fontWeight: '600', color: '#111827', marginBottom: 4 }}>
            #{job.id.slice(-6)}
          </Text>
          <Text style={{ fontSize: 14, color: '#374151', marginBottom: 2 }}>
            {job.customerInfo.name}
          </Text>
          <Text style={{ fontSize: 12, color: '#6B7280' }}>
            {job.files.length} file(s) • ₱{(job.totalPrice / 100).toFixed(2)}
          </Text>
        </View>
        
        <View style={{ 
          paddingHorizontal: 10, 
          paddingVertical: 6, 
          borderRadius: 12, 
          backgroundColor: getStatusColor(job.status) + '20'
        }}>
          <Text style={{ 
            fontSize: 12, 
            fontWeight: '600', 
            color: getStatusColor(job.status),
            textTransform: 'capitalize'
          }}>
            {job.status}
          </Text>
        </View>
      </View>

      <View style={{ 
        backgroundColor: '#F9FAFB',
        borderRadius: 8,
        padding: 12,
        marginBottom: 12
      }}>
        <Text style={{ fontSize: 12, color: '#6B7280', marginBottom: 4 }}>
          Order Details:
        </Text>
        <Text style={{ fontSize: 12, color: '#374151' }}>
          Payment: {job.paymentMethod.toUpperCase()} • {job.fulfillmentMethod}
        </Text>
        <Text style={{ fontSize: 11, color: '#9CA3AF', marginTop: 4 }}>
          Created: {new Date(job.createdAt).toLocaleTimeString()}
        </Text>
      </View>

      <View style={{ flexDirection: 'row', gap: 8 }}>
        {nextAction && (
          <Pressable
            onPress={nextAction.action}
            style={{ 
              flex: 1,
              backgroundColor: nextAction.color,
              paddingVertical: 12,
              borderRadius: 8,
              alignItems: 'center'
            }}
          >
            <Text style={{ color: 'white', fontSize: 14, fontWeight: '600' }}>
              {nextAction.label}
            </Text>
          </Pressable>
        )}
        
        {job.status === 'ongoing' && (
          <Pressable
            onPress={() => 
              Alert.alert(
                'Mark as Failed',
                'Are you sure this job failed to print correctly?',
                [
                  { text: 'Cancel' },
                  { text: 'Mark Failed', onPress: () => onUpdateStatus(job.id, 'failed'), style: 'destructive' }
                ]
              )
            }
            style={{ 
              backgroundColor: '#DC2626',
              paddingVertical: 12,
              paddingHorizontal: 16,
              borderRadius: 8,
              alignItems: 'center'
            }}
          >
            <Text style={{ color: 'white', fontSize: 14, fontWeight: '600' }}>
              Failed
            </Text>
          </Pressable>
        )}
      </View>
    </View>
  );
}

function EmptyJobsState({ view, onRefresh }: {
  view: 'queue' | 'active' | 'today';
  onRefresh: () => void;
}) {
  const getEmptyMessage = () => {
    switch (view) {
      case 'queue': return 'No jobs in queue';
      case 'active': return 'No active print jobs';
      case 'today': return 'No jobs processed today';
      default: return 'No jobs found';
    }
  };

  const getEmptyDescription = () => {
    switch (view) {
      case 'queue': return 'All caught up! New jobs will appear here.';
      case 'active': return 'Start printing jobs from the queue.';
      case 'today': return 'Jobs processed today will show here.';
      default: return 'Jobs will appear here when available.';
    }
  };

  return (
    <View style={{ 
      backgroundColor: 'white',
      borderRadius: 16,
      padding: 32,
      alignItems: 'center',
      marginTop: 32,
      elevation: 2,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.05,
      shadowRadius: 4,
    }}>
      <View style={{ 
        width: 64, 
        height: 64, 
        backgroundColor: '#F3F4F6',
        borderRadius: 32, 
        alignItems: 'center', 
        justifyContent: 'center',
        marginBottom: 16
      }}>
        <Ionicons 
          name={view === 'queue' ? 'list-outline' : view === 'active' ? 'print-outline' : 'time-outline'} 
          size={32} 
          color="#9CA3AF" 
        />
      </View>
      
      <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#111827', marginBottom: 8, textAlign: 'center' }}>
        {getEmptyMessage()}
      </Text>
      <Text style={{ fontSize: 14, color: '#6B7280', textAlign: 'center', lineHeight: 20, marginBottom: 20 }}>
        {getEmptyDescription()}
      </Text>
      
      <Pressable
        onPress={onRefresh}
        style={{ 
          backgroundColor: '#10B981',
          paddingVertical: 10,
          paddingHorizontal: 20,
          borderRadius: 8
        }}
      >
        <Text style={{ fontSize: 14, fontWeight: '600', color: 'white' }}>
          Refresh
        </Text>
      </Pressable>
    </View>
  );
}