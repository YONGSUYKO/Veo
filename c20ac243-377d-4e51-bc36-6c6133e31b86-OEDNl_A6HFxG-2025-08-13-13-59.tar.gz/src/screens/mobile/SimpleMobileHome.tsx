import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

interface SimpleMobileHomeProps {
  onServiceSelect: (service: 'document' | 'scan' | 'photo') => void;
}

export default function SimpleMobileHome({ onServiceSelect }: SimpleMobileHomeProps) {
  return (
    <View style={{ flex: 1, backgroundColor: '#F9FAFB', padding: 20 }}>
      <View style={{ alignItems: 'center', marginBottom: 40, marginTop: 60 }}>
        <View style={{ 
          width: 80, 
          height: 80, 
          backgroundColor: '#3B82F6', 
          borderRadius: 20, 
          alignItems: 'center', 
          justifyContent: 'center',
          marginBottom: 16
        }}>
          <Ionicons name="print" size={40} color="white" />
        </View>
        <Text style={{ fontSize: 28, fontWeight: 'bold', color: '#111827', textAlign: 'center' }}>
          PISO Print Express
        </Text>
        <Text style={{ fontSize: 16, color: '#6B7280', textAlign: 'center', marginTop: 8 }}>
          Professional Mobile Printing
        </Text>
      </View>

      <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#111827', marginBottom: 24, textAlign: 'center' }}>
        Choose Your Service
      </Text>

      <ServiceButton
        icon="document-text"
        title="Documents"
        description="Print PDF, Word, Excel files"
        color="#3B82F6"
        onPress={() => onServiceSelect('document')}
      />

      <ServiceButton
        icon="scan"
        title="Scan & Print"
        description="AI-powered document scanning"
        color="#10B981"
        onPress={() => onServiceSelect('scan')}
      />

      <ServiceButton
        icon="camera"
        title="Photos"
        description="Professional photo printing"
        color="#8B5CF6"
        onPress={() => onServiceSelect('photo')}
      />
    </View>
  );
}

function ServiceButton({ icon, title, description, color, onPress }: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  description: string;
  color: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        backgroundColor: pressed ? '#F3F4F6' : 'white',
        borderRadius: 16,
        padding: 20,
        marginBottom: 16,
        elevation: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        flexDirection: 'row',
        alignItems: 'center',
      })}
    >
      <View style={{ 
        width: 56, 
        height: 56, 
        backgroundColor: color + '20',
        borderRadius: 16, 
        alignItems: 'center', 
        justifyContent: 'center',
        marginRight: 16
      }}>
        <Ionicons name={icon} size={28} color={color} />
      </View>
      
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#111827', marginBottom: 4 }}>
          {title}
        </Text>
        <Text style={{ fontSize: 14, color: '#6B7280' }}>
          {description}
        </Text>
      </View>
      
      <Ionicons name="chevron-forward" size={24} color="#9CA3AF" />
    </Pressable>
  );
}