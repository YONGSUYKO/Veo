import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, ScrollView, RefreshControl, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../../state/authStore';
import { useNewAppStore } from '../../state/newAppStore';
import { newApiClient } from '../../api/newPisoAPI';
import OrderProgressTracker from '../../components/OrderProgressTracker';

export default function CustomerOrdersScreen() {
  const insets = useSafeAreaInsets();
  const { currentUser } = useAuthStore();
  const { printJobs, setPrintJobs } = useNewAppStore();
  const [refreshing, setRefreshing] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'queue' | 'ongoing' | 'ready' | 'completed'>('all');
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [showProgressTracker, setShowProgressTracker] = useState(false);

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = async () => {
    try {
      const jobs = await newApiClient.getPrintJobs();
      setPrintJobs(jobs);
    } catch (error) {
      console.error('Failed to load orders:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadOrders();
    setRefreshing(false);
  };

  const userOrders = printJobs.filter(job => 
    currentUser?.id && job.customerId === currentUser.id
  );

  const filteredOrders = selectedFilter === 'all' 
    ? userOrders 
    : userOrders.filter(order => order.status === selectedFilter);

  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'queue':
        return { color: '#F59E0B', bg: '#FEF3C7', label: 'In Queue', icon: 'time' };
      case 'ongoing':
        return { color: '#3B82F6', bg: '#DBEAFE', label: 'Printing', icon: 'print' };
      case 'ready':
        return { color: '#8B5CF6', bg: '#EDE9FE', label: 'Ready', icon: 'checkmark-circle' };
      case 'completed':
        return { color: '#10B981', bg: '#D1FAE5', label: 'Completed', icon: 'checkmark-done' };
      case 'failed':
        return { color: '#DC2626', bg: '#FEE2E2', label: 'Failed', icon: 'close-circle' };
      default:
        return { color: '#6B7280', bg: '#F3F4F6', label: 'Unknown', icon: 'help-circle' };
    }
  };

  const getOrderSummary = () => {
    return {
      total: userOrders.length,
      queue: userOrders.filter(o => o.status === 'queue').length,
      ongoing: userOrders.filter(o => o.status === 'ongoing').length,
      ready: userOrders.filter(o => o.status === 'ready').length,
      completed: userOrders.filter(o => o.status === 'completed').length,
    };
  };

  const summary = getOrderSummary();

  const handleReorder = (order: any) => {
    Alert.alert(
      'Reorder',
      `Would you like to reorder "${order.files[0]?.name}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Reorder', onPress: () => {
          Alert.alert('Reorder', 'Reorder functionality will redirect to the upload screen with the same settings.');
        }}
      ]
    );
  };

  const handleTrackOrder = (order: any) => {
    setSelectedOrder(order);
    setShowProgressTracker(true);
  };

  const filters = [
    { id: 'all', label: 'All', count: summary.total },
    { id: 'queue', label: 'Queue', count: summary.queue },
    { id: 'ongoing', label: 'Printing', count: summary.ongoing },
    { id: 'ready', label: 'Ready', count: summary.ready },
    { id: 'completed', label: 'Completed', count: summary.completed },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: '#F9FAFB' }}>
      {/* Header */}
      <View style={{ 
        backgroundColor: 'white',
        paddingHorizontal: 24,
        paddingTop: 20,
        paddingBottom: 16,
        borderBottomWidth: 1,
        borderBottomColor: '#E5E7EB'
      }}>
        <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#111827', marginBottom: 8 }}>
          My Orders
        </Text>
        <Text style={{ fontSize: 16, color: '#6B7280' }}>
          Track your print jobs and order history
        </Text>
      </View>

      {/* Order Summary */}
      {summary.total > 0 && (
        <View style={{ 
          backgroundColor: 'white',
          margin: 16,
          borderRadius: 16,
          padding: 20,
          elevation: 2,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 1 },
          shadowOpacity: 0.05,
          shadowRadius: 4,
        }}>
          <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#111827', marginBottom: 16 }}>
            Order Summary
          </Text>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <SummaryItem label="Total Orders" value={summary.total} color="#6B7280" />
            <SummaryItem label="In Progress" value={summary.queue + summary.ongoing} color="#F59E0B" />
            <SummaryItem label="Ready" value={summary.ready} color="#8B5CF6" />
            <SummaryItem label="Completed" value={summary.completed} color="#10B981" />
          </View>
        </View>
      )}

      {/* Filter Tabs */}
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: 16 }}
        style={{ maxHeight: 60, marginBottom: 8 }}
      >
        {filters.map((filter) => (
          <Pressable
            key={filter.id}
            onPress={() => setSelectedFilter(filter.id as any)}
            style={({ pressed }) => [
              {
                paddingHorizontal: 16,
                paddingVertical: 8,
                marginHorizontal: 4,
                borderRadius: 20,
                backgroundColor: selectedFilter === filter.id ? '#3B82F6' : 'white',
                borderWidth: 1,
                borderColor: selectedFilter === filter.id ? '#3B82F6' : '#E5E7EB',
                flexDirection: 'row',
                alignItems: 'center',
              },
              pressed && { opacity: 0.8 }
            ]}
          >
            <Text style={{ 
              fontSize: 14, 
              fontWeight: '500',
              color: selectedFilter === filter.id ? 'white' : '#374151',
              marginRight: filter.count > 0 ? 6 : 0
            }}>
              {filter.label}
            </Text>
            {filter.count > 0 && (
              <View style={{ 
                backgroundColor: selectedFilter === filter.id ? 'rgba(255,255,255,0.3)' : '#F3F4F6',
                borderRadius: 10,
                minWidth: 20,
                height: 20,
                alignItems: 'center',
                justifyContent: 'center',
                paddingHorizontal: 6
              }}>
                <Text style={{ 
                  fontSize: 12, 
                  fontWeight: 'bold',
                  color: selectedFilter === filter.id ? 'white' : '#6B7280'
                }}>
                  {filter.count}
                </Text>
              </View>
            )}
          </Pressable>
        ))}
      </ScrollView>

      {/* Orders List */}
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 20 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        showsVerticalScrollIndicator={false}
      >
        {filteredOrders.length > 0 ? (
          filteredOrders.map((order) => (
            <OrderCard 
              key={order.id} 
              order={order}
              onTrack={() => handleTrackOrder(order)}
              onReorder={() => handleReorder(order)}
            />
          ))
        ) : (
          <EmptyState 
            filter={selectedFilter}
            onCreateOrder={() => {
              // This would typically navigate to the home screen or services
              Alert.alert('Create Order', 'Navigate to services to create a new print order!');
            }}
          />
        )}
      </ScrollView>

      {/* Order Progress Tracker Modal */}
      <OrderProgressTracker
        visible={showProgressTracker}
        onClose={() => setShowProgressTracker(false)}
        order={selectedOrder}
      />
    </View>
  );
}

// Helper Components
function SummaryItem({ label, value, color }: {
  label: string;
  value: number;
  color: string;
}) {
  return (
    <View style={{ alignItems: 'center' }}>
      <Text style={{ fontSize: 20, fontWeight: 'bold', color, marginBottom: 4 }}>
        {value}
      </Text>
      <Text style={{ fontSize: 12, color: '#6B7280' }}>
        {label}
      </Text>
    </View>
  );
}

function OrderCard({ order, onTrack, onReorder }: {
  order: any;
  onTrack: () => void;
  onReorder: () => void;
}) {
  const statusInfo = getStatusInfo(order.status);
  
  return (
    <View style={{ 
      backgroundColor: 'white',
      borderRadius: 16,
      padding: 20,
      marginBottom: 12,
      elevation: 2,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.05,
      shadowRadius: 4,
    }}>
      {/* Order Header */}
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
        <View>
          <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#111827', marginBottom: 4 }}>
            Order #{order.id.slice(-6)}
          </Text>
          <Text style={{ fontSize: 12, color: '#6B7280' }}>
            {new Date(order.createdAt).toLocaleDateString()} • {new Date(order.createdAt).toLocaleTimeString()}
          </Text>
        </View>
        
        <View style={{ 
          paddingHorizontal: 12, 
          paddingVertical: 6, 
          borderRadius: 16, 
          backgroundColor: statusInfo.bg,
          flexDirection: 'row',
          alignItems: 'center'
        }}>
          <Ionicons name={statusInfo.icon as any} size={14} color={statusInfo.color} />
          <Text style={{ 
            fontSize: 12, 
            fontWeight: '600', 
            color: statusInfo.color,
            marginLeft: 4
          }}>
            {statusInfo.label}
          </Text>
        </View>
      </View>
      
      {/* Order Details */}
      <View style={{ 
        backgroundColor: '#F9FAFB',
        borderRadius: 12,
        padding: 16,
        marginBottom: 16
      }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }}>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>Files:</Text>
          <Text style={{ fontSize: 14, fontWeight: '500', color: '#111827' }}>
            {order.files.length} file(s)
          </Text>
        </View>
        
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }}>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>Payment:</Text>
          <Text style={{ fontSize: 14, fontWeight: '500', color: '#111827' }}>
            {order.paymentMethod.toUpperCase()}
          </Text>
        </View>
        
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }}>
          <Text style={{ fontSize: 14, color: '#6B7280' }}>Fulfillment:</Text>
          <Text style={{ fontSize: 14, fontWeight: '500', color: '#111827' }}>
            {order.fulfillmentMethod}
          </Text>
        </View>
        
        <View style={{ 
          flexDirection: 'row', 
          justifyContent: 'space-between',
          paddingTop: 8,
          borderTopWidth: 1,
          borderTopColor: '#E5E7EB'
        }}>
          <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#111827' }}>Total:</Text>
          <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#111827' }}>
            ₱{(order.totalPrice / 100).toFixed(2)}
          </Text>
        </View>
      </View>
      
      {/* Action Buttons */}
      <View style={{ flexDirection: 'row', gap: 12 }}>
        <Pressable
          onPress={onTrack}
          style={{ 
            flex: 1,
            backgroundColor: '#F3F4F6',
            paddingVertical: 12,
            paddingHorizontal: 16,
            borderRadius: 12,
            alignItems: 'center'
          }}
        >
          <Text style={{ fontSize: 14, fontWeight: '600', color: '#374151' }}>
            Track Order
          </Text>
        </Pressable>
        
        {order.status === 'completed' && (
          <Pressable
            onPress={onReorder}
            style={{ 
              flex: 1,
              backgroundColor: '#3B82F6',
              paddingVertical: 12,
              paddingHorizontal: 16,
              borderRadius: 12,
              alignItems: 'center'
            }}
          >
            <Text style={{ fontSize: 14, fontWeight: '600', color: 'white' }}>
              Reorder
            </Text>
          </Pressable>
        )}
      </View>
    </View>
  );
}

function EmptyState({ filter, onCreateOrder }: {
  filter: string;
  onCreateOrder: () => void;
}) {
  const getEmptyMessage = () => {
    switch (filter) {
      case 'queue': return 'No jobs in queue';
      case 'ongoing': return 'No jobs currently printing';
      case 'ready': return 'No jobs ready for pickup';
      case 'completed': return 'No completed orders yet';
      default: return 'No orders yet';
    }
  };

  const getEmptyDescription = () => {
    switch (filter) {
      case 'queue': return 'Your future print jobs will appear here when queued.';
      case 'ongoing': return 'Jobs currently being printed will show up here.';
      case 'ready': return 'Finished jobs ready for pickup will be listed here.';
      case 'completed': return 'Your order history will appear here after completion.';
      default: return 'Start printing to see your orders here.';
    }
  };

  return (
    <View style={{ 
      backgroundColor: 'white',
      borderRadius: 16,
      padding: 48,
      alignItems: 'center',
      marginTop: 32,
      elevation: 2,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.05,
      shadowRadius: 4,
    }}>
      <View style={{ 
        width: 80, 
        height: 80, 
        backgroundColor: '#F3F4F6',
        borderRadius: 40, 
        alignItems: 'center', 
        justifyContent: 'center',
        marginBottom: 24
      }}>
        <Ionicons name="receipt-outline" size={36} color="#9CA3AF" />
      </View>
      
      <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#111827', marginBottom: 8 }}>
        {getEmptyMessage()}
      </Text>
      <Text style={{ fontSize: 14, color: '#6B7280', textAlign: 'center', lineHeight: 20, marginBottom: 24 }}>
        {getEmptyDescription()}
      </Text>
      
      {filter === 'all' && (
        <Pressable
          onPress={onCreateOrder}
          style={{ 
            backgroundColor: '#3B82F6',
            paddingVertical: 12,
            paddingHorizontal: 24,
            borderRadius: 12
          }}
        >
          <Text style={{ fontSize: 14, fontWeight: '600', color: 'white' }}>
            Create Your First Order
          </Text>
        </Pressable>
      )}
    </View>
  );
}

// Helper function moved outside component
function getStatusInfo(status: string) {
  switch (status) {
    case 'queue':
      return { color: '#F59E0B', bg: '#FEF3C7', label: 'In Queue', icon: 'time' };
    case 'ongoing':
      return { color: '#3B82F6', bg: '#DBEAFE', label: 'Printing', icon: 'print' };
    case 'ready':
      return { color: '#8B5CF6', bg: '#EDE9FE', label: 'Ready', icon: 'checkmark-circle' };
    case 'completed':
      return { color: '#10B981', bg: '#D1FAE5', label: 'Completed', icon: 'checkmark-done' };
    case 'failed':
      return { color: '#DC2626', bg: '#FEE2E2', label: 'Failed', icon: 'close-circle' };
    default:
      return { color: '#6B7280', bg: '#F3F4F6', label: 'Unknown', icon: 'help-circle' };
  }
}