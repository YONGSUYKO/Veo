import React, { useState } from 'react';
import { View, Text, Pressable, ScrollView, TextInput, Alert, Switch } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../../state/authStore';
import { useNewAppStore } from '../../state/newAppStore';
import ContactSupportModal from '../../components/ContactSupportModal';
import { smsService } from '../../services/smsService';
import UnifiedNotificationManager from '../../components/UnifiedNotificationManager';

export default function CustomerProfileScreen() {
  const insets = useSafeAreaInsets();
  const { currentUser, logout, login } = useAuthStore();
  const { printJobs } = useNewAppStore();
  const [isEditing, setIsEditing] = useState(false);
  const [notifications, setNotifications] = useState(true);
  const [emailUpdates, setEmailUpdates] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);
  const [showNotificationManager, setShowNotificationManager] = useState(false);
  const [editForm, setEditForm] = useState({
    name: currentUser?.name || '',
    email: currentUser?.email || '',
    phone: currentUser?.phone || '',
  });

  const userStats = {
    totalOrders: printJobs.filter(job => job.customerId === currentUser?.id).length,
    totalSpent: printJobs
      .filter(job => job.customerId === currentUser?.id)
      .reduce((sum, job) => sum + job.totalPrice, 0),
    loyaltyPoints: currentUser?.loyaltyPoints || 0,
  };

  const handleSaveProfile = () => {
    if (!editForm.name.trim()) {
      Alert.alert('Error', 'Please enter your name');
      return;
    }

    // Update the user profile
    login({
      ...currentUser!,
      name: editForm.name,
      email: editForm.email,
      phone: editForm.phone,
    });

    setIsEditing(false);
    Alert.alert('Success', 'Profile updated successfully!');
  };

  const handleLogout = () => {
    Alert.alert(
      'Sign Out',
      'Are you sure you want to sign out?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Sign Out', onPress: logout, style: 'destructive' },
      ]
    );
  };

  const isGuestUser = currentUser?.name === 'Guest User' || currentUser?.name === 'Mobile User';

  return (
    <View style={{ flex: 1, backgroundColor: '#F9FAFB' }}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Profile Header */}
        <View style={{ 
          backgroundColor: '#6B7280',
          paddingTop: 20,
          paddingHorizontal: 24,
          paddingBottom: 32,
          borderBottomLeftRadius: 24,
          borderBottomRightRadius: 24
        }}>
          <View style={{ alignItems: 'center' }}>
            <View style={{ 
              width: 80, 
              height: 80, 
              backgroundColor: 'rgba(255,255,255,0.2)',
              borderRadius: 40, 
              alignItems: 'center', 
              justifyContent: 'center',
              marginBottom: 16
            }}>
              <Ionicons 
                name={isGuestUser ? "person-outline" : "person"} 
                size={40} 
                color="white" 
              />
            </View>
            
            <Text style={{ fontSize: 24, fontWeight: 'bold', color: 'white', marginBottom: 8 }}>
              {currentUser?.name || 'User'}
            </Text>
            <Text style={{ fontSize: 16, color: 'rgba(255,255,255,0.8)' }}>
              {isGuestUser ? 'Guest Account' : 'PISO Print Customer'}
            </Text>
            
            {!isGuestUser && (
              <Pressable
                onPress={() => setIsEditing(!isEditing)}
                style={{ 
                  backgroundColor: 'rgba(255,255,255,0.2)',
                  paddingHorizontal: 16,
                  paddingVertical: 8,
                  borderRadius: 16,
                  marginTop: 16,
                  flexDirection: 'row',
                  alignItems: 'center'
                }}
              >
                <Ionicons name={isEditing ? "close" : "pencil"} size={16} color="white" />
                <Text style={{ color: 'white', fontSize: 14, fontWeight: '500', marginLeft: 6 }}>
                  {isEditing ? 'Cancel Edit' : 'Edit Profile'}
                </Text>
              </Pressable>
            )}
          </View>
        </View>

        {/* Stats Cards */}
        <View style={{ 
          flexDirection: 'row', 
          paddingHorizontal: 24, 
          marginTop: -16,
          marginBottom: 24,
          gap: 12
        }}>
          <StatCard
            icon="receipt"
            label="Orders"
            value={userStats.totalOrders.toString()}
            color="#3B82F6"
          />
          <StatCard
            icon="cash"
            label="Total Spent"
            value={`₱${(userStats.totalSpent / 100).toFixed(2)}`}
            color="#10B981"
          />
          <StatCard
            icon="star"
            label="Points"
            value={userStats.loyaltyPoints.toString()}
            color="#F59E0B"
          />
        </View>

        {/* Profile Information */}
        <View style={{ paddingHorizontal: 24, marginBottom: 24 }}>
          <View style={{ 
            backgroundColor: 'white',
            borderRadius: 16,
            padding: 20,
            elevation: 2,
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 1 },
            shadowOpacity: 0.05,
            shadowRadius: 4,
          }}>
            <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#111827', marginBottom: 16 }}>
              Profile Information
            </Text>

            {isGuestUser ? (
              <View style={{ alignItems: 'center', paddingVertical: 24 }}>
                <Ionicons name="person-add" size={48} color="#9CA3AF" />
                <Text style={{ fontSize: 16, fontWeight: '600', color: '#111827', marginTop: 16, marginBottom: 8 }}>
                  Create Your Account
                </Text>
                <Text style={{ fontSize: 14, color: '#6B7280', textAlign: 'center', marginBottom: 20 }}>
                  Sign up to track orders, earn points, and save your preferences
                </Text>
                <Pressable
                  style={{ 
                    backgroundColor: '#3B82F6',
                    paddingHorizontal: 24,
                    paddingVertical: 12,
                    borderRadius: 12
                  }}
                  onPress={() => Alert.alert('Sign Up', 'Account creation feature will be available soon!')}
                >
                  <Text style={{ color: 'white', fontSize: 14, fontWeight: '600' }}>
                    Create Account
                  </Text>
                </Pressable>
              </View>
            ) : (
              <>
                <ProfileField
                  label="Full Name"
                  value={isEditing ? editForm.name : currentUser?.name || ''}
                  isEditing={isEditing}
                  onChangeText={(text) => setEditForm(prev => ({ ...prev, name: text }))}
                  placeholder="Enter your name"
                />
                
                <ProfileField
                  label="Email Address"
                  value={isEditing ? editForm.email : currentUser?.email || ''}
                  isEditing={isEditing}
                  onChangeText={(text) => setEditForm(prev => ({ ...prev, email: text }))}
                  placeholder="Enter your email"
                  keyboardType="email-address"
                />
                
                <ProfileField
                  label="Phone Number"
                  value={isEditing ? editForm.phone : currentUser?.phone || ''}
                  isEditing={isEditing}
                  onChangeText={(text) => setEditForm(prev => ({ ...prev, phone: text }))}
                  placeholder="Enter your phone number"
                  keyboardType="phone-pad"
                  isLast={true}
                />
                
                {isEditing && (
                  <Pressable
                    onPress={handleSaveProfile}
                    style={{ 
                      backgroundColor: '#10B981',
                      paddingVertical: 12,
                      borderRadius: 12,
                      alignItems: 'center',
                      marginTop: 16
                    }}
                  >
                    <Text style={{ color: 'white', fontSize: 16, fontWeight: '600' }}>
                      Save Changes
                    </Text>
                  </Pressable>
                )}
              </>
            )}
          </View>
        </View>

        {/* Settings */}
        {!isGuestUser && (
          <View style={{ paddingHorizontal: 24, marginBottom: 24 }}>
            <View style={{ 
              backgroundColor: 'white',
              borderRadius: 16,
              padding: 20,
              elevation: 2,
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 1 },
              shadowOpacity: 0.05,
              shadowRadius: 4,
            }}>
              <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#111827', marginBottom: 16 }}>
                Preferences
              </Text>

              <Pressable
                onPress={() => setShowNotificationManager(true)}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  paddingHorizontal: 20,
                  paddingVertical: 16,
                  borderBottomWidth: 0,
                }}
              >
                <View style={{
                  width: 40,
                  height: 40,
                  borderRadius: 20,
                  backgroundColor: '#DBEAFE',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginRight: 12,
                }}>
                  <Ionicons name="notifications" size={20} color="#3B82F6" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 16, fontWeight: '600', color: '#111827', marginBottom: 2 }}>
                    Notification Settings
                  </Text>
                  <Text style={{ fontSize: 13, color: '#6B7280' }}>
                    Manage email, SMS, and push notifications
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
              </Pressable>
            </View>
          </View>
        )}

        {/* Quick Actions */}
        <View style={{ paddingHorizontal: 24, marginBottom: 32 }}>
          <View style={{ 
            backgroundColor: 'white',
            borderRadius: 16,
            overflow: 'hidden',
            elevation: 2,
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 1 },
            shadowOpacity: 0.05,
            shadowRadius: 4,
          }}>
            <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#111827', padding: 20, paddingBottom: 16 }}>
              Quick Actions
            </Text>

            <ActionRow
              icon="help-circle"
              label="Contact Support"
              description="Send message directly to owner"
              onPress={() => setShowContactModal(true)}
            />

            <ActionRow
              icon="chatbubble"
              label="Test SMS Service"
              description="Test SMS notifications"
              onPress={() => {
                if (currentUser?.phone) {
                  smsService.testSms(currentUser.phone);
                } else {
                  Alert.alert('No Phone Number', 'Please add your phone number to test SMS service');
                }
              }}
            />

            <ActionRow
              icon="document-text"
              label="Terms & Privacy"
              description="View our terms and privacy policy"
              onPress={() => Alert.alert('Legal', 'Terms of Service and Privacy Policy will be displayed here.')}
            />

            <ActionRow
              icon="star"
              label="Rate Our App"
              description="Help us improve with your feedback"
              onPress={() => Alert.alert('Rate App', 'Thank you for your feedback!')}
            />

            <ActionRow
              icon="log-out"
              label="Sign Out"
              description={isGuestUser ? "Switch to a different account" : "Sign out of your account"}
              onPress={handleLogout}
              isDestructive={!isGuestUser}
              isLast={true}
            />
          </View>
        </View>
      </ScrollView>

      {/* Unified Notification Manager Modal */}
      <UnifiedNotificationManager
        visible={showNotificationManager}
        onClose={() => setShowNotificationManager(false)}
      />

      {/* Contact Support Modal */}
      <ContactSupportModal
        visible={showContactModal}
        onClose={() => setShowContactModal(false)}
      />
    </View>
  );
}

// Helper Components
function StatCard({ icon, label, value, color }: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  value: string;
  color: string;
}) {
  return (
    <View style={{ 
      flex: 1,
      backgroundColor: 'white',
      borderRadius: 16,
      padding: 16,
      alignItems: 'center',
      elevation: 2,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.05,
      shadowRadius: 4,
    }}>
      <View style={{ 
        width: 40, 
        height: 40, 
        backgroundColor: color + '20',
        borderRadius: 20, 
        alignItems: 'center', 
        justifyContent: 'center',
        marginBottom: 8
      }}>
        <Ionicons name={icon} size={20} color={color} />
      </View>
      <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#111827', marginBottom: 4 }}>
        {value}
      </Text>
      <Text style={{ fontSize: 12, color: '#6B7280', textAlign: 'center' }}>
        {label}
      </Text>
    </View>
  );
}

function ProfileField({ label, value, isEditing, onChangeText, placeholder, keyboardType, isLast }: {
  label: string;
  value: string;
  isEditing: boolean;
  onChangeText?: (text: string) => void;
  placeholder?: string;
  keyboardType?: any;
  isLast?: boolean;
}) {
  return (
    <View style={{ 
      marginBottom: isLast ? 0 : 16,
      paddingBottom: isLast ? 0 : 16,
      borderBottomWidth: isLast ? 0 : 1,
      borderBottomColor: '#F3F4F6'
    }}>
      <Text style={{ fontSize: 14, fontWeight: '500', color: '#374151', marginBottom: 8 }}>
        {label}
      </Text>
      {isEditing ? (
        <TextInput
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          keyboardType={keyboardType}
          style={{ 
            backgroundColor: '#F9FAFB',
            borderWidth: 1,
            borderColor: '#E5E7EB',
            borderRadius: 8,
            paddingHorizontal: 12,
            paddingVertical: 10,
            fontSize: 16,
            color: '#111827'
          }}
        />
      ) : (
        <Text style={{ fontSize: 16, color: '#111827' }}>
          {value || 'Not provided'}
        </Text>
      )}
    </View>
  );
}

function SettingRow({ icon, label, description, value, onValueChange, isLast }: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  description: string;
  value: boolean;
  onValueChange: (value: boolean) => void;
  isLast?: boolean;
}) {
  return (
    <View style={{ 
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 12,
      borderBottomWidth: isLast ? 0 : 1,
      borderBottomColor: '#F3F4F6'
    }}>
      <View style={{ 
        width: 40, 
        height: 40, 
        backgroundColor: '#F3F4F6',
        borderRadius: 20, 
        alignItems: 'center', 
        justifyContent: 'center',
        marginRight: 16
      }}>
        <Ionicons name={icon} size={20} color="#6B7280" />
      </View>
      
      <View style={{ flex: 1, marginRight: 16 }}>
        <Text style={{ fontSize: 16, fontWeight: '500', color: '#111827', marginBottom: 2 }}>
          {label}
        </Text>
        <Text style={{ fontSize: 13, color: '#6B7280' }}>
          {description}
        </Text>
      </View>
      
      <Switch
        value={value}
        onValueChange={onValueChange}
        trackColor={{ false: '#E5E7EB', true: '#93C5FD' }}
        thumbColor={value ? '#3B82F6' : '#F3F4F6'}
      />
    </View>
  );
}

function ActionRow({ icon, label, description, onPress, isDestructive, isLast }: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  description: string;
  onPress: () => void;
  isDestructive?: boolean;
  isLast?: boolean;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        {
          flexDirection: 'row',
          alignItems: 'center',
          paddingHorizontal: 20,
          paddingVertical: 16,
          borderBottomWidth: isLast ? 0 : 1,
          borderBottomColor: '#F3F4F6',
          backgroundColor: pressed ? '#F9FAFB' : 'transparent'
        }
      ]}
    >
      <View style={{ 
        width: 40, 
        height: 40, 
        backgroundColor: isDestructive ? '#FEE2E2' : '#F3F4F6',
        borderRadius: 20, 
        alignItems: 'center', 
        justifyContent: 'center',
        marginRight: 16
      }}>
        <Ionicons name={icon} size={20} color={isDestructive ? '#DC2626' : '#6B7280'} />
      </View>
      
      <View style={{ flex: 1, marginRight: 16 }}>
        <Text style={{ 
          fontSize: 16, 
          fontWeight: '500', 
          color: isDestructive ? '#DC2626' : '#111827', 
          marginBottom: 2 
        }}>
          {label}
        </Text>
        <Text style={{ fontSize: 13, color: '#6B7280' }}>
          {description}
        </Text>
      </View>
      
      <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
    </Pressable>
  );
}

// Add ContactSupportModal at the end of the component
// (Modal integration happens in the JSX above)