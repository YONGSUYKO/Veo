import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, ScrollView, RefreshControl, Alert, Switch } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../../state/authStore';
import { useNewAppStore } from '../../state/newAppStore';
import { newApiClient } from '../../api/newPisoAPI';

export default function AdminMobileScreen() {
  const insets = useSafeAreaInsets();
  const { currentUser, logout } = useAuthStore();
  const { printJobs, setPrintJobs, systemSettings } = useNewAppStore();
  const [refreshing, setRefreshing] = useState(false);
  const [systemStatus, setSystemStatus] = useState({
    online: true,
    queueEnabled: true,
    emergencyMode: false,
  });

  useEffect(() => {
    loadData();
    // Auto-refresh every 30 seconds for mobile monitoring
    const interval = setInterval(loadData, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    try {
      const jobs = await newApiClient.getPrintJobs();
      setPrintJobs(jobs);
    } catch (error) {
      console.error('Failed to load data:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const getBusinessStats = () => {
    // Ensure printJobs is an array and handle potential data issues
    const safeJobs = Array.isArray(printJobs) ? printJobs : [];
    const today = new Date().toISOString().split('T')[0];
    
    const todayJobs = safeJobs.filter(job => {
      try {
        // Handle different date formats
        const jobDate = job.createdAt instanceof Date ? job.createdAt : new Date(job.createdAt);
        return jobDate.toISOString().split('T')[0] === today;
      } catch (error) {
        // If date parsing fails, exclude the job
        return false;
      }
    });
    
    return {
      totalJobs: safeJobs.length,
      todayJobs: todayJobs.length,
      todayRevenue: todayJobs.reduce((sum, job) => sum + (job.totalPrice || 0), 0),
      queueLength: safeJobs.filter(job => job.status === 'queue').length,
      ongoingJobs: safeJobs.filter(job => job.status === 'ongoing').length,
      pendingIssues: safeJobs.filter(job => job.status === 'failed').length,
    };
  };

  const stats = getBusinessStats();

  const handleEmergencyStop = () => {
    Alert.alert(
      'Emergency Stop',
      'This will pause all printing operations and alert operators. Are you sure?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Emergency Stop', 
          style: 'destructive',
          onPress: () => {
            setSystemStatus(prev => ({ ...prev, emergencyMode: true, queueEnabled: false }));
            Alert.alert('System Alert', 'Emergency stop activated. All operators have been notified.');
          }
        },
      ]
    );
  };

  const handleResumeOperations = () => {
    setSystemStatus(prev => ({ ...prev, emergencyMode: false, queueEnabled: true }));
    Alert.alert('System Resumed', 'Normal operations have been restored.');
  };

  const handleQuickPricing = () => {
    Alert.alert(
      'Quick Pricing Update',
      'Document B&W: ₱1.00\nDocument Color: ₱2.00\nPhoto 4R: ₱2.00\n\nFor detailed pricing management, use the desktop interface.',
      [{ text: 'OK' }]
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#F9FAFB' }}>
      {/* Header */}
      <View style={{ 
        backgroundColor: '#DC2626',
        paddingTop: insets.top + 16,
        paddingHorizontal: 24,
        paddingBottom: 24,
        borderBottomLeftRadius: 16,
        borderBottomRightRadius: 16
      }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <View style={{ 
              width: 40, 
              height: 40, 
              backgroundColor: 'rgba(255,255,255,0.2)', 
              borderRadius: 20, 
              alignItems: 'center', 
              justifyContent: 'center',
              marginRight: 12
            }}>
              <Ionicons name="shield" size={20} color="white" />
            </View>
            <View>
              <Text style={{ fontSize: 18, fontWeight: 'bold', color: 'white' }}>
                Admin Mobile
              </Text>
              <Text style={{ fontSize: 12, color: 'rgba(255,255,255,0.8)' }}>
                System Monitoring
              </Text>
            </View>
          </View>
          
          <Pressable 
            onPress={() => Alert.alert('Logout', 'Return to login screen?', [
              { text: 'Cancel' },
              { text: 'Logout', onPress: logout }
            ])}
            style={{ 
              width: 36, 
              height: 36, 
              backgroundColor: 'rgba(255,255,255,0.2)', 
              borderRadius: 18, 
              alignItems: 'center', 
              justifyContent: 'center' 
            }}
          >
            <Ionicons name="log-out" size={18} color="white" />
          </Pressable>
        </View>

        <Text style={{ fontSize: 20, fontWeight: 'bold', color: 'white', marginBottom: 4 }}>
          Hello, {currentUser?.name?.split(' ')[0]}!
        </Text>
        <Text style={{ fontSize: 14, color: 'rgba(255,255,255,0.9)' }}>
          Mobile admin dashboard for system monitoring
        </Text>
      </View>

      <ScrollView 
        style={{ flex: 1 }}
        contentContainerStyle={{ padding: 16 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        showsVerticalScrollIndicator={false}
      >
        {/* System Status */}
        <View style={{ 
          backgroundColor: systemStatus.emergencyMode ? '#FEE2E2' : '#ECFDF5',
          borderRadius: 16,
          padding: 20,
          marginBottom: 16,
          borderLeftWidth: 4,
          borderLeftColor: systemStatus.emergencyMode ? '#DC2626' : '#10B981'
        }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <Text style={{ 
              fontSize: 16, 
              fontWeight: 'bold', 
              color: systemStatus.emergencyMode ? '#DC2626' : '#065F46' 
            }}>
              System Status
            </Text>
            <View style={{ 
              paddingHorizontal: 8, 
              paddingVertical: 4, 
              borderRadius: 12, 
              backgroundColor: systemStatus.emergencyMode ? '#DC2626' : '#10B981'
            }}>
              <Text style={{ fontSize: 12, fontWeight: 'bold', color: 'white' }}>
                {systemStatus.emergencyMode ? 'EMERGENCY' : 'ONLINE'}
              </Text>
            </View>
          </View>

          {systemStatus.emergencyMode ? (
            <View>
              <Text style={{ fontSize: 14, color: '#991B1B', marginBottom: 12 }}>
                System is in emergency mode. All operations are paused.
              </Text>
              <Pressable 
                onPress={handleResumeOperations}
                style={{ 
                  backgroundColor: '#10B981', 
                  paddingHorizontal: 16, 
                  paddingVertical: 8, 
                  borderRadius: 8,
                  alignSelf: 'flex-start'
                }}
              >
                <Text style={{ color: 'white', fontSize: 14, fontWeight: '600' }}>
                  Resume Operations
                </Text>
              </Pressable>
            </View>
          ) : (
            <View>
              <Text style={{ fontSize: 14, color: '#065F46', marginBottom: 12 }}>
                All systems operational. Queue processing normally.
              </Text>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                <Text style={{ fontSize: 14, color: '#047857' }}>
                  Queue Processing
                </Text>
                <Switch
                  value={systemStatus.queueEnabled}
                  onValueChange={(value) => {
                    setSystemStatus(prev => ({ ...prev, queueEnabled: value }));
                    Alert.alert('Queue Status', value ? 'Queue processing enabled' : 'Queue processing paused');
                  }}
                  trackColor={{ false: '#E5E7EB', true: '#86EFAC' }}
                  thumbColor={systemStatus.queueEnabled ? '#10B981' : '#F3F4F6'}
                />
              </View>
            </View>
          )}
        </View>

        {/* Quick Stats */}
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 16 }}>
          <StatCard
            icon="print"
            label="Today's Jobs"
            value={stats.todayJobs.toString()}
            color="#3B82F6"
          />
          <StatCard
            icon="cash"
            label="Today's Revenue"
            value={`₱${(stats.todayRevenue / 100).toFixed(0)}`}
            color="#10B981"
          />
          <StatCard
            icon="time"
            label="Queue Length"
            value={stats.queueLength.toString()}
            color="#F59E0B"
          />
          <StatCard
            icon="warning"
            label="Issues"
            value={stats.pendingIssues.toString()}
            color={stats.pendingIssues > 0 ? "#DC2626" : "#6B7280"}
          />
        </View>

        {/* Quick Actions */}
        <View style={{ 
          backgroundColor: 'white',
          borderRadius: 16,
          padding: 20,
          marginBottom: 16,
          elevation: 2,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 1 },
          shadowOpacity: 0.05,
          shadowRadius: 4,
        }}>
          <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#111827', marginBottom: 16 }}>
            Quick Actions
          </Text>

          <View style={{ gap: 12 }}>
            <ActionButton
              icon="pause-circle"
              label="Emergency Stop"
              description="Pause all operations"
              color="#DC2626"
              onPress={handleEmergencyStop}
              disabled={systemStatus.emergencyMode}
            />
            <ActionButton
              icon="pricetag"
              label="Quick Pricing"
              description="View current rates"
              color="#8B5CF6"
              onPress={handleQuickPricing}
            />
            <ActionButton
              icon="refresh"
              label="Refresh Data"
              description="Update system status"
              color="#3B82F6"
              onPress={onRefresh}
            />
          </View>
        </View>

        {/* Recent Activity */}
        <View style={{ 
          backgroundColor: 'white',
          borderRadius: 16,
          padding: 20,
          marginBottom: 16,
          elevation: 2,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 1 },
          shadowOpacity: 0.05,
          shadowRadius: 4,
        }}>
          <Text style={{ fontSize: 16, fontWeight: 'bold', color: '#111827', marginBottom: 16 }}>
            Recent Activity
          </Text>

          {Array.isArray(printJobs) && printJobs.slice(0, 5).map((job) => (
            <JobItem key={job.id} job={job} />
          ))}
          
          {(!Array.isArray(printJobs) || printJobs.length === 0) && (
            <View style={{ alignItems: 'center', paddingVertical: 24 }}>
              <Ionicons name="document-outline" size={48} color="#9CA3AF" />
              <Text style={{ fontSize: 14, color: '#6B7280', marginTop: 8 }}>
                No recent activity
              </Text>
            </View>
          )}
        </View>

        {/* Limited Features Notice */}
        <View style={{ 
          backgroundColor: '#FEF3C7',
          borderRadius: 12,
          padding: 16,
          marginBottom: 32
        }}>
          <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
            <Ionicons name="information-circle" size={20} color="#F59E0B" />
            <View style={{ flex: 1, marginLeft: 8 }}>
              <Text style={{ fontSize: 14, fontWeight: '600', color: '#92400E', marginBottom: 4 }}>
                Mobile Admin Features
              </Text>
              <Text style={{ fontSize: 13, color: '#B45309', lineHeight: 18 }}>
                This mobile interface provides essential monitoring and emergency controls. For full admin features like detailed analytics, staff management, and system configuration, please use the desktop interface.
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

// Helper Components
function StatCard({ icon, label, value, color }: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  value: string;
  color: string;
}) {
  return (
    <View style={{ 
      backgroundColor: 'white',
      borderRadius: 12,
      padding: 16,
      alignItems: 'center',
      width: '47%',
      elevation: 2,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.05,
      shadowRadius: 4,
    }}>
      <View style={{ 
        width: 32, 
        height: 32, 
        backgroundColor: color + '20',
        borderRadius: 16, 
        alignItems: 'center', 
        justifyContent: 'center',
        marginBottom: 8
      }}>
        <Ionicons name={icon} size={16} color={color} />
      </View>
      <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#111827', marginBottom: 2 }}>
        {value}
      </Text>
      <Text style={{ fontSize: 12, color: '#6B7280', textAlign: 'center' }}>
        {label}
      </Text>
    </View>
  );
}

function ActionButton({ icon, label, description, color, onPress, disabled }: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  description: string;
  color: string;
  onPress: () => void;
  disabled?: boolean;
}) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        {
          flexDirection: 'row',
          alignItems: 'center',
          padding: 12,
          borderRadius: 12,
          backgroundColor: pressed ? '#F9FAFB' : 'transparent',
          opacity: disabled ? 0.5 : 1,
        }
      ]}
    >
      <View style={{ 
        width: 40, 
        height: 40, 
        backgroundColor: color + '20',
        borderRadius: 20, 
        alignItems: 'center', 
        justifyContent: 'center',
        marginRight: 12
      }}>
        <Ionicons name={icon} size={20} color={color} />
      </View>
      
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827', marginBottom: 2 }}>
          {label}
        </Text>
        <Text style={{ fontSize: 12, color: '#6B7280' }}>
          {description}
        </Text>
      </View>
      
      <Ionicons name="chevron-forward" size={16} color="#9CA3AF" />
    </Pressable>
  );
}

function JobItem({ job }: { job: any }) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return '#10B981';
      case 'ongoing': return '#3B82F6';
      case 'ready': return '#8B5CF6';
      case 'queue': return '#F59E0B';
      case 'failed': return '#DC2626';
      default: return '#6B7280';
    }
  };

  return (
    <View style={{ 
      flexDirection: 'row', 
      alignItems: 'center', 
      paddingVertical: 8,
      borderBottomWidth: 1,
      borderBottomColor: '#F3F4F6'
    }}>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 14, fontWeight: '500', color: '#111827', marginBottom: 2 }}>
          #{job.id.slice(-6)} - {job.customerInfo.name}
        </Text>
        <Text style={{ fontSize: 12, color: '#6B7280' }}>
          {job.files.length} files • ₱{(job.totalPrice / 100).toFixed(2)}
        </Text>
      </View>
      
      <View style={{ 
        paddingHorizontal: 8, 
        paddingVertical: 4, 
        borderRadius: 12, 
        backgroundColor: getStatusColor(job.status) + '20'
      }}>
        <Text style={{ 
          fontSize: 11, 
          fontWeight: '600', 
          color: getStatusColor(job.status),
          textTransform: 'capitalize'
        }}>
          {job.status}
        </Text>
      </View>
    </View>
  );
}