import React from 'react';
import { View, Text, Pressable, ScrollView, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

interface CustomerHomeScreenProps {
  navigation?: any;
}

export default function CustomerHomeScreen({ navigation }: CustomerHomeScreenProps) {
  const insets = useSafeAreaInsets();

  const handleServiceSelect = (service: string) => {
    if (service === 'scan') {
      navigation?.navigate('Scanner');
    } else {
      navigation?.navigate('FileUpload', { serviceType: service });
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Header */}
        <View style={[styles.header, { paddingTop: insets.top + 20 }]}>
          <View style={styles.headerContent}>
            <View style={styles.brandSection}>
              <View style={styles.logoIcon}>
                <Ionicons name="print" size={24} color="white" />
              </View>
              <View>
                <Text style={styles.brandTitle}>PISO Print Express</Text>
                <Text style={styles.brandSubtitle}>Professional Printing</Text>
              </View>
            </View>
            
            <Pressable 
              style={styles.profileButton}
              onPress={() => navigation?.getParent()?.navigate('Profile')}
            >
              <Ionicons name="person" size={20} color="white" />
            </Pressable>
          </View>
          
          <Text style={styles.greeting}>Hello!</Text>
          <Text style={styles.subtitle}>What would you like to print today?</Text>
        </View>

        {/* Quick Actions */}
        <View style={styles.quickActionsContainer}>
          <View style={styles.quickActionsCard}>
            <Text style={styles.sectionTitle}>Quick Start</Text>
            
            <View style={styles.actionsGrid}>
              <Pressable 
                style={styles.actionButton}
                onPress={() => handleServiceSelect('document')}
              >
                <View style={[styles.actionIcon, { backgroundColor: '#3B82F620' }]}>
                  <Ionicons name="document-text" size={24} color="#3B82F6" />
                </View>
                <Text style={styles.actionLabel}>Documents</Text>
              </Pressable>

              <Pressable 
                style={styles.actionButton}
                onPress={() => handleServiceSelect('scan')}
              >
                <View style={[styles.actionIcon, { backgroundColor: '#10B98120' }]}>
                  <Ionicons name="scan" size={24} color="#10B981" />
                </View>
                <Text style={styles.actionLabel}>Scan & Print</Text>
              </Pressable>

              <Pressable 
                style={styles.actionButton}
                onPress={() => handleServiceSelect('photo')}
              >
                <View style={[styles.actionIcon, { backgroundColor: '#8B5CF620' }]}>
                  <Ionicons name="camera" size={24} color="#8B5CF6" />
                </View>
                <Text style={styles.actionLabel}>Photos</Text>
              </Pressable>
            </View>
          </View>
        </View>

        {/* Features */}
        <View style={styles.featuresContainer}>
          <Text style={styles.sectionTitle}>Why Choose Us?</Text>
          
          <View style={styles.featuresGrid}>
            <View style={styles.featureCard}>
              <View style={[styles.featureIcon, { backgroundColor: '#F59E0B20' }]}>
                <Ionicons name="flash" size={20} color="#F59E0B" />
              </View>
              <Text style={styles.featureTitle}>Express Service</Text>
              <Text style={styles.featureDescription}>Ready in minutes</Text>
            </View>

            <View style={styles.featureCard}>
              <View style={[styles.featureIcon, { backgroundColor: '#10B98120' }]}>
                <Ionicons name="shield-checkmark" size={20} color="#10B981" />
              </View>
              <Text style={styles.featureTitle}>Premium Quality</Text>
              <Text style={styles.featureDescription}>Professional results</Text>
            </View>

            <View style={styles.featureCard}>
              <View style={[styles.featureIcon, { backgroundColor: '#8B5CF620' }]}>
                <Ionicons name="sparkles" size={20} color="#8B5CF6" />
              </View>
              <Text style={styles.featureTitle}>AI Enhanced</Text>
              <Text style={styles.featureDescription}>Smart processing</Text>
            </View>

            <View style={styles.featureCard}>
              <View style={[styles.featureIcon, { backgroundColor: '#3B82F620' }]}>
                <Ionicons name="bicycle" size={20} color="#3B82F6" />
              </View>
              <Text style={styles.featureTitle}>Free Delivery</Text>
              <Text style={styles.featureDescription}>Orders over ₱50</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  scrollContent: {
    paddingBottom: 20,
  },
  header: {
    backgroundColor: '#3B82F6',
    paddingHorizontal: 24,
    paddingBottom: 32,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  brandSection: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logoIcon: {
    width: 48,
    height: 48,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  brandTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  brandSubtitle: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
  },
  profileButton: {
    width: 40,
    height: 40,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  greeting: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.9)',
    lineHeight: 22,
  },
  quickActionsContainer: {
    paddingHorizontal: 24,
    marginTop: -16,
  },
  quickActionsCard: {
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 24,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 16,
  },
  actionsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  actionButton: {
    alignItems: 'center',
    flex: 1,
    padding: 16,
    borderRadius: 16,
  },
  actionIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  actionLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    textAlign: 'center',
  },
  featuresContainer: {
    paddingHorizontal: 24,
  },
  featuresGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  featureCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    width: '47%',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    marginBottom: 16,
  },
  featureIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  featureTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 4,
    textAlign: 'center',
  },
  featureDescription: {
    fontSize: 12,
    color: '#6B7280',
    textAlign: 'center',
  },
});