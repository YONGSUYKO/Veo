import React, { useState } from 'react';
import { View, Text, Pressable, ScrollView, Modal } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNewAppStore } from '../../state/newAppStore';

interface CustomerServicesScreenProps {
  navigation?: any;
  route?: any;
}

export default function CustomerServicesScreen({ navigation, route }: CustomerServicesScreenProps) {
  const insets = useSafeAreaInsets();
  const { systemSettings } = useNewAppStore();
  const [selectedService, setSelectedService] = useState<'document' | 'photo' | null>(
    route?.params?.selectedService || null
  );
  const [showPricingModal, setShowPricingModal] = useState(false);

  const services = [
    {
      id: 'document',
      title: 'Digital Documents',
      description: 'Print your PDF, Word, Excel, and PowerPoint files',
      icon: 'document-text',
      color: '#3B82F6',
      features: [
        'PDF, Word, Excel, PowerPoint support',
        'A4, A3, Letter, Legal sizes available',
        'Black & white or full color printing',
        'Single or double-sided options',
        'Binding and lamination services'
      ],
      priceRange: 'Starting at ₱1.00/page',
      badge: 'Most Popular'
    },
    {
      id: 'scan',
      title: 'AI Document Scanner',
      description: 'Professional scanning with automatic quality enhancement',
      icon: 'scan',
      color: '#10B981',
      features: [
        'AI-powered edge detection',
        'Automatic quality enhancement',
        'Multi-page document scanning',
        'Instant preview and editing',
        'Direct print after scanning'
      ],
      priceRange: 'Scan + Print from ₱2.00',
      badge: 'AI Powered'
    },
    {
      id: 'photo',
      title: 'Premium Photo Prints',
      description: 'Professional photo printing in multiple sizes',
      icon: 'camera',
      color: '#8B5CF6',
      features: [
        'Wallet to 8R sizes available',
        '4R (4×6) default photo size',
        'Premium glossy photo paper',
        'Color correction included',
        'Same-day pickup available'
      ],
      priceRange: 'From ₱0.50 (Wallet) to ₱6.50 (8R)',
      badge: 'Pro Quality'
    }
  ];

  const handleServiceSelect = (serviceId: 'document' | 'scan' | 'photo') => {
    setSelectedService(serviceId);
    
    // Navigate to Home tab first, then to the specific screen
    navigation?.getParent()?.navigate('Home', {
      screen: serviceId === 'scan' ? 'Scanner' : 'FileUpload',
      params: { serviceType: serviceId }
    });
  };

  const getPricingData = () => {
    if (!systemSettings) return null;
    
    return {
      documents: systemSettings.documentPricing,
      photos: systemSettings.photoPricing,
      binding: systemSettings.bindingPricing,
      lamination: systemSettings.laminationPricing
    };
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#F9FAFB' }}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={{ paddingHorizontal: 24, paddingTop: 20, paddingBottom: 16 }}>
          <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#111827', marginBottom: 8 }}>
            Our Services
          </Text>
          <Text style={{ fontSize: 16, color: '#6B7280', lineHeight: 22 }}>
            Professional printing solutions for all your needs
          </Text>
        </View>

        {/* Service Cards */}
        <View style={{ paddingHorizontal: 24 }}>
          {services.map((service, index) => (
            <ServiceCard
              key={service.id}
              service={service}
              isSelected={selectedService === service.id}
              onPress={() => handleServiceSelect(service.id as any)}
              style={{ marginBottom: index === services.length - 1 ? 0 : 16 }}
            />
          ))}
        </View>

        {/* Pricing Overview */}
        <View style={{ paddingHorizontal: 24, paddingTop: 32, paddingBottom: 24 }}>
          <View style={{ 
            backgroundColor: 'white',
            borderRadius: 16,
            padding: 24,
            elevation: 2,
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 1 },
            shadowOpacity: 0.05,
            shadowRadius: 4,
          }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#111827' }}>
                Transparent Pricing
              </Text>
              <Pressable onPress={() => setShowPricingModal(true)}>
                <Text style={{ fontSize: 14, color: '#3B82F6', fontWeight: '500' }}>
                  View Details
                </Text>
              </Pressable>
            </View>
            
            <Text style={{ fontSize: 14, color: '#6B7280', lineHeight: 20, marginBottom: 16 }}>
              No hidden fees. Pay only for what you print with our competitive rates.
            </Text>
            
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <PricingPoint
                icon="document-text"
                label="Documents"
                price="₱1.00+"
                color="#3B82F6"
              />
              <PricingPoint
                icon="camera"
                label="Photos"
                price="₱0.50+"
                color="#8B5CF6"
              />
              <PricingPoint
                icon="layers"
                label="Binding"
                price="₱8.00+"
                color="#10B981"
              />
            </View>
          </View>
        </View>

        {/* Why Choose Us */}
        <View style={{ paddingHorizontal: 24, paddingBottom: 32 }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#111827', marginBottom: 16 }}>
            Why Choose PISO Print Express?
          </Text>
          
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>
            <FeatureBadge icon="flash" label="Fast Service" />
            <FeatureBadge icon="shield-checkmark" label="Quality Guaranteed" />
            <FeatureBadge icon="sparkles" label="AI Enhanced" />
            <FeatureBadge icon="bicycle" label="Free Delivery" />
            <FeatureBadge icon="card" label="Multiple Payments" />
            <FeatureBadge icon="time" label="Extended Hours" />
          </View>
        </View>
      </ScrollView>

      {/* Pricing Modal */}
      <Modal
        visible={showPricingModal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowPricingModal(false)}
      >
        <PricingModal 
          onClose={() => setShowPricingModal(false)}
          pricingData={getPricingData()}
        />
      </Modal>
    </View>
  );
}

// Helper Components
function ServiceCard({ service, isSelected, onPress, style }: {
  service: any;
  isSelected: boolean;
  onPress: () => void;
  style?: any;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        {
          backgroundColor: 'white',
          borderRadius: 16,
          padding: 20,
          elevation: 2,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.1,
          shadowRadius: 8,
          position: 'relative',
        },
        isSelected && {
          borderWidth: 2,
          borderColor: service.color,
          elevation: 4,
        },
        pressed && {
          opacity: 0.9,
          transform: [{ scale: 0.98 }],
        },
        style
      ]}
    >
      {service.badge && (
        <View style={{ position: 'absolute', top: 16, right: 16, zIndex: 1 }}>
          <View style={{ 
            backgroundColor: service.color,
            paddingHorizontal: 8,
            paddingVertical: 4,
            borderRadius: 12
          }}>
            <Text style={{ color: 'white', fontSize: 12, fontWeight: 'bold' }}>
              {service.badge}
            </Text>
          </View>
        </View>
      )}
      
      <View style={{ flexDirection: 'row', alignItems: 'flex-start', marginBottom: 16 }}>
        <View style={{ 
          width: 56, 
          height: 56, 
          backgroundColor: service.color + '20',
          borderRadius: 16, 
          alignItems: 'center', 
          justifyContent: 'center',
          marginRight: 16
        }}>
          <Ionicons name={service.icon} size={28} color={service.color} />
        </View>
        
        <View style={{ flex: 1, marginRight: service.badge ? 80 : 0 }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#111827', marginBottom: 4 }}>
            {service.title}
          </Text>
          <Text style={{ fontSize: 14, color: '#6B7280', lineHeight: 20 }}>
            {service.description}
          </Text>
        </View>
      </View>
      
      <View style={{ marginBottom: 16 }}>
        {service.features.map((feature: string, index: number) => (
          <View key={index} style={{ 
            flexDirection: 'row', 
            alignItems: 'center',
            marginBottom: index === service.features.length - 1 ? 0 : 6
          }}>
            <View style={{ 
              width: 4, 
              height: 4, 
              backgroundColor: service.color, 
              borderRadius: 2, 
              marginRight: 8 
            }} />
            <Text style={{ fontSize: 13, color: '#374151' }}>
              {feature}
            </Text>
          </View>
        ))}
      </View>
      
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Text style={{ fontSize: 16, fontWeight: '600', color: service.color }}>
          {service.priceRange}
        </Text>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Text style={{ fontSize: 14, color: service.color, fontWeight: '500', marginRight: 4 }}>
            {service.id === 'scan' ? 'Scan Now' : 'Start Printing'}
          </Text>
          <Ionicons name="arrow-forward" size={16} color={service.color} />
        </View>
      </View>
    </Pressable>
  );
}

function PricingPoint({ icon, label, price, color }: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  price: string;
  color: string;
}) {
  return (
    <View style={{ alignItems: 'center', flex: 1 }}>
      <View style={{ 
        width: 40, 
        height: 40, 
        backgroundColor: color + '20',
        borderRadius: 20, 
        alignItems: 'center', 
        justifyContent: 'center',
        marginBottom: 8
      }}>
        <Ionicons name={icon} size={20} color={color} />
      </View>
      <Text style={{ fontSize: 12, color: '#6B7280', marginBottom: 2 }}>
        {label}
      </Text>
      <Text style={{ fontSize: 14, fontWeight: 'bold', color: '#111827' }}>
        {price}
      </Text>
    </View>
  );
}

function FeatureBadge({ icon, label }: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
}) {
  return (
    <View style={{ 
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: 'white',
      paddingHorizontal: 12,
      paddingVertical: 8,
      borderRadius: 20,
      elevation: 1,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.05,
      shadowRadius: 2,
    }}>
      <Ionicons name={icon} size={16} color="#10B981" style={{ marginRight: 6 }} />
      <Text style={{ fontSize: 12, fontWeight: '500', color: '#374151' }}>
        {label}
      </Text>
    </View>
  );
}

function PricingModal({ onClose, pricingData }: { 
  onClose: () => void;
  pricingData: any;
}) {
  const insets = useSafeAreaInsets();

  return (
    <View style={{ flex: 1, backgroundColor: '#F9FAFB' }}>
      <View style={{ 
        backgroundColor: 'white',
        paddingTop: insets.top + 16,
        paddingHorizontal: 24,
        paddingBottom: 16,
        borderBottomWidth: 1,
        borderBottomColor: '#E5E7EB'
      }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#111827' }}>
            Pricing Details
          </Text>
          <Pressable onPress={onClose}>
            <Ionicons name="close" size={24} color="#6B7280" />
          </Pressable>
        </View>
      </View>
      
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 24 }}>
        {pricingData && (
          <>
            {/* Document Pricing */}
            <PricingSection
              title="Document Printing"
              icon="document-text"
              color="#3B82F6"
              items={Object.entries(pricingData.documents).map(([size, prices]: [string, any]) => ({
                name: `${size} Size`,
                details: `B&W: ₱${(prices.blackwhite / 100).toFixed(2)} • Color: ₱${(prices.color / 100).toFixed(2)}`,
                extra: prices.doubleSidedSurcharge ? `Double-sided +₱${(prices.doubleSidedSurcharge / 100).toFixed(2)}` : null
              }))}
            />
            
            {/* Photo Pricing */}
            <PricingSection
              title="Photo Printing"
              icon="camera"
              color="#8B5CF6"
              items={Object.entries(pricingData.photos).map(([size, price]: [string, any]) => ({
                name: size,
                details: `₱${(price / 100).toFixed(2)} per photo`,
                extra: size === '4R' ? 'Default size' : null
              }))}
            />
            
            {/* Services Pricing */}
            {pricingData.binding && (
              <PricingSection
                title="Binding Services"
                icon="layers"
                color="#10B981"
                items={Object.entries(pricingData.binding).map(([size, services]: [string, any]) => ({
                  name: `${size} Size`,
                  details: `Spiral: ₱${(services.spiral / 100).toFixed(2)} • Perfect: ₱${(services.perfect / 100).toFixed(2)}`,
                  extra: `Saddle: ₱${(services.saddle / 100).toFixed(2)}`
                }))}
              />
            )}
          </>
        )}
      </ScrollView>
    </View>
  );
}

function PricingSection({ title, icon, color, items }: {
  title: string;
  icon: keyof typeof Ionicons.glyphMap;
  color: string;
  items: Array<{ name: string; details: string; extra?: string | null }>;
}) {
  return (
    <View style={{ marginBottom: 24 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16 }}>
        <View style={{ 
          width: 32, 
          height: 32, 
          backgroundColor: color + '20',
          borderRadius: 16, 
          alignItems: 'center', 
          justifyContent: 'center',
          marginRight: 12
        }}>
          <Ionicons name={icon} size={16} color={color} />
        </View>
        <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#111827' }}>
          {title}
        </Text>
      </View>
      
      <View style={{ 
        backgroundColor: 'white',
        borderRadius: 12,
        padding: 16,
        elevation: 1,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 2,
      }}>
        {items.map((item, index) => (
          <View key={index} style={{ 
            paddingVertical: 8,
            borderBottomWidth: index === items.length - 1 ? 0 : 1,
            borderBottomColor: '#F3F4F6'
          }}>
            <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827', marginBottom: 2 }}>
              {item.name}
            </Text>
            <Text style={{ fontSize: 13, color: '#6B7280' }}>
              {item.details}
            </Text>
            {item.extra && (
              <Text style={{ fontSize: 12, color: '#9CA3AF', marginTop: 2 }}>
                {item.extra}
              </Text>
            )}
          </View>
        ))}
      </View>
    </View>
  );
}