import React, { useState } from 'react';
import { View, Text, Pressable, ScrollView, StyleSheet, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../../state/authStore';
import SendFilesModal from '../../components/SendFilesModal';

interface GuestHomeScreenProps {
  navigation?: any;
}

export default function GuestHomeScreen({ navigation }: GuestHomeScreenProps) {
  const insets = useSafeAreaInsets();
  const { currentUser, isAuthenticated } = useAuthStore();
  const [showSendFilesModal, setShowSendFilesModal] = useState(false);

  const handleServiceSelect = (service: string) => {
    // Handle login separately
    if (service === 'login') {
      navigation?.navigate('Login');
      return;
    }
    
    // Direct services that can start immediately
    if (service === 'documents') {
      navigation?.navigate('FileUpload', { serviceType: 'document' });
      return;
    }
    
    if (service === 'scan') {
      navigation?.navigate('FileUpload', { serviceType: 'scan' });
      return;
    }
    
    if (service === 'photos') {
      navigation?.navigate('FileUpload', { serviceType: 'photo' });
      return;
    }
    
    // Handle specific services with dedicated screens
    if (service === 'marketplace') {
      navigation?.navigate('ServiceBrowser', { serviceType: 'marketplace' });
      return;
    }
    

    
    if (service === 'rewards') {
      // For now, show info about loyalty program
      Alert.alert(
        'Loyalty Rewards Program',
        'Earn points with every order!\n\n• 1 point = ₱1 earned per ₱100 spent\n• Redeem points for discounts\n• Special member pricing\n\nCreate an account to start earning!',
        [
          { text: 'Sign Up', onPress: () => navigation?.navigate('Login') },
          { text: 'Maybe Later', style: 'cancel' }
        ]
      );
      return;
    }
    
    if (service === 'subscription') {
      navigation?.navigate('ServiceBrowser', { serviceType: 'subscription' });
      return;
    }
    
    if (service === 'franchising') {
      navigation?.navigate('Franchising');
      return;
    }
    
    if (service === 'pricing') {
      navigation?.navigate('CompletePricing');
      return;
    }
    
    if (service === 'staff-support') {
      setShowSendFilesModal(true);
      return;
    }
    
    // Default fallback for other services
    navigation?.navigate('ServiceBrowser', { serviceType: service });
  };

  const handleLoginPress = () => {
    navigation?.navigate('Login');
  };

  // Main Service Buttons (Reordered: Print My Docs, Scan My Docs, Premium Items, Print My Pics, Print With Chat first)
  const services = [
    {
      id: 'documents',
      title: 'Print My Docs',
      subtitle: 'PDF, Word, Excel',
      icon: 'document-text',
      color: '#3B82F6',
      description: 'Print your documents with professional quality'
    },
    {
      id: 'scan',
      title: 'Scan My Docs',
      subtitle: 'Camera Scanning',
      icon: 'scan',
      color: '#10B981', 
      description: 'Scan documents using your phone camera'
    },
    {
      id: 'products',
      title: 'Premium Items',
      subtitle: 'Business Cards, etc',
      icon: 'briefcase',
      color: '#84CC16',
      description: 'Business cards, flyers, and custom prints'
    },
    {
      id: 'photos',
      title: 'Print My Pics',
      subtitle: 'High Quality Prints',
      icon: 'camera',
      color: '#8B5CF6',
      description: 'Professional photo printing in various sizes'
    },
    {
      id: 'staff-support',
      title: 'Print With Chat',
      subtitle: 'Quick Check',
      icon: 'people',
      color: '#8B5CF6',
      description: 'Upload files for expert review, custom specifications, and two-way communication before payment'
    },
    {
      id: 'marketplace',
      title: 'Marketplace',
      subtitle: 'Browse Products',
      icon: 'storefront',
      color: '#F59E0B',
      description: 'Office supplies, stationery, and more'
    },
    {
      id: 'rewards',
      title: 'Loyalty Rewards',
      subtitle: 'Earn Points',
      icon: 'star',
      color: '#EC4899',
      description: 'Collect points and get exclusive discounts'
    },
    {
      id: 'subscription',
      title: 'Subscription',
      subtitle: 'Monthly Packages',
      icon: 'calendar',
      color: '#06B6D4',
      description: 'Affordable monthly printing subscriptions'
    },
    {
      id: 'franchising',
      title: 'Franchising',
      subtitle: 'Business Opportunity',
      icon: 'business',
      color: '#DC2626',
      description: 'Join our franchise network and start your own print business'
    },
    {
      id: 'pricing',
      title: 'View Pricing',
      subtitle: 'All Service Rates',
      icon: 'pricetag',
      color: '#7C3AED',
      description: 'Complete pricing guide for all our services'
    },
    {
      id: 'login',
      title: isAuthenticated ? currentUser?.name || 'Account' : 'Log In',
      subtitle: isAuthenticated ? 'Manage Account' : 'Sign In / Register',
      icon: isAuthenticated ? 'person-circle' : 'log-in',
      color: '#6B7280',
      description: isAuthenticated ? 'View orders and manage your account' : 'Access your account or create new one'
    }
  ];

  return (
    <View style={styles.container}>
      <ScrollView 
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={[styles.header, { paddingTop: insets.top + 20 }]}>
          <View style={styles.headerContent}>
            <View style={styles.brandSection}>
              <View style={styles.logoContainer}>
                <Ionicons name="print" size={32} color="white" />
              </View>
              <View>
                <Text style={styles.brandTitle}>PISO Print Express</Text>
                <Text style={styles.brandSubtitle}>Your Complete Printing Solution</Text>
              </View>
            </View>

            {/* Status Indicator */}
            <View style={styles.statusContainer}>
              {isAuthenticated ? (
                <View style={styles.loggedInStatus}>
                  <Ionicons name="checkmark-circle" size={16} color="#10B981" />
                  <Text style={styles.statusText}>Signed In</Text>
                </View>
              ) : (
                <View style={styles.guestStatus}>
                  <Ionicons name="eye" size={16} color="#6B7280" />
                  <Text style={styles.statusText}>Browsing</Text>
                </View>
              )}
            </View>
          </View>

          {/* Welcome Message */}
          <View style={styles.welcomeSection}>
            <Pressable
              onLongPress={() => {
                Alert.alert(
                  'Developer Access',
                  'Access DESKTOP dashboards on mobile?',
                  [
                    { text: 'Cancel', style: 'cancel' },
                    { text: 'Access Desktop Dashboards', onPress: () => navigation?.navigate('TempDesktopDashboardAccess') }
                  ]
                );
              }}
            >
              <Text style={styles.welcomeTitle}>
                {isAuthenticated 
                  ? `Welcome back, ${currentUser?.name?.split(' ')[0]}!`
                  : 'Explore Our Services'
                }
              </Text>
            </Pressable>
            <Text style={styles.welcomeSubtitle}>
              {isAuthenticated
                ? 'Ready to print? Choose from our services below.'
                : 'Browse freely. Login only when you\'re ready to proceed.'
              }
            </Text>
          </View>
        </View>

        {/* Services Grid */}
        <View style={styles.servicesContainer}>
          <Text style={styles.sectionTitle}>Choose Your Service</Text>
          
          <View style={styles.servicesGrid}>
            {services.map((service, index) => (
              <ServiceButton
                key={service.id}
                service={service}
                onPress={() => handleServiceSelect(service.id)}
                isLogin={service.id === 'login'}
                isAuthenticated={isAuthenticated}
              />
            ))}
          </View>
        </View>

        {/* Why Choose Us */}
        <View style={styles.featuresContainer}>
          <Text style={styles.sectionTitle}>Why Choose PISO Print?</Text>
          
          <View style={styles.featuresGrid}>
            <FeatureCard
              icon="flash"
              title="Express Service"
              description="Ready in minutes"
              color="#F59E0B"
            />
            <FeatureCard
              icon="shield-checkmark"
              title="Premium Quality"
              description="Professional results"
              color="#10B981"
            />
            <FeatureCard
              icon="sparkles"
              title="AI Enhanced"
              description="Smart processing"
              color="#8B5CF6"
            />
            <FeatureCard
              icon="bicycle"
              title="Free Delivery"
              description="Orders over ₱50"
              color="#3B82F6"
            />
          </View>
        </View>

        {/* Browse Notice */}
        <View style={styles.browseNotice}>
          <View style={styles.browseCard}>
            <Ionicons name="information-circle" size={24} color="#3B82F6" />
            <View style={styles.browseText}>
              <Text style={styles.browseTitle}>Browse Freely</Text>
              <Text style={styles.browseDescription}>
                Explore all our services, view prices, and see samples. 
                You only need to login when you're ready to proceed with any service.
              </Text>
            </View>
          </View>
        </View>

        {/* Send Files Modal */}
        <SendFilesModal
          visible={showSendFilesModal}
          onClose={() => setShowSendFilesModal(false)}
          navigation={navigation}
        />
      </ScrollView>
    </View>
  );
}

function ServiceButton({ service, onPress, isLogin, isAuthenticated }: {
  service: any;
  onPress: () => void;
  isLogin: boolean;
  isAuthenticated: boolean;
}) {
  return (
    <Pressable
      style={({ pressed }) => [
        styles.serviceButton,
        pressed && styles.serviceButtonPressed,
        isLogin && styles.loginButton
      ]}
      onPress={onPress}
    >
      <View style={[styles.serviceIcon, { backgroundColor: `${service.color}20` }]}>
        <Ionicons name={service.icon} size={28} color={service.color} />
      </View>
      
      <View style={styles.serviceContent}>
        <Text style={styles.serviceTitle}>{service.title}</Text>
        <Text style={styles.serviceSubtitle}>{service.subtitle}</Text>
      </View>

      {isLogin && isAuthenticated && (
        <View style={[styles.serviceBadge, { backgroundColor: '#10B981' }]}>
          <Ionicons name="checkmark" size={16} color="white" />
        </View>
      )}
    </Pressable>
  );
}

function FeatureCard({ icon, title, description, color }: {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  description: string;
  color: string;
}) {
  return (
    <View style={styles.featureCard}>
      <View style={[styles.featureIcon, { backgroundColor: `${color}20` }]}>
        <Ionicons name={icon} size={20} color={color} />
      </View>
      <Text style={styles.featureTitle}>{title}</Text>
      <Text style={styles.featureDescription}>{description}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  scrollContent: {
    paddingBottom: 20,
  },
  header: {
    backgroundColor: '#3B82F6',
    paddingHorizontal: 24,
    paddingBottom: 32,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  brandSection: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logoContainer: {
    width: 48,
    height: 48,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  brandTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  brandSubtitle: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
  },
  statusContainer: {
    alignItems: 'flex-end',
  },
  loggedInStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(16,185,129,0.2)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  guestStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 12,
    color: 'white',
    marginLeft: 4,
    fontWeight: '500',
  },
  welcomeSection: {
    alignItems: 'center',
  },
  welcomeTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 8,
    textAlign: 'center',
  },
  welcomeSubtitle: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.9)',
    textAlign: 'center',
    lineHeight: 20,
  },
  servicesContainer: {
    paddingHorizontal: 24,
    marginTop: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 16,
  },
  servicesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 12,
  },
  serviceButton: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    width: '47%',
    marginBottom: 12,
    minHeight: 120,
  },
  serviceButtonPressed: {
    backgroundColor: '#F9FAFB',
    transform: [{ scale: 0.98 }],
  },
  loginButton: {
    borderWidth: 2,
    borderColor: '#E5E7EB',
    borderStyle: 'dashed',
  },
  serviceIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  serviceContent: {
    alignItems: 'center',
    flex: 1,
  },
  serviceTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 4,
    textAlign: 'center',
  },
  serviceSubtitle: {
    fontSize: 12,
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 16,
  },
  serviceDescription: {
    fontSize: 12,
    color: '#9CA3AF',
    lineHeight: 16,
  },
  serviceBadge: {
    width: 20,
    height: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    top: 12,
    right: 12,
  },
  featuresContainer: {
    paddingHorizontal: 24,
    marginTop: 32,
  },
  featuresGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  featureCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    width: '47%',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    marginBottom: 16,
  },
  featureIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  featureTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 4,
    textAlign: 'center',
  },
  featureDescription: {
    fontSize: 12,
    color: '#6B7280',
    textAlign: 'center',
  },
  browseNotice: {
    paddingHorizontal: 24,
    marginTop: 24,
  },
  browseCard: {
    backgroundColor: '#EFF6FF',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  browseText: {
    flex: 1,
    marginLeft: 12,
  },
  browseTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1E40AF',
    marginBottom: 4,
  },
  browseDescription: {
    fontSize: 12,
    color: '#1D4ED8',
    lineHeight: 18,
  },
});