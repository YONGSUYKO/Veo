import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';
import { socialAuthService } from '../services/socialAuth';

interface LoginScreenProps {
  navigation?: any;
}

export default function LoginScreen({ navigation }: LoginScreenProps) {
  const insets = useSafeAreaInsets();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [socialLoading, setSocialLoading] = useState<'google' | 'facebook' | null>(null);
  const { login } = useAuthStore();

  // Mock user database (in real app, this would be API calls)
  const mockUsers = [
    {
      id: 'admin-1',
      email: 'admin@pisoprint.com',
      password: 'admin123',
      name: 'Admin User',
      role: 'admin' as const,
      loyaltyPoints: 0,
    },
    {
      id: 'operator-1',
      email: 'staff@pisoprint.com', 
      password: 'staff123',
      name: 'Store Operator',
      role: 'operator' as const,
      loyaltyPoints: 0,
    },
    {
      id: 'customer-1',
      email: 'customer@gmail.com',
      password: 'customer123', 
      name: 'John Customer',
      role: 'customer' as const,
      loyaltyPoints: 250,
    },
  ];

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Error', 'Please enter email and password');
      return;
    }

    setLoading(true);

    // Simulate API call delay
    setTimeout(() => {
      const user = mockUsers.find(u => u.email === email && u.password === password);
      
      if (user) {
        login({
          ...user,
          isLoggedIn: true,
        });
        Alert.alert('Success', `Welcome ${user.name}!`, [
          { text: 'OK', onPress: () => navigation?.goBack() }
        ]);
      } else {
        Alert.alert('Error', 'Invalid email or password');
      }
      
      setLoading(false);
    }, 1000);
  };

  const handleGoogleSignIn = async () => {
    setSocialLoading('google');
    
    try {
      const result = await socialAuthService.signInWithGoogle();
      
      if (result.success && result.user) {
        const appUser = {
          id: result.user.id,
          name: result.user.name,
          email: result.user.email,
          role: 'customer' as const,
          loyaltyPoints: 0,
          isLoggedIn: true,
        };
        
        login(appUser);
        Alert.alert('Welcome!', `Signed in successfully with Google`, [
          { text: 'OK', onPress: () => navigation?.goBack() }
        ]);
      } else {
        Alert.alert('Sign In Failed', result.error || 'Unable to sign in with Google');
      }
    } catch (error) {
      Alert.alert('Error', 'Something went wrong. Please try again.');
    } finally {
      setSocialLoading(null);
    }
  };

  const handleFacebookSignIn = async () => {
    setSocialLoading('facebook');
    
    try {
      const result = await socialAuthService.signInWithFacebook();
      
      if (result.success && result.user) {
        const appUser = {
          id: result.user.id,
          name: result.user.name,
          email: result.user.email,
          role: 'customer' as const,
          loyaltyPoints: 0,
          isLoggedIn: true,
        };
        
        login(appUser);
        Alert.alert('Welcome!', `Signed in successfully with Facebook`, [
          { text: 'OK', onPress: () => navigation?.goBack() }
        ]);
      } else {
        Alert.alert('Sign In Failed', result.error || 'Unable to sign in with Facebook');
      }
    } catch (error) {
      Alert.alert('Error', 'Something went wrong. Please try again.');
    } finally {
      setSocialLoading(null);
    }
  };

  const handleGuestLogin = () => {
    login({
      id: `guest-${Date.now()}`,
      name: 'Guest User',
      email: 'guest@pisoprint.com',
      role: 'customer',
      loyaltyPoints: 0,
      isLoggedIn: true,
    });
    navigation?.goBack();
  };

  const quickLogin = (userEmail: string, userPassword: string, userName: string) => {
    setEmail(userEmail);
    setPassword(userPassword);
    // Auto-login after setting credentials
    setTimeout(() => handleLogin(), 100);
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.content}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.logoContainer}>
            <Ionicons name="print" size={40} color="#3B82F6" />
          </View>
          <Text style={styles.title}>PISO Print Express</Text>
          <Text style={styles.subtitle}>Professional Printing Services</Text>
        </View>

        {/* Login Form */}
        <View style={styles.form}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Email</Text>
            <TextInput
              style={styles.input}
              value={email}
              onChangeText={setEmail}
              placeholder="Enter your email"
              keyboardType="email-address"
              autoCapitalize="none"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Password</Text>
            <TextInput
              style={styles.input}
              value={password}
              onChangeText={setPassword}
              placeholder="Enter your password"
              secureTextEntry
            />
          </View>

          <Pressable 
            style={[styles.loginButton, loading && styles.disabledButton]}
            onPress={handleLogin}
            disabled={loading}
          >
            <Text style={styles.loginButtonText}>
              {loading ? 'Logging in...' : 'Login'}
            </Text>
          </Pressable>
        </View>

        {/* Divider */}
        <View style={styles.divider}>
          <View style={styles.dividerLine} />
          <Text style={styles.dividerText}>or continue with</Text>
          <View style={styles.dividerLine} />
        </View>

        {/* Social Login Buttons */}
        <View style={styles.socialButtons}>
          <Pressable 
            style={[
              styles.socialButton, 
              styles.googleButton, 
              (loading || socialLoading) && styles.disabledButton
            ]}
            onPress={handleGoogleSignIn}
            disabled={loading || socialLoading !== null}
          >
            {socialLoading === 'google' ? (
              <>
                <View style={styles.loadingSpinner} />
                <Text style={styles.socialButtonText}>Connecting to Google...</Text>
              </>
            ) : (
              <>
                <Ionicons name="logo-google" size={20} color="#DB4437" />
                <Text style={styles.socialButtonText}>Continue with Google</Text>
              </>
            )}
          </Pressable>

          <Pressable 
            style={[
              styles.socialButton, 
              styles.facebookButton, 
              (loading || socialLoading) && styles.disabledButton
            ]}
            onPress={handleFacebookSignIn}
            disabled={loading || socialLoading !== null}
          >
            {socialLoading === 'facebook' ? (
              <>
                <View style={styles.loadingSpinner} />
                <Text style={styles.socialButtonText}>Connecting to Facebook...</Text>
              </>
            ) : (
              <>
                <Ionicons name="logo-facebook" size={20} color="#4267B2" />
                <Text style={styles.socialButtonText}>Continue with Facebook</Text>
              </>
            )}
          </Pressable>
        </View>

        {/* Quick Login Options (Demo) */}
        <View style={styles.quickLogin}>
          <Text style={styles.quickLoginTitle}>Quick Demo Login:</Text>
          
          <Pressable 
            style={[styles.quickButton, { backgroundColor: '#DC262620' }]}
            onPress={() => quickLogin('admin@pisoprint.com', 'admin123', 'Admin')}
          >
            <Ionicons name="shield-checkmark" size={20} color="#DC2626" />
            <Text style={[styles.quickButtonText, { color: '#DC2626' }]}>Admin</Text>
          </Pressable>

          <Pressable 
            style={[styles.quickButton, { backgroundColor: '#059F6220' }]}
            onPress={() => quickLogin('staff@pisoprint.com', 'staff123', 'Staff')}
          >
            <Ionicons name="people" size={20} color="#059F62" />
            <Text style={[styles.quickButtonText, { color: '#059F62' }]}>Staff/Operator</Text>
          </Pressable>

          <Pressable 
            style={[styles.quickButton, { backgroundColor: '#3B82F620' }]}
            onPress={() => quickLogin('customer@gmail.com', 'customer123', 'Customer')}
          >
            <Ionicons name="person" size={20} color="#3B82F6" />
            <Text style={[styles.quickButtonText, { color: '#3B82F6' }]}>Registered Customer</Text>
          </Pressable>
        </View>

        {/* Benefits Notice */}
        <View style={styles.benefitsNotice}>
          <Text style={styles.benefitsTitle}>Why sign in?</Text>
          <View style={styles.benefitsList}>
            <View style={styles.benefitItem}>
              <Ionicons name="checkmark-circle" size={16} color="#10B981" />
              <Text style={styles.benefitText}>Save & track your orders</Text>
            </View>
            <View style={styles.benefitItem}>
              <Ionicons name="checkmark-circle" size={16} color="#10B981" />
              <Text style={styles.benefitText}>Earn loyalty points & rewards</Text>
            </View>
            <View style={styles.benefitItem}>
              <Ionicons name="checkmark-circle" size={16} color="#10B981" />
              <Text style={styles.benefitText}>Faster checkout with saved info</Text>
            </View>
          </View>
        </View>

        {/* Guest Option */}
        <View style={styles.guestSection}>
          <Text style={styles.guestText}>Just browsing or need something quickly?</Text>
          <Pressable style={styles.guestButton} onPress={handleGuestLogin}>
            <Text style={styles.guestButtonText}>Continue as Guest</Text>
          </Pressable>
        </View>

        {/* Demo Credentials */}
        <View style={styles.credentialsInfo}>
          <Text style={styles.credentialsTitle}>Demo Credentials:</Text>
          <Text style={styles.credentialsText}>Admin: admin@pisoprint.com / admin123</Text>
          <Text style={styles.credentialsText}>Staff: staff@pisoprint.com / staff123</Text>
          <Text style={styles.credentialsText}>Customer: customer@gmail.com / customer123</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  content: {
    flex: 1,
    padding: 24,
    justifyContent: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logoContainer: {
    width: 80,
    height: 80,
    backgroundColor: '#EFF6FF',
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#6B7280',
    textAlign: 'center',
  },
  form: {
    marginBottom: 32,
  },
  inputGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: 'white',
  },
  loginButton: {
    backgroundColor: '#3B82F6',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  disabledButton: {
    opacity: 0.6,
  },
  loginButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: 'white',
  },
  quickLogin: {
    marginBottom: 24,
  },
  quickLoginTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 12,
    textAlign: 'center',
  },
  quickButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
  },
  quickButtonText: {
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 8,
  },
  guestSection: {
    alignItems: 'center',
    marginBottom: 24,
    paddingTop: 24,
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
  },
  guestText: {
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 12,
    textAlign: 'center',
  },
  guestButton: {
    backgroundColor: '#6B7280',
    borderRadius: 8,
    paddingHorizontal: 24,
    paddingVertical: 12,
  },
  guestButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: 'white',
  },
  credentialsInfo: {
    backgroundColor: '#F3F4F6',
    borderRadius: 8,
    padding: 16,
  },
  credentialsTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
  },
  credentialsText: {
    fontSize: 11,
    color: '#6B7280',
    marginBottom: 4,
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 24,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#E5E7EB',
  },
  dividerText: {
    fontSize: 14,
    color: '#6B7280',
    paddingHorizontal: 16,
  },
  socialButtons: {
    gap: 12,
    marginBottom: 24,
  },
  socialButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 8,
    borderWidth: 1,
    backgroundColor: 'white',
  },
  googleButton: {
    borderColor: '#DB4437',
  },
  facebookButton: {
    borderColor: '#4267B2',
  },
  socialButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginLeft: 8,
  },
  loadingSpinner: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    borderTopColor: '#3B82F6',
  },
  benefitsNotice: {
    backgroundColor: '#F0F9FF',
    borderRadius: 8,
    padding: 16,
    marginBottom: 20,
  },
  benefitsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1E40AF',
    marginBottom: 8,
  },
  benefitsList: {
    gap: 6,
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  benefitText: {
    fontSize: 12,
    color: '#1D4ED8',
    marginLeft: 8,
  },
});