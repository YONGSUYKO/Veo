import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, ScrollView, RefreshControl, Alert, FlatList, TextInput, Modal } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';
import { useNewAppStore } from '../state/newAppStore';
import { newApiClient } from '../api/newPisoAPI';
import DesktopLayout from '../components/desktop/DesktopLayout';

interface OperatorDesktopDashboardFullProps {
  onSwitchToCustomer?: () => void;
}

export default function OperatorDesktopDashboardFull({ onSwitchToCustomer }: OperatorDesktopDashboardFullProps) {
  const { currentUser, logout } = useAuthStore();
  const { printJobs, setPrintJobs } = useNewAppStore();
  const [refreshing, setRefreshing] = useState(false);
  const [currentView, setCurrentView] = useState<'dashboard' | 'queue' | 'customers' | 'inventory' | 'reports' | 'settings'>('dashboard');
  const [selectedJob, setSelectedJob] = useState<any>(null);
  const [showJobDetails, setShowJobDetails] = useState(false);
  const [customerSearch, setCustomerSearch] = useState('');
  const [inventoryItems, setInventoryItems] = useState([
    { id: 1, name: 'A4 Paper', stock: 5000, unit: 'sheets', lowStockThreshold: 500 },
    { id: 2, name: 'Black Ink Cartridge', stock: 12, unit: 'pieces', lowStockThreshold: 5 },
    { id: 3, name: 'Color Ink Cartridge', stock: 8, unit: 'pieces', lowStockThreshold: 3 },
    { id: 4, name: 'Photo Paper 4R', stock: 200, unit: 'sheets', lowStockThreshold: 50 },
  ]);

  useEffect(() => {
    loadJobs();
    const interval = setInterval(loadJobs, 15000);
    return () => clearInterval(interval);
  }, []);

  const loadJobs = async () => {
    try {
      const jobs = await newApiClient.getPrintJobs();
      setPrintJobs(jobs);
    } catch (error) {
      console.error('Failed to load jobs:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadJobs();
    setRefreshing(false);
  };

  const updateJobStatus = async (jobId: string, newStatus: 'queue' | 'ongoing' | 'ready' | 'completed' | 'failed') => {
    try {
      await newApiClient.updatePrintJobStatus(jobId, newStatus);
      await loadJobs();
      Alert.alert('Success', `Job status updated to ${newStatus}`);
    } catch (error) {
      Alert.alert('Error', 'Failed to update job status');
    }
  };

  const getDashboardStats = () => {
    const today = new Date().toISOString().split('T')[0];
    const todayJobs = printJobs.filter(job => job.createdAt.toISOString().split('T')[0] === today);
    const queueJobs = printJobs.filter(job => job.status === 'queue');
    const activeJobs = printJobs.filter(job => job.status === 'ongoing');
    const completedJobs = printJobs.filter(job => job.status === 'completed');
    const todayRevenue = todayJobs.reduce((sum, job) => sum + job.totalPrice, 0);

    return {
      todayJobs: todayJobs.length,
      queueJobs: queueJobs.length,
      activeJobs: activeJobs.length,
      completedJobs: completedJobs.length,
      todayRevenue,
      lowStockItems: inventoryItems.filter(item => item.stock <= item.lowStockThreshold).length
    };
  };

  const navigation = [
    { id: 'dashboard', label: 'Dashboard', icon: 'speedometer' as const, active: currentView === 'dashboard', onPress: () => setCurrentView('dashboard') },
    { id: 'queue', label: 'Print Queue', icon: 'list' as const, active: currentView === 'queue', onPress: () => setCurrentView('queue') },
    { id: 'customers', label: 'Customer Service', icon: 'people' as const, active: currentView === 'customers', onPress: () => setCurrentView('customers') },
    { id: 'inventory', label: 'Inventory', icon: 'cube' as const, active: currentView === 'inventory', onPress: () => setCurrentView('inventory') },
    { id: 'reports', label: 'Reports', icon: 'document-text' as const, active: currentView === 'reports', onPress: () => setCurrentView('reports') },
    { id: 'settings', label: 'Settings', icon: 'settings' as const, active: currentView === 'settings', onPress: () => setCurrentView('settings') },
  ];

  const actions = [
    { id: 'refresh', label: 'Refresh', icon: 'refresh' as const, variant: 'secondary' as const, onPress: onRefresh },
    { id: 'emergency', label: 'Emergency Stop', icon: 'stop-circle' as const, variant: 'danger' as const, onPress: () => Alert.alert('Emergency Stop', 'All printers stopped') },
  ];

  const renderDashboardView = () => {
    const stats = getDashboardStats();
    
    return (
      <ScrollView style={{ flex: 1 }} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}>
        {/* Stats Cards */}
        <View style={{ flexDirection: 'row', gap: 16, marginBottom: 24 }}>
          <StatCard title="Today's Jobs" value={stats.todayJobs.toString()} icon="calendar" color="#3B82F6" />
          <StatCard title="In Queue" value={stats.queueJobs.toString()} icon="list" color="#F59E0B" />
          <StatCard title="Printing" value={stats.activeJobs.toString()} icon="print" color="#10B981" />
          <StatCard title="Revenue Today" value={`₱${(stats.todayRevenue / 100).toFixed(2)}`} icon="cash" color="#8B5CF6" />
        </View>

        {/* Quick Actions */}
        <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 24, marginBottom: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
          <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginBottom: 16 }}>Quick Actions</Text>
          <View style={{ flexDirection: 'row', gap: 12 }}>
            <QuickActionButton title="New Walk-in Order" icon="add-circle" color="#10B981" onPress={() => Alert.alert('New Order', 'Walk-in order creation')} />
            <QuickActionButton title="Check Printer Status" icon="hardware-chip" color="#3B82F6" onPress={() => Alert.alert('Printer Status', 'All printers online')} />
            <QuickActionButton title="Customer Assistance" icon="help-circle" color="#8B5CF6" onPress={() => setCurrentView('customers')} />
            <QuickActionButton title="View Reports" icon="bar-chart" color="#F59E0B" onPress={() => setCurrentView('reports')} />
          </View>
        </View>

        {/* Active Jobs Summary */}
        <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
          <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginBottom: 16 }}>Active Jobs</Text>
          {printJobs.filter(job => job.status === 'ongoing' || job.status === 'queue').slice(0, 5).map((job) => (
            <JobSummaryRow key={job.id} job={job} onPress={() => { setSelectedJob(job); setShowJobDetails(true); }} />
          ))}
        </View>
      </ScrollView>
    );
  };

  const renderQueueView = () => (
    <ScrollView style={{ flex: 1 }} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}>
      <View style={{ flexDirection: 'row', gap: 16, marginBottom: 24 }}>
        <View style={{ flex: 1, backgroundColor: 'white', borderRadius: 12, padding: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
          <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginBottom: 16 }}>Print Queue</Text>
          {printJobs.filter(job => job.status === 'queue').map((job) => (
            <QueueJobCard key={job.id} job={job} onUpdateStatus={updateJobStatus} />
          ))}
        </View>
        <View style={{ flex: 1, backgroundColor: 'white', borderRadius: 12, padding: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
          <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginBottom: 16 }}>Currently Printing</Text>
          {printJobs.filter(job => job.status === 'ongoing').map((job) => (
            <ActiveJobCard key={job.id} job={job} onUpdateStatus={updateJobStatus} />
          ))}
        </View>
      </View>
    </ScrollView>
  );

  const renderCustomerServiceView = () => (
    <ScrollView style={{ flex: 1 }}>
      <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 24, borderWidth: 1, borderColor: '#E5E7EB', marginBottom: 24 }}>
        <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginBottom: 16 }}>Customer Search</Text>
        <TextInput
          style={{ borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, padding: 12, fontSize: 16, marginBottom: 16 }}
          placeholder="Search by name, phone, or order ID..."
          value={customerSearch}
          onChangeText={setCustomerSearch}
        />
        <View style={{ flexDirection: 'row', gap: 12, marginBottom: 16 }}>
          <Pressable style={{ backgroundColor: '#3B82F6', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8 }}>
            <Text style={{ color: 'white', fontWeight: '600' }}>Search Orders</Text>
          </Pressable>
          <Pressable style={{ backgroundColor: '#10B981', paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8 }}>
            <Text style={{ color: 'white', fontWeight: '600' }}>New Walk-in Order</Text>
          </Pressable>
        </View>
      </View>

      <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
        <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginBottom: 16 }}>Recent Customer Interactions</Text>
        {printJobs.slice(0, 8).map((job) => (
          <CustomerInteractionRow key={job.id} job={job} />
        ))}
      </View>
    </ScrollView>
  );

  const renderInventoryView = () => (
    <ScrollView style={{ flex: 1 }}>
      <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 24, borderWidth: 1, borderColor: '#E5E7EB', marginBottom: 24 }}>
        <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginBottom: 16 }}>Inventory Status</Text>
        {inventoryItems.map((item) => (
          <InventoryRow key={item.id} item={item} />
        ))}
      </View>
    </ScrollView>
  );

  const renderReportsView = () => {
    const stats = getDashboardStats();
    const weeklyJobs = printJobs.filter(job => {
      const jobDate = new Date(job.createdAt);
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      return jobDate >= weekAgo;
    });

    return (
      <ScrollView style={{ flex: 1 }}>
        <View style={{ flexDirection: 'row', gap: 16, marginBottom: 24 }}>
          <ReportCard title="Daily Revenue" value={`₱${(stats.todayRevenue / 100).toFixed(2)}`} change="+12%" changeType="positive" />
          <ReportCard title="Weekly Jobs" value={weeklyJobs.length.toString()} change="+8%" changeType="positive" />
          <ReportCard title="Success Rate" value="94%" change="+2%" changeType="positive" />
          <ReportCard title="Avg Job Value" value={`₱${printJobs.length > 0 ? (printJobs.reduce((sum, job) => sum + job.totalPrice, 0) / printJobs.length / 100).toFixed(2) : '0.00'}`} change="+5%" changeType="positive" />
        </View>

        <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 24, borderWidth: 1, borderColor: '#E5E7EB' }}>
          <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginBottom: 16 }}>Performance Metrics</Text>
          <View style={{ gap: 12 }}>
            <MetricRow label="Orders Processed Today" value={stats.todayJobs.toString()} />
            <MetricRow label="Average Processing Time" value="8 minutes" />
            <MetricRow label="Customer Satisfaction" value="4.8/5" />
            <MetricRow label="Peak Hours" value="2PM - 4PM" />
            <MetricRow label="Most Popular Service" value="Document Printing" />
          </View>
        </View>
      </ScrollView>
    );
  };

  const renderCurrentView = () => {
    switch (currentView) {
      case 'dashboard': return renderDashboardView();
      case 'queue': return renderQueueView();
      case 'customers': return renderCustomerServiceView();
      case 'inventory': return renderInventoryView();
      case 'reports': return renderReportsView();
      case 'settings': return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <Text style={{ fontSize: 18, color: '#6B7280' }}>Operator Settings Panel</Text>
        </View>
      );
      default: return renderDashboardView();
    }
  };

  return (
    <DesktopLayout
      title="Operator Dashboard"
      subtitle="Store operations and order management"
      userInfo={{
        name: currentUser?.name || 'Operator',
        role: 'operator'
      }}
      navigation={navigation}
      actions={actions}
      onLogout={logout}
    >
      {renderCurrentView()}
      
      {/* Job Details Modal */}
      <Modal visible={showJobDetails} animationType="slide" presentationStyle="pageSheet">
        {selectedJob && (
          <JobDetailsModal 
            job={selectedJob} 
            onClose={() => setShowJobDetails(false)}
            onUpdateStatus={updateJobStatus}
          />
        )}
      </Modal>
    </DesktopLayout>
  );
}

// Helper Components
function StatCard({ title, value, icon, color }: { title: string; value: string; icon: any; color: string }) {
  return (
    <View style={{ flex: 1, backgroundColor: 'white', borderRadius: 12, padding: 20, borderWidth: 1, borderColor: '#E5E7EB' }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <View>
          <Text style={{ fontSize: 14, color: '#6B7280', marginBottom: 4 }}>{title}</Text>
          <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#111827' }}>{value}</Text>
        </View>
        <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: color + '20', alignItems: 'center', justifyContent: 'center' }}>
          <Ionicons name={icon} size={20} color={color} />
        </View>
      </View>
    </View>
  );
}

function QuickActionButton({ title, icon, color, onPress }: { title: string; icon: any; color: string; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={{ flex: 1, backgroundColor: color + '10', borderRadius: 8, padding: 16, alignItems: 'center' }}>
      <Ionicons name={icon} size={24} color={color} style={{ marginBottom: 8 }} />
      <Text style={{ fontSize: 12, fontWeight: '600', color: color, textAlign: 'center' }}>{title}</Text>
    </Pressable>
  );
}

function JobSummaryRow({ job, onPress }: { job: any; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' }}>
      <View>
        <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827' }}>#{job.id.slice(-6)} - {job.customerInfo.name}</Text>
        <Text style={{ fontSize: 12, color: '#6B7280' }}>{job.files.length} files • ₱{(job.totalPrice / 100).toFixed(2)}</Text>
      </View>
      <View style={{ paddingHorizontal: 12, paddingVertical: 4, borderRadius: 12, backgroundColor: job.status === 'ongoing' ? '#DBEAFE' : '#FEF3C7' }}>
        <Text style={{ fontSize: 12, fontWeight: '600', color: job.status === 'ongoing' ? '#1D4ED8' : '#D97706' }}>
          {job.status.charAt(0).toUpperCase() + job.status.slice(1)}
        </Text>
      </View>
    </Pressable>
  );
}

function QueueJobCard({ job, onUpdateStatus }: { job: any; onUpdateStatus: (id: string, status: any) => void }) {
  return (
    <View style={{ borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 16, marginBottom: 12 }}>
      <Text style={{ fontSize: 16, fontWeight: '600', color: '#111827', marginBottom: 8 }}>#{job.id.slice(-6)}</Text>
      <Text style={{ fontSize: 14, color: '#6B7280', marginBottom: 8 }}>{job.customerInfo.name} • {job.files.length} files</Text>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Pressable onPress={() => onUpdateStatus(job.id, 'ongoing')} style={{ backgroundColor: '#10B981', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6 }}>
          <Text style={{ color: 'white', fontSize: 12, fontWeight: '600' }}>Start Printing</Text>
        </Pressable>
        <Pressable onPress={() => onUpdateStatus(job.id, 'failed')} style={{ backgroundColor: '#DC2626', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6 }}>
          <Text style={{ color: 'white', fontSize: 12, fontWeight: '600' }}>Mark Failed</Text>
        </Pressable>
      </View>
    </View>
  );
}

function ActiveJobCard({ job, onUpdateStatus }: { job: any; onUpdateStatus: (id: string, status: any) => void }) {
  return (
    <View style={{ borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 16, marginBottom: 12 }}>
      <Text style={{ fontSize: 16, fontWeight: '600', color: '#111827', marginBottom: 8 }}>#{job.id.slice(-6)}</Text>
      <Text style={{ fontSize: 14, color: '#6B7280', marginBottom: 8 }}>{job.customerInfo.name} • Printing...</Text>
      <View style={{ backgroundColor: '#DBEAFE', height: 4, borderRadius: 2, marginBottom: 8 }}>
        <View style={{ backgroundColor: '#3B82F6', height: 4, borderRadius: 2, width: '65%' }} />
      </View>
      <Pressable onPress={() => onUpdateStatus(job.id, 'ready')} style={{ backgroundColor: '#8B5CF6', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6 }}>
        <Text style={{ color: 'white', fontSize: 12, fontWeight: '600' }}>Mark Ready</Text>
      </Pressable>
    </View>
  );
}

function CustomerInteractionRow({ job }: { job: any }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' }}>
      <View>
        <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827' }}>{job.customerInfo.name}</Text>
        <Text style={{ fontSize: 12, color: '#6B7280' }}>#{job.id.slice(-6)} • {new Date(job.createdAt).toLocaleDateString()}</Text>
      </View>
      <Pressable style={{ backgroundColor: '#3B82F6', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6 }}>
        <Text style={{ color: 'white', fontSize: 12, fontWeight: '600' }}>View Details</Text>
      </Pressable>
    </View>
  );
}

function InventoryRow({ item }: { item: any }) {
  const isLowStock = item.stock <= item.lowStockThreshold;
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' }}>
      <View>
        <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827' }}>{item.name}</Text>
        <Text style={{ fontSize: 12, color: '#6B7280' }}>Threshold: {item.lowStockThreshold} {item.unit}</Text>
      </View>
      <View style={{ alignItems: 'flex-end' }}>
        <Text style={{ fontSize: 16, fontWeight: '600', color: isLowStock ? '#DC2626' : '#111827' }}>
          {item.stock} {item.unit}
        </Text>
        {isLowStock && <Text style={{ fontSize: 10, color: '#DC2626', fontWeight: '600' }}>LOW STOCK</Text>}
      </View>
    </View>
  );
}

function ReportCard({ title, value, change, changeType }: { title: string; value: string; change: string; changeType: 'positive' | 'negative' }) {
  return (
    <View style={{ flex: 1, backgroundColor: 'white', borderRadius: 12, padding: 20, borderWidth: 1, borderColor: '#E5E7EB' }}>
      <Text style={{ fontSize: 14, color: '#6B7280', marginBottom: 4 }}>{title}</Text>
      <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#111827', marginBottom: 4 }}>{value}</Text>
      <Text style={{ fontSize: 12, color: changeType === 'positive' ? '#10B981' : '#DC2626' }}>{change}</Text>
    </View>
  );
}

function MetricRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
      <Text style={{ fontSize: 14, color: '#6B7280' }}>{label}</Text>
      <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827' }}>{value}</Text>
    </View>
  );
}

function JobDetailsModal({ job, onClose, onUpdateStatus }: { job: any; onClose: () => void; onUpdateStatus: (id: string, status: any) => void }) {
  return (
    <View style={{ flex: 1, backgroundColor: 'white' }}>
      <View style={{ padding: 24, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Text style={{ fontSize: 20, fontWeight: '600', color: '#111827' }}>Job #{job.id.slice(-6)}</Text>
          <Pressable onPress={onClose}>
            <Ionicons name="close" size={24} color="#6B7280" />
          </Pressable>
        </View>
      </View>
      <ScrollView style={{ flex: 1, padding: 24 }}>
        <Text style={{ fontSize: 16, fontWeight: '600', color: '#111827', marginBottom: 16 }}>Customer: {job.customerInfo.name}</Text>
        <Text style={{ fontSize: 14, color: '#6B7280', marginBottom: 16 }}>Phone: {job.customerInfo.phone}</Text>
        <Text style={{ fontSize: 14, color: '#6B7280', marginBottom: 16 }}>Files: {job.files.length}</Text>
        <Text style={{ fontSize: 14, color: '#6B7280', marginBottom: 16 }}>Total: ₱{(job.totalPrice / 100).toFixed(2)}</Text>
        <Text style={{ fontSize: 14, color: '#6B7280', marginBottom: 16 }}>Status: {job.status}</Text>
      </ScrollView>
    </View>
  );
}