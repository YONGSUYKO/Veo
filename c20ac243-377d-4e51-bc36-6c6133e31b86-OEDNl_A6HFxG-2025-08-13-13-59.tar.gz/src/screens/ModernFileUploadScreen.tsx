import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, ScrollView, Alert, Animated, Dimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { useNewAppStore, FileInfo } from '../state/newAppStore';
import { newApiClient } from '../api/newPisoAPI';
import LoadingSpinner from '../components/LoadingSpinner';
import { cn } from '../utils/cn';

interface ModernFileUploadScreenProps {
  serviceType: 'document' | 'scan' | 'photo';
  onFilesProcessed: (files: FileInfo[]) => void;
  onBack: () => void;
}

const { width, height } = Dimensions.get('window');

export default function ModernFileUploadScreen({ 
  serviceType, 
  onFilesProcessed, 
  onBack 
}: ModernFileUploadScreenProps) {
  const insets = useSafeAreaInsets();
  const [selectedFiles, setSelectedFiles] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [cameraPermission, requestCameraPermission] = useCameraPermissions();
  
  // Animations
  const [fadeAnim] = useState(new Animated.Value(0));
  const [slideAnim] = useState(new Animated.Value(30));
  const [pulseAnim] = useState(new Animated.Value(1));

  useEffect(() => {
    // Entrance animation
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 600,
        useNativeDriver: true,
      }),
    ]).start();

    // Pulse animation for empty state
    if (selectedFiles.length === 0) {
      const pulseAnimation = () => {
        Animated.sequence([
          Animated.timing(pulseAnim, {
            toValue: 1.05,
            duration: 1500,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1,
            duration: 1500,
            useNativeDriver: true,
          }),
        ]).start(() => {
          if (selectedFiles.length === 0) pulseAnimation();
        });
      };
      pulseAnimation();
    }
  }, [selectedFiles.length]);

  const getServiceConfig = () => {
    switch (serviceType) {
      case 'document':
        return {
          title: '📄 Upload Documents',
          subtitle: 'PDFs, Word docs, presentations, and more',
          gradient: ['#667eea', '#764ba2'],
          emoji: '📚',
        };
      case 'scan':
        return {
          title: '📸 Scan & Print',
          subtitle: 'Capture documents with your camera',
          gradient: ['#f093fb', '#f5576c'],
          emoji: '🔍',
        };
      case 'photo':
        return {
          title: '🖼️ Print Photos',
          subtitle: 'Select from gallery or take new photos',
          gradient: ['#4facfe', '#00f2fe'],
          emoji: '📷',
        };
      default:
        return {
          title: 'Upload Files',
          subtitle: 'Select files to print',
          gradient: ['#667eea', '#764ba2'],
          emoji: '📁',
        };
    }
  };

  const config = getServiceConfig();

  const handleDocumentPick = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: serviceType === 'photo' ? 'image/*' : ['application/*', 'text/*', 'image/*'],
        multiple: true,
      });

      if (!result.canceled) {
        const newFiles = result.assets.map(asset => ({
          ...asset,
          id: Date.now() + Math.random(),
        }));
        setSelectedFiles([...selectedFiles, ...newFiles]);
      }
    } catch (error) {
      Alert.alert('Oops! 😅', 'Failed to select files. Please try again.');
    }
  };

  const handleImagePick = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsMultipleSelection: true,
        quality: 1,
      });

      if (!result.canceled) {
        const newFiles = result.assets.map(asset => ({
          ...asset,
          id: Date.now() + Math.random(),
        }));
        setSelectedFiles([...selectedFiles, ...newFiles]);
      }
    } catch (error) {
      Alert.alert('Oops! 😅', 'Failed to select images. Please try again.');
    }
  };

  const handleCameraCapture = async () => {
    if (!cameraPermission) {
      const permission = await requestCameraPermission();
      if (!permission.granted) {
        Alert.alert(
          'Camera Permission Needed 📷', 
          'We need camera access to scan documents. Please enable it in your settings.',
          [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Open Settings', onPress: () => {} }
          ]
        );
        return;
      }
    }

    if (!cameraPermission?.granted) {
      Alert.alert('Camera Permission Needed 📷', 'Please enable camera access to continue.');
      return;
    }

    setShowCamera(true);
  };

  const takePicture = async (cameraRef: any) => {
    try {
      const photo = await cameraRef.takePictureAsync({
        quality: 0.8,
      });
      
      const newFile = {
        id: Date.now(),
        name: `${serviceType}_${Date.now()}.jpg`,
        uri: photo.uri,
        type: 'image/jpeg',
        mimeType: 'image/jpeg',
        size: 0,
      };
      
      setSelectedFiles([...selectedFiles, newFile]);
      setShowCamera(false);
    } catch (error) {
      Alert.alert('Oops! 😅', 'Failed to take picture. Please try again.');
    }
  };

  const processFiles = async () => {
    if (selectedFiles.length === 0) {
      Alert.alert('No Files Selected 📝', 'Please select at least one file to continue.');
      return;
    }

    setLoading(true);
    try {
      const processed: FileInfo[] = [];
      
      for (const file of selectedFiles) {
        const fileInfo = await newApiClient.analyzeFile(file);
        processed.push(fileInfo);
      }
      
      onFilesProcessed(processed);
    } catch (error) {
      Alert.alert('Processing Error 😞', 'Failed to process files. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const removeFile = (fileId: any) => {
    setSelectedFiles(selectedFiles.filter(file => file.id !== fileId));
  };

  if (loading) {
    return (
      <View className="flex-1" style={{ backgroundColor: '#0F0F23' }}>
        <LinearGradient
          colors={config.gradient as any}
          className="absolute inset-0"
        />
        <View className="flex-1 items-center justify-center px-8">
          <Animated.View
            style={{
              transform: [{
                rotate: fadeAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: ['0deg', '360deg'],
                })
              }]
            }}
          >
            <LinearGradient
              colors={['rgba(255,255,255,0.3)', 'rgba(255,255,255,0.1)']}
              className="w-24 h-24 rounded-full items-center justify-center mb-8"
            >
              <Text className="text-4xl">{config.emoji}</Text>
            </LinearGradient>
          </Animated.View>
          
          <Text className="text-white font-black text-2xl mb-2 text-center">
            Processing your files...
          </Text>
          <Text className="text-white/70 text-lg text-center">
            Analyzing and optimizing for print ✨
          </Text>
        </View>
      </View>
    );
  }

  if (showCamera) {
    let cameraRef: any;
    
    return (
      <View className="flex-1 bg-black">
        <CameraView 
          style={{ flex: 1 }}
          facing="back"
          ref={(ref) => { cameraRef = ref; }}
        />
        
        {/* Camera Overlay */}
        <LinearGradient
          colors={['rgba(0,0,0,0.8)', 'transparent', 'rgba(0,0,0,0.8)']}
          className="absolute inset-0"
        />
        
        {/* Top Bar */}
        <View 
          className="absolute top-0 left-0 right-0 flex-row items-center justify-between p-6"
          style={{ paddingTop: insets.top + 20 }}
        >
          <Pressable 
            onPress={() => setShowCamera(false)}
            className="w-12 h-12 bg-black/50 rounded-full items-center justify-center"
            accessibilityRole="button"
            accessibilityLabel="Close camera"
          >
            <Ionicons name="close" size={24} color="white" />
          </Pressable>
          
          <Text className="text-white font-bold text-lg">
            {serviceType === 'scan' ? 'Scan Document' : 'Take Photo'}
          </Text>
          
          <View className="w-12" />
        </View>

        {/* Bottom Controls */}
        <View 
          className="absolute bottom-0 left-0 right-0 pb-12 px-8"
          style={{ paddingBottom: Math.max(insets.bottom, 48) }}
        >
          <View className="items-center">
            <Text className="text-white/80 text-center mb-8 text-lg">
              Position your {serviceType === 'scan' ? 'document' : 'subject'} in the frame
            </Text>
            
            <View className="flex-row items-center justify-center space-x-8">
              <Pressable 
                onPress={() => setShowCamera(false)}
                className="w-16 h-16 bg-white/20 rounded-full items-center justify-center"
                accessibilityRole="button"
                accessibilityLabel="Cancel"
              >
                <Ionicons name="close" size={24} color="white" />
              </Pressable>

              <Pressable 
                onPress={() => takePicture(cameraRef)}
                className="w-20 h-20 bg-white rounded-full items-center justify-center border-4 border-white/30"
                accessibilityRole="button"
                accessibilityLabel="Take picture"
              >
                <View className="w-16 h-16 bg-white rounded-full" />
              </Pressable>

              <Pressable 
                className="w-16 h-16 bg-white/20 rounded-full items-center justify-center"
                accessibilityRole="button"
                accessibilityLabel="Flash toggle"
              >
                <Ionicons name="flash" size={24} color="white" />
              </Pressable>
            </View>
          </View>
        </View>
      </View>
    );
  }

  return (
    <View className="flex-1" style={{ backgroundColor: '#0F0F23' }}>
      <LinearGradient
        colors={[config.gradient[0], config.gradient[1], config.gradient[0]] as any}
        locations={[0, 0.7, 1]}
        className="absolute inset-0"
      />

      <Animated.View
        style={{
          flex: 1,
          opacity: fadeAnim,
          transform: [{ translateY: slideAnim }]
        }}
      >
        {/* Header */}
        <View 
          className="flex-row items-center px-6 pt-4"
          style={{ paddingTop: insets.top + 16 }}
        >
          <Pressable 
            onPress={onBack} 
            className="w-12 h-12 bg-white/20 rounded-2xl items-center justify-center mr-4"
            accessibilityRole="button"
            accessibilityLabel="Go back"
          >
            <Ionicons name="arrow-back" size={24} color="white" />
          </Pressable>
          
          <View className="flex-1">
            <Text className="text-white font-black text-2xl">
              {config.title}
            </Text>
            <Text className="text-white/80 font-medium text-base">
              {config.subtitle}
            </Text>
          </View>

          <View className="w-12 h-12 bg-white/20 rounded-2xl items-center justify-center">
            <Text className="text-2xl">{config.emoji}</Text>
          </View>
        </View>

        <ScrollView className="flex-1 px-6" showsVerticalScrollIndicator={false}>
          
          {/* Upload Options */}
          <View className="mt-8 mb-6 space-y-4">
            {serviceType === 'document' && (
              <>
                <ModernUploadOption
                  icon="folder-open"
                  title="Browse Files"
                  subtitle="From device storage"
                  gradient={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0.05)']}
                  onPress={handleDocumentPick}
                  delay={0}
                />
                <ModernUploadOption
                  icon="scan"
                  title="Scan Document"
                  subtitle="Use camera to capture"
                  gradient={['rgba(255,255,255,0.15)', 'rgba(255,255,255,0.05)']}
                  onPress={handleCameraCapture}
                  delay={200}
                />
              </>
            )}

            {serviceType === 'scan' && (
              <ModernUploadOption
                icon="camera"
                title="Scan Document"
                subtitle="Capture with camera"
                gradient={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0.05)']}
                onPress={handleCameraCapture}
                delay={0}
              />
            )}

            {serviceType === 'photo' && (
              <>
                <ModernUploadOption
                  icon="images"
                  title="Choose from Gallery"
                  subtitle="Select existing photos"
                  gradient={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0.05)']}
                  onPress={handleImagePick}
                  delay={0}
                />
                <ModernUploadOption
                  icon="camera"
                  title="Take Photo"
                  subtitle="Capture new memories"
                  gradient={['rgba(255,255,255,0.15)', 'rgba(255,255,255,0.05)']}
                  onPress={handleCameraCapture}
                  delay={200}
                />
              </>
            )}
          </View>

          {/* Selected Files */}
          {selectedFiles.length > 0 ? (
            <View className="mb-8">
              <View className="flex-row items-center justify-between mb-6">
                <Text className="text-white font-black text-xl">
                  Selected Files ✨
                </Text>
                <View className="bg-white/20 rounded-full px-3 py-1">
                  <Text className="text-white font-bold text-sm">
                    {selectedFiles.length}
                  </Text>
                </View>
              </View>
              
              <View className="space-y-3">
                {selectedFiles.map((file, index) => (
                  <ModernFileCard
                    key={file.id}
                    file={file}
                    index={index}
                    onRemove={() => removeFile(file.id)}
                  />
                ))}
              </View>

              {/* Process Button */}
              <Pressable 
                onPress={processFiles}
                className="rounded-2xl overflow-hidden mt-8"
                accessibilityRole="button"
                accessibilityLabel={`Process ${selectedFiles.length} files`}
              >
                <LinearGradient
                  colors={['rgba(255,255,255,0.9)', 'rgba(255,255,255,0.8)']}
                  className="py-5 items-center"
                >
                  <Text className="font-black text-xl" style={{ color: config.gradient[0] }}>
                    Process {selectedFiles.length} {selectedFiles.length === 1 ? 'File' : 'Files'} 🚀
                  </Text>
                </LinearGradient>
              </Pressable>
            </View>
          ) : (
            // Empty State
            <Animated.View 
              className="flex-1 items-center justify-center py-16"
              style={{ transform: [{ scale: pulseAnim }] }}
            >
              <View className="items-center">
                <View 
                  className="w-32 h-32 rounded-3xl items-center justify-center mb-6"
                  style={{ backgroundColor: 'rgba(255,255,255,0.1)' }}
                >
                  <Text className="text-6xl">{config.emoji}</Text>
                </View>
                
                <Text className="text-white font-black text-2xl mb-3 text-center">
                  No files yet
                </Text>
                <Text className="text-white/70 text-lg text-center leading-relaxed px-8">
                  Tap an option above to get started with your printing request
                </Text>
              </View>
            </Animated.View>
          )}

        </ScrollView>
      </Animated.View>
    </View>
  );
}

interface ModernUploadOptionProps {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  subtitle: string;
  gradient: string[];
  onPress: () => void;
  delay: number;
}

function ModernUploadOption({ icon, title, subtitle, gradient, onPress, delay }: ModernUploadOptionProps) {
  const [animValue] = useState(new Animated.Value(0));
  const [pressAnim] = useState(new Animated.Value(1));

  useEffect(() => {
    setTimeout(() => {
      Animated.timing(animValue, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }).start();
    }, delay);
  }, []);

  const handlePress = () => {
    Animated.sequence([
      Animated.timing(pressAnim, {
        toValue: 0.95,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(pressAnim, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();
    
    setTimeout(onPress, 150);
  };

  return (
    <Animated.View
      style={{
        opacity: animValue,
        transform: [
          { scale: pressAnim },
          { 
            translateX: animValue.interpolate({
              inputRange: [0, 1],
              outputRange: [-50, 0],
            })
          }
        ],
      }}
    >
      <Pressable 
        onPress={handlePress}
        accessibilityRole="button"
        accessibilityLabel={`${title}: ${subtitle}`}
        accessibilityHint="Tap to select files"
      >
        <LinearGradient
          colors={gradient as any}
          className="rounded-2xl p-6 border border-white/10"
        >
          <View className="flex-row items-center">
            <View className="w-16 h-16 bg-white/20 rounded-2xl items-center justify-center mr-5">
              <Ionicons name={icon} size={28} color="white" />
            </View>
            
            <View className="flex-1">
              <Text className="text-white font-bold text-lg mb-1">
                {title}
              </Text>
              <Text className="text-white/80 font-medium">
                {subtitle}
              </Text>
            </View>
            
            <View className="w-10 h-10 bg-white/20 rounded-xl items-center justify-center">
              <Ionicons name="chevron-forward" size={20} color="white" />
            </View>
          </View>
        </LinearGradient>
      </Pressable>
    </Animated.View>
  );
}

function ModernFileCard({ file, index, onRemove }: { file: any; index: number; onRemove: () => void }) {
  const [animValue] = useState(new Animated.Value(0));

  useEffect(() => {
    Animated.timing(animValue, {
      toValue: 1,
      duration: 400,
      delay: index * 100,
      useNativeDriver: true,
    }).start();
  }, []);

  const getFileIcon = (file: any) => {
    if (file.type?.includes('pdf') || file.mimeType?.includes('pdf')) return 'document-text';
    if (file.type?.includes('image') || file.mimeType?.includes('image')) return 'image';
    if (file.type?.includes('word')) return 'document';
    return 'document-outline';
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return 'Unknown size';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  return (
    <Animated.View
      style={{
        opacity: animValue,
        transform: [{
          translateX: animValue.interpolate({
            inputRange: [0, 1],
            outputRange: [100, 0],
          })
        }]
      }}
    >
      <View 
        className="rounded-2xl p-4 border border-white/10"
        style={{ backgroundColor: 'rgba(255,255,255,0.1)' }}
      >
        <View className="flex-row items-center">
          <View className="w-12 h-12 bg-white/20 rounded-xl items-center justify-center mr-4">
            <Ionicons name={getFileIcon(file)} size={20} color="white" />
          </View>
          
          <View className="flex-1">
            <Text className="text-white font-bold text-base mb-1" numberOfLines={1}>
              {file.name}
            </Text>
            <Text className="text-white/70 text-sm">
              {formatFileSize(file.size || 0)}
            </Text>
          </View>
          
          <Pressable 
            onPress={onRemove} 
            className="w-10 h-10 bg-red-500/20 rounded-xl items-center justify-center"
            accessibilityRole="button"
            accessibilityLabel="Remove file"
          >
            <Ionicons name="trash-outline" size={18} color="#FF6B6B" />
          </Pressable>
        </View>
      </View>
    </Animated.View>
  );
}