import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  Pressable,
  StyleSheet,
  RefreshControl,
  TextInput,
  SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { StaffSupportOrder, OrderStatus } from '../types/staffSupportOrder';

interface OperatorDashboardNewProps {
  navigation: {
    navigate: (screen: string, params?: any) => void;
  };
}

const OperatorDashboardNew: React.FC<OperatorDashboardNewProps> = ({ navigation }) => {
  const [orders, setOrders] = useState<StaffSupportOrder[]>([]);
  const [filter, setFilter] = useState<OrderStatus | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    // Set up real-time subscription to orders
    const { staffSupportService } = require('../services/staffSupportService');
    const loadOrders = async () => {
      const ordersList = await staffSupportService.getAllOrders();
      setOrders(ordersList);
    };
    loadOrders();

    // Set up polling for real-time updates (in production, use Firebase real-time updates)
    const interval = setInterval(loadOrders, 3000);
    return () => clearInterval(interval);
  }, []);

  const getFilteredOrders = () => {
    let filtered = filter === 'all' ? orders : orders.filter(order => order.status === filter);
    
    if (searchQuery) {
      filtered = filtered.filter(order => 
        order.customerId?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        order.id.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    return filtered;
  };

  const getStatusColor = (status: OrderStatus) => {
    const colors: Record<OrderStatus, string> = {
      uploaded: '#ffc107',
      under_review: '#17a2b8',
      approved_for_payment: '#28a745',
      paid: '#6f42c1',
      printing: '#fd7e14',
      ready: '#20c997',
      completed: '#6c757d'
    };
    return colors[status] || '#6c757d';
  };

  const getStatusPriority = (status: OrderStatus) => {
    const priorities: Record<OrderStatus, number> = {
      uploaded: 1,
      under_review: 2,
      approved_for_payment: 3,
      paid: 4,
      printing: 5,
      ready: 6,
      completed: 7
    };
    return priorities[status] || 8;
  };

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      const { staffSupportService } = await import('../services/staffSupportService');
      const ordersList = await staffSupportService.getAllOrders();
      setOrders(ordersList);
    } catch (error) {
      console.error('Error refreshing orders:', error);
    } finally {
      setRefreshing(false);
    }
  };

  const renderOrderCard = ({ item: order }: { item: StaffSupportOrder }) => (
    <Pressable
      onPress={() => navigation.navigate('OperatorReview', { orderId: order.id })}
      style={[styles.orderCard, { borderLeftColor: getStatusColor(order.status) }]}
    >
      <View style={styles.orderHeader}>
        <Text style={styles.orderId}>#{order.id.slice(-6)}</Text>
        <View style={[styles.statusChip, { backgroundColor: getStatusColor(order.status) }]}>
          <Text style={styles.statusText}>
            {order.status.replace('_', ' ').toUpperCase()}
          </Text>
        </View>
      </View>
      
      <Text style={styles.customerInfo}>
        👤 {order.customerId}
      </Text>
      
      <View style={styles.orderDetails}>
        <Text style={styles.detailText}>📁 {order.files?.length || 0} files</Text>
        <Text style={styles.detailText}>💰 ₱{order.totalAmount || 'Not set'}</Text>
        <Text style={styles.detailText}>📅 {order.createdAt.toLocaleDateString()}</Text>
      </View>

      {order.completionTime && (
        <Text style={styles.completionTime}>
          ⏰ Due: {order.completionTime}
        </Text>
      )}
    </Pressable>
  );

  const filterButtons = [
    { key: 'all' as const, label: 'All', count: orders.length },
    { key: 'uploaded' as const, label: 'New', count: orders.filter(o => o.status === 'uploaded').length },
    { key: 'under_review' as const, label: 'Review', count: orders.filter(o => o.status === 'under_review').length },
    { key: 'approved_for_payment' as const, label: 'Approved', count: orders.filter(o => o.status === 'approved_for_payment').length },
    { key: 'paid' as const, label: 'Paid', count: orders.filter(o => o.status === 'paid').length },
    { key: 'printing' as const, label: 'Printing', count: orders.filter(o => o.status === 'printing').length },
    { key: 'ready' as const, label: 'Ready', count: orders.filter(o => o.status === 'ready').length }
  ];

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Print Orders Dashboard</Text>
      </View>

      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <Ionicons name="search" size={20} color="#666" style={styles.searchIcon} />
        <TextInput
          placeholder="Search orders, customers..."
          value={searchQuery}
          onChangeText={setSearchQuery}
          style={styles.searchInput}
        />
      </View>

      {/* Filter Buttons */}
      <View style={styles.filterContainer}>
        <FlatList
          horizontal
          data={filterButtons}
          showsHorizontalScrollIndicator={false}
          renderItem={({ item }) => (
            <Pressable
              style={[
                styles.filterButton,
                filter === item.key && styles.activeFilter
              ]}
              onPress={() => setFilter(item.key)}
            >
              <Text style={[
                styles.filterText,
                filter === item.key && styles.activeFilterText
              ]}>
                {item.label}
              </Text>
              {item.count > 0 && (
                <View style={styles.filterBadge}>
                  <Text style={styles.badgeText}>{item.count}</Text>
                </View>
              )}
            </Pressable>
          )}
          keyExtractor={item => item.key}
        />
      </View>

      {/* Orders List */}
      <FlatList
        data={getFilteredOrders().sort((a, b) => getStatusPriority(a.status) - getStatusPriority(b.status))}
        renderItem={renderOrderCard}
        keyExtractor={item => item.id}
        style={styles.ordersList}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Ionicons name="document-outline" size={64} color="#ccc" />
            <Text style={styles.emptyText}>No orders found</Text>
            <Text style={styles.emptySubText}>Orders will appear here when customers upload files</Text>
          </View>
        }
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5'
  },
  header: {
    backgroundColor: '#007bff',
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white'
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    margin: 16,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
  },
  filterContainer: {
    paddingHorizontal: 16,
    marginBottom: 16
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 8,
    backgroundColor: '#fff',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#e0e0e0'
  },
  activeFilter: {
    backgroundColor: '#007bff',
    borderColor: '#007bff'
  },
  filterText: {
    fontSize: 14,
    color: '#666'
  },
  activeFilterText: {
    color: 'white',
    fontWeight: 'bold'
  },
  filterBadge: {
    marginLeft: 6,
    backgroundColor: '#dc3545',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 10,
    minWidth: 20,
    alignItems: 'center'
  },
  badgeText: {
    color: 'white',
    fontSize: 10,
    fontWeight: 'bold'
  },
  ordersList: {
    flex: 1,
    paddingHorizontal: 16
  },
  orderCard: {
    backgroundColor: 'white',
    marginBottom: 12,
    padding: 16,
    borderLeftWidth: 4,
    borderRadius: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
  },
  orderHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8
  },
  orderId: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333'
  },
  statusChip: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    color: 'white',
    fontSize: 10,
    fontWeight: 'bold'
  },
  customerInfo: {
    fontSize: 13,
    color: '#666',
    marginBottom: 8
  },
  orderDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8
  },
  detailText: {
    fontSize: 12,
    color: '#666'
  },
  completionTime: {
    marginTop: 8,
    fontSize: 12,
    color: '#e67e22',
    fontWeight: '600'
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60
  },
  emptyText: {
    fontSize: 18,
    color: '#666',
    fontWeight: 'bold',
    marginTop: 16
  },
  emptySubText: {
    fontSize: 14,
    color: '#999',
    marginTop: 8,
    textAlign: 'center'
  }
});

export default OperatorDashboardNew;