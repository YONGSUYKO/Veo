import React, { useState } from 'react';
import { View, Text, Pressable, ScrollView, StyleSheet, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';

interface ServiceBrowserScreenProps {
  navigation?: any;
  route?: {
    params?: {
      serviceType?: string;
    };
  };
}

export default function ServiceBrowserScreen({ navigation, route }: ServiceBrowserScreenProps) {
  const insets = useSafeAreaInsets();
  const { isAuthenticated } = useAuthStore();
  const serviceType = route?.params?.serviceType || 'documents';
  const [selectedTab, setSelectedTab] = useState('overview');

  const serviceData = {
    documents: {
      title: 'Document Printing',
      description: 'Professional document printing for all your business and personal needs',
      icon: 'document-text',
      color: '#3B82F6',
      pricing: [
        { size: 'Letter (8.5" x 11")', bw: '₱1.00', color: '₱2.00' },
        { size: 'A4 (8.3" x 11.7")', bw: '₱1.00', color: '₱2.00' },
        { size: 'Legal (8.5" x 14")', bw: '₱1.50', color: '₱3.00' },
        { size: 'A3 (11.7" x 16.5")', bw: '₱2.00', color: '₱4.00' },
      ],
      features: [
        'High-quality laser printing',
        'Various paper sizes available',
        'Double-sided printing option',
        'Binding and lamination services',
        'Bulk printing discounts'
      ],
      samples: ['Resume', 'Business Reports', 'Contracts', 'Thesis Papers']
    },
    scan: {
      title: 'Scan & Print',
      description: 'Capture documents with your phone and get professional prints',
      icon: 'scan',
      color: '#10B981',
      pricing: [
        { size: 'Letter Scan', bw: '₱2.00', color: '₱3.00' },
        { size: 'A4 Scan', bw: '₱2.00', color: '₱3.00' },
        { size: 'Legal Scan', bw: '₱2.50', color: '₱4.00' },
        { size: 'A3 Scan', bw: '₱3.00', color: '₱5.00' },
      ],
      features: [
        'AI-powered edge detection',
        'Automatic quality enhancement',
        'Multiple page scanning',
        'PDF compilation',
        'Cloud storage integration'
      ],
      samples: ['ID Cards', 'Certificates', 'Old Documents', 'Book Pages']
    },
    photos: {
      title: 'Premium Photo Prints',
      description: 'High-quality photo printing for memories that last',
      icon: 'camera',
      color: '#8B5CF6',
      pricing: [
        { size: 'Wallet (1.75" x 2.5")', bw: '₱0.50', color: '₱0.50' },
        { size: '4R (4" x 6")', bw: '₱2.00', color: '₱2.00' },
        { size: '5R (5" x 7")', bw: '₱3.50', color: '₱3.50' },
        { size: '8R (8" x 10")', bw: '₱6.50', color: '₱6.50' },
      ],
      features: [
        'Professional photo paper',
        'Color correction included',
        'Various sizes available',
        'Matte or glossy finish',
        'Same-day printing'
      ],
      samples: ['Family Photos', 'Events', 'Portraits', 'Landscapes']
    },
    marketplace: {
      title: 'Marketplace',
      description: 'Office supplies, stationery, and printing accessories',
      icon: 'storefront',
      color: '#F59E0B',
      pricing: [
        { size: 'Ballpen (Blue/Black)', bw: '₱8.00', color: '₱8.00' },
        { size: 'Notebook (50 pages)', bw: '₱25.00', color: '₱25.00' },
        { size: 'Bond Paper (500 sheets)', bw: '₱280.00', color: '₱280.00' },
        { size: 'Folder (Plastic)', bw: '₱15.00', color: '₱15.00' },
      ],
      features: [
        'School and office supplies',
        'Printing materials',
        'Competitive prices',
        'Bulk order discounts',
        'Same-day availability'
      ],
      samples: ['Pens', 'Papers', 'Folders', 'Calculators']
    },
    rewards: {
      title: 'Loyalty Rewards',
      description: 'Earn points with every purchase and unlock exclusive benefits',
      icon: 'star',
      color: '#EC4899',
      pricing: [
        { size: 'Bronze Member', bw: '5% cashback', color: 'Free' },
        { size: 'Silver Member', bw: '10% cashback', color: '₱500 spending' },
        { size: 'Gold Member', bw: '15% cashback', color: '₱2000 spending' },
        { size: 'Platinum Member', bw: '20% cashback', color: '₱5000 spending' },
      ],
      features: [
        'Points for every peso spent',
        'Exclusive member discounts',
        'Priority printing service',
        'Free delivery perks',
        'Birthday rewards'
      ],
      samples: ['Cashback', 'Discounts', 'Free Services', 'Priority Queue']
    },
    subscription: {
      title: 'Print Plans',
      description: 'Monthly printing packages for regular users',
      icon: 'calendar',
      color: '#06B6D4',
      pricing: [
        { size: 'Basic Plan', bw: '100 pages/month', color: '₱150/month' },
        { size: 'Standard Plan', bw: '300 pages/month', color: '₱400/month' },
        { size: 'Premium Plan', bw: '500 pages/month', color: '₱600/month' },
        { size: 'Business Plan', bw: '1000 pages/month', color: '₱1000/month' },
      ],
      features: [
        'Monthly page allowances',
        'Discounted rates',
        'Rollover unused pages',
        'Priority support',
        'Free binding included'
      ],
      samples: ['Student Plans', 'Office Plans', 'Business Plans', 'Family Plans']
    },
    products: {
      title: 'Other Services',
      description: 'Business cards, flyers, and custom printing services',
      icon: 'briefcase',
      color: '#84CC16',
      pricing: [
        { size: 'Business Cards (100pcs)', bw: '₱150', color: '₱250' },
        { size: 'Flyers A4 (50pcs)', bw: '₱200', color: '₱350' },
        { size: 'Tarpaulin (2x3 ft)', bw: '₱180', color: '₱280' },
        { size: 'ID Cards (10pcs)', bw: '₱100', color: '₱150' },
      ],
      features: [
        'Custom designs available',
        'Professional templates',
        'Various materials',
        'Fast turnaround',
        'Bulk order discounts'
      ],
      samples: ['Business Cards', 'Flyers', 'Banners', 'ID Cards']
    },
    franchising: {
      title: 'Franchising Opportunity',
      description: 'Start your own PISO Print Express franchise and build a profitable business',
      icon: 'business',
      color: '#DC2626',
      pricing: [
        { size: 'Franchise Package A', bw: 'Small Town', color: '₱150,000' },
        { size: 'Franchise Package B', bw: 'City Location', color: '₱300,000' },
        { size: 'Franchise Package C', bw: 'Premium Mall', color: '₱500,000' },
        { size: 'Master Franchise', bw: 'Regional Rights', color: '₱1,000,000' },
      ],
      features: [
        'Complete business setup',
        'Training & ongoing support',
        'Marketing materials included',
        'Proven business model',
        'Territory protection',
        'Online system access',
        'Equipment package included',
        'Grand opening support'
      ],
      samples: ['Business Training', 'Marketing Kit', 'Equipment Setup', 'Ongoing Support']
    },
    pricing: {
      title: 'Complete Pricing Guide',
      description: 'Transparent pricing for all our printing and business services',
      icon: 'pricetag',
      color: '#7C3AED',
      pricing: [
        { size: 'Document Printing', bw: '₱1.00/page', color: '₱2.00/page' },
        { size: 'Photo Printing 4R', bw: '₱2.00/photo', color: '₱2.00/photo' },
        { size: 'Scan & Print', bw: '₱2.00/page', color: '₱3.00/page' },
        { size: 'Business Cards', bw: '₱150/100pcs', color: '₱250/100pcs' },
      ],
      features: [
        'No hidden fees',
        'Bulk discounts available',
        'Loyalty points system',
        'Member exclusive rates',
        'Seasonal promotions',
        'Student discounts',
        'Corporate packages',
        'Free delivery over ₱50'
      ],
      samples: ['Print Pricing', 'Photo Rates', 'Business Services', 'Membership Benefits']
    }
  };

  const currentService = serviceData[serviceType as keyof typeof serviceData];

  if (!currentService) {
    return (
      <View style={styles.container}>
        <Text>Service not found</Text>
      </View>
    );
  }

  const getActionText = () => {
    switch (serviceType) {
      case 'documents': return isAuthenticated ? 'Print Documents' : 'Proceed to Print';
      case 'scan': return isAuthenticated ? 'Scan & Print' : 'Proceed to Scan';
      case 'photos': return isAuthenticated ? 'Print Photos' : 'Proceed to Photos';
      case 'marketplace': return isAuthenticated ? 'Shop Now' : 'Proceed to Shop';
      case 'rewards': return isAuthenticated ? 'View Rewards' : 'Proceed to Rewards';
      case 'subscription': return isAuthenticated ? 'View Plans' : 'Proceed to Plans';
      case 'products': return isAuthenticated ? 'Order Services' : 'Proceed to Services';
      case 'franchising': return 'View Franchise Info';
      case 'pricing': return 'View Complete Pricing';
      default: return isAuthenticated ? 'Order Now' : 'Proceed to Order';
    }
  };

  const handleOrderNow = () => {
    // Handle special services with dedicated screens
    if (serviceType === 'pricing') {
      navigation?.navigate('CompletePricing');
      return;
    }
    
    if (serviceType === 'franchising') {
      navigation?.navigate('Franchising');
      return;
    }
    
    // For browsing services (marketplace, rewards, subscription), show they need to login
    if (['marketplace', 'rewards', 'subscription'].includes(serviceType) && !isAuthenticated) {
      Alert.alert(
        'Login Required',
        `To access ${currentService.title.toLowerCase()}, please login or create an account first.`,
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Login', onPress: () => navigation?.navigate('Login') }
        ]
      );
      return;
    }
    
    // For printing services, show they need to login to place orders
    if (['documents', 'scan', 'photos', 'products'].includes(serviceType) && !isAuthenticated) {
      Alert.alert(
        'Login Required',
        'To place an order, please login or create an account first.',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Login', onPress: () => navigation?.navigate('Login') }
        ]
      );
      return;
    }
    
    // Proceed to file upload for authenticated users with printing services
    if (['documents', 'scan', 'photos', 'products'].includes(serviceType)) {
      navigation?.navigate('FileUpload', { serviceType });
      return;
    }
    
    // Handle specific services
    if (serviceType === 'marketplace') {
      navigation?.navigate('Marketplace');
      return;
    }
    
    if (serviceType === 'subscription') {
      navigation?.navigate('Subscriptions');
      return;
    }
    
    if (serviceType === 'franchising') {
      navigation?.navigate('Franchising');
      return;
    }
    
    if (serviceType === 'pricing') {
      navigation?.navigate('CompletePricing');
      return;
    }
    
    // For truly unavailable services
    Alert.alert('Service Info', `${currentService.title} - Contact us for more information about this service.`);
  };

  const handleLoginPrompt = () => {
    navigation?.navigate('Login');
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 20 }]}>
        <View style={styles.headerContent}>
          <Pressable onPress={() => navigation?.goBack()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color="white" />
          </Pressable>
          
          <View style={styles.headerInfo}>
            <View style={[styles.serviceIcon, { backgroundColor: 'rgba(255,255,255,0.2)' }]}>
              <Ionicons name={currentService.icon} size={24} color="white" />
            </View>
            <View style={styles.headerText}>
              <Text style={styles.headerTitle}>{currentService.title}</Text>
              <Text style={styles.headerSubtitle}>{currentService.description}</Text>
            </View>
          </View>
        </View>
      </View>

      {/* Content */}
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Tabs */}
        <View style={styles.tabsContainer}>
          <Pressable 
            style={[styles.tab, selectedTab === 'overview' && styles.activeTab]}
            onPress={() => setSelectedTab('overview')}
          >
            <Text style={[styles.tabText, selectedTab === 'overview' && styles.activeTabText]}>
              Overview
            </Text>
          </Pressable>
          <Pressable 
            style={[styles.tab, selectedTab === 'pricing' && styles.activeTab]}
            onPress={() => setSelectedTab('pricing')}
          >
            <Text style={[styles.tabText, selectedTab === 'pricing' && styles.activeTabText]}>
              Pricing
            </Text>
          </Pressable>
          <Pressable 
            style={[styles.tab, selectedTab === 'samples' && styles.activeTab]}
            onPress={() => setSelectedTab('samples')}
          >
            <Text style={[styles.tabText, selectedTab === 'samples' && styles.activeTabText]}>
              Samples
            </Text>
          </Pressable>
        </View>

        {/* Tab Content */}
        {selectedTab === 'overview' && (
          <View style={styles.tabContent}>
            <Text style={styles.sectionTitle}>Features & Benefits</Text>
            {currentService.features.map((feature, index) => (
              <View key={index} style={styles.featureItem}>
                <Ionicons name="checkmark-circle" size={16} color={currentService.color} />
                <Text style={styles.featureText}>{feature}</Text>
              </View>
            ))}
          </View>
        )}

        {selectedTab === 'pricing' && (
          <View style={styles.tabContent}>
            <Text style={styles.sectionTitle}>Pricing Information</Text>
            <View style={styles.pricingTable}>
              <View style={styles.pricingHeader}>
                <Text style={styles.pricingHeaderText}>Size/Type</Text>
                <Text style={styles.pricingHeaderText}>B&W</Text>
                <Text style={styles.pricingHeaderText}>Color</Text>
              </View>
              {currentService.pricing.map((item, index) => (
                <View key={index} style={styles.pricingRow}>
                  <Text style={styles.pricingCell}>{item.size}</Text>
                  <Text style={styles.pricingPrice}>{item.bw}</Text>
                  <Text style={styles.pricingPrice}>{item.color}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {selectedTab === 'samples' && (
          <View style={styles.tabContent}>
            <Text style={styles.sectionTitle}>Popular Uses</Text>
            <View style={styles.samplesGrid}>
              {currentService.samples.map((sample, index) => (
                <View key={index} style={styles.sampleCard}>
                  <Ionicons name="document" size={24} color={currentService.color} />
                  <Text style={styles.sampleText}>{sample}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Login Notice for Guests */}
        {!isAuthenticated && (
          <View style={styles.loginNotice}>
            <View style={styles.loginCard}>
              <Ionicons name="information-circle" size={24} color="#3B82F6" />
              <View style={styles.loginText}>
                <Text style={styles.loginTitle}>Ready to Proceed?</Text>
                <Text style={styles.loginDescription}>
                  Login or create an account to access full features and place orders.
                </Text>
                <Pressable style={styles.loginPromptButton} onPress={handleLoginPrompt}>
                  <Text style={styles.loginPromptText}>Login / Register</Text>
                  <Ionicons name="arrow-forward" size={16} color="#3B82F6" />
                </Pressable>
              </View>
            </View>
          </View>
        )}
      </ScrollView>

      {/* Bottom Action */}
      <View style={styles.bottomAction}>
        <Pressable 
          style={[styles.orderButton, { backgroundColor: currentService.color }]}
          onPress={handleOrderNow}
        >
          <Ionicons name="print" size={20} color="white" />
          <Text style={styles.orderButtonText}>
            {getActionText()}
          </Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    backgroundColor: '#3B82F6',
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButton: {
    padding: 8,
    marginRight: 12,
  },
  headerInfo: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  serviceIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  headerText: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  headerSubtitle: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    marginTop: 2,
  },
  content: {
    flex: 1,
  },
  tabsContainer: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  tab: {
    flex: 1,
    paddingVertical: 16,
    alignItems: 'center',
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: '#3B82F6',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#6B7280',
  },
  activeTabText: {
    color: '#3B82F6',
    fontWeight: '600',
  },
  tabContent: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 16,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  featureText: {
    fontSize: 14,
    color: '#374151',
    marginLeft: 8,
    flex: 1,
  },
  pricingTable: {
    backgroundColor: 'white',
    borderRadius: 8,
    overflow: 'hidden',
  },
  pricingHeader: {
    flexDirection: 'row',
    backgroundColor: '#F3F4F6',
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  pricingHeaderText: {
    flex: 1,
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
  },
  pricingRow: {
    flexDirection: 'row',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  pricingCell: {
    flex: 1,
    fontSize: 14,
    color: '#374151',
  },
  pricingPrice: {
    flex: 1,
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
  },
  samplesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  sampleCard: {
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
    width: '47%',
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  sampleText: {
    fontSize: 12,
    color: '#374151',
    marginTop: 8,
    textAlign: 'center',
  },
  loginNotice: {
    padding: 20,
  },
  loginCard: {
    backgroundColor: '#EFF6FF',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  loginText: {
    flex: 1,
    marginLeft: 12,
  },
  loginTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1E40AF',
    marginBottom: 4,
  },
  loginDescription: {
    fontSize: 12,
    color: '#1D4ED8',
    lineHeight: 18,
    marginBottom: 12,
  },
  loginPromptButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  loginPromptText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#3B82F6',
    marginRight: 4,
  },
  bottomAction: {
    padding: 20,
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
  },
  orderButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 12,
  },
  orderButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: 'white',
    marginLeft: 8,
  },
});