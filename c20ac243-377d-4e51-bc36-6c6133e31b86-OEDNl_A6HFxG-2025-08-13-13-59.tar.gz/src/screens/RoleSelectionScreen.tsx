import React, { useState } from 'react';
import { View, Text, Pressable, ScrollView, TextInput, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore, UserRole } from '../state/authStore';
import { newApiClient } from '../api/newPisoAPI';
import { cn } from '../utils/cn';

interface RoleSelectionScreenProps {
  onRoleSelected: () => void;
}

export default function RoleSelectionScreen({ onRoleSelected }: RoleSelectionScreenProps) {
  const insets = useSafeAreaInsets();
  const { login } = useAuthStore();
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);

  const roles: Array<{
    id: UserRole;
    title: string;
    description: string;
    icon: keyof typeof Ionicons.glyphMap;
    color: string;
    defaultEmail: string;
  }> = [
    {
      id: 'customer',
      title: 'Customer',
      description: 'Place printing orders and track your jobs',
      icon: 'person',
      color: 'bg-blue-500',
      defaultEmail: 'customer@example.com',
    },
    {
      id: 'operator',
      title: 'Store Operator',
      description: 'Process print jobs and serve customers',
      icon: 'construct',
      color: 'bg-green-500',
      defaultEmail: 'operator@pisoprint.com',
    },
    {
      id: 'admin',
      title: 'Administrator',
      description: 'Manage store settings and operations',
      icon: 'settings',
      color: 'bg-red-500',
      defaultEmail: 'admin@pisoprint.com',
    },
  ];

  const handleRoleSelect = (role: UserRole) => {
    setSelectedRole(role);
    const roleData = roles.find(r => r.id === role);
    if (roleData) {
      setEmail(roleData.defaultEmail);
    }
  };

  const handleLogin = async () => {
    if (!selectedRole) {
      Alert.alert('Role Required', 'Please select your role to continue');
      return;
    }

    if (!email.trim()) {
      Alert.alert('Email Required', 'Please enter an email address');
      return;
    }

    if (!email.includes('@')) {
      Alert.alert('Invalid Email', 'Please enter a valid email address');
      return;
    }

    setLoading(true);
    try {
      const user = await newApiClient.authenticateUser(email.trim(), selectedRole);
      login(user);
      onRoleSelected();
    } catch (error) {
      Alert.alert('Authentication Error', 'Failed to authenticate. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView className="flex-1 bg-white">
      <View style={{ paddingTop: insets.top + 40 }} className="px-6 pb-8">
        
        {/* App Header */}
        <View className="items-center mb-12">
          <View className="w-24 h-24 bg-blue-500 rounded-3xl items-center justify-center mb-6">
            <Ionicons name="print" size={48} color="white" />
          </View>
          <Text className="text-4xl font-bold text-gray-900 mb-2">
            PISO Print Express
          </Text>
          <Text className="text-lg text-gray-600 text-center">
            Your Professional Printing Partner
          </Text>
          <Text className="text-sm text-gray-500 text-center mt-2">
            Available on Android, iOS & Windows PC
          </Text>
        </View>

        {/* Role Selection */}
        <View className="mb-8">
          <Text className="text-2xl font-bold text-gray-900 mb-2 text-center">
            Welcome! Who are you?
          </Text>
          <Text className="text-gray-600 text-center mb-8">
            Select your role to get started with the app
          </Text>

          <View className="space-y-4">
            {roles.map((role) => (
              <RoleCard
                key={role.id}
                role={role}
                selected={selectedRole === role.id}
                onPress={() => handleRoleSelect(role.id)}
              />
            ))}
          </View>
        </View>

        {/* Email Input */}
        {selectedRole && (
          <View className="mb-8">
            <Text className="text-lg font-semibold text-gray-900 mb-4">
              Enter Your Email
            </Text>
            <View className="relative">
              <Ionicons 
                name="mail" 
                size={20} 
                color="#6B7280" 
                style={{ position: 'absolute', left: 16, top: 16, zIndex: 1 }}
              />
              <TextInput
                className="border border-gray-300 rounded-xl pl-12 pr-4 py-4 text-base"
                value={email}
                onChangeText={setEmail}
                placeholder="Enter your email address"
                keyboardType="email-address"
                autoCapitalize="none"
                autoComplete="email"
              />
            </View>
            <Text className="text-sm text-gray-500 mt-2">
              {selectedRole === 'customer' 
                ? 'Use any email address for demo purposes'
                : 'Demo credentials are pre-filled for testing'
              }
            </Text>
          </View>
        )}

        {/* Continue Button */}
        {selectedRole && email.trim() && (
          <View className="space-y-4">
            <Pressable 
              className={cn(
                "py-4 rounded-xl",
                loading ? "bg-gray-400" : "bg-blue-500"
              )}
              onPress={handleLogin}
              disabled={loading}
            >
              <Text className="text-white text-center font-semibold text-lg">
                {loading ? 'Signing in...' : `Continue as ${roles.find(r => r.id === selectedRole)?.title}`}
              </Text>
            </Pressable>

            {/* Demo Note */}
            <View className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
              <View className="flex-row items-start">
                <Ionicons name="information-circle" size={20} color="#F59E0B" />
                <View className="ml-3 flex-1">
                  <Text className="text-yellow-800 font-medium text-sm">
                    Demo Mode
                  </Text>
                  <Text className="text-yellow-700 text-sm mt-1 leading-relaxed">
                    This is a demonstration app. All features are simulated for testing purposes.
                    {selectedRole === 'customer' && ' You can use any email address to continue.'}
                  </Text>
                </View>
              </View>
            </View>
          </View>
        )}

        {/* Features Preview */}
        <View className="mt-12">
          <Text className="text-lg font-semibold text-gray-900 mb-6 text-center">
            What you can do with PISO Print Express
          </Text>
          <View className="space-y-4">
            <FeatureItem 
              icon="document-text"
              title="Document Printing"
              description="Print PDFs, Word docs, presentations with custom settings"
            />
            <FeatureItem 
              icon="scan"
              title="Scan & Print"
              description="Use camera to scan documents and print instantly"
            />
            <FeatureItem 
              icon="camera"
              title="Photo Printing"
              description="Print photos in various sizes with professional quality"
            />
            <FeatureItem 
              icon="card"
              title="Multiple Payment Options"
              description="Pay with cash, GCash, or card for your convenience"
            />
            <FeatureItem 
              icon="bicycle"
              title="Pickup & Delivery"
              description="Choose to pickup from store or get it delivered"
            />
            <FeatureItem 
              icon="star"
              title="Loyalty Points"
              description="Earn and redeem points for discounts on future orders"
            />
          </View>
        </View>

      </View>
    </ScrollView>
  );
}

interface RoleCardProps {
  role: {
    id: UserRole;
    title: string;
    description: string;
    icon: keyof typeof Ionicons.glyphMap;
    color: string;
  };
  selected: boolean;
  onPress: () => void;
}

function RoleCard({ role, selected, onPress }: RoleCardProps) {
  return (
    <Pressable 
      onPress={onPress}
      className={cn(
        "border-2 rounded-2xl p-6 active:scale-98 transition-transform",
        selected 
          ? "bg-blue-50 border-blue-500 shadow-lg" 
          : "bg-white border-gray-200"
      )}
    >
      <View className="flex-row items-center">
        <View className={cn(
          "w-16 h-16 rounded-2xl items-center justify-center mr-4",
          selected ? "bg-blue-500" : role.color
        )}>
          <Ionicons 
            name={role.icon} 
            size={32} 
            color="white" 
          />
        </View>
        
        <View className="flex-1">
          <Text className={cn(
            "text-xl font-bold mb-1",
            selected ? "text-blue-900" : "text-gray-900"
          )}>
            {role.title}
          </Text>
          <Text className={cn(
            "text-sm leading-relaxed",
            selected ? "text-blue-700" : "text-gray-600"
          )}>
            {role.description}
          </Text>
        </View>
        
        {selected && (
          <View className="ml-4">
            <Ionicons name="checkmark-circle" size={28} color="#3B82F6" />
          </View>
        )}
      </View>
    </Pressable>
  );
}

interface FeatureItemProps {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  description: string;
}

function FeatureItem({ icon, title, description }: FeatureItemProps) {
  return (
    <View className="flex-row items-center">
      <View className="w-10 h-10 bg-blue-100 rounded-full items-center justify-center mr-4">
        <Ionicons name={icon} size={20} color="#3B82F6" />
      </View>
      <View className="flex-1">
        <Text className="font-semibold text-gray-900 mb-1">
          {title}
        </Text>
        <Text className="text-sm text-gray-600 leading-relaxed">
          {description}
        </Text>
      </View>
    </View>
  );
}