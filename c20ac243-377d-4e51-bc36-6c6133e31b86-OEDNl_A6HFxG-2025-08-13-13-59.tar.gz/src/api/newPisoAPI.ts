import { FileInfo, PrintJob, SystemSettings, QuestionOfTheDay } from '../state/newAppStore';
import { User } from '../state/authStore';

// Mock data
const mockQuestionsOfTheDay: QuestionOfTheDay[] = [
  {
    id: '1',
    question: 'Did you know that printing double-sided can save up to 50% on paper costs?',
    date: new Date().toISOString().split('T')[0],
  },
  {
    id: '2', 
    question: 'Pro tip: Use color printing sparingly to make your documents more impactful!',
    date: new Date().toISOString().split('T')[0],
  },
  {
    id: '3',
    question: 'Remember to check your file preview before printing to avoid reprints.',
    date: new Date().toISOString().split('T')[0],
  },
];

const mockUsers: User[] = [
  {
    id: 'admin-1',
    name: 'Admin User',
    email: 'admin@pisoprint.com',
    role: 'admin',
    loyaltyPoints: 0,
    isLoggedIn: false,
  },
  {
    id: 'operator-1', 
    name: 'Store Operator',
    email: 'operator@pisoprint.com',
    role: 'operator',
    loyaltyPoints: 0,
    isLoggedIn: false,
  },
  {
    id: 'customer-1',
    name: 'John Doe',
    email: 'john@example.com',
    phone: '+639123456789',
    role: 'customer',
    loyaltyPoints: 150,
    isLoggedIn: false,
  },
];

const mockPrintJobs: PrintJob[] = [];

class NewPisoAPI {
  
  // Authentication
  async authenticateUser(email: string, role?: string): Promise<User> {
    await this.delay(500);
    
    // For demo purposes, find user by email or create new customer
    let user = mockUsers.find(u => u.email === email);
    
    if (!user && role) {
      user = {
        id: `user-${Date.now()}`,
        name: email.split('@')[0],
        email,
        role: role as any,
        loyaltyPoints: role === 'customer' ? 0 : 0,
        isLoggedIn: true,
      };
      mockUsers.push(user);
    }
    
    if (!user) {
      throw new Error('User not found');
    }
    
    return { ...user, isLoggedIn: true };
  }
  
  // Daily content
  async getQuestionOfTheDay(): Promise<QuestionOfTheDay> {
    await this.delay(300);
    const randomIndex = Math.floor(Math.random() * mockQuestionsOfTheDay.length);
    return mockQuestionsOfTheDay[randomIndex];
  }
  
  // File analysis
  async analyzeFile(file: any): Promise<FileInfo> {
    await this.delay(1000); // Simulate file processing
    
    // Mock file analysis - in real app this would use AI/OCR
    const pages = this.estimatePages(file);
    const isPhoto = this.isPhotoFile(file);
    
    return {
      id: `file-${Date.now()}`,
      name: file.name,
      uri: file.uri,
      type: file.type || file.mimeType,
      size: file.size,
      pages,
      paperSize: isPhoto ? '4R' : 'Letter', // Default based on file type
      pageColor: this.detectColorMode(file),
      pageSidedness: 'single',
      pageOrientation: 'portrait',
      copies: 1,
      binding: 'none',
      lamination: 'none',
    };
  }
  
  // Print jobs
  async createPrintJob(jobData: Omit<PrintJob, 'id' | 'createdAt' | 'updatedAt'>): Promise<PrintJob> {
    await this.delay(800);
    
    const newJob: PrintJob = {
      ...jobData,
      id: `job-${Date.now()}`,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    
    mockPrintJobs.push(newJob);
    
    // Start the print job simulation
    this.simulatePrintJobProgress(newJob.id);
    
    return newJob;
  }
  
  async getPrintJobs(): Promise<PrintJob[]> {
    await this.delay(300);
    return [...mockPrintJobs];
  }
  
  async updatePrintJobStatus(id: string, status: PrintJob['status']): Promise<PrintJob> {
    await this.delay(200);
    
    const jobIndex = mockPrintJobs.findIndex(job => job.id === id);
    if (jobIndex === -1) throw new Error('Print job not found');
    
    mockPrintJobs[jobIndex] = {
      ...mockPrintJobs[jobIndex],
      status,
      updatedAt: new Date(),
    };
    
    return mockPrintJobs[jobIndex];
  }
  
  // Pricing calculation
  calculatePricing(files: FileInfo[]): { subtotal: number; total: number; breakdown: any } {
    let subtotal = 0;
    const breakdown: any = [];
    
    if (!files || files.length === 0) {
      return { subtotal: 0, total: 0, breakdown: [] };
    }
    
    files.forEach(file => {
      // Safety checks to prevent NaN
      const safeFile = {
        ...file,
        pages: Math.max(1, file.pages || 1),
        copies: Math.max(1, file.copies || 1),
        paperSize: file.paperSize || 'A4',
        pageColor: file.pageColor || 'auto',
        pageSidedness: file.pageSidedness || 'single',
        binding: file.binding || 'none',
        lamination: file.lamination || 'none',
      };
      
      const isPhoto = this.isPhotoFile(safeFile);
      const basePrice = this.getBasePrice(safeFile.paperSize, safeFile.pageColor, safeFile.pageSidedness, isPhoto);
      const totalPages = safeFile.pages * safeFile.copies;
      const sidednessMultiplier = safeFile.pageSidedness === 'double' ? 0.75 : 1;
      
      // Calculate costs with safety checks
      const printingCost = Math.round((basePrice || 100) * totalPages * sidednessMultiplier);
      const bindingCost = this.getBindingPrice(safeFile.binding) * safeFile.copies;
      const laminationCost = this.getLaminationPrice(safeFile.lamination, totalPages);
      
      const fileTotal = printingCost + bindingCost + laminationCost;
      
      // Ensure no NaN values
      if (!isNaN(fileTotal) && isFinite(fileTotal)) {
        subtotal += fileTotal;
      }
      
      breakdown.push({
        fileName: safeFile.name,
        pages: safeFile.pages,
        copies: safeFile.copies,
        totalPages,
        basePrice: basePrice || 100,
        sidednessMultiplier,
        printingCost,
        bindingCost,
        laminationCost,
        total: fileTotal,
      });
    });
    
    // Final safety check
    const finalTotal = isNaN(subtotal) || !isFinite(subtotal) ? 0 : subtotal;
    
    return {
      subtotal: finalTotal,
      total: finalTotal,
      breakdown,
    };
  }
  
  // Loyalty points
  async getLoyaltyPoints(userId: string): Promise<number> {
    await this.delay(200);
    const user = mockUsers.find(u => u.id === userId);
    return user?.loyaltyPoints || 0;
  }
  
  async redeemLoyaltyPoints(userId: string, points: number): Promise<number> {
    await this.delay(300);
    const user = mockUsers.find(u => u.id === userId);
    if (user && user.loyaltyPoints >= points) {
      user.loyaltyPoints -= points;
      return user.loyaltyPoints;
    }
    throw new Error('Insufficient loyalty points');
  }
  
  // Delivery couriers
  async getAvailableCouriers(): Promise<Array<{id: string; name: string; estimatedTime: string}>> {
    await this.delay(400);
    return [
      { id: 'grab', name: 'Grab Express', estimatedTime: '30-45 mins' },
      { id: 'lalamove', name: 'Lalamove', estimatedTime: '45-60 mins' },
      { id: 'borzo', name: 'Borzo', estimatedTime: '60-90 mins' },
      { id: 'local', name: 'Local Courier', estimatedTime: '2-3 hours' },
    ];
  }
  
  // Paper size utilities
  getAvailableDocumentSizes(): Array<{id: string, name: string, description: string}> {
    return [
      { id: 'Letter', name: 'Letter', description: '8.5" × 11" (216 × 279 mm)' },
      { id: 'A4', name: 'A4', description: '8.3" × 11.7" (210 × 297 mm)' },
      { id: 'Legal', name: 'Legal', description: '8.5" × 13" (216 × 330 mm)' },
      { id: 'A3', name: 'A3', description: '11.7" × 16.5" (297 × 420 mm)' },
    ];
  }
  
  getAvailablePhotoSizes(): Array<{id: string, name: string, description: string}> {
    return [
      { id: 'Wallet', name: 'Wallet', description: '1.75" × 2.5" (Half of 3R)' },
      { id: '2R', name: '2R', description: '2" × 3" (Half of 4R)' },
      { id: '3R', name: '3R', description: '3.5" × 5" (89 × 127 mm)' },
      { id: '4R', name: '4R (Standard)', description: '4" × 6" (102 × 152 mm)' },
      { id: '5R', name: '5R', description: '5" × 7" (127 × 178 mm)' },
      { id: '6R', name: '6R', description: '6" × 8" (152 × 203 mm)' },
      { id: '8R', name: '8R', description: '8" × 10" (203 × 254 mm)' },
      { id: 'A4', name: 'A4 Photo', description: '8.3" × 11.7" (210 × 297 mm)' },
      { id: 'A3', name: 'A3 Photo', description: '11.7" × 16.5" (297 × 420 mm)' },
    ];
  }

  // Helper methods
  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  private estimatePages(file: any): number {
    // Mock page estimation based on file size and type
    if (file.type?.includes('pdf')) {
      return Math.max(1, Math.floor(file.size / 50000)); // Rough estimate
    } else if (file.type?.includes('image')) {
      return 1;
    } else if (file.type?.includes('document') || file.type?.includes('text')) {
      return Math.max(1, Math.floor(file.size / 30000));
    }
    return 1;
  }
  
  private detectColorMode(file: any): 'auto' | 'color' | 'blackwhite' {
    // Mock color detection - in real app would analyze file content
    if (file.type?.includes('image')) {
      return 'color';
    }
    return 'auto';
  }
  
  private isPhotoFile(file: any): boolean {
    // Determine if file is a photo based on type and context
    const imageTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/bmp', 'image/webp'];
    const fileType = file.type || file.mimeType || '';
    
    // Check if it's an image type
    if (imageTypes.some(type => fileType.includes(type))) {
      return true;
    }
    
    // Check file extension
    const fileName = file.name || '';
    const photoExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'];
    
    return photoExtensions.some(ext => fileName.toLowerCase().includes(ext));
  }
  
  private getBasePrice(paperSize: string, pageColor: string, pageSidedness: string = 'single', isPhoto: boolean = false): number {
    // Get pricing from system settings - in real app, this would be fetched from store
    
    if (isPhoto) {
      const photoPricing = {
        'Wallet': 50, // ₱0.50
        '2R': 100, // ₱1.00
        '3R': 150, // ₱1.50
        '4R': 200, // ₱2.00
        '5R': 350, // ₱3.50
        '6R': 450, // ₱4.50
        '8R': 650, // ₱6.50
        'A4': 800, // ₱8.00 (A4 Photo)
        'A3': 1200, // ₱12.00 (A3 Photo)
      };
      return photoPricing[paperSize as keyof typeof photoPricing] || 200;
    } else {
      const documentPricing = {
        'Letter': { blackwhite: 100, color: 200, doubleSidedSurcharge: 50 },
        'A4': { blackwhite: 100, color: 200, doubleSidedSurcharge: 50 },
        'Legal': { blackwhite: 150, color: 300, doubleSidedSurcharge: 50 },
        'A3': { blackwhite: 200, color: 400, doubleSidedSurcharge: 200 }, // ₱2.00 for A3
      };
      
      const sizePrice = documentPricing[paperSize as keyof typeof documentPricing];
      if (!sizePrice) return 100; // Default fallback
      
      let basePrice = 0;
      // Get base price based on color mode
      if (pageColor === 'blackwhite') {
        basePrice = sizePrice.blackwhite;
      } else if (pageColor === 'color') {
        basePrice = sizePrice.color;
      } else {
        // Auto mode - use color pricing
        basePrice = sizePrice.color;
      }
      
      // Add double-sided surcharge if needed
      if (pageSidedness === 'double') {
        basePrice += sizePrice.doubleSidedSurcharge;
      }
      
      return basePrice;
    }
  }
  
  private getBindingPrice(bindingType: string): number {
    const bindingPricing = {
      'none': 0,
      'spiral': 1500, // ₱15.00
      'perfect': 2000, // ₱20.00  
      'saddle': 800, // ₱8.00
    };
    return bindingPricing[bindingType as keyof typeof bindingPricing] || 0;
  }
  
  private getLaminationPrice(laminationType: string, pages: number): number {
    const laminationPricing = {
      'none': 0,
      'matte': 1000, // ₱10.00 per page
      'glossy': 1200, // ₱12.00 per page
    };
    const pricePerPage = laminationPricing[laminationType as keyof typeof laminationPricing] || 0;
    return pricePerPage * pages;
  }
  
  private async simulatePrintJobProgress(jobId: string): Promise<void> {
    // Simulate print job status updates
    const statusSequence: PrintJob['status'][] = ['queue', 'ongoing', 'ready'];
    
    for (let i = 0; i < statusSequence.length; i++) {
      await this.delay((i + 1) * 5000); // 5s, 10s, 15s delays
      
      try {
        await this.updatePrintJobStatus(jobId, statusSequence[i]);
        // In real app, this would trigger push notifications
        console.log(`Job ${jobId} status updated to: ${statusSequence[i]}`);
      } catch (error) {
        console.error('Failed to update job status:', error);
        // Set status to failed after 3 attempts
        if (i === statusSequence.length - 1) {
          await this.updatePrintJobStatus(jobId, 'failed');
        }
        break;
      }
    }
  }
}

export const newApiClient = new NewPisoAPI();