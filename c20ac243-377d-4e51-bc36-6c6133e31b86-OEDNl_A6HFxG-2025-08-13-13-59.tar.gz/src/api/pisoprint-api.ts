import { PrintJob, PhotoSize, Subscription, MarketplaceItem, DashboardStats } from '../state/appStore';

// Mock data based on the original storage implementation
const mockPhotoSizes: PhotoSize[] = [
  {
    id: "photo-1",
    name: "1x1 ID Photo",
    width: "1.00",
    height: "1.00",
    unit: "inches",
    price: 500, // ₱5.00
    isActive: true,
  },
  {
    id: "photo-2",
    name: "2x2 ID Photo",
    width: "2.00",
    height: "2.00",
    unit: "inches",
    price: 800, // ₱8.00
    isActive: true,
  },
  {
    id: "photo-3",
    name: "4x6 Photo",
    width: "4.00",
    height: "6.00",
    unit: "inches",
    price: 1500, // ₱15.00
    isActive: true,
  },
];

const mockPrintJobs: PrintJob[] = [
  {
    id: "job-1",
    customerId: "customer-1",
    operatorId: "operator-1",
    status: "printing",
    type: "document",
    files: [{ name: "resume.pdf", size: 1024, type: "application/pdf" }],
    copies: 3,
    paperSize: "A4",
    colorMode: "black_white",
    printSettings: { duplex: false, quality: "normal" },
    total: 4500, // ₱45.00
    paymentMethod: "cash",
    paymentStatus: "paid",
    notes: "Urgent - needed for interview",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: "job-2",
    customerId: "customer-2", 
    status: "queue",
    type: "photo",
    files: [{ name: "graduation-photo.jpg", size: 2048, type: "image/jpeg" }],
    copies: 5,
    paperSize: "4x6",
    colorMode: "color",
    total: 7500, // ₱75.00
    paymentStatus: "pending",
    notes: "High quality print needed",
    createdAt: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
    updatedAt: new Date(Date.now() - 30 * 60 * 1000),
  },
];

const mockSubscriptions: Subscription[] = [
  {
    id: "sub-1",
    customerEmail: "premium@example.com",
    customerName: "Premium User",
    plan: "business",
    status: "active",
    price: 59900, // ₱599.00
    credits: 250,
    maxCredits: 300,
    startDate: new Date(),
    endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
    createdAt: new Date(),
  },
];

const mockMarketplaceItems: MarketplaceItem[] = [
  {
    id: "market-1",
    title: "Professional Resume Template",
    description: "Clean, modern resume template perfect for corporate jobs",
    category: "templates",
    type: "document_template",
    price: 15000, // ₱150.00
    commission: 70,
    downloads: 45,
    rating: 450, // 4.50 stars
    status: "approved",
    filePath: "/templates/resume-professional.docx",
    creatorEmail: "designer@example.com",
    creatorName: "Design Pro",
    createdAt: new Date(),
  },
  {
    id: "market-2",
    title: "Birthday Invitation Card",
    description: "Colorful and fun birthday invitation template",
    category: "designs",
    type: "business_card",
    price: 8000, // ₱80.00
    commission: 70,
    downloads: 23,
    rating: 400, // 4.00 stars
    status: "approved",
    filePath: "/designs/birthday-invitation.psd",
    creatorEmail: "creative@example.com",
    creatorName: "Creative Studio",
    createdAt: new Date(),
  },
];

const mockDashboardStats: DashboardStats = {
  jobsToday: 12,
  revenueToday: 25400, // ₱254.00
  activeOperators: 2,
  totalOperators: 3,
  queueLength: 5,
};

// API service class
class PisoPrintAPI {
  
  // Dashboard
  async getDashboardStats(): Promise<DashboardStats> {
    await this.delay(500); // Simulate network delay
    return mockDashboardStats;
  }
  
  // Print Jobs
  async getPrintJobs(): Promise<PrintJob[]> {
    await this.delay(300);
    return mockPrintJobs;
  }
  
  async createPrintJob(job: Omit<PrintJob, 'id' | 'createdAt' | 'updatedAt'>): Promise<PrintJob> {
    await this.delay(500);
    const newJob: PrintJob = {
      ...job,
      id: `job-${Date.now()}`,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    mockPrintJobs.push(newJob);
    return newJob;
  }
  
  async updatePrintJob(id: string, updates: Partial<PrintJob>): Promise<PrintJob> {
    await this.delay(300);
    const index = mockPrintJobs.findIndex(job => job.id === id);
    if (index === -1) throw new Error('Print job not found');
    
    mockPrintJobs[index] = {
      ...mockPrintJobs[index],
      ...updates,
      updatedAt: new Date()
    };
    return mockPrintJobs[index];
  }
  
  // Photo Sizes
  async getPhotoSizes(): Promise<PhotoSize[]> {
    await this.delay(200);
    return mockPhotoSizes.filter(size => size.isActive);
  }
  
  // Subscriptions
  async getSubscriptions(): Promise<Subscription[]> {
    await this.delay(300);
    return mockSubscriptions;
  }
  
  async createSubscription(subscription: Omit<Subscription, 'id' | 'createdAt'>): Promise<Subscription> {
    await this.delay(1000); // Simulate payment processing
    const newSubscription: Subscription = {
      ...subscription,
      id: `sub-${Date.now()}`,
      createdAt: new Date(),
    };
    mockSubscriptions.push(newSubscription);
    return newSubscription;
  }
  
  // Marketplace
  async getMarketplaceItems(category?: string, searchQuery?: string): Promise<MarketplaceItem[]> {
    await this.delay(400);
    let items = mockMarketplaceItems.filter(item => item.status === 'approved');
    
    if (category && category !== 'all') {
      items = items.filter(item => item.category === category);
    }
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      items = items.filter(item => 
        item.title.toLowerCase().includes(query) ||
        (item.description && item.description.toLowerCase().includes(query))
      );
    }
    
    return items;
  }
  
  async createMarketplaceItem(item: Omit<MarketplaceItem, 'id' | 'createdAt'>): Promise<MarketplaceItem> {
    await this.delay(800);
    const newItem: MarketplaceItem = {
      ...item,
      id: `market-${Date.now()}`,
      status: 'pending', // Items need approval
      downloads: 0,
      rating: 0,
      createdAt: new Date(),
    };
    mockMarketplaceItems.push(newItem);
    return newItem;
  }
  
  // Utility
  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export const apiClient = new PisoPrintAPI();