import React, { useState, useEffect } from 'react';
import { View, Text, Pressable } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';
import { useDeviceInfo } from '../utils/deviceDetection';

// Import screens
import GuestHomeScreen from '../screens/mobile/GuestHomeScreen';
import ServiceBrowserScreen from '../screens/ServiceBrowserScreen';
import CustomerOrdersScreen from '../screens/mobile/CustomerOrdersScreen';
import CustomerProfileScreen from '../screens/mobile/CustomerProfileScreen';
import CustomerServicesScreen from '../screens/mobile/CustomerServicesScreen';
import FileUploadScreen from '../screens/FileUploadScreen';
import FileInfoScreen from '../screens/FileInfoScreen';
import PaymentScreen from '../screens/PaymentScreen';
import ScannerScreen from '../screens/ScannerScreen';
import LoginScreen from '../screens/LoginScreen';
import CompletePricingScreen from '../screens/CompletePricingScreen';
import FranchisingScreen from '../screens/FranchisingScreen';
import MarketplaceScreen from '../screens/MarketplaceScreen';
import SubscriptionsScreen from '../screens/SubscriptionsScreen';
import OperatorReviewScreen from '../screens/OperatorReviewScreen';
import OperatorDashboardNew from '../screens/OperatorDashboardNew';
import CustomerOrderStatusScreenFixed from '../screens/CustomerOrderStatusScreenFixed';
import TempDesktopDashboardAccess from '../screens/TempDesktopDashboardAccess';


const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

// Stack navigators for each tab
function HomeStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen 
        name="HomeMain" 
        component={GuestHomeScreen} 
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="ServiceBrowser" 
        component={ServiceBrowserScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="Login" 
        component={LoginScreen}
        options={{ 
          title: 'Login',
          headerStyle: { backgroundColor: '#3B82F6' },
          headerTintColor: 'white'
        }}
      />
      <Stack.Screen 
        name="CompletePricing" 
        component={CompletePricingScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="Franchising" 
        component={FranchisingScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="FileUpload" 
        component={FileUploadScreen}
        options={{ 
          title: 'Upload Files',
          headerStyle: { backgroundColor: '#3B82F6' },
          headerTintColor: 'white'
        }}
      />
      <Stack.Screen 
        name="Scanner" 
        component={ScannerScreen}
        options={{ 
          title: 'Document Scanner',
          headerShown: false,
          presentation: 'fullScreenModal'
        }}
      />

      <Stack.Screen 
        name="FileInfo" 
        component={FileInfoScreen}
        options={{ 
          title: 'Print Settings',
          headerStyle: { backgroundColor: '#3B82F6' },
          headerTintColor: 'white'
        }}
      />
      <Stack.Screen 
        name="Payment" 
        component={PaymentScreen}
        options={{ 
          title: 'Payment',
          headerStyle: { backgroundColor: '#10B981' },
          headerTintColor: 'white'
        }}
      />
      <Stack.Screen 
        name="Marketplace" 
        component={MarketplaceScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="Subscriptions" 
        component={SubscriptionsScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="OperatorReview" 
        component={OperatorReviewScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="OperatorDashboardNew" 
        component={OperatorDashboardNew}
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="CustomerOrderStatus" 
        component={CustomerOrderStatusScreenFixed}
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="TempDesktopDashboardAccess" 
        component={TempDesktopDashboardAccess}
        options={{ headerShown: false }}
      />
    </Stack.Navigator>
  );
}

function ServicesStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen 
        name="ServicesMain" 
        component={CustomerServicesScreen} 
        options={{ 
          title: 'Our Services',
          headerStyle: { backgroundColor: '#3B82F6' },
          headerTintColor: 'white',
          headerTitleStyle: { fontWeight: 'bold' }
        }}
      />
    </Stack.Navigator>
  );
}

function OrdersStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen 
        name="OrdersMain" 
        component={CustomerOrdersScreen} 
        options={{ 
          title: 'My Orders',
          headerStyle: { backgroundColor: '#8B5CF6' },
          headerTintColor: 'white',
          headerTitleStyle: { fontWeight: 'bold' }
        }}
      />
    </Stack.Navigator>
  );
}

function ProfileStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen 
        name="ProfileMain" 
        component={CustomerProfileScreen} 
        options={{ 
          title: 'My Profile',
          headerStyle: { backgroundColor: '#6B7280' },
          headerTintColor: 'white',
          headerTitleStyle: { fontWeight: 'bold' }
        }}
      />
    </Stack.Navigator>
  );
}

export default function CustomerMobileApp() {
  const { currentUser, isAuthenticated, isGuestMode } = useAuthStore();
  const deviceInfo = useDeviceInfo();

  // Ensure this only renders on mobile devices
  if (!deviceInfo.isMobile && !deviceInfo.isTablet) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20, backgroundColor: '#F9FAFB' }}>
        <View style={{ 
          width: 80, 
          height: 80, 
          backgroundColor: '#EFF6FF', 
          borderRadius: 40, 
          alignItems: 'center', 
          justifyContent: 'center', 
          marginBottom: 24 
        }}>
          <Ionicons name="phone-portrait" size={40} color="#3B82F6" />
        </View>
        <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#111827', marginBottom: 12, textAlign: 'center' }}>
          Mobile App Interface
        </Text>
        <Text style={{ fontSize: 16, color: '#6B7280', textAlign: 'center', lineHeight: 24 }}>
          This interface is optimized for mobile devices. Please use a mobile phone or tablet to access the full mobile experience.
        </Text>
      </View>
    );
  }

  // Route to different interfaces based on user role
  if (currentUser?.role === 'operator') {
    const OperatorMobileApp = require('./OperatorMobileApp').default;
    return <OperatorMobileApp />;
  }

  if (currentUser?.role === 'admin') {
    const AdminMobileApp = require('./AdminMobileApp').default;
    return <AdminMobileApp />;
  }

  // Default: Customer interface
  return (
    <NavigationContainer independent={true}>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName: keyof typeof Ionicons.glyphMap;

            if (route.name === 'Home') {
              iconName = focused ? 'home' : 'home-outline';
            } else if (route.name === 'Services') {
              iconName = focused ? 'grid' : 'grid-outline';
            } else if (route.name === 'Orders') {
              iconName = focused ? 'receipt' : 'receipt-outline';
            } else if (route.name === 'Profile') {
              iconName = focused ? 'person' : 'person-outline';
            } else {
              iconName = 'circle';
            }

            return <Ionicons name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: '#3B82F6',
          tabBarInactiveTintColor: '#6B7280',
          tabBarStyle: {
            backgroundColor: 'white',
            borderTopColor: '#E5E7EB',
            borderTopWidth: 1,
            height: 84,
            paddingBottom: 20,
            paddingTop: 8,
          },
          tabBarLabelStyle: {
            fontSize: 12,
            fontWeight: '600',
          },
          headerShown: false,
        })}
      >
        <Tab.Screen 
          name="Home" 
          component={HomeStack}
          options={{
            tabBarLabel: 'Home',
          }}
        />
        <Tab.Screen 
          name="Services" 
          component={ServicesStack}
          options={{
            tabBarLabel: 'Services',
          }}
        />
        <Tab.Screen 
          name="Orders" 
          component={OrdersStack}
          options={{
            tabBarLabel: 'My Orders',
            tabBarBadge: currentUser?.id ? 
              undefined : // Show badge count based on user orders
              undefined
          }}
        />
        <Tab.Screen 
          name="Profile" 
          component={ProfileStack}
          options={{
            tabBarLabel: 'Profile',
          }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}