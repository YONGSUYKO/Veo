import React from 'react';
import { View, Text, StyleSheet, Pressable, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';

export default function OperatorMobileApp() {
  const insets = useSafeAreaInsets();
  const { currentUser, logout } = useAuthStore();

  const handleClockIn = () => {
    // Handle clock in logic
    alert('Clocked In Successfully!');
  };

  const handleClockOut = () => {
    // Handle clock out logic
    alert('Clocked Out Successfully!');
  };

  const handleViewJobs = () => {
    // Handle view print jobs
    alert('Print Jobs: 5 pending, 3 in progress');
  };

  const handleLogout = () => {
    logout();
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Header */}
        <View style={[styles.header, { paddingTop: insets.top + 20 }]}>
          <View style={styles.headerContent}>
            <View style={styles.userInfo}>
              <View style={styles.avatarContainer}>
                <Ionicons name="person" size={24} color="white" />
              </View>
              <View>
                <Text style={styles.userName}>{currentUser?.name}</Text>
                <Text style={styles.userRole}>Store Operator</Text>
              </View>
            </View>
            
            <Pressable style={styles.logoutButton} onPress={handleLogout}>
              <Ionicons name="log-out" size={20} color="white" />
            </Pressable>
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.quickActionsContainer}>
          <View style={styles.quickActionsCard}>
            <Text style={styles.sectionTitle}>Attendance</Text>
            
            <View style={styles.attendanceGrid}>
              <Pressable style={[styles.attendanceButton, { backgroundColor: '#10B981' }]} onPress={handleClockIn}>
                <Ionicons name="time" size={32} color="white" />
                <Text style={styles.attendanceButtonText}>Clock In</Text>
              </Pressable>

              <Pressable style={[styles.attendanceButton, { backgroundColor: '#EF4444' }]} onPress={handleClockOut}>
                <Ionicons name="time" size={32} color="white" />
                <Text style={styles.attendanceButtonText}>Clock Out</Text>
              </Pressable>
            </View>

            <View style={styles.timeInfo}>
              <Text style={styles.timeText}>Today: 09:15 AM - Present</Text>
              <Text style={styles.timeSubtext}>7 hours 45 minutes</Text>
            </View>
          </View>
        </View>

        {/* Work Overview */}
        <View style={styles.workContainer}>
          <View style={styles.workCard}>
            <Text style={styles.sectionTitle}>Today's Work</Text>
            
            <Pressable style={styles.jobsButton} onPress={handleViewJobs}>
              <View style={styles.jobsIcon}>
                <Ionicons name="print" size={24} color="#3B82F6" />
              </View>
              <View style={styles.jobsInfo}>
                <Text style={styles.jobsTitle}>Print Jobs</Text>
                <Text style={styles.jobsDescription}>View and manage print queue</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
            </Pressable>

            <View style={styles.statsGrid}>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>8</Text>
                <Text style={styles.statLabel}>Completed</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>5</Text>
                <Text style={styles.statLabel}>Pending</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>3</Text>
                <Text style={styles.statLabel}>In Progress</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Restrictions Notice */}
        <View style={styles.restrictionsContainer}>
          <View style={styles.restrictionsCard}>
            <Ionicons name="information-circle" size={24} color="#F59E0B" />
            <View style={styles.restrictionsText}>
              <Text style={styles.restrictionsTitle}>Operator Mode</Text>
              <Text style={styles.restrictionsDescription}>
                This mobile interface is limited to attendance tracking and basic job monitoring. 
                Full operator functions are available on the in-store kiosk/tablet system.
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  scrollContent: {
    paddingBottom: 20,
  },
  header: {
    backgroundColor: '#059669',
    paddingHorizontal: 24,
    paddingBottom: 32,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatarContainer: {
    width: 48,
    height: 48,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  userName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  userRole: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
  },
  logoutButton: {
    width: 40,
    height: 40,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  quickActionsContainer: {
    paddingHorizontal: 24,
    marginTop: -16,
  },
  quickActionsCard: {
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 24,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 16,
  },
  attendanceGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  attendanceButton: {
    flex: 1,
    alignItems: 'center',
    padding: 20,
    borderRadius: 12,
    marginHorizontal: 4,
  },
  attendanceButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: 'white',
    marginTop: 8,
  },
  timeInfo: {
    backgroundColor: '#F3F4F6',
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
  },
  timeText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
  },
  timeSubtext: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 2,
  },
  workContainer: {
    paddingHorizontal: 24,
  },
  workCard: {
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 24,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    marginBottom: 24,
  },
  jobsButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    marginBottom: 16,
  },
  jobsIcon: {
    width: 48,
    height: 48,
    backgroundColor: '#EFF6FF',
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  jobsInfo: {
    flex: 1,
  },
  jobsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
  },
  jobsDescription: {
    fontSize: 14,
    color: '#6B7280',
  },
  statsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statCard: {
    alignItems: 'center',
    flex: 1,
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#3B82F6',
  },
  statLabel: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 4,
  },
  restrictionsContainer: {
    paddingHorizontal: 24,
  },
  restrictionsCard: {
    backgroundColor: '#FFFBEB',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  restrictionsText: {
    flex: 1,
    marginLeft: 12,
  },
  restrictionsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#92400E',
    marginBottom: 4,
  },
  restrictionsDescription: {
    fontSize: 12,
    color: '#B45309',
    lineHeight: 18,
  },
});