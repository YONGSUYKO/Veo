import React, { useState } from 'react';
import { View, Text, Pressable, ScrollView, TextInput, Dimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { cn } from '../../utils/cn';

const { width, height } = Dimensions.get('window');

interface CustomerOnboardingScreenProps {
  onComplete: (userInfo?: any) => void;
}

export default function CustomerOnboardingScreen({ onComplete }: CustomerOnboardingScreenProps) {
  const insets = useSafeAreaInsets();
  const [currentStep, setCurrentStep] = useState(0);
  const [userInfo, setUserInfo] = useState({
    name: '',
    phone: '',
    email: '',
  });

  const onboardingSteps = [
    {
      id: 'welcome',
      title: 'Welcome to PISO Print Express!',
      subtitle: 'Your convenient printing solution',
      description: 'Print documents, scan papers, and order photos directly from your phone.',
      icon: 'print',
      color: 'bg-blue-500',
    },
    {
      id: 'features',
      title: 'What You Can Do',
      subtitle: 'Professional printing made simple',
      description: 'Upload documents, scan with camera, print photos, choose pickup or delivery.',
      icon: 'star',
      color: 'bg-green-500',
    },
    {
      id: 'payment',
      title: 'Multiple Payment Options',
      subtitle: 'Pay your way',
      description: 'Cash, GCash, or Card payments. Earn loyalty points for discounts.',
      icon: 'card',
      color: 'bg-purple-500',
    },
    {
      id: 'info',
      title: 'Quick Setup',
      subtitle: 'Help us serve you better',
      description: 'Provide your details for faster checkout and order tracking.',
      icon: 'person',
      color: 'bg-orange-500',
    },
  ];

  const currentStepData = onboardingSteps[currentStep];

  const handleNext = () => {
    if (currentStep < onboardingSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      // Last step - complete onboarding
      onComplete(userInfo.name.trim() ? userInfo : undefined);
    }
  };

  const handleSkip = () => {
    onComplete(); // Skip with no user info
  };

  const isLastStep = currentStep === onboardingSteps.length - 1;
  const isInfoStep = currentStepData.id === 'info';

  return (
    <View className="flex-1 bg-white">
      <ScrollView>
        <View style={{ paddingTop: insets.top + 40 }} className="px-8 pb-8">
          
          {/* Progress Indicator */}
          <View className="flex-row items-center justify-center mb-12">
            {onboardingSteps.map((_, index) => (
              <View key={index} className="flex-row items-center">
                <View className={cn(
                  "w-3 h-3 rounded-full",
                  index <= currentStep ? "bg-blue-500" : "bg-gray-300"
                )} />
                {index < onboardingSteps.length - 1 && (
                  <View className={cn(
                    "w-8 h-0.5 mx-2",
                    index < currentStep ? "bg-blue-500" : "bg-gray-300"
                  )} />
                )}
              </View>
            ))}
          </View>

          {/* Main Content */}
          <View className="items-center mb-12">
            <View className={cn(
              "w-24 h-24 rounded-full items-center justify-center mb-8",
              currentStepData.color
            )}>
              <Ionicons name={currentStepData.icon as any} size={48} color="white" />
            </View>

            <Text className="text-3xl font-bold text-gray-900 text-center mb-4">
              {currentStepData.title}
            </Text>

            <Text className="text-lg text-blue-600 text-center mb-6 font-medium">
              {currentStepData.subtitle}
            </Text>

            <Text className="text-gray-600 text-center leading-relaxed text-base px-4">
              {currentStepData.description}
            </Text>
          </View>

          {/* Feature Highlights for specific steps */}
          {currentStepData.id === 'features' && (
            <View className="mb-8">
              <View>
                <View className="mb-4">
                  <FeatureItem 
                    icon="document-text"
                    title="Documents"
                    description="PDF, Word, Excel, PowerPoint"
                  />
                </View>
                <View className="mb-4">
                  <FeatureItem 
                    icon="scan"
                    title="Scan & Print"
                    description="Use camera to scan documents"
                  />
                </View>
                <View>
                  <FeatureItem 
                    icon="camera"
                    title="Photos"
                    description="Print memories in various sizes"
                  />
                </View>
              </View>
            </View>
          )}

          {currentStepData.id === 'payment' && (
            <View className="mb-8">
              <View className="flex-row justify-between">
                <PaymentOption icon="cash" title="Cash" />
                <PaymentOption icon="phone-portrait" title="GCash" />
                <PaymentOption icon="card" title="Card" />
              </View>
            </View>
          )}

          {/* User Info Form (Last Step) */}
          {isInfoStep && (
            <View className="mb-8">
              <View className="bg-gray-50 rounded-2xl p-6">
                <View>
                  <View className="mb-4">
                    <Text className="text-sm font-medium text-gray-700 mb-2">
                      Full Name (Optional)
                    </Text>
                    <TextInput
                      className="border border-gray-300 rounded-xl px-4 py-3 text-base"
                      value={userInfo.name}
                      onChangeText={(text) => setUserInfo({...userInfo, name: text})}
                      placeholder="Enter your name"
                      autoCapitalize="words"
                    />
                  </View>
                  
                  <View className="mb-4">
                    <Text className="text-sm font-medium text-gray-700 mb-2">
                      Phone Number (Optional)
                    </Text>
                    <TextInput
                      className="border border-gray-300 rounded-xl px-4 py-3 text-base"
                      value={userInfo.phone}
                      onChangeText={(text) => setUserInfo({...userInfo, phone: text})}
                      placeholder="+639123456789"
                      keyboardType="phone-pad"
                    />
                  </View>
                  
                  <View>
                    <Text className="text-sm font-medium text-gray-700 mb-2">
                      Email Address (Optional)
                    </Text>
                    <TextInput
                      className="border border-gray-300 rounded-xl px-4 py-3 text-base"
                      value={userInfo.email}
                      onChangeText={(text) => setUserInfo({...userInfo, email: text})}
                      placeholder="email@example.com"
                      keyboardType="email-address"
                      autoCapitalize="none"
                    />
                  </View>
                </View>
                
                <View className="bg-blue-50 rounded-xl p-4 mt-4">
                  <Text className="text-blue-800 text-sm text-center">
                    💡 Providing your details helps us send order updates and offer better service!
                  </Text>
                </View>
              </View>
            </View>
          )}

        </View>
      </ScrollView>

      {/* Bottom Actions */}
      <View className="px-8 pb-8 bg-white" style={{ paddingBottom: Math.max(insets.bottom, 32) }}>
        <View>
          <Pressable 
            className="bg-blue-500 py-4 rounded-xl mb-3"
            onPress={handleNext}
          >
            <Text className="text-white text-center font-semibold text-lg">
              {isLastStep ? 'Start Printing!' : 'Next'}
            </Text>
          </Pressable>
          
          <Pressable 
            className="py-3"
            onPress={handleSkip}
          >
            <Text className="text-gray-600 text-center font-medium">
              {isLastStep ? 'Skip for now' : 'Skip'}
            </Text>
          </Pressable>
        </View>
      </View>

    </View>
  );
}

function FeatureItem({ icon, title, description }: { 
  icon: keyof typeof Ionicons.glyphMap; 
  title: string; 
  description: string; 
}) {
  return (
    <View className="flex-row items-center bg-white rounded-xl p-4">
      <View className="w-12 h-12 bg-blue-100 rounded-full items-center justify-center mr-4">
        <Ionicons name={icon} size={24} color="#3B82F6" />
      </View>
      <View className="flex-1">
        <Text className="font-semibold text-gray-900 mb-1">{title}</Text>
        <Text className="text-sm text-gray-600">{description}</Text>
      </View>
    </View>
  );
}

function PaymentOption({ icon, title }: { 
  icon: keyof typeof Ionicons.glyphMap; 
  title: string; 
}) {
  return (
    <View className="items-center">
      <View className="w-16 h-16 bg-white rounded-2xl border-2 border-gray-200 items-center justify-center mb-3">
        <Ionicons name={icon} size={28} color="#6B7280" />
      </View>
      <Text className="text-sm font-medium text-gray-700">{title}</Text>
    </View>
  );
}