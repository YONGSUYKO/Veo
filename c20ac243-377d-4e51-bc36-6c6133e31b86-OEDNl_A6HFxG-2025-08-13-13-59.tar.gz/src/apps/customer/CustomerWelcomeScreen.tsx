import React from 'react';
import { View, Text, Pressable, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useDeviceInfo } from '../../utils/deviceDetection';
import SimpleMobileHome from '../../screens/mobile/SimpleMobileHome';

interface CustomerWelcomeScreenProps {
  onServiceSelect: (service: 'document' | 'scan' | 'photo') => void;
}

export default function CustomerWelcomeScreen({ onServiceSelect }: CustomerWelcomeScreenProps) {
  const insets = useSafeAreaInsets();
  const deviceInfo = useDeviceInfo();

  // Use simple mobile version for mobile devices
  if (deviceInfo.isMobile || deviceInfo.isTablet) {
    return <SimpleMobileHome onServiceSelect={onServiceSelect} />;
  }

  return (
    <View style={{ flex: 1, backgroundColor: 'white' }}>
      <ScrollView contentContainerStyle={{ 
        paddingTop: insets.top + 20, 
        paddingHorizontal: 24, 
        paddingBottom: 32 
      }}>
        
        <View style={{ alignItems: 'center', marginBottom: 40 }}>
          <View style={{ 
            width: 80, 
            height: 80, 
            backgroundColor: '#3B82F6', 
            borderRadius: 20, 
            alignItems: 'center', 
            justifyContent: 'center',
            marginBottom: 16
          }}>
            <Ionicons name="print" size={40} color="white" />
          </View>
          <Text style={{ fontSize: 28, fontWeight: 'bold', color: '#111827', textAlign: 'center' }}>
            PISO Print Express
          </Text>
          <Text style={{ fontSize: 16, color: '#6B7280', textAlign: 'center', marginTop: 8 }}>
            Professional Printing Services
          </Text>
        </View>

        <Text style={{ fontSize: 24, fontWeight: 'bold', color: '#111827', marginBottom: 24, textAlign: 'center' }}>
          Choose Your Service
        </Text>

        <View style={{ gap: 16 }}>
          <Pressable 
            style={({ pressed }) => ({
              backgroundColor: pressed ? '#F3F4F6' : 'white',
              borderRadius: 16,
              padding: 24,
              borderWidth: 2,
              borderColor: '#3B82F6',
              alignItems: 'center'
            })}
            onPress={() => onServiceSelect('document')}
          >
            <Ionicons name="document-text" size={48} color="#3B82F6" />
            <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginTop: 12 }}>
              Digital Documents
            </Text>
            <Text style={{ fontSize: 14, color: '#6B7280', textAlign: 'center', marginTop: 8 }}>
              Print PDF, Word, Excel files
            </Text>
          </Pressable>

          <Pressable 
            style={({ pressed }) => ({
              backgroundColor: pressed ? '#F3F4F6' : 'white',
              borderRadius: 16,
              padding: 24,
              borderWidth: 2,
              borderColor: '#10B981',
              alignItems: 'center'
            })}
            onPress={() => onServiceSelect('scan')}
          >
            <Ionicons name="scan" size={48} color="#10B981" />
            <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginTop: 12 }}>
              AI Document Scanner
            </Text>
            <Text style={{ fontSize: 14, color: '#6B7280', textAlign: 'center', marginTop: 8 }}>
              Scan and enhance documents
            </Text>
          </Pressable>

          <Pressable 
            style={({ pressed }) => ({
              backgroundColor: pressed ? '#F3F4F6' : 'white',
              borderRadius: 16,
              padding: 24,
              borderWidth: 2,
              borderColor: '#8B5CF6',
              alignItems: 'center'
            })}
            onPress={() => onServiceSelect('photo')}
          >
            <Ionicons name="camera" size={48} color="#8B5CF6" />
            <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginTop: 12 }}>
              Photo Prints
            </Text>
            <Text style={{ fontSize: 14, color: '#6B7280', textAlign: 'center', marginTop: 8 }}>
              Professional photo printing
            </Text>
          </Pressable>
        </View>

      </ScrollView>
    </View>
  );
}