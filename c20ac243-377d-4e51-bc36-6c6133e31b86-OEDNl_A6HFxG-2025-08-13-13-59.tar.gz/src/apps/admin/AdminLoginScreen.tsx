import React, { useState } from 'react';
import { View, Text, Pressable, TextInput, Alert, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { cn } from '../../utils/cn';

interface AdminLoginScreenProps {
  onLogin: (credentials: { username: string; password: string; mfaCode?: string }) => void;
}

export default function AdminLoginScreen({ onLogin }: AdminLoginScreenProps) {
  const insets = useSafeAreaInsets();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [mfaCode, setMfaCode] = useState('');
  const [showMFA, setShowMFA] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleInitialLogin = async () => {
    if (!username.trim()) {
      Alert.alert('Missing Information', 'Please enter your admin username');
      return;
    }

    if (!password.trim() || password.length < 6) {
      Alert.alert('Invalid Password', 'Password must be at least 6 characters');
      return;
    }

    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate API call
      
      // For demo, skip MFA and login directly
      onLogin({ username, password });
    } catch (error) {
      Alert.alert('Login Failed', 'Invalid credentials. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleMFALogin = async () => {
    if (!mfaCode.trim() || mfaCode.length !== 6) {
      Alert.alert('Invalid Code', 'Please enter the 6-digit authentication code');
      return;
    }

    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      onLogin({ username, password, mfaCode });
    } catch (error) {
      Alert.alert('Authentication Failed', 'Invalid authentication code. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Quick login for demo
  const quickAdminLogin = () => {
    setUsername('admin');
    setPassword('admin123');
    setTimeout(() => {
      onLogin({ username: 'admin', password: 'admin123' });
    }, 500);
  };

  return (
    <ScrollView className="flex-1 bg-gray-900">
      <View style={{ paddingTop: insets.top + 40 }} className="px-8 flex-1 min-h-screen">
        
        {/* Header */}
        <View className="items-center mb-12">
          <View className="w-20 h-20 bg-red-600 rounded-2xl items-center justify-center mb-6">
            <Ionicons name="shield-checkmark" size={40} color="white" />
          </View>
          <Text className="text-3xl font-bold text-white mb-2">
            Admin Access
          </Text>
          <Text className="text-lg text-gray-300 text-center">
            PISO Print Express Administration
          </Text>
          <View className="bg-red-900 bg-opacity-50 rounded-lg px-4 py-2 mt-4">
            <Text className="text-red-200 text-sm text-center">
              🔒 Secure Admin Portal
            </Text>
          </View>
        </View>

        {/* Security Notice */}
        <View className="bg-yellow-900 bg-opacity-30 border border-yellow-600 rounded-xl p-4 mb-8">
          <View className="flex-row items-start">
            <Ionicons name="warning" size={20} color="#FBBF24" />
            <View className="ml-3 flex-1">
              <Text className="text-yellow-200 font-medium text-sm">
                Administrative Access
              </Text>
              <Text className="text-yellow-300 text-sm mt-1 leading-relaxed">
                This portal provides full system control. Only authorized personnel should access this interface.
              </Text>
            </View>
          </View>
        </View>

        {!showMFA ? (
          /* Initial Login Form */
          <View className="bg-gray-800 rounded-2xl p-6 mb-8">
            <Text className="text-xl font-semibold text-white mb-6">
              Administrator Sign In
            </Text>
            
            <View className="mb-6">
              <View className="mb-4">
                <Text className="text-sm font-medium text-gray-300 mb-2">
                  Admin Username
                </Text>
                <View className="relative">
                  <Ionicons 
                    name="person" 
                    size={20} 
                    color="#9CA3AF" 
                    style={{ position: 'absolute', left: 16, top: 14, zIndex: 1 }}
                  />
                  <TextInput
                    className="bg-gray-700 border border-gray-600 rounded-xl pl-12 pr-4 py-3 text-base text-white"
                    value={username}
                    onChangeText={setUsername}
                    placeholder="Enter admin username"
                    placeholderTextColor="#9CA3AF"
                    autoCapitalize="none"
                  />
                </View>
              </View>
              
              <View>
                <Text className="text-sm font-medium text-gray-300 mb-2">
                  Password
                </Text>
                <View className="relative">
                  <Ionicons 
                    name="lock-closed" 
                    size={20} 
                    color="#9CA3AF" 
                    style={{ position: 'absolute', left: 16, top: 14, zIndex: 1 }}
                  />
                  <TextInput
                    className="bg-gray-700 border border-gray-600 rounded-xl pl-12 pr-12 py-3 text-base text-white"
                    value={password}
                    onChangeText={setPassword}
                    placeholder="Enter secure password"
                    placeholderTextColor="#9CA3AF"
                    secureTextEntry={!showPassword}
                  />
                  <Pressable
                    onPress={() => setShowPassword(!showPassword)}
                    style={{ position: 'absolute', right: 16, top: 14 }}
                  >
                    <Ionicons 
                      name={showPassword ? "eye-off" : "eye"} 
                      size={20} 
                      color="#9CA3AF" 
                    />
                  </Pressable>
                </View>
              </View>
            </View>

            <Pressable 
              className={cn(
                "py-4 rounded-xl",
                loading ? "bg-gray-600" : "bg-red-600"
              )}
              onPress={handleInitialLogin}
              disabled={loading}
            >
              <Text className="text-white text-center font-semibold text-lg">
                {loading ? 'Authenticating...' : 'Sign In'}
              </Text>
            </Pressable>
          </View>
        ) : (
          /* MFA Form */
          <View className="bg-gray-800 rounded-2xl p-6 mb-8">
            <View className="items-center mb-6">
              <View className="w-16 h-16 bg-blue-600 rounded-full items-center justify-center mb-4">
                <Ionicons name="phone-portrait" size={32} color="white" />
              </View>
              <Text className="text-xl font-semibold text-white mb-2">
                Two-Factor Authentication
              </Text>
              <Text className="text-gray-300 text-center">
                Enter the 6-digit code from your authenticator app
              </Text>
            </View>
            
            <View className="mb-6">
              <Text className="text-sm font-medium text-gray-300 mb-2 text-center">
                Authentication Code
              </Text>
              <TextInput
                className="bg-gray-700 border border-gray-600 rounded-xl px-4 py-4 text-2xl text-white text-center tracking-widest"
                value={mfaCode}
                onChangeText={setMfaCode}
                placeholder="000000"
                placeholderTextColor="#6B7280"
                keyboardType="numeric"
                maxLength={6}
              />
            </View>

            <Pressable 
              className={cn(
                "py-4 rounded-xl mb-4",
                loading ? "bg-gray-600" : "bg-red-600"
              )}
              onPress={handleMFALogin}
              disabled={loading}
            >
              <Text className="text-white text-center font-semibold text-lg">
                {loading ? 'Verifying...' : 'Verify & Login'}
              </Text>
            </Pressable>

            <Pressable onPress={() => setShowMFA(false)}>
              <Text className="text-gray-400 text-center">
                Back to login
              </Text>
            </Pressable>
          </View>
        )}

        {/* Demo Quick Access */}
        <View className="bg-blue-900 bg-opacity-30 rounded-xl p-4 mb-8">
          <Text className="text-blue-200 font-medium mb-3 text-center">
            🚀 Demo Admin Access
          </Text>
          <Pressable 
            className="bg-blue-600 py-3 rounded-lg"
            onPress={quickAdminLogin}
          >
            <Text className="text-white text-center font-medium">
              Quick Admin Login (Demo)
            </Text>
          </Pressable>
          <Text className="text-blue-300 text-xs text-center mt-2">
            Username: admin | Password: admin123
          </Text>
        </View>

        {/* Admin Features */}
        <View className="bg-gray-800 rounded-xl p-6 mb-8">
          <Text className="text-lg font-semibold text-white mb-4">
            Administrative Capabilities
          </Text>
          <View>
            <AdminFeatureItem 
              icon="settings"
              title="System Configuration"
              description="Manage print settings and controls"
            />
            <AdminFeatureItem 
              icon="bar-chart"
              title="Business Analytics"
              description="Revenue reports and performance metrics"
            />
            <AdminFeatureItem 
              icon="people"
              title="Staff Management"
              description="Operator accounts and permissions"
            />
            <AdminFeatureItem 
              icon="shield-checkmark"
              title="Security Controls"
              description="Access management and audit logs"
            />
          </View>
        </View>

        <View className="items-center mb-8">
          <Text className="text-gray-500 text-xs text-center">
            PISO Print Express v1.0 • Secure Admin Portal
          </Text>
        </View>

      </View>
    </ScrollView>
  );
}

function AdminFeatureItem({ icon, title, description }: { 
  icon: keyof typeof Ionicons.glyphMap; 
  title: string; 
  description: string; 
}) {
  return (
    <View className="flex-row items-center">
      <View className="w-10 h-10 bg-red-900 bg-opacity-50 rounded-full items-center justify-center mr-3">
        <Ionicons name={icon} size={18} color="#F87171" />
      </View>
      <View className="flex-1">
        <Text className="font-medium text-white">{title}</Text>
        <Text className="text-sm text-gray-400">{description}</Text>
      </View>
    </View>
  );
}