import React, { useState, useEffect } from 'react';
import { View, Alert, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';
import { useNewAppStore } from '../state/newAppStore';
import { newApiClient } from '../api/newPisoAPI';
import { useDeviceInfo } from '../utils/deviceDetection';

import OperatorLoginScreen from './operator/OperatorLoginScreen';
import OperatorDashboard from '../screens/OperatorDashboard';
import OperatorDesktopDashboardEnhanced from '../screens/OperatorDesktopDashboardEnhanced';
import OperatorMobileScreen from '../screens/mobile/OperatorMobileScreen';
import CustomerApp from './CustomerApp';

type OperatorFlow = 
  | 'login'
  | 'dashboard'
  | 'customer_assist';

export default function OperatorApp() {
  const { currentUser, isAuthenticated, login } = useAuthStore();
  const deviceInfo = useDeviceInfo();
  const [currentFlow, setCurrentFlow] = useState<OperatorFlow>('login');
  const [operatorShift, setOperatorShift] = useState<'morning' | 'afternoon' | 'evening'>('morning');

  useEffect(() => {
    if (isAuthenticated && currentUser?.role === 'operator') {
      setCurrentFlow('dashboard');
    } else {
      setCurrentFlow('login');
    }
  }, [isAuthenticated, currentUser]);

  const handleOperatorLogin = async (credentials: { employeeId: string; pin: string; shift: string }) => {
    try {
      // In real app, this would validate employee credentials
      const operatorUser = await newApiClient.authenticateUser(
        `operator_${credentials.employeeId}@pisoprint.com`,
        'operator'
      );
      
      login({
        ...operatorUser,
        name: `Operator ${credentials.employeeId}`,
        role: 'operator',
      });

      setOperatorShift(credentials.shift as any);
      setCurrentFlow('dashboard');

      Alert.alert(
        'Login Successful',
        `Welcome back! You are now logged in for ${credentials.shift} shift.`,
        [{ text: 'OK' }]
      );

    } catch (error) {
      Alert.alert('Login Failed', 'Invalid credentials. Please try again.');
    }
  };

  const handleSwitchToCustomerAssist = () => {
    setCurrentFlow('customer_assist');
  };

  const handleBackToDashboard = () => {
    setCurrentFlow('dashboard');
  };

  const renderCurrentScreen = () => {
    switch (currentFlow) {
      case 'login':
        return (
          <OperatorLoginScreen
            onLogin={handleOperatorLogin}
          />
        );

      case 'dashboard':
        return deviceInfo.isDesktop ? (
          <OperatorDesktopDashboardEnhanced
            onSwitchToCustomer={handleSwitchToCustomerAssist}
          />
        ) : deviceInfo.isMobile || deviceInfo.isTablet ? (
          <OperatorMobileScreen />
        ) : (
          <OperatorDashboard
            onSwitchToCustomer={handleSwitchToCustomerAssist}
          />
        );

      case 'customer_assist':
        return (
          <View className="flex-1">
            {/* Customer assistance mode - simplified customer app */}
            <CustomerApp />
            {/* Add floating back button for operator */}
            <View className="absolute top-12 right-4 z-50">
              <Pressable 
                className="bg-green-600 w-14 h-14 rounded-full items-center justify-center shadow-lg"
                onPress={handleBackToDashboard}
              >
                <Ionicons name="person-outline" size={24} color="white" />
              </Pressable>
            </View>
          </View>
        );

      default:
        return (
          <OperatorLoginScreen
            onLogin={handleOperatorLogin}
          />
        );
    }
  };

  return (
    <View className="flex-1">
      {renderCurrentScreen()}
    </View>
  );
}