import React, { useState } from 'react';
import { View, Text, Pressable, ScrollView, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { APP_CONFIG } from '../config/AppConfig';
import { cn } from '../utils/cn';

import CustomerApp from './CustomerApp';
import { useAuthStore } from '../state/authStore';
import { useNewAppStore } from '../state/newAppStore';
import OperatorApp from './OperatorApp';
import AdminApp from './AdminApp';

type AppMode = 'selector' | 'customer' | 'operator' | 'admin';

export default function DevelopmentApp() {
  const insets = useSafeAreaInsets();
  const [currentMode, setCurrentMode] = useState<AppMode>('selector');
  const { resetAuth } = useAuthStore();
  const { resetAppState } = useNewAppStore();

  const handleModeSwitch = (newMode: AppMode) => {
    // Reset state when switching modes to prevent pollution
    if (newMode === 'customer' || newMode === 'selector') {
      resetAuth();
      resetAppState();
    }
    setCurrentMode(newMode);
  };

  if (currentMode !== 'selector') {
    return (
      <View className="flex-1">
        {/* Development Mode Indicator */}
        <View className="absolute top-0 left-0 right-0 z-50 bg-yellow-500" style={{ paddingTop: insets.top }}>
          <View className="flex-row items-center justify-between px-4 py-2">
            <Text className="text-yellow-900 font-bold text-sm">
              🧪 DEV MODE: {currentMode.toUpperCase()}
            </Text>
            <Pressable 
              onPress={() => handleModeSwitch('selector')}
              className="bg-yellow-600 px-3 py-1 rounded"
            >
              <Text className="text-white text-xs font-medium">SWITCH</Text>
            </Pressable>
          </View>
        </View>

        {/* App Content with offset for dev banner */}
        <View className="flex-1" style={{ marginTop: 40 + insets.top }}>
          {currentMode === 'customer' && <CustomerApp />}
          {currentMode === 'operator' && <OperatorApp />}
          {currentMode === 'admin' && <AdminApp />}
        </View>
      </View>
    );
  }

  return (
    <ScrollView className="flex-1 bg-gray-100">
      <View style={{ paddingTop: insets.top + 20 }} className="px-6 pb-8">
        
        {/* Development Header */}
        <View className="bg-yellow-50 border-l-4 border-yellow-400 rounded-r-xl p-4 mb-8">
          <View className="flex-row items-start">
            <Ionicons name="warning" size={20} color="#F59E0B" />
            <View className="ml-3 flex-1">
              <Text className="text-yellow-800 font-bold">Development Mode</Text>
              <Text className="text-yellow-700 text-sm mt-1">
                Testing environment with all app features available. In production, each deployment type will show only its relevant interface.
              </Text>
            </View>
          </View>
        </View>

        {/* App Info */}
        <View className="bg-white rounded-xl p-6 mb-8">
          <Text className="text-2xl font-bold text-gray-900 mb-4">
            PISO Print Express
          </Text>
          
          <View>
            <View className="mb-3">
              <InfoRow label="Current Config" value={APP_CONFIG.deploymentType} />
            </View>
            <View className="mb-3">
              <InfoRow label="Platform" value={APP_CONFIG.deployment.platform} />
            </View>
            <View className="mb-3">
              <InfoRow label="Environment" value={APP_CONFIG.deployment.environment} />
            </View>
            <View>
              <InfoRow label="Version" value="Development Build" />
            </View>
          </View>
        </View>

        {/* App Selection */}
        <View className="mb-8">
          <Text className="text-xl font-bold text-gray-900 mb-4">
            Choose App to Test
          </Text>
          
          <View>
            <View className="mb-4">
              <AppModeCard
                icon="phone-portrait"
                title="Customer App"
                subtitle="Mobile app for end customers"
                description="Print ordering, payment, tracking on personal devices"
                color="bg-blue-500"
                deployment="📱 Google Play / App Store"
                onPress={() => handleModeSwitch('customer')}
              />
            </View>
            
            <View className="mb-4">
              <AppModeCard
                icon="tablet-portrait"
                title="Operator Station"
                subtitle="Kiosk/tablet interface for staff"
                description="Job processing, customer assistance, payment handling"
                color="bg-green-500"
                deployment="🏪 In-store tablets / kiosks"
                onPress={() => handleModeSwitch('operator')}
              />
            </View>
            
            <View>
              <AppModeCard
                icon="desktop"
                title="Admin Dashboard"
                subtitle="Management console for business owners"
                description="System settings, analytics, staff management, reports"
                color="bg-red-500"
                deployment="💻 Office computers / Web portal"
                onPress={() => handleModeSwitch('admin')}
              />
            </View>
          </View>
        </View>

        {/* Architecture Info */}
        <View className="bg-white rounded-xl p-6">
          <Text className="text-lg font-semibold text-gray-900 mb-4">
            Production Deployment Architecture
          </Text>
          
          <View>
            <View className="mb-4">
              <ArchitectureItem
                title="Customer Mobile App"
                details={[
                  "Distributed via app stores",
                  "No role selection - customer only",
                  "Guest users allowed",
                  "Order tracking & payment"
                ]}
              />
            </View>
            
            <View className="mb-4">
              <ArchitectureItem
                title="Operator Kiosk/Tablet"
                details={[
                  "Installed on in-store devices",
                  "Requires employee authentication",
                  "Job processing interface",
                  "Customer assistance mode"
                ]}
              />
            </View>
            
            <View>
              <ArchitectureItem
                title="Admin Web/Desktop"
                details={[
                  "Web portal or desktop app",
                  "Secure admin authentication",
                  "Full system management",
                  "Business intelligence & reports"
                ]}
              />
            </View>
          </View>
        </View>

      </View>
    </ScrollView>
  );
}

interface AppModeCardProps {
  icon: keyof typeof Ionicons.glyphMap;
  title: string;
  subtitle: string;
  description: string;
  color: string;
  deployment: string;
  onPress: () => void;
}

function AppModeCard({ icon, title, subtitle, description, color, deployment, onPress }: AppModeCardProps) {
  return (
    <Pressable 
      className="bg-white rounded-xl p-6 border border-gray-200 active:bg-gray-50"
      onPress={onPress}
    >
      <View className="flex-row items-start">
        <View className={cn("w-16 h-16 rounded-2xl items-center justify-center mr-4", color)}>
          <Ionicons name={icon} size={28} color="white" />
        </View>
        
        <View className="flex-1">
          <Text className="text-lg font-bold text-gray-900 mb-1">
            {title}
          </Text>
          <Text className="text-blue-600 font-medium mb-2">
            {subtitle}
          </Text>
          <Text className="text-gray-600 mb-3 leading-relaxed">
            {description}
          </Text>
          <View className="bg-gray-50 rounded-lg px-3 py-2 mb-3">
            <Text className="text-xs text-gray-600 font-medium">
              {deployment}
            </Text>
          </View>
          <View className="flex-row items-center">
            <Text className="text-blue-600 font-medium mr-2">Test This App</Text>
            <Ionicons name="arrow-forward" size={16} color="#3B82F6" />
          </View>
        </View>
      </View>
    </Pressable>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <View className="flex-row justify-between">
      <Text className="text-gray-600">{label}</Text>
      <Text className="font-medium text-gray-900">{value}</Text>
    </View>
  );
}

function ArchitectureItem({ title, details }: { title: string; details: string[] }) {
  return (
    <View>
      <Text className="font-medium text-gray-900 mb-2">{title}</Text>
      <View className="ml-4">
        {details.map((detail, index) => (
          <View key={index} className={cn("flex-row items-start", index > 0 ? "mt-1" : "")}>
            <View className="w-1.5 h-1.5 bg-gray-400 rounded-full mr-3 mt-2" />
            <Text className="text-sm text-gray-600 flex-1">{detail}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}