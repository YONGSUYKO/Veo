import React, { useState } from 'react';
import { View, Text, Pressable, TextInput, Alert, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { cn } from '../../utils/cn';

interface OperatorLoginScreenProps {
  onLogin: (credentials: { employeeId: string; pin: string; shift: string }) => void;
}

export default function OperatorLoginScreen({ onLogin }: OperatorLoginScreenProps) {
  const insets = useSafeAreaInsets();
  const [employeeId, setEmployeeId] = useState('');
  const [pin, setPin] = useState('');
  const [selectedShift, setSelectedShift] = useState<'morning' | 'afternoon' | 'evening'>('morning');
  const [loading, setLoading] = useState(false);
  const [showBiometric, setShowBiometric] = useState(false);

  const shifts = [
    { id: 'morning', label: 'Morning Shift', time: '6:00 AM - 2:00 PM', icon: 'sunny' },
    { id: 'afternoon', label: 'Afternoon Shift', time: '2:00 PM - 10:00 PM', icon: 'partly-sunny' },
    { id: 'evening', label: 'Evening Shift', time: '10:00 PM - 6:00 AM', icon: 'moon' },
  ] as const;

  const handleLogin = async () => {
    if (!employeeId.trim()) {
      Alert.alert('Missing Information', 'Please enter your Employee ID');
      return;
    }

    if (!pin.trim() || pin.length < 4) {
      Alert.alert('Invalid PIN', 'Please enter a valid 4-digit PIN');
      return;
    }

    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
      onLogin({
        employeeId: employeeId.trim(),
        pin,
        shift: selectedShift,
      });
    } catch (error) {
      Alert.alert('Login Failed', 'Please check your credentials and try again.');
    } finally {
      setLoading(false);
    }
  };

  // Biometric authentication with proper validation
  const handleBiometricLogin = async () => {
    // First validate that a finger is present
    if (!employeeId.trim()) {
      Alert.alert('Employee Required', 'Please enter your Employee ID first, then use fingerprint to verify.');
      setShowBiometric(false);
      return;
    }

    setLoading(true);
    try {
      // Simulate realistic fingerprint scanning delay
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Simulate fingerprint validation for the entered employee
      if (employeeId.trim() === 'OP001' || employeeId.trim() === 'OP002') {
        onLogin({
          employeeId: employeeId.trim(),
          pin: 'BIOMETRIC_VERIFIED',
          shift: selectedShift,
        });
      } else {
        Alert.alert(
          'Fingerprint Mismatch', 
          `No fingerprint registered for Employee ID: ${employeeId}. Please use manual login or contact admin.`
        );
      }
    } catch (error) {
      Alert.alert('Biometric Failed', 'Fingerprint scanner error. Please try manual login.');
    } finally {
      setLoading(false);
      setShowBiometric(false);
    }
  };

  // Quick login for demo
  const quickLogin = (id: string, shift: 'morning' | 'afternoon' | 'evening') => {
    setEmployeeId(id);
    setPin('1234');
    setSelectedShift(shift);
  };

  return (
    <KeyboardAvoidingView 
      className="flex-1 bg-gray-50" 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
    >
      <ScrollView 
        className="flex-1" 
        contentContainerStyle={{ flexGrow: 1 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <View style={{ paddingTop: insets.top + 40 }} className="px-8 flex-1">
        
        {/* Header */}
        <View className="items-center mb-12">
          <View className="w-20 h-20 bg-green-600 rounded-2xl items-center justify-center mb-6">
            <Ionicons name="construct" size={40} color="white" />
          </View>
          <Text className="text-3xl font-bold text-gray-900 mb-2">
            Operator Station
          </Text>
          <Text className="text-lg text-gray-600 text-center">
            PISO Print Express Staff Login
          </Text>
        </View>

        {/* Login Form */}
        <View className="bg-white rounded-2xl p-6 mb-8 shadow-sm">
          <Text className="text-xl font-semibold text-gray-900 mb-6">
            Sign In to Start Your Shift
          </Text>
          
          <View className="mb-6">
            <View className="mb-4">
              <Text className="text-sm font-medium text-gray-700 mb-2">
                Employee ID
              </Text>
              <TextInput
                className="border border-gray-300 rounded-xl px-4 py-3 text-base"
                value={employeeId}
                onChangeText={setEmployeeId}
                placeholder="Enter your employee ID"
                autoCapitalize="none"
              />
            </View>
            
            <View>
              <Text className="text-sm font-medium text-gray-700 mb-2">
                PIN Code
              </Text>
              <TextInput
                className="border border-gray-300 rounded-xl px-4 py-3 text-base"
                value={pin}
                onChangeText={setPin}
                placeholder="4-digit PIN"
                secureTextEntry
                keyboardType="numeric"
                maxLength={4}
              />
            </View>
          </View>

          {/* Shift Selection */}
          <View className="mb-6">
            <Text className="text-sm font-medium text-gray-700 mb-3">
              Select Your Shift
            </Text>
            <View>
              {shifts.map((shift, index) => (
                <Pressable
                  key={shift.id}
                  onPress={() => setSelectedShift(shift.id)}
                  className={cn(
                    "border-2 rounded-xl p-4",
                    selectedShift === shift.id
                      ? "bg-green-50 border-green-500"
                      : "bg-white border-gray-200",
                    index > 0 ? "mt-3" : ""
                  )}
                >
                  <View className="flex-row items-center">
                    <View className={cn(
                      "w-12 h-12 rounded-xl items-center justify-center mr-4",
                      selectedShift === shift.id ? "bg-green-500" : "bg-gray-100"
                    )}>
                      <Ionicons 
                        name={shift.icon as any} 
                        size={24} 
                        color={selectedShift === shift.id ? "white" : "#6B7280"} 
                      />
                    </View>
                    <View className="flex-1">
                      <Text className={cn(
                        "font-semibold",
                        selectedShift === shift.id ? "text-green-900" : "text-gray-900"
                      )}>
                        {shift.label}
                      </Text>
                      <Text className={cn(
                        "text-sm",
                        selectedShift === shift.id ? "text-green-700" : "text-gray-600"
                      )}>
                        {shift.time}
                      </Text>
                    </View>
                    {selectedShift === shift.id && (
                      <Ionicons name="checkmark-circle" size={24} color="#10B981" />
                    )}
                  </View>
                </Pressable>
              ))}
            </View>
          </View>

          <Pressable 
            className={cn(
              "py-4 rounded-xl mb-4",
              loading ? "bg-gray-400" : "bg-green-600"
            )}
            onPress={handleLogin}
            disabled={loading}
          >
            <Text className="text-white text-center font-semibold text-lg">
              {loading ? 'Signing In...' : 'Start Shift'}
            </Text>
          </Pressable>

          {/* Biometric Login Option */}
          <Pressable 
            className="border-2 border-green-600 py-4 rounded-xl"
            onPress={() => setShowBiometric(true)}
            disabled={loading}
          >
            <View className="flex-row items-center justify-center">
              <Ionicons name="finger-print" size={24} color="#16A34A" />
              <Text className="text-green-600 font-semibold text-lg ml-2">
                Use Fingerprint
              </Text>
            </View>
          </Pressable>
        </View>

        {/* Quick Demo Login */}
        <View className="bg-blue-50 rounded-xl p-4 mb-8">
          <Text className="text-blue-900 font-medium mb-3 text-center">
            🚀 Demo Quick Login
          </Text>
          <View className="flex-row">
            <Pressable 
              className="flex-1 bg-blue-500 py-3 rounded-lg mr-3"
              onPress={() => quickLogin('OP001', 'morning')}
            >
              <Text className="text-white text-center font-medium">
                Morning Staff
              </Text>
            </Pressable>
            <Pressable 
              className="flex-1 bg-blue-500 py-3 rounded-lg"
              onPress={() => quickLogin('OP002', 'afternoon')}
            >
              <Text className="text-white text-center font-medium">
                Afternoon Staff
              </Text>
            </Pressable>
          </View>
        </View>

        {/* Features Info */}
        <View className="bg-white rounded-xl p-6">
          <Text className="text-lg font-semibold text-gray-900 mb-4">
            Operator Features
          </Text>
          <View>
            <View className="mb-3">
              <FeatureItem 
                icon="print"
                title="Process Print Jobs"
                description="Manage queue and update job status"
              />
            </View>
            <View className="mb-3">
              <FeatureItem 
                icon="person-add"
                title="Assist Customers"
                description="Help customers place orders"
              />
            </View>
            <View className="mb-3">
              <FeatureItem 
                icon="cash"
                title="Handle Payments"
                description="Process cash and other payments"
              />
            </View>
            <View>
              <FeatureItem 
                icon="notifications"
                title="Send Updates"
                description="Notify customers about job status"
              />
            </View>
          </View>
        </View>

        </View>
      </ScrollView>

      {/* Biometric Authentication Modal */}
      {showBiometric && (
        <View className="absolute inset-0 bg-black bg-opacity-50 items-center justify-center px-6">
          <View className="bg-white rounded-2xl p-6 max-w-sm w-full">
            <View className="items-center mb-6">
              <View className="w-20 h-20 bg-green-100 rounded-full items-center justify-center mb-4">
                <Ionicons name="finger-print" size={40} color="#16A34A" />
              </View>
              <Text className="text-xl font-bold text-gray-900 text-center mb-2">
                Fingerprint Verification
              </Text>
              <Text className="text-gray-600 text-center mb-4">
                {employeeId.trim() ? 
                  `Verifying identity for: ${employeeId}` : 
                  'Enter Employee ID first to enable fingerprint'
                }
              </Text>
              
              {loading ? (
                <View className="items-center">
                  <View className="w-16 h-16 bg-green-50 rounded-full items-center justify-center mb-2">
                    <Ionicons name="finger-print" size={24} color="#16A34A" />
                  </View>
                  <Text className="text-green-600 font-medium">
                    Place your registered index finger on the sensor...
                  </Text>
                  <Text className="text-sm text-gray-500 mt-1">
                    Hold steady for 3 seconds
                  </Text>
                </View>
              ) : (
                <View className="items-center">
                  <Text className="text-blue-600 font-medium text-center">
                    👆 Ready to scan your index finger
                  </Text>
                  <Text className="text-sm text-gray-500 mt-1 text-center">
                    Make sure your finger is clean and dry
                  </Text>
                </View>
              )}
            </View>

            <View className="bg-green-50 rounded-xl p-4 mb-4">
              <Text className="text-sm font-semibold text-green-800 mb-1">
                Selected Shift: {shifts.find(s => s.id === selectedShift)?.label}
              </Text>
              <Text className="text-sm text-green-700">
                {shifts.find(s => s.id === selectedShift)?.time}
              </Text>
            </View>

            <View className="flex-row">
              <Pressable 
                className="flex-1 bg-gray-100 py-3 rounded-xl mr-3"
                onPress={() => setShowBiometric(false)}
                disabled={loading}
              >
                <Text className="text-gray-700 text-center font-medium">
                  Cancel
                </Text>
              </Pressable>
              
              <Pressable 
                className={cn(
                  "flex-1 py-3 rounded-xl",
                  loading ? "bg-gray-400" : !employeeId.trim() ? "bg-gray-300" : "bg-green-500"
                )}
                onPress={handleBiometricLogin}
                disabled={loading || !employeeId.trim()}
              >
                <Text className="text-white text-center font-medium">
                  {loading ? 'Scanning Finger...' : !employeeId.trim() ? 'Enter ID First' : 'Start Scan'}
                </Text>
              </Pressable>
            </View>
          </View>
        </View>
      )}
    </KeyboardAvoidingView>
  );
}

function FeatureItem({ icon, title, description }: { 
  icon: keyof typeof Ionicons.glyphMap; 
  title: string; 
  description: string; 
}) {
  return (
    <View className="flex-row items-center">
      <View className="w-10 h-10 bg-green-100 rounded-full items-center justify-center mr-3">
        <Ionicons name={icon} size={18} color="#10B981" />
      </View>
      <View className="flex-1">
        <Text className="font-medium text-gray-900">{title}</Text>
        <Text className="text-sm text-gray-600">{description}</Text>
      </View>
    </View>
  );
}