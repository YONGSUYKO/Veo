import React from 'react';
import { View, Text, StyleSheet, Pressable, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';

export default function AdminMobileApp() {
  const insets = useSafeAreaInsets();
  const { currentUser, logout } = useAuthStore();

  const handleViewDashboard = () => {
    alert('Today: ₱2,450 revenue, 18 orders, 3 staff');
  };

  const handleManageStaff = () => {
    alert('3 staff members: 2 on duty, 1 off');
  };

  const handleViewReports = () => {
    alert('Weekly report: 15% increase in orders');
  };

  const handleSystemSettings = () => {
    alert('Settings: Pricing, paper sizes, business hours');
  };

  const handleLogout = () => {
    logout();
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Header */}
        <View style={[styles.header, { paddingTop: insets.top + 20 }]}>
          <View style={styles.headerContent}>
            <View style={styles.userInfo}>
              <View style={styles.avatarContainer}>
                <Ionicons name="shield-checkmark" size={24} color="white" />
              </View>
              <View>
                <Text style={styles.userName}>{currentUser?.name}</Text>
                <Text style={styles.userRole}>Administrator</Text>
              </View>
            </View>
            
            <Pressable style={styles.logoutButton} onPress={handleLogout}>
              <Ionicons name="log-out" size={20} color="white" />
            </Pressable>
          </View>
        </View>

        {/* Quick Stats */}
        <View style={styles.statsContainer}>
          <View style={styles.statsCard}>
            <Text style={styles.sectionTitle}>Today's Overview</Text>
            
            <View style={styles.statsGrid}>
              <View style={styles.statItem}>
                <View style={[styles.statIcon, { backgroundColor: '#10B98120' }]}>
                  <Ionicons name="cash" size={24} color="#10B981" />
                </View>
                <Text style={styles.statValue}>₱2,450</Text>
                <Text style={styles.statLabel}>Revenue</Text>
              </View>

              <View style={styles.statItem}>
                <View style={[styles.statIcon, { backgroundColor: '#3B82F620' }]}>
                  <Ionicons name="receipt" size={24} color="#3B82F6" />
                </View>
                <Text style={styles.statValue}>18</Text>
                <Text style={styles.statLabel}>Orders</Text>
              </View>

              <View style={styles.statItem}>
                <View style={[styles.statIcon, { backgroundColor: '#8B5CF620' }]}>
                  <Ionicons name="people" size={24} color="#8B5CF6" />
                </View>
                <Text style={styles.statValue}>3</Text>
                <Text style={styles.statLabel}>Staff</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.actionsContainer}>
          <View style={styles.actionsCard}>
            <Text style={styles.sectionTitle}>Quick Actions</Text>
            
            <View style={styles.actionsList}>
              <Pressable style={styles.actionButton} onPress={handleViewDashboard}>
                <View style={[styles.actionIcon, { backgroundColor: '#3B82F620' }]}>
                  <Ionicons name="analytics" size={24} color="#3B82F6" />
                </View>
                <View style={styles.actionInfo}>
                  <Text style={styles.actionTitle}>Dashboard</Text>
                  <Text style={styles.actionDescription}>View business metrics</Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
              </Pressable>

              <Pressable style={styles.actionButton} onPress={handleManageStaff}>
                <View style={[styles.actionIcon, { backgroundColor: '#8B5CF620' }]}>
                  <Ionicons name="people" size={24} color="#8B5CF6" />
                </View>
                <View style={styles.actionInfo}>
                  <Text style={styles.actionTitle}>Staff Management</Text>
                  <Text style={styles.actionDescription}>Manage employees</Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
              </Pressable>

              <Pressable style={styles.actionButton} onPress={handleViewReports}>
                <View style={[styles.actionIcon, { backgroundColor: '#10B98120' }]}>
                  <Ionicons name="document-text" size={24} color="#10B981" />
                </View>
                <View style={styles.actionInfo}>
                  <Text style={styles.actionTitle}>Reports</Text>
                  <Text style={styles.actionDescription}>Analytics & insights</Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
              </Pressable>

              <Pressable style={styles.actionButton} onPress={handleSystemSettings}>
                <View style={[styles.actionIcon, { backgroundColor: '#F59E0B20' }]}>
                  <Ionicons name="settings" size={24} color="#F59E0B" />
                </View>
                <View style={styles.actionInfo}>
                  <Text style={styles.actionTitle}>System Settings</Text>
                  <Text style={styles.actionDescription}>Configure business rules</Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
              </Pressable>
            </View>
          </View>
        </View>

        {/* Limitations Notice */}
        <View style={styles.limitationsContainer}>
          <View style={styles.limitationsCard}>
            <Ionicons name="information-circle" size={24} color="#DC2626" />
            <View style={styles.limitationsText}>
              <Text style={styles.limitationsTitle}>Mobile Admin Limitations</Text>
              <Text style={styles.limitationsDescription}>
                This mobile interface provides basic admin overview. For full administrative 
                functions including detailed reports, system configuration, and user management, 
                please use the web portal or desktop application.
              </Text>
            </View>
          </View>
        </View>

        {/* Quick Access to Web Portal */}
        <View style={styles.webPortalContainer}>
          <View style={styles.webPortalCard}>
            <Text style={styles.sectionTitle}>Full Admin Access</Text>
            <Text style={styles.webPortalDescription}>
              Access the complete admin dashboard with advanced features
            </Text>
            <Pressable style={styles.webPortalButton}>
              <Ionicons name="laptop" size={20} color="white" />
              <Text style={styles.webPortalButtonText}>Open Web Portal</Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  scrollContent: {
    paddingBottom: 20,
  },
  header: {
    backgroundColor: '#DC2626',
    paddingHorizontal: 24,
    paddingBottom: 32,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatarContainer: {
    width: 48,
    height: 48,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  userName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  userRole: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
  },
  logoutButton: {
    width: 40,
    height: 40,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statsContainer: {
    paddingHorizontal: 24,
    marginTop: -16,
  },
  statsCard: {
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 24,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statItem: {
    alignItems: 'center',
    flex: 1,
  },
  statIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#111827',
  },
  statLabel: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 4,
  },
  actionsContainer: {
    paddingHorizontal: 24,
  },
  actionsCard: {
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 24,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    marginBottom: 24,
  },
  actionsList: {
    gap: 12,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
  },
  actionIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  actionInfo: {
    flex: 1,
  },
  actionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
  },
  actionDescription: {
    fontSize: 14,
    color: '#6B7280',
  },
  limitationsContainer: {
    paddingHorizontal: 24,
    marginBottom: 24,
  },
  limitationsCard: {
    backgroundColor: '#FEF2F2',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  limitationsText: {
    flex: 1,
    marginLeft: 12,
  },
  limitationsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#991B1B',
    marginBottom: 4,
  },
  limitationsDescription: {
    fontSize: 12,
    color: '#B91C1C',
    lineHeight: 18,
  },
  webPortalContainer: {
    paddingHorizontal: 24,
  },
  webPortalCard: {
    backgroundColor: '#1F2937',
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
  },
  webPortalDescription: {
    fontSize: 14,
    color: '#9CA3AF',
    textAlign: 'center',
    marginBottom: 20,
  },
  webPortalButton: {
    backgroundColor: '#3B82F6',
    borderRadius: 12,
    paddingHorizontal: 24,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
  },
  webPortalButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: 'white',
    marginLeft: 8,
  },
});