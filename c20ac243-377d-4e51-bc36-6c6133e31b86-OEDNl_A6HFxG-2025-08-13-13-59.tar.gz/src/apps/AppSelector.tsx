import React from "react";
import { Platform } from "react-native";
import CustomerApp from "../screens/customer/CustomerApp";
import OperatorApp from "../screens/operator/OperatorApp";
import OperatorMobileMonitor from "../screens/operator/OperatorMobileMonitor";
import AdminApp from "../screens/admin/AdminApp";
import ErrorScreen from "../screens/ErrorScreen";
import DevelopmentApp from './DevelopmentApp';
import { isDevelopmentMode } from '../config/AppConfig';

// Get environment variable
const appType = process.env.EXPO_PUBLIC_APP_TYPE || "customer";

// Simple device type detection
const isWeb = Platform.OS === "web";
const isMobile = Platform.OS === "ios" || Platform.OS === "android";
const isDesktop = isWeb && typeof navigator !== "undefined" && !/Mobile|Android|iP(ad|hone)/i.test(navigator.userAgent);
const isKiosk = typeof window !== "undefined" && window.innerWidth >= 1024 && window.innerHeight <= 800;

// AppSelector decides which version of the app to load
export default function AppSelector() {
  console.log('🚀 PISO Print Express Starting...');
  console.log('📱 App Type:', appType);
  console.log('🔧 Platform:', Platform.OS);
  console.log('📱 Mobile:', isMobile);
  console.log('💻 Desktop:', isDesktop);
  console.log('🖥️ Kiosk:', isKiosk);

  // Development mode shows all features for testing
  if (isDevelopmentMode()) {
    console.log('🧪 Development mode - showing all features');
    return <DevelopmentApp />;
  }

  // CUSTOMER (Allowed on mobile, kiosk, web)
  if (appType === "customer") {
    console.log('📱 Loading Customer App');
    return <CustomerApp />;
  }

  // OPERATOR
  if (appType === "operator") {
    if (isMobile) {
      // Mobile operator only gets monitoring + attendance
      console.log('📱 Loading Operator Mobile Monitor');
      return <OperatorMobileMonitor />;
    } else {
      // Desktop operator gets full access
      console.log('🏪 Loading Operator Desktop App');
      return <OperatorApp />;
    }
  }

  // ADMIN (Full access on all platforms)
  if (appType === "admin") {
    console.log('🔧 Loading Admin App');
    return <AdminApp />;
  }

  // Fallback
  console.error('❌ Unknown app type or unsupported device:', appType);
  return <ErrorScreen message="Unknown app type or unsupported device." />;
}