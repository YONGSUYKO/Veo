import React, { useState, useEffect } from 'react';
import { View, Alert, Pressable, Text } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../state/authStore';
import { useNewAppStore } from '../state/newAppStore';
import { newApiClient } from '../api/newPisoAPI';
import { useDeviceInfo } from '../utils/deviceDetection';

import AdminLoginScreen from './admin/AdminLoginScreen';
import AdminDashboard from '../screens/AdminDashboard';
import AdminDesktopDashboard from '../screens/AdminDesktopDashboard';
import AdminMobileScreen from '../screens/mobile/AdminMobileScreen';
import CustomerApp from './CustomerApp';

type AdminFlow = 
  | 'login'
  | 'dashboard'
  | 'customer_preview';

export default function AdminApp() {
  const { currentUser, isAuthenticated, login } = useAuthStore();
  const deviceInfo = useDeviceInfo();
  const [currentFlow, setCurrentFlow] = useState<AdminFlow>('login');

  useEffect(() => {
    if (isAuthenticated && currentUser?.role === 'admin') {
      setCurrentFlow('dashboard');
    } else {
      setCurrentFlow('login');
    }
  }, [isAuthenticated, currentUser]);

  const handleAdminLogin = async (credentials: { username: string; password: string; mfaCode?: string }) => {
    try {
      // In real app, this would validate admin credentials with MFA
      const adminUser = await newApiClient.authenticateUser(
        credentials.username.includes('@') 
          ? credentials.username 
          : `${credentials.username}@pisoprint.com`,
        'admin'
      );
      
      login({
        ...adminUser,
        name: credentials.username === 'admin' ? 'System Administrator' : `Admin ${credentials.username}`,
        role: 'admin',
      });

      setCurrentFlow('dashboard');

      Alert.alert(
        'Admin Access Granted',
        'Welcome to the PISO Print Express Administration Panel. You have full system access.',
        [{ text: 'Continue' }]
      );

    } catch (error) {
      Alert.alert('Access Denied', 'Invalid admin credentials. Please check your username and password.');
    }
  };

  const handleSwitchToCustomerPreview = () => {
    setCurrentFlow('customer_preview');
  };

  const handleBackToDashboard = () => {
    setCurrentFlow('dashboard');
  };

  const renderCurrentScreen = () => {
    switch (currentFlow) {
      case 'login':
        return (
          <AdminLoginScreen
            onLogin={handleAdminLogin}
          />
        );

      case 'dashboard':
        return deviceInfo.isDesktop ? (
          <AdminDesktopDashboard
            onSwitchToCustomer={handleSwitchToCustomerPreview}
          />
        ) : deviceInfo.isMobile || deviceInfo.isTablet ? (
          <AdminMobileScreen />
        ) : (
          <AdminDashboard
            onSwitchToCustomer={handleSwitchToCustomerPreview}
          />
        );

      case 'customer_preview':
        return (
          <View className="flex-1">
            {/* Customer preview mode for testing */}
            <CustomerApp />
            {/* Admin overlay controls */}
            <View className="absolute top-12 right-4 z-50">
              <View className="bg-red-600 rounded-lg px-3 py-2 mb-2">
                <Text className="text-white text-xs font-medium">ADMIN PREVIEW</Text>
              </View>
              <Pressable 
                className="bg-red-600 w-14 h-14 rounded-full items-center justify-center shadow-lg"
                onPress={handleBackToDashboard}
              >
                <Ionicons name="shield" size={24} color="white" />
              </Pressable>
            </View>
          </View>
        );

      default:
        return (
          <AdminLoginScreen
            onLogin={handleAdminLogin}
          />
        );
    }
  };

  return (
    <View className="flex-1">
      {renderCurrentScreen()}
    </View>
  );
}