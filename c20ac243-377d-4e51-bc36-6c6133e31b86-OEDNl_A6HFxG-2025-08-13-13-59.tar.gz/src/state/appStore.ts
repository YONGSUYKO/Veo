import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface PrintJob {
  id: string;
  customerId?: string;
  operatorId?: string;
  status: 'queue' | 'printing' | 'ready' | 'completed' | 'cancelled';
  type: 'document' | 'photo' | 'scan';
  files: { name: string; size: number; type: string; uri?: string }[];
  copies: number;
  paperSize: string;
  colorMode: 'black_white' | 'color';
  printSettings?: any;
  total: number;
  paymentMethod?: string;
  paymentStatus: 'pending' | 'paid';
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface PhotoSize {
  id: string;
  name: string;
  width: string;
  height: string;
  unit: string;
  price: number;
  isActive: boolean;
}

export interface Subscription {
  id: string;
  customerEmail: string;
  customerName: string;
  plan: 'basic' | 'student' | 'business' | 'premium';
  status: 'active' | 'cancelled' | 'expired';
  price: number;
  credits: number;
  maxCredits: number;
  startDate: Date;
  endDate: Date;
  createdAt: Date;
}

export interface MarketplaceItem {
  id: string;
  title: string;
  description?: string;
  category: 'templates' | 'designs' | 'fonts' | 'clipart';
  type: string;
  price: number;
  commission: number;
  downloads: number;
  rating: number;
  status: 'pending' | 'approved' | 'rejected';
  filePath?: string;
  creatorEmail?: string;
  creatorName?: string;
  createdAt: Date;
}

export interface DashboardStats {
  jobsToday: number;
  revenueToday: number;
  activeOperators: number;
  totalOperators: number;
  queueLength: number;
}

interface AppState {
  // Print Jobs
  printJobs: PrintJob[];
  currentPrintJob: PrintJob | null;
  
  // Photo sizes
  photoSizes: PhotoSize[];
  
  // Subscriptions
  subscriptions: Subscription[];
  
  // Marketplace
  marketplaceItems: MarketplaceItem[];
  
  // Dashboard stats
  dashboardStats: DashboardStats | null;
  
  // Actions
  setPrintJobs: (jobs: PrintJob[]) => void;
  addPrintJob: (job: PrintJob) => void;
  updatePrintJob: (id: string, updates: Partial<PrintJob>) => void;
  setCurrentPrintJob: (job: PrintJob | null) => void;
  
  setPhotoSizes: (sizes: PhotoSize[]) => void;
  
  setSubscriptions: (subscriptions: Subscription[]) => void;
  addSubscription: (subscription: Subscription) => void;
  
  setMarketplaceItems: (items: MarketplaceItem[]) => void;
  addMarketplaceItem: (item: MarketplaceItem) => void;
  
  setDashboardStats: (stats: DashboardStats) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Initial state
      printJobs: [],
      currentPrintJob: null,
      photoSizes: [],
      subscriptions: [],
      marketplaceItems: [],
      dashboardStats: null,
      
      // Actions
      setPrintJobs: (jobs) => set({ printJobs: jobs }),
      
      addPrintJob: (job) => set((state) => ({
        printJobs: [...state.printJobs, job]
      })),
      
      updatePrintJob: (id, updates) => set((state) => ({
        printJobs: state.printJobs.map(job => 
          job.id === id ? { ...job, ...updates } : job
        )
      })),
      
      setCurrentPrintJob: (job) => set({ currentPrintJob: job }),
      
      setPhotoSizes: (sizes) => set({ photoSizes: sizes }),
      
      setSubscriptions: (subscriptions) => set({ subscriptions }),
      
      addSubscription: (subscription) => set((state) => ({
        subscriptions: [...state.subscriptions, subscription]
      })),
      
      setMarketplaceItems: (items) => set({ marketplaceItems: items }),
      
      addMarketplaceItem: (item) => set((state) => ({
        marketplaceItems: [...state.marketplaceItems, item]
      })),
      
      setDashboardStats: (stats) => set({ dashboardStats: stats }),
    }),
    {
      name: 'piso-print-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        printJobs: state.printJobs,
        subscriptions: state.subscriptions,
        // Don't persist dashboard stats and marketplace items as they should be fetched fresh
      }),
    }
  )
);