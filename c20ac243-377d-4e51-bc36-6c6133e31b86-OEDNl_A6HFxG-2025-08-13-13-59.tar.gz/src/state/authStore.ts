import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export type UserRole = 'customer' | 'operator' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: UserRole;
  loyaltyPoints: number;
  isLoggedIn: boolean;
  isGuest?: boolean;
}

interface AuthState {
  currentUser: User | null;
  isAuthenticated: boolean;
  isGuestMode: boolean;
  
  // Actions
  login: (user: User) => void;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;
  setUserRole: (role: UserRole) => void; // For demo purposes
  resetAuth: () => void; // Reset auth state for mode switching
  enableGuestMode: () => void;
  convertGuestToUser: (userInfo: {name: string; phone?: string; email?: string}) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      currentUser: null,
      isAuthenticated: false,
      isGuestMode: true, // Default to guest mode
      
      login: (user) => set({ 
        currentUser: user, 
        isAuthenticated: true,
        isGuestMode: false
      }),
      
      logout: () => set({ 
        currentUser: null, 
        isAuthenticated: false,
        isGuestMode: true
      }),
      
      updateUser: (updates) => set((state) => ({
        currentUser: state.currentUser 
          ? { ...state.currentUser, ...updates }
          : null
      })),
      
      setUserRole: (role) => set((state) => ({
        currentUser: state.currentUser 
          ? { ...state.currentUser, role }
          : null
      })),
      
      resetAuth: () => set({
        currentUser: null,
        isAuthenticated: false,
        isGuestMode: true
      }),

      enableGuestMode: () => set({
        isGuestMode: true
      }),

      convertGuestToUser: (userInfo) => set((state) => {
        const guestUser: User = {
          id: `guest_${Date.now()}`,
          name: userInfo.name,
          email: userInfo.email || '',
          phone: userInfo.phone || '',
          role: 'customer',
          loyaltyPoints: 0,
          isLoggedIn: false,
          isGuest: true
        };
        return {
          currentUser: guestUser,
          isAuthenticated: false, // Still not fully authenticated until login
          isGuestMode: false
        };
      }),
    }),
    {
      name: 'piso-print-auth',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({ 
        currentUser: state.currentUser,
        isAuthenticated: state.isAuthenticated,
        // Don't persist guest mode - always start as guest
      }),
    }
  )
);