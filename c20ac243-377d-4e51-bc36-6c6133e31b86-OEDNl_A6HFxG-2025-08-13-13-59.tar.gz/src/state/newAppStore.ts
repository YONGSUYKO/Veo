import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface FileInfo {
  id: string;
  name: string;
  uri: string;
  type: string;
  size: number;
  pages: number;
  paperSize: 'A4' | 'A3' | 'Letter' | 'Legal' | 'Wallet' | '2R' | '3R' | '4R' | '5R' | '6R' | '8R';
  pageColor: 'auto' | 'color' | 'blackwhite';
  pageSidedness: 'single' | 'double';
  pageOrientation: 'portrait' | 'landscape';
  copies: number;
  binding?: 'none' | 'spiral' | 'perfect' | 'saddle';
  lamination?: 'none' | 'matte' | 'glossy';
}

export interface PrintJob {
  id: string;
  customerId?: string;
  customerInfo: {
    name: string;
    phone?: string;
    email?: string;
  };
  files: FileInfo[];
  totalPrice: number;
  loyaltyPointsUsed: number;
  paymentMethod: 'cash' | 'gcash' | 'card';
  fulfillmentMethod: 'pickup' | 'delivery';
  deliveryCourier?: string;
  deliveryFee?: number;
  status: 'queue' | 'ongoing' | 'ready' | 'completed' | 'failed';
  createdAt: Date;
  updatedAt: Date;
}

export interface SystemSettings {
  // Admin-controlled toggles
  allowColorToggle: boolean;
  allowSidednessToggle: boolean;
  allowOrientationToggle: boolean;
  allowCopiesToggle: boolean;
  maxCopies: number;
  deliveryFee: number;
  
  // Default settings
  defaultDocumentPaperSize: string;
  defaultPhotoPaperSize: string;
  defaultPageColor: string;
  defaultPageSidedness: string;
  defaultPageOrientation: string;
  
  // Pricing (in centavos)
  documentPricing: {
    [size: string]: {
      blackwhite: number;
      color: number;
      doubleSidedSurcharge: number; // Additional cost for double-sided
    };
  };
  photoPricing: {
    [size: string]: number;
  };
  bindingPricing: {
    [size: string]: {
      none: number;
      spiral: number;
      perfect: number;
      saddle: number;
    };
  };
  laminationPricing: {
    [size: string]: {
      none: number;
      matte: number;
      glossy: number;
    };
  };
}

export interface QuestionOfTheDay {
  id: string;
  question: string;
  date: string;
}

interface AppState {
  // System settings
  systemSettings: SystemSettings;
  
  // Print jobs
  printJobs: PrintJob[];
  currentPrintJob: PrintJob | null;
  
  // Daily content
  questionOfTheDay: QuestionOfTheDay | null;
  
  // Actions
  setSystemSettings: (settings: Partial<SystemSettings>) => void;
  
  setPrintJobs: (jobs: PrintJob[]) => void;
  addPrintJob: (job: PrintJob) => void;
  updatePrintJob: (id: string, updates: Partial<PrintJob>) => void;
  setCurrentPrintJob: (job: PrintJob | null) => void;
  
  setQuestionOfTheDay: (question: QuestionOfTheDay) => void;
  
  resetAppState: () => void; // Reset app state for mode switching
}

export const useNewAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Initial state
      systemSettings: {
        allowColorToggle: true,
        allowSidednessToggle: true,
        allowOrientationToggle: true,
        allowCopiesToggle: true,
        maxCopies: 1000,
        deliveryFee: 2000, // 20 pesos in centavos
        defaultDocumentPaperSize: 'Letter',
        defaultPhotoPaperSize: '4R',
        defaultPageColor: 'auto',
        defaultPageSidedness: 'single',
        defaultPageOrientation: 'portrait',
        
        // Document pricing (in centavos)
        documentPricing: {
          'Letter': { blackwhite: 100, color: 200, doubleSidedSurcharge: 50 }, // ₱0.50 for double-sided
          'A4': { blackwhite: 100, color: 200, doubleSidedSurcharge: 50 },
          'Legal': { blackwhite: 150, color: 300, doubleSidedSurcharge: 50 },
          'A3': { blackwhite: 200, color: 400, doubleSidedSurcharge: 200 }, // ₱2.00 for A3 double-sided
        },
        
        // Photo pricing (in centavos)
        photoPricing: {
          'Wallet': 50, // ₱0.50
          '2R': 100, // ₱1.00
          '3R': 150, // ₱1.50
          '4R': 200, // ₱2.00
          '5R': 350, // ₱3.50
          '6R': 450, // ₱4.50
          '8R': 650, // ₱6.50
          'A4': 800, // ₱8.00 (A4 Photo)
          'A3': 1200, // ₱12.00 (A3 Photo)
        },
        
        // Binding pricing by size (in centavos)
        bindingPricing: {
          'Letter': { none: 0, spiral: 1500, perfect: 2000, saddle: 800 }, // ₱15, ₱20, ₱8
          'A4': { none: 0, spiral: 1500, perfect: 2000, saddle: 800 },
          'Legal': { none: 0, spiral: 1800, perfect: 2500, saddle: 1000 }, // ₱18, ₱25, ₱10
          'A3': { none: 0, spiral: 2500, perfect: 3500, saddle: 1500 }, // ₱25, ₱35, ₱15
        },
        
        // Lamination pricing by size (in centavos per page)
        laminationPricing: {
          'Letter': { none: 0, matte: 1000, glossy: 1200 }, // ₱10, ₱12 per page
          'A4': { none: 0, matte: 1000, glossy: 1200 },
          'Legal': { none: 0, matte: 1200, glossy: 1500 }, // ₱12, ₱15 per page
          'A3': { none: 0, matte: 1800, glossy: 2200 }, // ₱18, ₱22 per page
        },
      },
      
      printJobs: [],
      currentPrintJob: null,
      questionOfTheDay: null,
      
      // Actions
      setSystemSettings: (settings) => set((state) => ({
        systemSettings: { ...state.systemSettings, ...settings }
      })),
      
      setPrintJobs: (jobs) => set({ printJobs: jobs }),
      
      addPrintJob: (job) => set((state) => ({
        printJobs: [...state.printJobs, job]
      })),
      
      updatePrintJob: (id, updates) => set((state) => ({
        printJobs: state.printJobs.map(job => 
          job.id === id ? { ...job, ...updates, updatedAt: new Date() } : job
        )
      })),
      
      setCurrentPrintJob: (job) => set({ currentPrintJob: job }),
      
      setQuestionOfTheDay: (question) => set({ questionOfTheDay: question }),
      
      resetAppState: () => set({
        printJobs: [],
        currentPrintJob: null,
        questionOfTheDay: null,
        // Keep system settings intact
      }),
    }),
    {
      name: 'piso-print-new-app',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        systemSettings: state.systemSettings,
        printJobs: state.printJobs,
        // Don't persist current job and daily questions
      }),
    }
  )
);