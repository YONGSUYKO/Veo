import AsyncStorage from '@react-native-async-storage/async-storage';
import { StaffSupportOrder, OrderMessage, OrderStatus } from '../types/staffSupportOrder';

// Mock database service (replace with Firebase when ready)
class StaffSupportService {
  private ordersKey = 'staff_support_orders';
  private messagesKey = 'staff_support_messages';

  // Create new staff support order with notifications
  async createOrder(orderData: Omit<StaffSupportOrder, 'id' | 'createdAt'>): Promise<StaffSupportOrder> {
    const newOrder: StaffSupportOrder = {
      ...orderData,
      id: `order_${Date.now()}`,
      createdAt: new Date(),
      status: 'uploaded',
    };

    const orders = await this.getAllOrders();
    orders.push(newOrder);
    await AsyncStorage.setItem(this.ordersKey, JSON.stringify(orders));

    console.log('✅ Staff support order created:', newOrder.id);

    // Send order confirmation notifications
    try {
      const { notificationManager } = await import('./notificationManager');
      await notificationManager.sendOrderUpdate(
        newOrder.customerId,
        newOrder.id,
        'uploaded',
        'Your files have been uploaded successfully! Our team will review them shortly.'
      );
      console.log(`📱 Order confirmation notifications sent for ${newOrder.id}`);
    } catch (error) {
      console.error('Error sending order confirmation notifications:', error);
    }

    return newOrder;
  }

  // Get order by ID
  async getOrder(orderId: string): Promise<StaffSupportOrder | null> {
    const orders = await this.getAllOrders();
    return orders.find(order => order.id === orderId) || null;
  }

  // Get order by ID (alias for compatibility)
  async getOrderById(orderId: string): Promise<StaffSupportOrder | null> {
    return this.getOrder(orderId);
  }

  // Update order with partial data
  async updateOrder(orderId: string, updates: Partial<StaffSupportOrder>): Promise<void> {
    const orders = await this.getAllOrders();
    const orderIndex = orders.findIndex(order => order.id === orderId);
    
    if (orderIndex !== -1) {
      orders[orderIndex] = {
        ...orders[orderIndex],
        ...updates,
      };
      await AsyncStorage.setItem(this.ordersKey, JSON.stringify(orders));
      console.log(`✅ Order ${orderId} updated`);
    }
  }

  // Update order status with notifications
  async updateOrderStatus(orderId: string, status: OrderStatus): Promise<void> {
    const orders = await this.getAllOrders();
    const orderIndex = orders.findIndex(order => order.id === orderId);
    
    if (orderIndex !== -1) {
      const order = orders[orderIndex];
      orders[orderIndex].status = status;
      await AsyncStorage.setItem(this.ordersKey, JSON.stringify(orders));
      console.log(`📝 Order ${orderId} status updated to: ${status}`);

      // Send notifications for status change
      try {
        const { notificationManager } = await import('./notificationManager');
        await notificationManager.sendOrderUpdate(
          order.customerId,
          orderId,
          status
        );
        console.log(`📱 Notifications sent for order ${orderId} status: ${status}`);
      } catch (error) {
        console.error('Error sending order status notifications:', error);
      }
    }
  }

  // Update order with operator review
  async updateOrderReview(
    orderId: string, 
    updates: {
      operatorMessage?: string;
      printSpecs?: StaffSupportOrder['printSpecs'];
      totalAmount?: number;
      completionTime?: string;
      paymentCode?: string;
    }
  ): Promise<void> {
    const orders = await this.getAllOrders();
    const orderIndex = orders.findIndex(order => order.id === orderId);
    
    if (orderIndex !== -1) {
      orders[orderIndex] = {
        ...orders[orderIndex],
        ...updates,
        status: 'approved_for_payment'
      };
      await AsyncStorage.setItem(this.ordersKey, JSON.stringify(orders));
      console.log(`✅ Order ${orderId} reviewed and approved for payment`);
    }
  }

  // Get all orders
  async getAllOrders(): Promise<StaffSupportOrder[]> {
    try {
      const ordersJson = await AsyncStorage.getItem(this.ordersKey);
      if (ordersJson) {
        const orders = JSON.parse(ordersJson);
        // Convert date strings back to Date objects
        return orders.map((order: any) => ({
          ...order,
          createdAt: new Date(order.createdAt)
        }));
      }
      return [];
    } catch (error) {
      console.error('Error loading staff support orders:', error);
      return [];
    }
  }

  // Get orders by customer ID
  async getCustomerOrders(customerId: string): Promise<StaffSupportOrder[]> {
    const orders = await this.getAllOrders();
    return orders.filter(order => order.customerId === customerId);
  }

  // Get orders by status
  async getOrdersByStatus(status: OrderStatus): Promise<StaffSupportOrder[]> {
    const orders = await this.getAllOrders();
    return orders.filter(order => order.status === status);
  }

  // Send message
  async sendMessage(messageData: Omit<OrderMessage, 'id' | 'timestamp'>): Promise<OrderMessage> {
    const newMessage: OrderMessage = {
      ...messageData,
      id: `msg_${Date.now()}`,
      timestamp: new Date(),
    };

    const messages = await this.getAllMessages();
    messages.push(newMessage);
    await AsyncStorage.setItem(this.messagesKey, JSON.stringify(messages));

    console.log('💬 Message sent for order:', messageData.orderId);
    return newMessage;
  }

  // Get messages for order
  async getOrderMessages(orderId: string): Promise<OrderMessage[]> {
    const messages = await this.getAllMessages();
    return messages
      .filter(message => message.orderId === orderId)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }

  // Mark message as read
  async markMessageAsRead(messageId: string): Promise<void> {
    const messages = await this.getAllMessages();
    const messageIndex = messages.findIndex(message => message.id === messageId);
    
    if (messageIndex !== -1) {
      messages[messageIndex].isRead = true;
      await AsyncStorage.setItem(this.messagesKey, JSON.stringify(messages));
    }
  }

  // Get all messages
  private async getAllMessages(): Promise<OrderMessage[]> {
    try {
      const messagesJson = await AsyncStorage.getItem(this.messagesKey);
      if (messagesJson) {
        const messages = JSON.parse(messagesJson);
        // Convert date strings back to Date objects
        return messages.map((message: any) => ({
          ...message,
          timestamp: new Date(message.timestamp)
        }));
      }
      return [];
    } catch (error) {
      console.error('Error loading messages:', error);
      return [];
    }
  }

  // Subscribe to order changes (mock real-time updates)
  subscribeToOrder(orderId: string, callback: (order: StaffSupportOrder | null) => void): () => void {
    const interval = setInterval(async () => {
      const order = await this.getOrder(orderId);
      callback(order);
    }, 2000); // Check every 2 seconds

    return () => clearInterval(interval);
  }

  // Subscribe to order messages (mock real-time updates)
  subscribeToMessages(orderId: string, callback: (messages: OrderMessage[]) => void): () => void {
    const interval = setInterval(async () => {
      const messages = await this.getOrderMessages(orderId);
      callback(messages);
    }, 1000); // Check every second

    return () => clearInterval(interval);
  }
}

export const staffSupportService = new StaffSupportService();
export default StaffSupportService;