import AsyncStorage from '@react-native-async-storage/async-storage';
import { StaffSupportOrder } from '../types/staffSupportOrder';

interface PickupCode {
  orderId: string;
  customerId: string;
  qrCode: string;
  pickupCode: string; // 6-digit backup code
  generatedAt: Date;
  expiresAt: Date;
  isUsed: boolean;
  scannedAt?: Date;
  scannedBy?: string; // operator ID
}

class QRCodeService {
  private pickupCodesKey = 'pickup_codes';

  // Generate QR code data for order pickup
  async generatePickupQR(order: StaffSupportOrder): Promise<PickupCode> {
    try {
      // Create unique QR code data
      const qrData = {
        type: 'PISO_PICKUP',
        orderId: order.id,
        customerId: order.customerId,
        amount: order.totalAmount,
        timestamp: Date.now(),
        checksum: this.generateChecksum(order.id, order.customerId)
      };

      // Generate 6-digit backup pickup code
      const pickupCode = this.generatePickupCode();
      
      // Create pickup code record
      const pickupCodeRecord: PickupCode = {
        orderId: order.id,
        customerId: order.customerId,
        qrCode: JSON.stringify(qrData),
        pickupCode: pickupCode,
        generatedAt: new Date(),
        expiresAt: new Date(Date.now() + (30 * 24 * 60 * 60 * 1000)), // 30 days expiry
        isUsed: false
      };

      // Store pickup code
      await this.storePickupCode(pickupCodeRecord);

      console.log(`📱 QR pickup code generated for order ${order.id}: ${pickupCode}`);
      return pickupCodeRecord;

    } catch (error) {
      console.error('Error generating pickup QR code:', error);
      throw new Error('Failed to generate pickup code');
    }
  }

  // Generate 6-digit pickup code as backup
  private generatePickupCode(): string {
    return Math.floor(100000 + Math.random() * 900000).toString();
  }

  // Generate checksum for security
  private generateChecksum(orderId: string, customerId: string): string {
    const combined = `${orderId}${customerId}${Date.now()}`;
    let hash = 0;
    for (let i = 0; i < combined.length; i++) {
      const char = combined.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash).toString(16).slice(0, 8);
  }

  // Validate and process scanned QR code
  async validatePickupQR(qrCodeData: string, operatorId: string): Promise<{
    success: boolean;
    order?: StaffSupportOrder;
    message: string;
    pickupCode?: PickupCode;
  }> {
    try {
      let parsedData;
      
      // Try to parse QR code data
      try {
        parsedData = JSON.parse(qrCodeData);
      } catch {
        // If not JSON, might be just the pickup code
        return await this.validatePickupCode(qrCodeData, operatorId);
      }

      // Validate QR code structure
      if (parsedData.type !== 'PISO_PICKUP' || !parsedData.orderId) {
        return {
          success: false,
          message: 'Invalid QR code. This is not a valid PISO Print pickup code.'
        };
      }

      // Get pickup code record
      const pickupCodes = await this.getAllPickupCodes();
      const pickupCode = pickupCodes.find(pc => pc.orderId === parsedData.orderId);

      if (!pickupCode) {
        return {
          success: false,
          message: 'Pickup code not found. Order may not exist or QR code may be invalid.'
        };
      }

      // Check if already used
      if (pickupCode.isUsed) {
        return {
          success: false,
          message: `This order was already picked up on ${pickupCode.scannedAt?.toLocaleDateString()} by ${pickupCode.scannedBy || 'operator'}.`
        };
      }

      // Check if expired
      if (new Date() > pickupCode.expiresAt) {
        return {
          success: false,
          message: 'This pickup code has expired. Please contact customer service.'
        };
      }

      // Validate checksum for security
      const expectedChecksum = this.generateChecksum(parsedData.orderId, parsedData.customerId);
      if (parsedData.checksum !== expectedChecksum) {
        return {
          success: false,
          message: 'Security validation failed. QR code may be tampered with.'
        };
      }

      // Get order details
      const { staffSupportService } = await import('./staffSupportService');
      const order = await staffSupportService.getOrderById(parsedData.orderId);

      if (!order) {
        return {
          success: false,
          message: 'Order not found in system.'
        };
      }

      // Check if order is ready for pickup
      if (order.status !== 'ready' && order.status !== 'completed') {
        return {
          success: false,
          message: `Order is not ready for pickup. Current status: ${order.status}`
        };
      }

      // Mark as picked up
      await this.markAsPickedUp(pickupCode, operatorId);
      await staffSupportService.updateOrderStatus(order.id, 'completed');

      return {
        success: true,
        order: order,
        pickupCode: pickupCode,
        message: 'Order successfully processed for pickup!'
      };

    } catch (error) {
      console.error('Error validating pickup QR:', error);
      return {
        success: false,
        message: 'Error processing QR code. Please try again or use manual pickup code.'
      };
    }
  }

  // Validate manual pickup code (6-digit backup)
  async validatePickupCode(code: string, operatorId: string): Promise<{
    success: boolean;
    order?: StaffSupportOrder;
    message: string;
    pickupCode?: PickupCode;
  }> {
    try {
      const pickupCodes = await this.getAllPickupCodes();
      const pickupCode = pickupCodes.find(pc => pc.pickupCode === code.trim());

      if (!pickupCode) {
        return {
          success: false,
          message: 'Invalid pickup code. Please check the code and try again.'
        };
      }

      if (pickupCode.isUsed) {
        return {
          success: false,
          message: `This order was already picked up on ${pickupCode.scannedAt?.toLocaleDateString()}.`
        };
      }

      if (new Date() > pickupCode.expiresAt) {
        return {
          success: false,
          message: 'This pickup code has expired.'
        };
      }

      // Get order details
      const { staffSupportService } = await import('./staffSupportService');
      const order = await staffSupportService.getOrderById(pickupCode.orderId);

      if (!order) {
        return {
          success: false,
          message: 'Order not found.'
        };
      }

      if (order.status !== 'ready' && order.status !== 'completed') {
        return {
          success: false,
          message: `Order is not ready for pickup. Current status: ${order.status}`
        };
      }

      // Mark as picked up
      await this.markAsPickedUp(pickupCode, operatorId);
      await staffSupportService.updateOrderStatus(order.id, 'completed');

      return {
        success: true,
        order: order,
        pickupCode: pickupCode,
        message: 'Order successfully processed for pickup!'
      };

    } catch (error) {
      console.error('Error validating pickup code:', error);
      return {
        success: false,
        message: 'Error processing pickup code. Please try again.'
      };
    }
  }

  // Mark pickup code as used
  private async markAsPickedUp(pickupCode: PickupCode, operatorId: string): Promise<void> {
    const allCodes = await this.getAllPickupCodes();
    const updatedCodes = allCodes.map(code => 
      code.orderId === pickupCode.orderId
        ? {
            ...code,
            isUsed: true,
            scannedAt: new Date(),
            scannedBy: operatorId
          }
        : code
    );

    await AsyncStorage.setItem(this.pickupCodesKey, JSON.stringify(updatedCodes));
    console.log(`✅ Order ${pickupCode.orderId} marked as picked up by ${operatorId}`);
  }

  // Get pickup code for order
  async getPickupCodeForOrder(orderId: string): Promise<PickupCode | null> {
    const pickupCodes = await this.getAllPickupCodes();
    return pickupCodes.find(code => code.orderId === orderId) || null;
  }

  // Store pickup code
  private async storePickupCode(pickupCode: PickupCode): Promise<void> {
    const existingCodes = await this.getAllPickupCodes();
    const updatedCodes = existingCodes.filter(code => code.orderId !== pickupCode.orderId);
    updatedCodes.push(pickupCode);
    await AsyncStorage.setItem(this.pickupCodesKey, JSON.stringify(updatedCodes));
  }

  // Get all pickup codes
  private async getAllPickupCodes(): Promise<PickupCode[]> {
    try {
      const codesJson = await AsyncStorage.getItem(this.pickupCodesKey);
      if (codesJson) {
        return JSON.parse(codesJson).map((code: any) => ({
          ...code,
          generatedAt: new Date(code.generatedAt),
          expiresAt: new Date(code.expiresAt),
          scannedAt: code.scannedAt ? new Date(code.scannedAt) : undefined
        }));
      }
      return [];
    } catch (error) {
      console.error('Error loading pickup codes:', error);
      return [];
    }
  }

  // Get pickup statistics
  async getPickupStatistics(period: 'today' | 'week' | 'month' = 'today'): Promise<{
    totalGenerated: number;
    totalPickedUp: number;
    totalExpired: number;
    pickupRate: number;
  }> {
    const pickupCodes = await this.getAllPickupCodes();
    const now = new Date();
    let startDate: Date;

    switch (period) {
      case 'today':
        startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        break;
      case 'week':
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case 'month':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
    }

    const periodCodes = pickupCodes.filter(code => code.generatedAt >= startDate);
    const totalGenerated = periodCodes.length;
    const totalPickedUp = periodCodes.filter(code => code.isUsed).length;
    const totalExpired = periodCodes.filter(code => now > code.expiresAt && !code.isUsed).length;
    const pickupRate = totalGenerated > 0 ? (totalPickedUp / totalGenerated) * 100 : 0;

    return {
      totalGenerated,
      totalPickedUp,
      totalExpired,
      pickupRate: Math.round(pickupRate * 100) / 100
    };
  }
}

export const qrCodeService = new QRCodeService();
export default QRCodeService;