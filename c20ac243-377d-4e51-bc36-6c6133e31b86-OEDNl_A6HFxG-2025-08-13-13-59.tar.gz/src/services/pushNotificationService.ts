import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Constants from 'expo-constants';
import { Platform } from 'react-native';

interface PushToken {
  userId: string;
  token: string;
  deviceId: string;
  platform: string;
  createdAt: Date;
  lastUsed: Date;
}

interface NotificationPayload {
  title: string;
  body: string;
  data?: any;
  categoryId?: string;
  priority?: 'low' | 'normal' | 'high';
  sound?: boolean;
  badge?: number;
}

// Configure notification handling
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

class PushNotificationService {
  private tokensKey = 'push_tokens';
  private subscriptionsKey = 'notification_subscriptions';

  constructor() {
    this.initializeNotificationChannels();
  }

  // Initialize notification channels (Android)
  private async initializeNotificationChannels(): Promise<void> {
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('order-updates', {
        name: 'Order Updates',
        description: 'Notifications about your print orders',
        importance: Notifications.AndroidImportance.HIGH,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#3B82F6',
        sound: true,
      });

      await Notifications.setNotificationChannelAsync('promotions', {
        name: 'Promotions & Offers',
        description: 'Special offers and promotional notifications',
        importance: Notifications.AndroidImportance.DEFAULT,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#10B981',
        sound: false,
      });

      await Notifications.setNotificationChannelAsync('system', {
        name: 'System Notifications',
        description: 'Important system messages and updates',
        importance: Notifications.AndroidImportance.HIGH,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#EF4444',
        sound: true,
      });
    }
  }

  // Register device for push notifications
  async registerDevice(userId: string): Promise<string | null> {
    try {
      if (!Device.isDevice) {
        console.log('⚠️ Push notifications only work on physical devices');
        return null;
      }

      // Check permissions
      const { status: existingStatus } = await Notifications.getPermissionsAsync();
      let finalStatus = existingStatus;

      if (existingStatus !== 'granted') {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }

      if (finalStatus !== 'granted') {
        console.log('❌ Push notification permissions denied');
        return null;
      }

      // Get push token
      const tokenData = await Notifications.getExpoPushTokenAsync({
        projectId: Constants.expoConfig?.extra?.eas?.projectId,
      });

      const pushToken: PushToken = {
        userId,
        token: tokenData.data,
        deviceId: Constants.deviceId || 'unknown',
        platform: Platform.OS,
        createdAt: new Date(),
        lastUsed: new Date(),
      };

      // Store token
      await this.storePushToken(pushToken);

      console.log('✅ Push token registered:', tokenData.data);
      return tokenData.data;

    } catch (error) {
      console.error('Error registering push notifications:', error);
      return null;
    }
  }

  // Send push notification to specific user
  async sendToUser(userId: string, payload: NotificationPayload): Promise<boolean> {
    try {
      const tokens = await this.getUserTokens(userId);
      if (tokens.length === 0) {
        console.log(`⚠️ No push tokens found for user ${userId}`);
        return false;
      }

      const messages = tokens.map(tokenData => ({
        to: tokenData.token,
        sound: payload.sound !== false ? 'default' : null,
        title: payload.title,
        body: payload.body,
        data: payload.data || {},
        priority: payload.priority || 'normal',
        badge: payload.badge,
        categoryId: payload.categoryId,
        channelId: this.getChannelId(payload.categoryId),
      }));

      const chunks = this.chunkArray(messages, 100); // Expo limit
      let success = true;

      for (const chunk of chunks) {
        const response = await fetch('https://exp.host/--/api/v2/push/send', {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Accept-encoding': 'gzip, deflate',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(chunk),
        });

        if (!response.ok) {
          console.error('❌ Expo push notification failed:', await response.text());
          success = false;
        } else {
          const result = await response.json();
          console.log('✅ Push notifications sent:', result);
          
          // Update last used timestamps
          await this.updateTokenUsage(tokens.map(t => t.token));
        }
      }

      return success;

    } catch (error) {
      console.error('Error sending push notification:', error);
      return false;
    }
  }

  // Send push notification to multiple users
  async sendToMultipleUsers(userIds: string[], payload: NotificationPayload): Promise<boolean> {
    try {
      const allTokens: string[] = [];
      
      for (const userId of userIds) {
        const userTokens = await this.getUserTokens(userId);
        allTokens.push(...userTokens.map(t => t.token));
      }

      if (allTokens.length === 0) {
        console.log('⚠️ No push tokens found for specified users');
        return false;
      }

      const messages = allTokens.map(token => ({
        to: token,
        sound: payload.sound !== false ? 'default' : null,
        title: payload.title,
        body: payload.body,
        data: payload.data || {},
        priority: payload.priority || 'normal',
        badge: payload.badge,
        categoryId: payload.categoryId,
        channelId: this.getChannelId(payload.categoryId),
      }));

      const chunks = this.chunkArray(messages, 100);
      let success = true;

      for (const chunk of chunks) {
        const response = await fetch('https://exp.host/--/api/v2/push/send', {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Accept-encoding': 'gzip, deflate',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(chunk),
        });

        if (!response.ok) {
          console.error('❌ Expo push notification failed:', await response.text());
          success = false;
        }
      }

      return success;

    } catch (error) {
      console.error('Error sending bulk push notifications:', error);
      return false;
    }
  }

  // Send order-specific notifications
  async sendOrderUpdate(userId: string, orderId: string, status: string, message: string): Promise<boolean> {
    const statusEmojis: Record<string, string> = {
      'uploaded': '📤',
      'under_review': '👀',
      'approved_for_payment': '💳',
      'paid': '✅',
      'printing': '🖨️',
      'ready': '📋',
      'completed': '🎉',
    };

    const emoji = statusEmojis[status] || '📋';
    
    return this.sendToUser(userId, {
      title: `${emoji} Order #${orderId.slice(-6)}`,
      body: message,
      data: {
        type: 'order_update',
        orderId,
        status,
      },
      categoryId: 'order-updates',
      priority: 'high',
      sound: true,
    });
  }

  // Send promotional notification
  async sendPromotion(userId: string, title: string, message: string, promoData?: any): Promise<boolean> {
    return this.sendToUser(userId, {
      title: `🎉 ${title}`,
      body: message,
      data: {
        type: 'promotion',
        ...promoData,
      },
      categoryId: 'promotions',
      priority: 'normal',
      sound: false,
    });
  }

  // Send system notification
  async sendSystemNotification(userId: string, title: string, message: string): Promise<boolean> {
    return this.sendToUser(userId, {
      title: `⚠️ ${title}`,
      body: message,
      data: {
        type: 'system',
      },
      categoryId: 'system',
      priority: 'high',
      sound: true,
    });
  }

  // Store push token
  private async storePushToken(pushToken: PushToken): Promise<void> {
    const tokens = await this.getAllTokens();
    const existingIndex = tokens.findIndex(
      t => t.userId === pushToken.userId && t.deviceId === pushToken.deviceId
    );

    if (existingIndex >= 0) {
      tokens[existingIndex] = pushToken;
    } else {
      tokens.push(pushToken);
    }

    await AsyncStorage.setItem(this.tokensKey, JSON.stringify(tokens));
  }

  // Get user's push tokens
  private async getUserTokens(userId: string): Promise<PushToken[]> {
    const allTokens = await this.getAllTokens();
    return allTokens.filter(token => token.userId === userId);
  }

  // Get all push tokens
  private async getAllTokens(): Promise<PushToken[]> {
    try {
      const tokensJson = await AsyncStorage.getItem(this.tokensKey);
      if (tokensJson) {
        return JSON.parse(tokensJson).map((token: any) => ({
          ...token,
          createdAt: new Date(token.createdAt),
          lastUsed: new Date(token.lastUsed),
        }));
      }
      return [];
    } catch (error) {
      console.error('Error loading push tokens:', error);
      return [];
    }
  }

  // Update token usage timestamp
  private async updateTokenUsage(tokens: string[]): Promise<void> {
    try {
      const allTokens = await this.getAllTokens();
      const updatedTokens = allTokens.map(token => 
        tokens.includes(token.token)
          ? { ...token, lastUsed: new Date() }
          : token
      );
      await AsyncStorage.setItem(this.tokensKey, JSON.stringify(updatedTokens));
    } catch (error) {
      console.error('Error updating token usage:', error);
    }
  }

  // Get notification channel ID
  private getChannelId(categoryId?: string): string {
    switch (categoryId) {
      case 'order-updates': return 'order-updates';
      case 'promotions': return 'promotions';
      case 'system': return 'system';
      default: return 'order-updates';
    }
  }

  // Utility: Chunk array into smaller arrays
  private chunkArray<T>(array: T[], chunkSize: number): T[][] {
    const chunks: T[][] = [];
    for (let i = 0; i < array.length; i += chunkSize) {
      chunks.push(array.slice(i, i + chunkSize));
    }
    return chunks;
  }

  // Clean up old/invalid tokens
  async cleanupTokens(): Promise<void> {
    try {
      const tokens = await this.getAllTokens();
      const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
      
      // Keep tokens used within last 30 days
      const validTokens = tokens.filter(token => token.lastUsed > thirtyDaysAgo);
      
      await AsyncStorage.setItem(this.tokensKey, JSON.stringify(validTokens));
      console.log(`🧹 Cleaned up ${tokens.length - validTokens.length} old push tokens`);
    } catch (error) {
      console.error('Error cleaning up tokens:', error);
    }
  }

  // Check if user has push notifications enabled
  async isPushEnabled(userId: string): Promise<boolean> {
    const tokens = await this.getUserTokens(userId);
    return tokens.length > 0;
  }

  // Remove user's push tokens (for logout/opt-out)
  async removeUserTokens(userId: string): Promise<void> {
    try {
      const allTokens = await this.getAllTokens();
      const filteredTokens = allTokens.filter(token => token.userId !== userId);
      await AsyncStorage.setItem(this.tokensKey, JSON.stringify(filteredTokens));
      console.log(`🗑️ Removed push tokens for user ${userId}`);
    } catch (error) {
      console.error('Error removing user tokens:', error);
    }
  }

  // Get push notification statistics
  async getStatistics(): Promise<{
    totalTokens: number;
    activeUsers: number;
    platformBreakdown: Record<string, number>;
  }> {
    const tokens = await this.getAllTokens();
    const uniqueUsers = new Set(tokens.map(t => t.userId)).size;
    const platformBreakdown = tokens.reduce((acc, token) => {
      acc[token.platform] = (acc[token.platform] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      totalTokens: tokens.length,
      activeUsers: uniqueUsers,
      platformBreakdown,
    };
  }
}

export const pushNotificationService = new PushNotificationService();
export default PushNotificationService;