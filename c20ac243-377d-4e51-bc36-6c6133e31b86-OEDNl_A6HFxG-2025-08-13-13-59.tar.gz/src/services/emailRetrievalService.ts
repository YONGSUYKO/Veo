import AsyncStorage from '@react-native-async-storage/async-storage';

export interface EmailFile {
  id: string;
  name: string;
  size: number;
  type: string;
  data: string; // base64 encoded
  uploadedAt: Date;
}

export interface EmailUpload {
  id: string;
  customerEmail: string;
  files: EmailFile[];
  retrievedAt: Date;
  totalSize: number;
  estimatedPrice: number;
  status: 'pending' | 'retrieved' | 'processed';
}

class EmailRetrievalService {
  private readonly storageKey = 'email_uploads';
  private readonly businessEmail = 'print@pisoprint.com';

  // Mock email polling - in production this would connect to actual email service
  async checkForNewEmails(): Promise<EmailUpload[]> {
    try {
      // Simulate checking emails - in production this would use IMAP/POP3 or email API
      const mockEmails = await this.getMockEmailData();
      
      // Store in local storage for demo
      await AsyncStorage.setItem(this.storageKey, JSON.stringify(mockEmails));
      
      return mockEmails;
    } catch (error) {
      console.error('Failed to check emails:', error);
      return [];
    }
  }

  async retrieveFilesByEmail(customerEmail: string): Promise<EmailUpload | null> {
    try {
      const storedEmails = await AsyncStorage.getItem(this.storageKey);
      const emails: EmailUpload[] = storedEmails ? JSON.parse(storedEmails) : [];
      
      // Find email upload for this customer
      const customerUpload = emails.find(upload => 
        upload.customerEmail.toLowerCase() === customerEmail.toLowerCase() &&
        upload.status === 'pending'
      );

      if (customerUpload) {
        // Mark as retrieved
        customerUpload.status = 'retrieved';
        customerUpload.retrievedAt = new Date();
        
        // Update storage
        await AsyncStorage.setItem(this.storageKey, JSON.stringify(emails));
        
        return customerUpload;
      }

      return null;
    } catch (error) {
      console.error('Failed to retrieve files:', error);
      return null;
    }
  }

  async processEmailUpload(uploadId: string): Promise<boolean> {
    try {
      const storedEmails = await AsyncStorage.getItem(this.storageKey);
      const emails: EmailUpload[] = storedEmails ? JSON.parse(storedEmails) : [];
      
      const uploadIndex = emails.findIndex(upload => upload.id === uploadId);
      if (uploadIndex !== -1) {
        emails[uploadIndex].status = 'processed';
        await AsyncStorage.setItem(this.storageKey, JSON.stringify(emails));
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Failed to process email upload:', error);
      return false;
    }
  }

  // Mock data for demonstration
  private async getMockEmailData(): Promise<EmailUpload[]> {
    const mockUploads: EmailUpload[] = [
      {
        id: 'email_001',
        customerEmail: 'customer@example.com',
        files: [
          {
            id: 'file_001',
            name: 'resume.pdf',
            size: 1024 * 500, // 500KB
            type: 'application/pdf',
            data: 'base64_encoded_data_here',
            uploadedAt: new Date()
          },
          {
            id: 'file_002',
            name: 'cover_letter.docx',
            size: 1024 * 200, // 200KB
            type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            data: 'base64_encoded_data_here',
            uploadedAt: new Date()
          }
        ],
        retrievedAt: new Date(),
        totalSize: 1024 * 700, // 700KB
        estimatedPrice: 15, // ₱15
        status: 'pending'
      },
      {
        id: 'email_002',
        customerEmail: 'test@gmail.com',
        files: [
          {
            id: 'file_003',
            name: 'presentation.pptx',
            size: 1024 * 1024 * 2, // 2MB
            type: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            data: 'base64_encoded_data_here',
            uploadedAt: new Date()
          }
        ],
        retrievedAt: new Date(),
        totalSize: 1024 * 1024 * 2, // 2MB
        estimatedPrice: 40, // ₱40
        status: 'pending'
      }
    ];

    return mockUploads;
  }

  getBusinessEmail(): string {
    return this.businessEmail;
  }

  // Calculate pricing based on file type and size
  calculatePrice(files: EmailFile[]): number {
    let totalPrice = 0;
    
    files.forEach(file => {
      const sizeInMB = file.size / (1024 * 1024);
      
      // Base pricing logic
      if (file.type.includes('pdf') || file.type.includes('document')) {
        // Document printing: ₱2 per page (estimate 1 page per 50KB)
        const estimatedPages = Math.max(1, Math.ceil(file.size / (1024 * 50)));
        totalPrice += estimatedPages * 2;
      } else if (file.type.includes('image')) {
        // Photo printing: ₱10 per photo
        totalPrice += 10;
      } else if (file.type.includes('presentation')) {
        // Presentation: ₱3 per slide (estimate 1 slide per 100KB)
        const estimatedSlides = Math.max(1, Math.ceil(file.size / (1024 * 100)));
        totalPrice += estimatedSlides * 3;
      } else {
        // Default: ₱5 per MB
        totalPrice += Math.ceil(sizeInMB) * 5;
      }
    });

    return Math.max(10, totalPrice); // Minimum ₱10
  }

  // Detect file configuration defaults
  detectFileDefaults(file: EmailFile) {
    const defaults = {
      paperSize: 'A4',
      orientation: 'portrait',
      colorMode: 'black_white',
      copies: 1,
      duplex: false
    };

    // Adjust defaults based on file type
    if (file.type.includes('image')) {
      defaults.colorMode = 'color';
      defaults.paperSize = '4x6'; // Standard photo size
    } else if (file.type.includes('presentation')) {
      defaults.colorMode = 'color';
    } else if (file.name.includes('landscape') || file.name.includes('wide')) {
      defaults.orientation = 'landscape';
    }

    return defaults;
  }
}

export const emailRetrievalService = new EmailRetrievalService();