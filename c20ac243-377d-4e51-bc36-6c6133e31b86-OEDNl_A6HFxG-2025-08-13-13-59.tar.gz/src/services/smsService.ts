import { Alert } from 'react-native';

interface SmsConfig {
  twilioAccountSid: string;
  twilioAuthToken: string;
  twilioPhoneNumber: string;
  businessName: string;
}

interface SmsMessage {
  to: string;
  message: string;
  orderId?: string;
}

class SmsService {
  private config: SmsConfig;

  constructor() {
    this.config = {
      // Add your Twilio credentials here
      twilioAccountSid: process.env.EXPO_PUBLIC_TWILIO_ACCOUNT_SID || '',
      twilioAuthToken: process.env.EXPO_PUBLIC_TWILIO_AUTH_TOKEN || '',
      twilioPhoneNumber: process.env.EXPO_PUBLIC_TWILIO_PHONE_NUMBER || '',
      businessName: 'PISO Print Express',
    };
  }

  // Send SMS to customer
  async sendSms(messageData: SmsMessage): Promise<boolean> {
    try {
      if (!this.config.twilioAccountSid || !this.config.twilioAuthToken) {
        console.log('⚠️ Twilio credentials not configured, SMS not sent');
        return false;
      }

      // Clean phone number (remove spaces, dashes, etc.)
      const cleanPhone = this.cleanPhoneNumber(messageData.to);
      if (!this.isValidPhoneNumber(cleanPhone)) {
        console.log('❌ Invalid phone number format:', messageData.to);
        return false;
      }

      const credentials = btoa(`${this.config.twilioAccountSid}:${this.config.twilioAuthToken}`);
      const formData = new URLSearchParams();
      formData.append('From', this.config.twilioPhoneNumber);
      formData.append('To', cleanPhone);
      formData.append('Body', messageData.message);

      const response = await fetch(
        `https://api.twilio.com/2010-04-01/Accounts/${this.config.twilioAccountSid}/Messages.json`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Basic ${credentials}`,
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: formData.toString(),
        }
      );

      if (response.ok) {
        const result = await response.json();
        console.log('✅ SMS sent successfully:', result.sid);
        return true;
      } else {
        const error = await response.json();
        console.error('❌ Twilio API error:', error);
        return false;
      }
    } catch (error) {
      console.error('SMS service error:', error);
      return false;
    }
  }

  // Send order confirmation SMS
  async sendOrderConfirmation(phone: string, orderData: any): Promise<boolean> {
    const message = `${this.config.businessName}: Order #${orderData.id?.slice(-6)} received! ${orderData.files?.length} file(s), Total: ₱${(orderData.totalPrice / 100).toFixed(2)}. We'll notify you when ready. Thanks!`;
    
    return this.sendSms({
      to: phone,
      message,
      orderId: orderData.id?.slice(-6),
    });
  }

  // Send order status update SMS
  async sendStatusUpdate(phone: string, orderData: any, newStatus: string): Promise<boolean> {
    const statusMessages = {
      'ongoing': `${this.config.businessName}: Your order #${orderData.id?.slice(-6)} is now being printed! 🖨️ Estimated completion: 15-20 mins.`,
      'ready': `${this.config.businessName}: Order #${orderData.id?.slice(-6)} is ready for pickup! 📋 Please collect at your convenience.`,
      'shipped': `${this.config.businessName}: Order #${orderData.id?.slice(-6)} is out for delivery! 🚚 Expected delivery: 20-30 mins.`,
      'completed': `${this.config.businessName}: Order #${orderData.id?.slice(-6)} completed! 🎉 Thank you for choosing us!`,
    };

    const message = statusMessages[newStatus as keyof typeof statusMessages] || 
                   `${this.config.businessName}: Order #${orderData.id?.slice(-6)} status updated to ${newStatus}.`;

    return this.sendSms({
      to: phone,
      message,
      orderId: orderData.id?.slice(-6),
    });
  }

  // Send delivery notification
  async sendDeliveryUpdate(phone: string, orderData: any, courierInfo?: string): Promise<boolean> {
    const message = courierInfo 
      ? `${this.config.businessName}: Order #${orderData.id?.slice(-6)} is out for delivery via ${courierInfo}! 🚚 Track your order in the app.`
      : `${this.config.businessName}: Order #${orderData.id?.slice(-6)} is out for delivery! 🚚 Estimated arrival: 20-30 mins.`;

    return this.sendSms({
      to: phone,
      message,
      orderId: orderData.id?.slice(-6),
    });
  }

  // Send promotional SMS (with opt-out)
  async sendPromotion(phone: string, promoMessage: string): Promise<boolean> {
    const message = `${this.config.businessName}: ${promoMessage} Reply STOP to opt-out.`;
    
    return this.sendSms({
      to: phone,
      message,
    });
  }

  // Send appointment reminder
  async sendReminder(phone: string, reminderText: string): Promise<boolean> {
    const message = `${this.config.businessName}: Reminder - ${reminderText}`;
    
    return this.sendSms({
      to: phone,
      message,
    });
  }

  // Utility: Clean phone number
  private cleanPhoneNumber(phone: string): string {
    // Remove all non-digit characters except +
    let cleaned = phone.replace(/[^\d+]/g, '');
    
    // If starts with 0, replace with +63 for Philippines
    if (cleaned.startsWith('0')) {
      cleaned = '+63' + cleaned.substring(1);
    }
    
    // If doesn't start with +, assume Philippines and add +63
    if (!cleaned.startsWith('+')) {
      // If it's 10 digits, assume it's missing country code
      if (cleaned.length === 10) {
        cleaned = '+63' + cleaned;
      }
    }
    
    return cleaned;
  }

  // Utility: Validate phone number
  private isValidPhoneNumber(phone: string): boolean {
    // Basic validation for international format
    const phoneRegex = /^\+[1-9]\d{8,14}$/;
    return phoneRegex.test(phone);
  }

  // Test SMS functionality
  async testSms(phone: string): Promise<boolean> {
    const testMessage = `${this.config.businessName}: SMS service is working! 📱 This is a test message.`;
    
    try {
      const result = await this.sendSms({
        to: phone,
        message: testMessage,
      });
      
      if (result) {
        Alert.alert('SMS Test', 'Test SMS sent successfully!');
      } else {
        Alert.alert('SMS Test Failed', 'Could not send test SMS. Check your Twilio configuration.');
      }
      
      return result;
    } catch (error) {
      Alert.alert('SMS Test Error', 'Error testing SMS service.');
      return false;
    }
  }

  // Check if SMS service is configured
  isConfigured(): boolean {
    return !!(this.config.twilioAccountSid && 
              this.config.twilioAuthToken && 
              this.config.twilioPhoneNumber);
  }

  // Get SMS service status
  getStatus(): { configured: boolean; phone: string } {
    return {
      configured: this.isConfigured(),
      phone: this.config.twilioPhoneNumber || 'Not configured',
    };
  }
}

export const smsService = new SmsService();
export default SmsService;