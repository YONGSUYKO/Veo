import { Camera, CameraType } from 'expo-camera';
import * as MediaLibrary from 'expo-media-library';
import * as ImageManipulator from 'expo-image-manipulator';
import { Alert } from 'react-native';

export interface CameraPermissions {
  camera: boolean;
  mediaLibrary: boolean;
}

export interface DocumentScanResult {
  uri: string;
  width: number;
  height: number;
  quality: 'excellent' | 'good' | 'fair' | 'poor';
  detectedEdges?: { x: number; y: number }[];
  isDocument: boolean;
}

export interface ImageEditOptions {
  brightness?: number;
  contrast?: number;
  saturation?: number;
  sharpen?: boolean;
  autoEnhance?: boolean;
  grayscale?: boolean;
}

class CameraService {
  private static instance: CameraService;
  
  static getInstance(): CameraService {
    if (!CameraService.instance) {
      CameraService.instance = new CameraService();
    }
    return CameraService.instance;
  }

  // Permission Management
  async requestPermissions(): Promise<CameraPermissions> {
    try {
      const cameraResult = await Camera.requestCameraPermissionsAsync();
      const mediaResult = await MediaLibrary.requestPermissionsAsync();
      
      return {
        camera: cameraResult.status === 'granted',
        mediaLibrary: mediaResult.status === 'granted',
      };
    } catch (error) {
      console.error('Failed to request camera permissions:', error);
      return { camera: false, mediaLibrary: false };
    }
  }

  async checkPermissions(): Promise<CameraPermissions> {
    try {
      const cameraResult = await Camera.getCameraPermissionsAsync();
      const mediaResult = await MediaLibrary.getPermissionsAsync();
      
      return {
        camera: cameraResult.status === 'granted',
        mediaLibrary: mediaResult.status === 'granted',
      };
    } catch (error) {
      console.error('Failed to check camera permissions:', error);
      return { camera: false, mediaLibrary: false };
    }
  }

  // Document Quality Detection
  analyzeDocumentQuality(imageUri: string, width: number, height: number): Promise<DocumentScanResult['quality']> {
    return new Promise((resolve) => {
      // Mock document quality analysis
      // In production, this would use ML/AI for real quality detection
      
      const aspectRatio = width / height;
      const isPortraitDocument = aspectRatio >= 0.6 && aspectRatio <= 0.8;
      const isLandscapeDocument = aspectRatio >= 1.2 && aspectRatio <= 1.8;
      
      if (width < 800 || height < 600) {
        resolve('poor');
      } else if (width < 1200 || height < 900) {
        resolve('fair');
      } else if (isPortraitDocument || isLandscapeDocument) {
        resolve('excellent');
      } else {
        resolve('good');
      }
    });
  }

  // Edge Detection (Mock Implementation)
  detectDocumentEdges(imageUri: string, width: number, height: number): Promise<{ x: number; y: number }[]> {
    return new Promise((resolve) => {
      // Mock edge detection - in production would use computer vision
      const padding = 0.05;
      const edges = [
        { x: width * padding, y: height * padding }, // Top-left
        { x: width * (1 - padding), y: height * padding }, // Top-right
        { x: width * (1 - padding), y: height * (1 - padding) }, // Bottom-right
        { x: width * padding, y: height * (1 - padding) }, // Bottom-left
      ];
      resolve(edges);
    });
  }

  // Document Analysis
  async analyzeDocument(imageUri: string): Promise<DocumentScanResult> {
    try {
      // Get image info
      const imageInfo = await ImageManipulator.manipulateAsync(
        imageUri,
        [],
        { format: ImageManipulator.SaveFormat.JPEG }
      );

      const quality = await this.analyzeDocumentQuality(
        imageInfo.uri,
        imageInfo.width,
        imageInfo.height
      );

      const edges = await this.detectDocumentEdges(
        imageInfo.uri,
        imageInfo.width,
        imageInfo.height
      );

      return {
        uri: imageInfo.uri,
        width: imageInfo.width,
        height: imageInfo.height,
        quality,
        detectedEdges: edges,
        isDocument: quality !== 'poor',
      };
    } catch (error) {
      console.error('Failed to analyze document:', error);
      throw new Error('Document analysis failed');
    }
  }

  // Image Enhancement (using supported expo-image-manipulator actions)
  async enhanceDocument(imageUri: string, options: ImageEditOptions = {}): Promise<string> {
    try {
      const manipulations: any[] = [];

      // Supported actions in expo-image-manipulator: resize, rotate, flip, crop
      // For document enhancement, we'll focus on optimization and basic processing

      // Auto-rotate for better document orientation if needed
      if (options.autoEnhance) {
        // We could add auto-rotation logic here if needed
        console.log('Auto-enhancement applied - optimized compression and format');
      }

      // Basic image processing
      const result = await ImageManipulator.manipulateAsync(
        imageUri,
        manipulations, // Keep manipulations array for future use
        {
          compress: this.getOptimalCompression(options),
          format: ImageManipulator.SaveFormat.JPEG,
        }
      );

      // For advanced features like brightness, contrast, saturation adjustments,
      // we would need to use libraries like react-native-image-filter-kit
      // or implement native modules. For now, we provide optimized output.

      return result.uri;
    } catch (error) {
      console.error('Failed to enhance document:', error);
      throw new Error('Document enhancement failed');
    }
  }

  private getOptimalCompression(options: ImageEditOptions): number {
    // Determine optimal compression based on options
    if (options.autoEnhance) {
      return 0.92; // High quality for enhanced documents
    }
    
    if (options.grayscale) {
      return 0.85; // Good compression for B&W documents
    }
    
    return 0.88; // Default balanced compression
  }

  // Crop document to detected edges
  async cropDocument(imageUri: string, edges: { x: number; y: number }[]): Promise<string> {
    try {
      // Calculate crop rectangle from edges
      const xCoords = edges.map(edge => edge.x);
      const yCoords = edges.map(edge => edge.y);
      
      const left = Math.min(...xCoords);
      const top = Math.min(...yCoords);
      const right = Math.max(...xCoords);
      const bottom = Math.max(...yCoords);

      const result = await ImageManipulator.manipulateAsync(
        imageUri,
        [
          {
            crop: {
              originX: left,
              originY: top,
              width: right - left,
              height: bottom - top,
            },
          },
        ],
        {
          compress: 0.8,
          format: ImageManipulator.SaveFormat.JPEG,
        }
      );

      return result.uri;
    } catch (error) {
      console.error('Failed to crop document:', error);
      throw new Error('Document cropping failed');
    }
  }

  // Save to device gallery
  async saveToGallery(imageUri: string, albumName: string = 'PISO Print Scans'): Promise<void> {
    try {
      const permissions = await this.checkPermissions();
      
      if (!permissions.mediaLibrary) {
        const granted = await this.requestPermissions();
        if (!granted.mediaLibrary) {
          Alert.alert(
            'Permission Required',
            'Media library access is needed to save scanned documents.'
          );
          return;
        }
      }

      await MediaLibrary.saveToLibraryAsync(imageUri);
      
      Alert.alert(
        'Saved Successfully',
        'Document has been saved to your photo gallery.'
      );
    } catch (error) {
      console.error('Failed to save to gallery:', error);
      Alert.alert(
        'Save Failed',
        'Could not save document to gallery. Please try again.'
      );
    }
  }

  // Generate filename for scanned document
  generateDocumentFilename(prefix: string = 'scan'): string {
    const now = new Date();
    const timestamp = now.getFullYear().toString() +
      (now.getMonth() + 1).toString().padStart(2, '0') +
      now.getDate().toString().padStart(2, '0') + '_' +
      now.getHours().toString().padStart(2, '0') +
      now.getMinutes().toString().padStart(2, '0') +
      now.getSeconds().toString().padStart(2, '0');
    
    return `${prefix}_${timestamp}.jpg`;
  }
}

export default CameraService.getInstance();