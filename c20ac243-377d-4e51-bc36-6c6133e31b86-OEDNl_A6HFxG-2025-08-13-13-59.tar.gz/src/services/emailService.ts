import { Alert } from 'react-native';

interface EmailConfig {
  brevoApiKey: string;
  businessEmail: string;
  businessName: string;
}

interface EmailMessage {
  to: string;
  subject: string;
  message: string;
  customerName?: string;
  orderId?: string;
  priority?: 'normal' | 'high';
}

interface CustomerMessage {
  customerEmail: string;
  customerName: string;
  subject: string;
  message: string;
  orderId?: string;
  phone?: string;
}

class EmailService {
  private config: EmailConfig;

  constructor() {
    this.config = {
      // Add your Brevo API key here
      brevoApiKey: process.env.EXPO_PUBLIC_BREVO_API_KEY || '',
      businessEmail: 'support@pisoprint.com', // Your business email
      businessName: 'PISO Print Express',
    };
  }

  // Send email from customer to business owner
  async sendCustomerMessage(messageData: CustomerMessage): Promise<boolean> {
    try {
      if (!this.config.brevoApiKey) {
        // Fallback: Open native email app
        return this.openNativeEmail(messageData);
      }

      const emailPayload = {
        sender: {
          name: messageData.customerName,
          email: messageData.customerEmail,
        },
        to: [
          {
            email: this.config.businessEmail,
            name: this.config.businessName,
          }
        ],
        subject: `[CUSTOMER MESSAGE] ${messageData.subject}`,
        htmlContent: this.formatCustomerMessage(messageData),
        replyTo: {
          email: messageData.customerEmail,
          name: messageData.customerName,
        },
        tags: ['customer-message', 'app-contact'],
      };

      const response = await fetch('https://api.brevo.com/v3/smtp/email', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'api-key': this.config.brevoApiKey,
        },
        body: JSON.stringify(emailPayload),
      });

      if (response.ok) {
        console.log('✅ Customer message sent via Brevo');
        return true;
      } else {
        console.error('❌ Brevo API error:', await response.text());
        return this.openNativeEmail(messageData);
      }
    } catch (error) {
      console.error('Email service error:', error);
      return this.openNativeEmail(messageData);
    }
  }

  // Send notification email to customer
  async sendToCustomer(messageData: EmailMessage): Promise<boolean> {
    try {
      if (!this.config.brevoApiKey) {
        console.log('⚠️ Brevo API key not configured');
        return false;
      }

      const emailPayload = {
        sender: {
          name: this.config.businessName,
          email: this.config.businessEmail,
        },
        to: [
          {
            email: messageData.to,
            name: messageData.customerName || 'Customer',
          }
        ],
        subject: messageData.subject,
        htmlContent: this.formatBusinessMessage(messageData),
        tags: ['notification', 'customer-update'],
      };

      const response = await fetch('https://api.brevo.com/v3/smtp/email', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'api-key': this.config.brevoApiKey,
        },
        body: JSON.stringify(emailPayload),
      });

      if (response.ok) {
        console.log('✅ Customer notification sent via Brevo');
        return true;
      } else {
        console.error('❌ Brevo API error:', await response.text());
        return false;
      }
    } catch (error) {
      console.error('Email service error:', error);
      return false;
    }
  }

  // Fallback: Open native email app
  private async openNativeEmail(messageData: CustomerMessage): Promise<boolean> {
    try {
      const { Linking } = require('react-native');
      const subject = encodeURIComponent(`[CUSTOMER MESSAGE] ${messageData.subject}`);
      const body = encodeURIComponent(this.formatPlainTextMessage(messageData));
      const emailUrl = `mailto:${this.config.businessEmail}?subject=${subject}&body=${body}`;
      
      const canOpen = await Linking.canOpenURL(emailUrl);
      if (canOpen) {
        await Linking.openURL(emailUrl);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Native email error:', error);
      return false;
    }
  }

  // Format customer message for business owner
  private formatCustomerMessage(data: CustomerMessage): string {
    return `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #3B82F6; color: white; padding: 20px; text-align: center;">
          <h2>📧 New Customer Message</h2>
        </div>
        
        <div style="padding: 20px; background: #f9fafb;">
          <div style="background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
            <h3 style="color: #1f2937; margin-top: 0;">Customer Details</h3>
            <p><strong>Name:</strong> ${data.customerName}</p>
            <p><strong>Email:</strong> ${data.customerEmail}</p>
            ${data.phone ? `<p><strong>Phone:</strong> ${data.phone}</p>` : ''}
            ${data.orderId ? `<p><strong>Order ID:</strong> #${data.orderId}</p>` : ''}
          </div>
          
          <div style="background: white; padding: 20px; border-radius: 8px;">
            <h3 style="color: #1f2937; margin-top: 0;">Message</h3>
            <div style="background: #f3f4f6; padding: 15px; border-radius: 6px; border-left: 4px solid #3B82F6;">
              <p style="margin: 0; line-height: 1.6;">${data.message}</p>
            </div>
          </div>
          
          <div style="margin-top: 20px; padding: 15px; background: #dbeafe; border-radius: 8px;">
            <p style="margin: 0; font-size: 14px; color: #1e40af;">
              💡 <strong>Tip:</strong> Reply directly to this email to respond to the customer.
            </p>
          </div>
        </div>
        
        <div style="background: #374151; color: #d1d5db; padding: 15px; text-align: center; font-size: 12px;">
          Sent via PISO Print Express App | ${new Date().toLocaleString()}
        </div>
      </div>
    `;
  }

  // Format business message to customer
  private formatBusinessMessage(data: EmailMessage): string {
    return `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #10B981; color: white; padding: 20px; text-align: center;">
          <h2>📋 ${this.config.businessName}</h2>
        </div>
        
        <div style="padding: 20px; background: #f9fafb;">
          <div style="background: white; padding: 20px; border-radius: 8px;">
            ${data.orderId ? `<p style="color: #6b7280; font-size: 14px;">Order #${data.orderId}</p>` : ''}
            <div style="line-height: 1.6;">
              ${data.message}
            </div>
          </div>
          
          <div style="margin-top: 20px; padding: 15px; background: #d1fae5; border-radius: 8px;">
            <p style="margin: 0; font-size: 14px; color: #047857;">
              📞 Need immediate help? Contact us at ${this.config.businessEmail}
            </p>
          </div>
        </div>
        
        <div style="background: #374151; color: #d1d5db; padding: 15px; text-align: center; font-size: 12px;">
          ${this.config.businessName} | ${new Date().toLocaleString()}
        </div>
      </div>
    `;
  }

  // Plain text version for native email
  private formatPlainTextMessage(data: CustomerMessage): string {
    return `
NEW CUSTOMER MESSAGE
===================

Customer Details:
- Name: ${data.customerName}
- Email: ${data.customerEmail}
${data.phone ? `- Phone: ${data.phone}` : ''}
${data.orderId ? `- Order ID: #${data.orderId}` : ''}

Message:
--------
${data.message}

===================
Sent via PISO Print Express App
${new Date().toLocaleString()}
    `;
  }

  // Send order confirmation email
  async sendOrderConfirmation(customerEmail: string, orderData: any): Promise<boolean> {
    return this.sendToCustomer({
      to: customerEmail,
      subject: `Order Confirmation #${orderData.id?.slice(-6)}`,
      message: `
        <h3>Thank you for your order!</h3>
        <p>Your print job has been received and will be processed shortly.</p>
        
        <h4>Order Details:</h4>
        <ul>
          <li><strong>Order ID:</strong> #${orderData.id?.slice(-6)}</li>
          <li><strong>Files:</strong> ${orderData.files?.length} file(s)</li>
          <li><strong>Total:</strong> ₱${(orderData.totalPrice / 100).toFixed(2)}</li>
          <li><strong>Payment:</strong> ${orderData.paymentMethod}</li>
          <li><strong>Fulfillment:</strong> ${orderData.fulfillmentMethod}</li>
        </ul>
        
        <p>We'll notify you when your order is ready!</p>
      `,
      customerName: orderData.customerInfo?.name,
      orderId: orderData.id?.slice(-6),
    });
  }

  // Send order status update
  async sendStatusUpdate(customerEmail: string, orderData: any, newStatus: string): Promise<boolean> {
    const statusMessages = {
      'ongoing': 'Your order is now being printed! 🖨️',
      'ready': 'Your order is ready for pickup! ✅',
      'shipped': 'Your order is out for delivery! 🚚',
      'completed': 'Your order has been completed! 🎉',
    };

    return this.sendToCustomer({
      to: customerEmail,
      subject: `Order Update #${orderData.id?.slice(-6)} - ${newStatus.toUpperCase()}`,
      message: `
        <h3>${statusMessages[newStatus as keyof typeof statusMessages] || 'Order Status Updated'}</h3>
        <p>Your order #${orderData.id?.slice(-6)} status has been updated.</p>
        
        <div style="background: #f3f4f6; padding: 15px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 0;"><strong>Current Status:</strong> ${newStatus.charAt(0).toUpperCase() + newStatus.slice(1)}</p>
        </div>
        
        <p>Track your order progress in the PISO Print Express app!</p>
      `,
      customerName: orderData.customerInfo?.name,
      orderId: orderData.id?.slice(-6),
    });
  }
}

export const emailService = new EmailService();
export default EmailService;