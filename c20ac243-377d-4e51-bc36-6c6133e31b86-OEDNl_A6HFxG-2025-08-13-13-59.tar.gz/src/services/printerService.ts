import AsyncStorage from '@react-native-async-storage/async-storage';

export interface PrinterCapability {
  type: 'paper_size' | 'color' | 'duplex' | 'quality';
  values: string[];
}

export interface PrinterStatus {
  id: string;
  name: string;
  manufacturer: string;
  model: string;
  status: 'online' | 'offline' | 'busy' | 'error' | 'paper_low' | 'ink_low' | 'maintenance';
  type: 'laser' | 'inkjet' | 'photo' | 'thermal';
  location: string;
  ipAddress?: string;
  jobsInQueue: number;
  lastActivity: Date;
  capabilities: PrinterCapability[];
  paperLevels: { [size: string]: number }; // percentage
  inkLevels: { [color: string]: number }; // percentage
  totalPagesCount: number;
  dailyPagesCount: number;
  estimatedSpeed: number; // pages per minute
}

export interface PrintJobSpecs {
  paperSize: 'A4' | 'A3' | 'Letter' | '4x6' | '5x7' | '8x10' | 'Custom';
  orientation: 'portrait' | 'landscape';
  colorMode: 'color' | 'grayscale' | 'blackwhite';
  quality: 'draft' | 'normal' | 'high' | 'photo';
  duplex: 'none' | 'horizontal' | 'vertical';
  copies: number;
  collate: boolean;
  pages?: string; // e.g., "1-5,8,10-12"
}

export interface PrintJob {
  id: string;
  customerId: string;
  customerName: string;
  files: {
    id: string;
    name: string;
    url: string;
    type: string;
    pages: number;
  }[];
  printSpecs: PrintJobSpecs;
  assignedPrinterId?: string;
  status: 'queued' | 'assigned' | 'printing' | 'printed' | 'ready' | 'completed' | 'cancelled' | 'failed';
  priority: 'low' | 'normal' | 'high' | 'urgent';
  estimatedTime: number; // minutes
  actualTime?: number; // minutes
  totalCost: number;
  createdAt: Date;
  startedAt?: Date;
  completedAt?: Date;
  errorMessage?: string;
  operatorId?: string;
  operatorNotes?: string;
}

class PrinterService {
  private printersKey = 'printers_status';
  private printJobsKey = 'print_jobs';
  private printStatsKey = 'print_statistics';

  // Initialize default printers
  async initializeDefaultPrinters(): Promise<PrinterStatus[]> {
    const defaultPrinters: PrinterStatus[] = [
      {
        id: 'hp_laser_01',
        name: 'HP LaserJet Pro M404n',
        manufacturer: 'HP',
        model: 'LaserJet Pro M404n',
        status: 'online',
        type: 'laser',
        location: 'Front Counter - Station A',
        ipAddress: '192.168.1.101',
        jobsInQueue: 0,
        lastActivity: new Date(),
        capabilities: [
          { type: 'paper_size', values: ['A4', 'A3', 'Letter', 'Legal'] },
          { type: 'color', values: ['blackwhite', 'grayscale'] },
          { type: 'duplex', values: ['none', 'horizontal', 'vertical'] },
          { type: 'quality', values: ['draft', 'normal', 'high'] }
        ],
        paperLevels: { 'A4': 85, 'A3': 60, 'Letter': 90 },
        inkLevels: { 'black': 75 },
        totalPagesCount: 45230,
        dailyPagesCount: 127,
        estimatedSpeed: 38 // ppm
      },
      {
        id: 'canon_inkjet_01',
        name: 'Canon PIXMA G7020',
        manufacturer: 'Canon',
        model: 'PIXMA G7020',
        status: 'online',
        type: 'inkjet',
        location: 'Back Station - Color Prints',
        ipAddress: '192.168.1.102',
        jobsInQueue: 2,
        lastActivity: new Date(),
        capabilities: [
          { type: 'paper_size', values: ['A4', 'Letter', '4x6', '5x7'] },
          { type: 'color', values: ['color', 'grayscale', 'blackwhite'] },
          { type: 'duplex', values: ['none', 'horizontal'] },
          { type: 'quality', values: ['draft', 'normal', 'high', 'photo'] }
        ],
        paperLevels: { 'A4': 45, 'Letter': 30, '4x6': 80 },
        inkLevels: { 'black': 60, 'cyan': 45, 'magenta': 70, 'yellow': 55 },
        totalPagesCount: 23150,
        dailyPagesCount: 89,
        estimatedSpeed: 15 // ppm
      },
      {
        id: 'epson_photo_01',
        name: 'Epson SureColor P800',
        manufacturer: 'Epson',
        model: 'SureColor P800',
        status: 'online',
        type: 'photo',
        location: 'Photo Station - Premium',
        ipAddress: '192.168.1.103',
        jobsInQueue: 0,
        lastActivity: new Date(),
        capabilities: [
          { type: 'paper_size', values: ['4x6', '5x7', '8x10', '11x14', '13x19'] },
          { type: 'color', values: ['color'] },
          { type: 'duplex', values: ['none'] },
          { type: 'quality', values: ['high', 'photo'] }
        ],
        paperLevels: { '4x6': 95, '5x7': 80, '8x10': 65, '11x14': 40 },
        inkLevels: { 
          'photo_black': 85, 'cyan': 70, 'magenta': 75, 'yellow': 80,
          'light_cyan': 65, 'light_magenta': 70, 'light_black': 90
        },
        totalPagesCount: 8940,
        dailyPagesCount: 23,
        estimatedSpeed: 3 // ppm (photo quality)
      }
    ];

    await AsyncStorage.setItem(this.printersKey, JSON.stringify(defaultPrinters));
    return defaultPrinters;
  }

  // Get all printers
  async getAllPrinters(): Promise<PrinterStatus[]> {
    try {
      const printersJson = await AsyncStorage.getItem(this.printersKey);
      if (printersJson) {
        return JSON.parse(printersJson).map((printer: any) => ({
          ...printer,
          lastActivity: new Date(printer.lastActivity)
        }));
      }
      return await this.initializeDefaultPrinters();
    } catch (error) {
      console.error('Error loading printers:', error);
      return await this.initializeDefaultPrinters();
    }
  }

  // Update printer status
  async updatePrinterStatus(printerId: string, status: PrinterStatus['status'], additionalData?: Partial<PrinterStatus>): Promise<void> {
    const printers = await this.getAllPrinters();
    const updatedPrinters = printers.map(printer => 
      printer.id === printerId 
        ? { 
            ...printer, 
            status, 
            lastActivity: new Date(),
            ...additionalData 
          }
        : printer
    );
    
    await AsyncStorage.setItem(this.printersKey, JSON.stringify(updatedPrinters));
    console.log(`📠 Printer ${printerId} status updated to: ${status}`);
  }

  // Get available printers for job type
  async getAvailablePrinters(jobSpecs: PrintJobSpecs): Promise<PrinterStatus[]> {
    const allPrinters = await this.getAllPrinters();
    
    return allPrinters.filter(printer => {
      // Check if printer is online
      if (printer.status !== 'online') return false;
      
      // Check paper size compatibility
      const paperSizeCapability = printer.capabilities.find(cap => cap.type === 'paper_size');
      if (paperSizeCapability && !paperSizeCapability.values.includes(jobSpecs.paperSize)) {
        return false;
      }
      
      // Check color compatibility
      const colorCapability = printer.capabilities.find(cap => cap.type === 'color');
      if (colorCapability && !colorCapability.values.includes(jobSpecs.colorMode)) {
        return false;
      }
      
      // Check paper levels
      if (printer.paperLevels[jobSpecs.paperSize] < 10) return false;
      
      return true;
    });
  }

  // Assign job to printer
  async assignJobToPrinter(jobId: string, printerId: string): Promise<boolean> {
    try {
      const printers = await this.getAllPrinters();
      const printer = printers.find(p => p.id === printerId);
      
      if (!printer || printer.status !== 'online') {
        throw new Error('Printer not available');
      }

      // Update printer queue count
      await this.updatePrinterStatus(printerId, 'online', {
        jobsInQueue: printer.jobsInQueue + 1
      });

      console.log(`✅ Job ${jobId} assigned to printer ${printerId}`);
      return true;
    } catch (error) {
      console.error('Error assigning job to printer:', error);
      return false;
    }
  }

  // Start printing job
  async startPrintJob(jobId: string, printerId: string, operatorId: string): Promise<boolean> {
    try {
      // Update printer status to busy
      await this.updatePrinterStatus(printerId, 'busy');
      
      // In production, this would send the actual print command to the printer
      // For now, we simulate the printing process
      
      console.log(`🖨️ Started printing job ${jobId} on printer ${printerId}`);
      return true;
    } catch (error) {
      console.error('Error starting print job:', error);
      return false;
    }
  }

  // Complete print job
  async completePrintJob(jobId: string, printerId: string): Promise<boolean> {
    try {
      const printers = await this.getAllPrinters();
      const printer = printers.find(p => p.id === printerId);
      
      if (!printer) return false;

      // Update printer status back to online and decrement queue
      await this.updatePrinterStatus(printerId, 'online', {
        jobsInQueue: Math.max(0, printer.jobsInQueue - 1),
        dailyPagesCount: printer.dailyPagesCount + 1 // Increment daily count
      });

      console.log(`✅ Completed printing job ${jobId} on printer ${printerId}`);
      return true;
    } catch (error) {
      console.error('Error completing print job:', error);
      return false;
    }
  }

  // Get printer statistics
  async getPrinterStatistics(printerId: string, period: 'today' | 'week' | 'month' = 'today'): Promise<any> {
    const printers = await this.getAllPrinters();
    const printer = printers.find(p => p.id === printerId);
    
    if (!printer) return null;

    return {
      printerId: printer.id,
      name: printer.name,
      period,
      stats: {
        pagesCount: printer.dailyPagesCount,
        totalJobs: printer.jobsInQueue + printer.dailyPagesCount, // Approximation
        averageTime: 2.5, // minutes per job
        successRate: 98.5, // percentage
        utilization: ((printer.dailyPagesCount / (8 * 60 * printer.estimatedSpeed)) * 100).toFixed(1) + '%'
      }
    };
  }

  // Simulate real-time printer monitoring
  startPrinterMonitoring(): () => void {
    const interval = setInterval(async () => {
      const printers = await this.getAllPrinters();
      
      // Simulate random status updates
      for (const printer of printers) {
        const random = Math.random();
        
        // Simulate ink/paper level changes
        if (random > 0.95) {
          const updates: Partial<PrinterStatus> = {};
          
          // Random paper level decrease
          if (random > 0.98) {
            Object.keys(printer.paperLevels).forEach(size => {
              printer.paperLevels[size] = Math.max(0, printer.paperLevels[size] - Math.floor(Math.random() * 5));
            });
            updates.paperLevels = printer.paperLevels;
          }
          
          // Random ink level decrease  
          if (random > 0.97) {
            Object.keys(printer.inkLevels).forEach(color => {
              printer.inkLevels[color] = Math.max(0, printer.inkLevels[color] - Math.floor(Math.random() * 3));
            });
            updates.inkLevels = printer.inkLevels;
          }
          
          // Check for low levels and update status
          const lowPaper = Object.values(printer.paperLevels).some(level => level < 20);
          const lowInk = Object.values(printer.inkLevels).some(level => level < 20);
          
          if (lowPaper && printer.status === 'online') {
            await this.updatePrinterStatus(printer.id, 'paper_low', updates);
          } else if (lowInk && printer.status === 'online') {
            await this.updatePrinterStatus(printer.id, 'ink_low', updates);
          } else if (updates.paperLevels || updates.inkLevels) {
            await this.updatePrinterStatus(printer.id, printer.status, updates);
          }
        }
      }
    }, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }
}

export const printerService = new PrinterService();
export default PrinterService;