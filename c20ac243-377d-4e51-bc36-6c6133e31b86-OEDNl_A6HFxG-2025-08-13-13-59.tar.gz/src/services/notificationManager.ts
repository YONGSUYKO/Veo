import { emailService } from './emailService';
import { smsService } from './smsService';
import { pushNotificationService } from './pushNotificationService';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Alert } from 'react-native';

export type CustomerTier = 'guest' | 'registered' | 'subscriber';

export interface NotificationPreferences {
  userId: string;
  customerTier: CustomerTier;
  email: {
    enabled: boolean;
    orderUpdates: boolean;
    promotions: boolean;
    receipts: boolean;
  };
  sms: {
    enabled: boolean;
    orderUpdates: boolean;
    promotions: boolean;
    chargeApproved: boolean; // User approved SMS charges
  };
  push: {
    enabled: boolean;
    orderUpdates: boolean;
    promotions: boolean;
    sound: boolean;
  };
  phone?: string;
  emailAddress?: string;
}

export interface NotificationCost {
  sms: number; // Cost per SMS in PHP
  email: number; // Usually free
  push: number; // Usually free
}

export interface NotificationOptions {
  orderId?: string;
  priority?: 'low' | 'normal' | 'high';
  category?: 'order' | 'promotion' | 'system';
  requireApproval?: boolean; // For SMS charges
}

class NotificationManager {
  private preferencesKey = 'notification_preferences';
  private costsKey = 'notification_costs';
  private defaultCosts: NotificationCost = {
    sms: 5, // 5 PHP per SMS
    email: 0,
    push: 0,
  };

  constructor() {
    this.initializeDefaultCosts();
  }

  // Initialize default notification costs
  private async initializeDefaultCosts(): Promise<void> {
    try {
      const existingCosts = await AsyncStorage.getItem(this.costsKey);
      if (!existingCosts) {
        await AsyncStorage.setItem(this.costsKey, JSON.stringify(this.defaultCosts));
      }
    } catch (error) {
      console.error('Error initializing notification costs:', error);
    }
  }

  // Get notification costs with fallback
  async getNotificationCosts(): Promise<NotificationCost> {
    try {
      const costsJson = await AsyncStorage.getItem(this.costsKey);
      return costsJson ? JSON.parse(costsJson) : this.defaultCosts;
    } catch (error) {
      console.error('Error loading notification costs:', error);
      // Always return default costs as fallback
      return this.defaultCosts;
    }
  }

  // Create default preferences for user
  async createDefaultPreferences(
    userId: string, 
    customerTier: CustomerTier,
    email?: string,
    phone?: string
  ): Promise<NotificationPreferences> {
    const preferences: NotificationPreferences = {
      userId,
      customerTier,
      email: {
        enabled: customerTier !== 'guest',
        orderUpdates: customerTier !== 'guest',
        promotions: customerTier === 'subscriber',
        receipts: customerTier !== 'guest',
      },
      sms: {
        enabled: true, // Always available
        orderUpdates: true,
        promotions: customerTier === 'subscriber',
        chargeApproved: false, // User must explicitly approve
      },
      push: {
        enabled: customerTier !== 'guest',
        orderUpdates: customerTier !== 'guest',
        promotions: customerTier === 'subscriber',
        sound: true,
      },
      emailAddress: email,
      phone: phone,
    };

    await this.savePreferences(preferences);
    return preferences;
  }

  // Get user's notification preferences
  async getUserPreferences(userId: string): Promise<NotificationPreferences | null> {
    try {
      const preferencesJson = await AsyncStorage.getItem(this.preferencesKey);
      if (preferencesJson) {
        const allPreferences: NotificationPreferences[] = JSON.parse(preferencesJson);
        return allPreferences.find(p => p.userId === userId) || null;
      }
      return null;
    } catch (error) {
      console.error('Error loading user preferences:', error);
      return null;
    }
  }

  // Save user preferences
  async savePreferences(preferences: NotificationPreferences): Promise<void> {
    try {
      const preferencesJson = await AsyncStorage.getItem(this.preferencesKey);
      let allPreferences: NotificationPreferences[] = preferencesJson ? JSON.parse(preferencesJson) : [];
      
      const existingIndex = allPreferences.findIndex(p => p.userId === preferences.userId);
      if (existingIndex >= 0) {
        allPreferences[existingIndex] = preferences;
      } else {
        allPreferences.push(preferences);
      }
      
      await AsyncStorage.setItem(this.preferencesKey, JSON.stringify(allPreferences));
      console.log('✅ Notification preferences saved for user:', preferences.userId);
    } catch (error) {
      console.error('Error saving preferences:', error);
    }
  }

  // Request SMS approval for charged notifications
  async requestSmsApproval(
    customerTier: CustomerTier, 
    message: string,
    orderId?: string
  ): Promise<boolean> {
    if (customerTier === 'subscriber') {
      return true; // Subscribers get free SMS
    }

    const costs = await this.getNotificationCosts();
    
    return new Promise((resolve) => {
      Alert.alert(
        'SMS Notification',
        `${message}\n\nSending this SMS notification will cost ₱${costs.sms}. Do you want to proceed?`,
        [
          {
            text: 'No, Skip SMS',
            onPress: () => resolve(false),
            style: 'cancel'
          },
          {
            text: `Pay ₱${costs.sms} & Send`,
            onPress: () => resolve(true)
          }
        ]
      );
    });
  }

  // Send comprehensive order update notification
  async sendOrderUpdate(
    userId: string,
    orderId: string,
    status: string,
    customMessage?: string,
    options?: NotificationOptions
  ): Promise<{
    email: boolean;
    sms: boolean;
    push: boolean;
    totalCost: number;
  }> {
    const preferences = await this.getUserPreferences(userId);
    if (!preferences) {
      console.log('⚠️ No preferences found for user:', userId);
      return { email: false, sms: false, push: false, totalCost: 0 };
    }

    const costs = await this.getNotificationCosts();
    let totalCost = 0;
    const results = { email: false, sms: false, push: false, totalCost: 0 };

    // Generate appropriate message for each channel
    const messages = this.generateOrderMessages(orderId, status, customMessage);

    // Email notification (Free for registered/subscribers, not available for guests)
    if (preferences.email.enabled && 
        preferences.email.orderUpdates && 
        preferences.emailAddress &&
        preferences.customerTier !== 'guest') {
      
      try {
        results.email = await emailService.sendStatusUpdate(
          preferences.emailAddress,
          { id: orderId },
          status
        );
        console.log('📧 Email notification sent');
      } catch (error) {
        console.error('Email notification failed:', error);
      }
    }

    // Push notification (Free for registered/subscribers)
    if (preferences.push.enabled && 
        preferences.push.orderUpdates &&
        preferences.customerTier !== 'guest') {
      
      try {
        results.push = await pushNotificationService.sendOrderUpdate(
          userId,
          orderId,
          status,
          messages.push
        );
        console.log('📱 Push notification sent');
      } catch (error) {
        console.error('Push notification failed:', error);
      }
    }

    // SMS notification (Charged for guests and registered, free for subscribers)
    if (preferences.sms.enabled && preferences.sms.orderUpdates && preferences.phone) {
      let sendSms = false;

      if (preferences.customerTier === 'subscriber') {
        // Subscribers get free SMS
        sendSms = true;
        console.log('📱 Free SMS for subscriber');
      } else if (preferences.customerTier === 'registered' && preferences.sms.chargeApproved) {
        // Registered users with pre-approved SMS charges
        sendSms = true;
        totalCost += costs.sms;
        console.log('📱 Charged SMS for registered user (pre-approved)');
      } else if (options?.requireApproval !== false) {
        // Request approval for SMS charge
        sendSms = await this.requestSmsApproval(preferences.customerTier, messages.sms, orderId);
        if (sendSms && preferences.customerTier !== 'subscriber') {
          totalCost += costs.sms;
        }
      }

      if (sendSms) {
        try {
          results.sms = await smsService.sendStatusUpdate(
            preferences.phone,
            { id: orderId },
            status
          );
          console.log('📱 SMS notification sent');
        } catch (error) {
          console.error('SMS notification failed:', error);
        }
      }
    }

    results.totalCost = totalCost;

    // Log notification summary
    console.log(`📊 Notification Summary for ${preferences.customerTier} user:`, {
      email: results.email,
      sms: results.sms,
      push: results.push,
      totalCost: `₱${totalCost}`
    });

    return results;
  }

  // Send promotional notification
  async sendPromotion(
    userId: string,
    title: string,
    message: string,
    options?: NotificationOptions
  ): Promise<{ email: boolean; sms: boolean; push: boolean; totalCost: number }> {
    const preferences = await this.getUserPreferences(userId);
    if (!preferences) {
      return { email: false, sms: false, push: false, totalCost: 0 };
    }

    const costs = await this.getNotificationCosts();
    let totalCost = 0;
    const results = { email: false, sms: false, push: false, totalCost: 0 };

    // Only send promotions to subscribers (free) or with explicit approval
    if (preferences.customerTier !== 'subscriber') {
      console.log('⚠️ Promotions only sent to subscribers or with approval');
      return results;
    }

    // Email promotion (Free for subscribers)
    if (preferences.email.enabled && 
        preferences.email.promotions && 
        preferences.emailAddress) {
      
      try {
        results.email = await emailService.sendToCustomer({
          to: preferences.emailAddress,
          subject: title,
          message: message,
        });
      } catch (error) {
        console.error('Promotional email failed:', error);
      }
    }

    // Push promotion (Free for subscribers)
    if (preferences.push.enabled && preferences.push.promotions) {
      try {
        results.push = await pushNotificationService.sendPromotion(userId, title, message);
      } catch (error) {
        console.error('Promotional push notification failed:', error);
      }
    }

    // SMS promotion (Free for subscribers only)
    if (preferences.sms.enabled && 
        preferences.sms.promotions && 
        preferences.phone &&
        preferences.customerTier === 'subscriber') {
      
      try {
        results.sms = await smsService.sendPromotion(preferences.phone, message);
      } catch (error) {
        console.error('Promotional SMS failed:', error);
      }
    }

    results.totalCost = totalCost;
    return results;
  }

  // Send bulk notifications to multiple users
  async sendBulkNotification(
    userIds: string[],
    title: string,
    message: string,
    category: 'order' | 'promotion' | 'system' = 'system'
  ): Promise<{ 
    totalSent: number; 
    emailSent: number; 
    smsSent: number; 
    pushSent: number; 
    totalCost: number 
  }> {
    const results = {
      totalSent: 0,
      emailSent: 0,
      smsSent: 0,
      pushSent: 0,
      totalCost: 0,
    };

    for (const userId of userIds) {
      try {
        let notificationResult;
        
        if (category === 'order') {
          notificationResult = await this.sendOrderUpdate(userId, 'system', 'system', message);
        } else {
          notificationResult = await this.sendPromotion(userId, title, message);
        }

        if (notificationResult.email) results.emailSent++;
        if (notificationResult.sms) results.smsSent++;
        if (notificationResult.push) results.pushSent++;
        results.totalCost += notificationResult.totalCost;
        
        if (notificationResult.email || notificationResult.sms || notificationResult.push) {
          results.totalSent++;
        }
      } catch (error) {
        console.error(`Error sending notification to user ${userId}:`, error);
      }
    }

    console.log('📊 Bulk notification results:', results);
    return results;
  }

  // Generate appropriate messages for different channels
  private generateOrderMessages(orderId: string, status: string, customMessage?: string): {
    email: string;
    sms: string;
    push: string;
  } {
    const orderNum = `#${orderId.slice(-6)}`;
    
    if (customMessage) {
      return {
        email: customMessage,
        sms: customMessage,
        push: customMessage,
      };
    }

    const statusMessages = {
      uploaded: {
        email: `Your order ${orderNum} has been received and is being reviewed by our team.`,
        sms: `PISO Print: Order ${orderNum} received! We're reviewing your files.`,
        push: `Order received and under review`,
      },
      under_review: {
        email: `Our team is currently reviewing your order ${orderNum} and will contact you with pricing soon.`,
        sms: `PISO Print: Order ${orderNum} under review. Pricing coming soon!`,
        push: `Order is being reviewed by our team`,
      },
      approved_for_payment: {
        email: `Great news! Order ${orderNum} has been reviewed and is ready for payment.`,
        sms: `PISO Print: Order ${orderNum} approved! Ready for payment.`,
        push: `Order approved - ready for payment`,
      },
      paid: {
        email: `Payment received for order ${orderNum}! Your order is now in the print queue.`,
        sms: `PISO Print: Payment received for ${orderNum}. Printing soon!`,
        push: `Payment received - order queued for printing`,
      },
      printing: {
        email: `Your order ${orderNum} is currently being printed. We'll notify you when it's ready!`,
        sms: `PISO Print: Order ${orderNum} is printing now! 🖨️`,
        push: `Your order is currently being printed`,
      },
      ready: {
        email: `Order ${orderNum} is ready for pickup! Please collect it at your convenience.`,
        sms: `PISO Print: Order ${orderNum} ready for pickup! 📋`,
        push: `Order ready for pickup!`,
      },
      completed: {
        email: `Order ${orderNum} has been completed. Thank you for choosing PISO Print Express!`,
        sms: `PISO Print: Order ${orderNum} completed! Thanks! 🎉`,
        push: `Order completed - thank you!`,
      },
    };

    return statusMessages[status as keyof typeof statusMessages] || {
      email: `Order ${orderNum} status updated to ${status}`,
      sms: `PISO Print: Order ${orderNum} - ${status}`,
      push: `Order status: ${status}`,
    };
  }

  // Update user's customer tier
  async updateCustomerTier(userId: string, newTier: CustomerTier): Promise<void> {
    const preferences = await this.getUserPreferences(userId);
    if (preferences) {
      preferences.customerTier = newTier;
      
      // Update default settings based on new tier
      if (newTier === 'subscriber') {
        preferences.email.promotions = true;
        preferences.sms.promotions = true;
        preferences.push.promotions = true;
        preferences.sms.chargeApproved = true; // Auto-approve for subscribers
      }
      
      await this.savePreferences(preferences);
      console.log(`✅ Customer tier updated to ${newTier} for user ${userId}`);
    }
  }

  // Get notification statistics
  async getNotificationStats(): Promise<{
    totalUsers: number;
    subscriberUsers: number;
    registeredUsers: number;
    guestUsers: number;
    totalSmsCost: number;
  }> {
    try {
      const preferencesJson = await AsyncStorage.getItem(this.preferencesKey);
      if (!preferencesJson) return { totalUsers: 0, subscriberUsers: 0, registeredUsers: 0, guestUsers: 0, totalSmsCost: 0 };

      const allPreferences: NotificationPreferences[] = JSON.parse(preferencesJson);
      const stats = {
        totalUsers: allPreferences.length,
        subscriberUsers: allPreferences.filter(p => p.customerTier === 'subscriber').length,
        registeredUsers: allPreferences.filter(p => p.customerTier === 'registered').length,
        guestUsers: allPreferences.filter(p => p.customerTier === 'guest').length,
        totalSmsCost: 0, // Would need to track actual SMS costs sent
      };

      return stats;
    } catch (error) {
      console.error('Error getting notification stats:', error);
      return { totalUsers: 0, subscriberUsers: 0, registeredUsers: 0, guestUsers: 0, totalSmsCost: 0 };
    }
  }
}

export const notificationManager = new NotificationManager();
export default NotificationManager;