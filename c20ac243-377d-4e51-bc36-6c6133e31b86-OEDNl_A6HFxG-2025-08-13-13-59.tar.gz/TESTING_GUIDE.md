# 🧪 PISO Print Express - iPhone Testing Guide

## 🚀 **Quick Start Testing**

### **Enable Testing Mode:**
1. **Development mode is now ENABLED** - restart the app
2. You'll see a **"Development Mode"** selector screen
3. Choose which app to test: Customer, Operator, or Admin

---

## 📱 **iPhone Testing Instructions**

### **1. Launch the App**
```bash
# In your terminal (if needed):
cd /home/user/workspace
bun run start
```

### **2. Development Mode Interface**
- **Yellow development banner** shows current mode
- **"SWITCH" button** to return to app selector
- Test all three app types from one interface

---

## 🎯 **Testing Scenarios by Role**

### **📱 CUSTOMER APP Testing**

#### **Core Workflow Test:**
```
1. 📋 Welcome Screen
   ✓ Dynamic greeting based on time
   ✓ Printing tip of the day
   ✓ Service selection buttons

2. 🗂️ Document Upload
   ✓ Choose "Print Documents"
   ✓ Browse files or camera scan
   ✓ Multiple file selection

3. ⚙️ File Settings
   ✓ Paper size selection (A4, A3, Letter)
   ✓ Color mode (Auto, Color, B&W)
   ✓ Page sidedness (Single, Double)
   ✓ Number of copies (up to 1000)
   ✓ Admin controls working (lock/unlock features)

4. 💳 Payment Process
   ✓ Cash/GCash/Card options
   ✓ Customer info form
   ✓ Loyalty points redemption
   ✓ Pickup vs Delivery selection
   ✓ Courier selection for delivery

5. ✅ Order Completion
   ✓ Order summary display
   ✓ Live status updates (Queue → Ongoing → Ready)
   ✓ Customer notifications
```

#### **Special Features to Test:**
- **Photo Printing**: Different sizes (1x1, 2x2, 4x6)
- **Scan & Print**: Camera document scanning
- **Guest vs Registered**: Test both user types
- **Loyalty Points**: Points earning and redemption

---

### **👨‍💼 OPERATOR APP Testing**

#### **Core Workflow Test:**
```
1. 🏠 Operator Dashboard
   ✓ Status control (Active/Break/Offline)
   ✓ Job metrics display
   ✓ Queue management

2. 📋 Job Processing
   ✓ View pending jobs in queue
   ✓ Job details modal (customer info, files, pricing)
   ✓ Status updates: Queue → Ongoing → Ready → Complete

3. 🔄 Customer Assistance
   ✓ "New Order" button switches to customer view
   ✓ Help customers place orders
   ✓ Switch back to operator dashboard

4. 📊 Quick Actions
   ✓ Scan code (placeholder)
   ✓ Process payment (placeholder)
   ✓ Send notifications (placeholder)
```

#### **Key Features to Verify:**
- **Job Queue**: Real-time job status updates
- **Multi-tasking**: Handle multiple jobs simultaneously
- **Customer Mode**: Seamless switching for customer assistance

---

### **👩‍💻 ADMIN APP Testing**

#### **Core Workflow Test:**
```
1. 🎛️ Admin Dashboard
   ✓ Business metrics (revenue, jobs, staff)
   ✓ System status indicators
   ✓ Recent jobs overview

2. ⚙️ System Settings
   ✓ Toggle customer controls on/off
   ✓ Enable/disable color mode toggle
   ✓ Enable/disable sidedness toggle
   ✓ Enable/disable orientation toggle
   ✓ Enable/disable copies adjustment
   ✓ Test settings impact on customer experience

3. 👥 Staff Management
   ✓ View operator status
   ✓ Monitor active staff
   ✓ Quick actions panel

4. 🔄 Customer Testing Mode
   ✓ Switch to customer view
   ✓ Test customer experience with admin settings
   ✓ Return to admin dashboard
```

#### **Critical Admin Tests:**
- **Settings Impact**: Change admin settings → test as customer
- **Real-time Updates**: Monitor live job status changes
- **System Controls**: Verify all toggles work properly

---

## 🔧 **iPhone-Specific Testing Tips**

### **Orientation Testing:**
- **Portrait**: Primary mobile experience
- **Landscape**: Tablet-like experience for operator/admin
- **Rotate device**: Test responsive layouts

### **Touch & Gestures:**
- **Tap accuracy**: All buttons and controls
- **Scroll performance**: Smooth scrolling in all views
- **Form inputs**: Keyboard behavior with text fields
- **Modal interactions**: Popup screens and overlays

### **iOS Features:**
- **Safe area**: Status bar and home indicator respect
- **Native feel**: iOS-style navigation and animations
- **Permissions**: Camera access for scanning
- **Keyboard**: Auto-dismiss and input validation

---

## 🚨 **Known Issues & Workarounds**

### **Current Limitations:**
1. **File Processing**: Simulated (no actual printing)
2. **Payment**: Mock payment processing
3. **Desktop Features**: Some admin features optimized for larger screens

### **Testing Workarounds:**
1. **Admin Dashboard**: Use landscape mode for better experience
2. **File Upload**: Mock files simulate real upload process
3. **Status Updates**: Automatic simulation shows real workflow

---

## ✅ **Testing Checklist**

### **Basic Functionality:**
- [ ] App launches without crashes
- [ ] All three modes accessible (Customer/Operator/Admin)
- [ ] Role switching works smoothly
- [ ] All buttons are responsive

### **Customer Experience:**
- [ ] Complete order flow works end-to-end
- [ ] File upload simulation functions
- [ ] Payment options all work
- [ ] Order tracking shows live updates

### **Operator Functions:**
- [ ] Job queue displays correctly
- [ ] Status updates work (Queue → Ongoing → Ready)
- [ ] Customer assistance mode accessible
- [ ] Dashboard metrics accurate

### **Admin Controls:**
- [ ] System settings toggle properly
- [ ] Settings changes affect customer experience
- [ ] Business metrics display
- [ ] Staff monitoring functions

### **Cross-Role Testing:**
- [ ] Settings changes by admin affect customer experience
- [ ] Operator can help customers place orders
- [ ] Real-time job updates across all roles

---

## 📞 **Testing Support**

### **If You Find Issues:**
1. **Note the specific screen/feature**
2. **Record the user role and action taken**
3. **Describe expected vs actual behavior**
4. **Test if it reproduces consistently**

### **Common Fixes:**
- **App crashes**: Restart the development server
- **UI issues**: Try rotating device orientation
- **Features missing**: Verify you're in correct role mode
- **Performance**: Background tasks might be running

---

## 🎉 **Success Indicators**

Your testing is successful when:
- ✅ All three user roles work smoothly
- ✅ Complete workflows function end-to-end  
- ✅ Admin controls properly affect customer experience
- ✅ Role switching is seamless
- ✅ UI is responsive and intuitive on iPhone
- ✅ All buttons, forms, and navigation work properly

**The app is production-ready when all testing scenarios pass!** 🚀