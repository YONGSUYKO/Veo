# 🔧 TROUBLESHOOTING GUIDE

## 🚨 **"Text strings must be rendered within a <Text> component" Error**

This error typically occurs when there are raw strings not wrapped in `<Text>` components.

### **Quick Fix:**
1. **Restart the development server:**
   ```bash
   # Stop the current server (Ctrl+C)
   # Then restart:
   bun run start
   ```

2. **Enable Development Mode:**
   - The app should now show a **"Development Mode"** screen
   - If not, check that `EXPO_PUBLIC_DEV_MODE=true` is in your `.env` file

3. **Test Each Role:**
   - Select "Customer App" to test customer features
   - Select "Operator Station" to test operator features  
   - Select "Admin Dashboard" to test admin features

---

## 📱 **Testing Each Role on iPhone**

### **🎯 DEVELOPMENT MODE ENABLED**
The app now has comprehensive testing capabilities:

#### **1. App Selection Screen:**
- **Customer App**: Mobile printing experience
- **Operator Station**: Staff job management
- **Admin Dashboard**: System management

#### **2. Role Switching:**
- **Yellow dev banner** shows current mode
- **"SWITCH" button** to change roles
- Test all features from one app

#### **3. Complete Testing:**
- **All workflows** available in development mode
- **Real-time switching** between user types
- **Settings testing** for admin controls

---

## ✅ **Testing Verification Steps**

### **1. Customer Flow:**
```
Welcome → Service Selection → File Upload → Settings → Payment → Tracking
```

### **2. Operator Flow:**
```
Dashboard → Job Queue → Status Updates → Customer Assistance
```

### **3. Admin Flow:**
```
Dashboard → System Settings → Toggle Controls → Staff Management
```

---

## 🔄 **If Issues Persist:**

### **Common Solutions:**
1. **Clear cache:** Restart the Expo development server
2. **Check console:** Look for specific error messages
3. **Role verification:** Ensure you're testing the right user role
4. **Device rotation:** Try landscape mode for admin features

### **Platform Compatibility:**
- ✅ **iPhone**: Full testing capability
- ✅ **Development Mode**: All features accessible
- ✅ **Role Switching**: Seamless between user types
- ✅ **Responsive Design**: Works in all orientations

The comprehensive testing system is now ready for your iPhone testing! 🚀