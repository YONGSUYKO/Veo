# PISO Print Express - Complete Print Shop Management System

A comprehensive React Native + Expo application for print shop operations with multi-deployment architecture supporting Customer, Operator, and Admin interfaces.

## 🚀 Features

### Customer Features
- **Guest Mode**: Browse and order without registration
- **Document Printing**: Upload PDFs, Word, Excel files
- **Scan & Print**: Multi-page PDF scanning with camera
- **Photo Printing**: High-quality photo prints in various sizes
- **Order Tracking**: Real-time delivery progress with visual status bar
- **Guest Checkout**: Name + phone/email for cash payments
- **Smart Auth**: Login/signup prompts only for GCash/card payments
- **Loyalty Points**: Earn and redeem points (for registered users)

### Operator Features
- **Print Queue Management**: View and process print jobs
- **Order Status Updates**: Update job progress in real-time
- **Customer Management**: View customer details and order history
- **Inventory Tracking**: Monitor supplies and materials
- **Daily Reports**: Track sales and performance metrics

### Admin Features
- **Business Dashboard**: Revenue, orders, and analytics
- **Staff Management**: Operator accounts and permissions
- **System Settings**: Pricing, services, and configurations
- **Financial Reports**: Detailed business insights
- **Multi-location Support**: Franchise management ready

## 🏗️ Architecture

### Multi-Deployment System
The app supports 3 deployment types via environment variables:

```bash
# Mobile app store deployment
EXPO_PUBLIC_APP_TYPE=customer

# In-store kiosk/tablet deployment  
EXPO_PUBLIC_APP_TYPE=operator

# Admin desktop/web deployment
EXPO_PUBLIC_APP_TYPE=admin
```

### Tech Stack
- **Framework**: React Native 0.76.7 + Expo SDK 53
- **Navigation**: React Navigation v7 (Native Stack)
- **Styling**: NativeWind + Tailwind CSS v3
- **State Management**: Zustand with AsyncStorage persistence
- **Animations**: React Native Reanimated v3
- **Gestures**: React Native Gesture Handler
- **Camera**: Expo Camera + React Native Vision Camera
- **File Handling**: Expo Document Picker + Image Picker
- **Icons**: @expo/vector-icons (Ionicons)

## 📱 Core Services

### 1. Document Printing
- Upload documents from device storage
- Support for PDF, DOC, DOCX, XLS, XLSX
- Paper size selection (A4, Letter, Legal, A3)
- Color/B&W printing options
- Copy quantity settings
- Binding and lamination options

### 2. Scan & Print
- **Multi-page PDF scanning** with camera
- Document frame detection
- Page management (add/remove pages)
- PDF generation from scanned images
- Professional document quality

### 3. Photo Printing
- Gallery photo selection (multiple photos)
- Camera capture integration
- Various print sizes (4R, 5R, 8R, A4)
- High-quality photo paper options

### 4. Order Management
- Real-time order tracking
- Visual progress indicators
- Delivery status updates
- Customer notifications
- Order history and reprints

## 🛠️ Installation & Setup

### Prerequisites
- Node.js 18+ 
- Bun (package manager)
- Expo CLI
- iOS Simulator / Android Emulator

### Environment Setup
1. Copy environment variables:
```bash
cp .env.example .env
```

2. Add your API keys:
```bash
# Required for AI features (provided in Vibecode environment)
EXPO_PUBLIC_VIBECODE_OPENAI_API_KEY=your-key
EXPO_PUBLIC_VIBECODE_ANTHROPIC_API_KEY=your-key
EXPO_PUBLIC_VIBECODE_GROK_API_KEY=your-key
```

### Installation
```bash
# Install dependencies
bun install

# Start development server
bun start

# Run on specific platform
bun run ios     # iOS simulator
bun run android # Android emulator
bun run web     # Web browser
```

## 📂 Project Structure

```
src/
├── api/           # API clients and services
├── apps/          # Multi-app architecture
│   ├── CustomerApp.tsx
│   ├── OperatorApp.tsx
│   └── AdminApp.tsx
├── components/    # Reusable UI components
├── navigation/    # Navigation configuration
├── screens/       # Screen components
│   └── mobile/    # Mobile-specific screens
├── services/      # Business logic services
├── state/         # Zustand state management
├── types/         # TypeScript type definitions
└── utils/         # Helper functions
```

## 🎯 User Flows

### Customer Journey
1. **Browse Services** → Select document/scan/photo printing
2. **Upload/Scan Files** → Choose files or scan with camera
3. **Configure Settings** → Paper size, copies, binding options
4. **Guest Checkout** → Enter basic info (name, phone, email)
5. **Choose Payment** → Cash, GCash, or Card
6. **Select Fulfillment** → Pickup or delivery
7. **Track Order** → Real-time progress updates

### Operator Workflow
1. **View Print Queue** → See pending jobs
2. **Process Orders** → Update status to printing/ready
3. **Manage Customers** → View order history and details
4. **Handle Payments** → Process cash/card transactions
5. **Update Inventory** → Track supplies and materials

### Admin Dashboard
1. **Monitor Performance** → Revenue, orders, efficiency metrics
2. **Manage Staff** → Operator accounts and permissions
3. **Configure System** → Pricing, services, business rules
4. **Generate Reports** → Financial and operational insights

## 🔧 Configuration

### Service Pricing
Edit pricing in `src/api/newPisoAPI.ts`:
```typescript
const PRICING = {
  document: {
    bw: 300,    // 3 pesos per page
    color: 500, // 5 pesos per page
  },
  photo: {
    '4R': 2000, // 20 pesos per photo
    '5R': 3000, // 30 pesos per photo
  }
}
```

### System Settings
Configure business rules in `src/state/newAppStore.ts`:
```typescript
systemSettings: {
  deliveryFee: 2500,        // 25 pesos
  minimumOrder: 1000,       // 10 pesos
  loyaltyPointsRate: 0.01,  // 1% cashback
}
```

## 📱 Platform Compatibility

| Feature | iOS | Android | Web |
|---------|-----|---------|-----|
| Document Upload | ✅ | ✅ | ✅ |
| Camera Scanning | ✅ | ✅ | ❌ |
| Photo Printing | ✅ | ✅ | ✅ |
| Push Notifications | ✅ | ✅ | ❌ |
| Biometric Auth | ✅ | ✅ | ❌ |

## 🔒 Security Features

- **Guest Mode**: No forced registration
- **Secure Auth**: Biometric authentication ready
- **Data Privacy**: Minimal data collection
- **API Security**: Environment variable protection
- **Role-based Access**: Customer/Operator/Admin permissions

## 🚀 Deployment

### Customer App (App Stores)
```bash
# Build for production
eas build --platform all

# Submit to stores
eas submit --platform all
```

### Operator Station (Kiosk)
```bash
# Set operator mode
EXPO_PUBLIC_APP_TYPE=operator

# Build kiosk version
eas build --platform android
```

### Admin Dashboard (Web)
```bash
# Set admin mode  
EXPO_PUBLIC_APP_TYPE=admin

# Build web version
expo build:web
```

## 📧 Integration Ready

The app is structured to easily add:
- **Email Notifications**: Brevo/SendinBlue integration points ready
- **SMS Alerts**: Twilio integration structure prepared
- **Payment Gateways**: GCash, PayMaya, card processing hooks
- **Inventory Systems**: API endpoints for stock management
- **Analytics**: Event tracking and business intelligence

## 🤝 Contributing

1. Fork the repository
2. Create feature branch: `git checkout -b feature/amazing-feature`
3. Commit changes: `git commit -m 'Add amazing feature'`
4. Push to branch: `git push origin feature/amazing-feature`
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Create an issue in the repository
- Contact the development team
- Check the troubleshooting guide in `/docs`

---

**Built with ❤️ for print shop owners and customers**