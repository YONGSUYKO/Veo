import React from 'react';
import { View, Text, Pressable, ScrollView } from 'react-native';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

function SimpleOperatorDashboard() {
  const insets = useSafeAreaInsets();
  
  return (
    <View style={{ flex: 1, backgroundColor: '#F9FAFB' }}>
      <ScrollView contentContainerStyle={{ paddingTop: insets.top + 20, padding: 20 }}>
        
        {/* Header */}
        <View style={{ backgroundColor: '#1F2937', borderRadius: 12, padding: 20, marginBottom: 20 }}>
          <Text style={{ fontSize: 24, fontWeight: 'bold', color: 'white', marginBottom: 8 }}>
            Operator Dashboard
          </Text>
          <Text style={{ fontSize: 14, color: '#9CA3AF' }}>
            Store operations and order management
          </Text>
        </View>

        {/* Stats Cards */}
        <View style={{ flexDirection: 'row', gap: 16, marginBottom: 24 }}>
          <View style={{ flex: 1, backgroundColor: 'white', borderRadius: 12, padding: 16 }}>
            <Text style={{ fontSize: 12, color: '#6B7280', marginBottom: 4 }}>Orders Today</Text>
            <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#111827' }}>24</Text>
          </View>
          <View style={{ flex: 1, backgroundColor: 'white', borderRadius: 12, padding: 16 }}>
            <Text style={{ fontSize: 12, color: '#6B7280', marginBottom: 4 }}>Revenue</Text>
            <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#111827' }}>₱2,450</Text>
          </View>
        </View>

        {/* Print Queue */}
        <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 20, marginBottom: 20 }}>
          <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginBottom: 16 }}>
            Print Queue
          </Text>
          {[1, 2, 3].map((item) => (
            <View key={item} style={{ 
              flexDirection: 'row', 
              justifyContent: 'space-between', 
              alignItems: 'center',
              paddingVertical: 12,
              borderBottomWidth: 1,
              borderBottomColor: '#F3F4F6'
            }}>
              <View>
                <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827' }}>
                  Order #00{item}
                </Text>
                <Text style={{ fontSize: 12, color: '#6B7280' }}>
                  Customer {item} • 3 pages
                </Text>
              </View>
              <Pressable style={{ backgroundColor: '#10B981', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 6 }}>
                <Text style={{ color: 'white', fontSize: 12, fontWeight: '600' }}>Start</Text>
              </Pressable>
            </View>
          ))}
        </View>

        {/* Success Message */}
        <View style={{ 
          backgroundColor: '#D1FAE5', 
          borderRadius: 12, 
          padding: 16,
          flexDirection: 'row',
          alignItems: 'center'
        }}>
          <Ionicons name="checkmark-circle" size={24} color="#059669" />
          <Text style={{ 
            color: '#047857', 
            fontSize: 14, 
            marginLeft: 12,
            fontWeight: '600'
          }}>
            ✅ Desktop Operator Dashboard Working!
          </Text>
        </View>

      </ScrollView>
    </View>
  );
}

function SimpleAdminDashboard() {
  const insets = useSafeAreaInsets();
  
  return (
    <View style={{ flex: 1, backgroundColor: '#F9FAFB' }}>
      <ScrollView contentContainerStyle={{ paddingTop: insets.top + 20, padding: 20 }}>
        
        {/* Header */}
        <View style={{ backgroundColor: '#7C3AED', borderRadius: 12, padding: 20, marginBottom: 20 }}>
          <Text style={{ fontSize: 24, fontWeight: 'bold', color: 'white', marginBottom: 8 }}>
            Admin Dashboard
          </Text>
          <Text style={{ fontSize: 14, color: '#C4B5FD' }}>
            System administration and business management
          </Text>
        </View>

        {/* Metrics Cards */}
        <View style={{ flexDirection: 'row', gap: 16, marginBottom: 24 }}>
          <View style={{ flex: 1, backgroundColor: 'white', borderRadius: 12, padding: 16 }}>
            <Text style={{ fontSize: 12, color: '#6B7280', marginBottom: 4 }}>Monthly Revenue</Text>
            <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#111827' }}>₱125,430</Text>
          </View>
          <View style={{ flex: 1, backgroundColor: 'white', borderRadius: 12, padding: 16 }}>
            <Text style={{ fontSize: 12, color: '#6B7280', marginBottom: 4 }}>Total Orders</Text>
            <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#111827' }}>1,247</Text>
          </View>
        </View>

        {/* System Status */}
        <View style={{ backgroundColor: 'white', borderRadius: 12, padding: 20, marginBottom: 20 }}>
          <Text style={{ fontSize: 18, fontWeight: '600', color: '#111827', marginBottom: 16 }}>
            System Status
          </Text>
          {[
            { name: 'Print Servers', status: 'Online' },
            { name: 'Payment Gateway', status: 'Online' },
            { name: 'Database', status: 'Online' }
          ].map((item, index) => (
            <View key={index} style={{ 
              flexDirection: 'row', 
              justifyContent: 'space-between', 
              alignItems: 'center',
              paddingVertical: 12,
              borderBottomWidth: index < 2 ? 1 : 0,
              borderBottomColor: '#F3F4F6'
            }}>
              <Text style={{ fontSize: 14, color: '#111827' }}>{item.name}</Text>
              <View style={{ backgroundColor: '#D1FAE5', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 }}>
                <Text style={{ fontSize: 12, color: '#065F46', fontWeight: '600' }}>{item.status}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* Success Message */}
        <View style={{ 
          backgroundColor: '#EFF6FF', 
          borderRadius: 12, 
          padding: 16,
          flexDirection: 'row',
          alignItems: 'center'
        }}>
          <Ionicons name="shield-checkmark" size={24} color="#3B82F6" />
          <Text style={{ 
            color: '#1E40AF', 
            fontSize: 14, 
            marginLeft: 12,
            fontWeight: '600'
          }}>
            ✅ Desktop Admin Dashboard Working!
          </Text>
        </View>

      </ScrollView>
    </View>
  );
}

function SimpleAppSelector() {
  const [currentView, setCurrentView] = React.useState<'selector' | 'operator' | 'admin'>('selector');
  const insets = useSafeAreaInsets();

  if (currentView === 'operator') {
    return <SimpleOperatorDashboard />;
  }

  if (currentView === 'admin') {
    return <SimpleAdminDashboard />;
  }

  return (
    <View style={{ flex: 1, backgroundColor: '#F3F4F6' }}>
      <ScrollView contentContainerStyle={{ paddingTop: insets.top + 40, padding: 20 }}>
        
        <View style={{ alignItems: 'center', marginBottom: 40 }}>
          <View style={{
            width: 80,
            height: 80,
            backgroundColor: '#3B82F6',
            borderRadius: 40,
            alignItems: 'center',
            justifyContent: 'center',
            marginBottom: 16,
          }}>
            <Ionicons name="desktop" size={40} color="white" />
          </View>
          <Text style={{ fontSize: 28, fontWeight: 'bold', color: '#111827', marginBottom: 8 }}>
            PISO Print Express
          </Text>
          <Text style={{ fontSize: 16, color: '#6B7280', textAlign: 'center' }}>
            Desktop Dashboard Access
          </Text>
        </View>

        <View style={{ gap: 16 }}>
          <Pressable
            onPress={() => setCurrentView('operator')}
            style={{
              backgroundColor: 'white',
              borderRadius: 16,
              padding: 24,
              alignItems: 'center',
              elevation: 2,
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 1 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
            }}
          >
            <View style={{
              width: 56,
              height: 56,
              backgroundColor: '#10B98120',
              borderRadius: 28,
              alignItems: 'center',
              justifyContent: 'center',
              marginBottom: 12,
            }}>
              <Ionicons name="storefront" size={28} color="#10B981" />
            </View>
            <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#111827', marginBottom: 4 }}>
              Operator Dashboard
            </Text>
            <Text style={{ fontSize: 14, color: '#6B7280', textAlign: 'center' }}>
              Store management and order processing
            </Text>
          </Pressable>

          <Pressable
            onPress={() => setCurrentView('admin')}
            style={{
              backgroundColor: 'white',
              borderRadius: 16,
              padding: 24,
              alignItems: 'center',
              elevation: 2,
              shadowColor: '#000',
              shadowOffset: { width: 0, height: 1 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
            }}
          >
            <View style={{
              width: 56,
              height: 56,
              backgroundColor: '#7C3AED20',
              borderRadius: 28,
              alignItems: 'center',
              justifyContent: 'center',
              marginBottom: 12,
            }}>
              <Ionicons name="settings" size={28} color="#7C3AED" />
            </View>
            <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#111827', marginBottom: 4 }}>
              Admin Dashboard
            </Text>
            <Text style={{ fontSize: 14, color: '#6B7280', textAlign: 'center' }}>
              System administration and analytics
            </Text>
          </Pressable>
        </View>

        <View style={{ 
          backgroundColor: '#D1FAE5', 
          borderRadius: 12, 
          padding: 16,
          marginTop: 32,
          flexDirection: 'row',
          alignItems: 'center'
        }}>
          <Ionicons name="checkmark-circle" size={24} color="#059669" />
          <Text style={{ 
            color: '#047857', 
            fontSize: 14, 
            marginLeft: 12,
            fontWeight: '600',
            flex: 1
          }}>
            ✅ Minimal Desktop Dashboard System Working! This bypasses all complex components.
          </Text>
        </View>

      </ScrollView>
    </View>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <SimpleAppSelector />
    </SafeAreaProvider>
  );
}