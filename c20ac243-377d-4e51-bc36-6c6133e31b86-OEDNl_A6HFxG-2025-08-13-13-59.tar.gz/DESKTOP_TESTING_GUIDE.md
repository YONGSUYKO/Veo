# 🖥️ DESKTOP TESTING GUIDE
## Testing Operator & Admin Dashboards

Your app has a sophisticated multi-deployment architecture that allows testing different interfaces. Here's how to test the operator and admin dashboards on desktop.

---

## 🚀 **METHOD 1: Development Mode (Recommended for Testing)**

### **Step 1: Enable Development Mode**
```bash
# Set environment variable for development testing
export EXPO_PUBLIC_DEV_MODE=true

# Or create/update .env file:
echo "EXPO_PUBLIC_DEV_MODE=true" >> .env
```

### **Step 2: Start the App**
```bash
# Make sure you're in the project directory
cd /home/user/workspace

# Start the development server
npm start
# or
bun start
# or
expo start
```

### **Step 3: Open in Web Browser (Desktop)**
- Open your web browser (Chrome/Firefox/Safari)
- Navigate to: `http://localhost:8081` (or the port shown in terminal)
- **Resize browser window to desktop size** (width > 1024px) for desktop detection

### **Step 4: Use Development Mode Selector**
When development mode is active, you'll see a **mode selector** with options:
- 📱 **Customer App** - Customer mobile interface
- 🏪 **Operator Station** - Full operator dashboard 
- 🔧 **Admin Dashboard** - Complete admin interface

**Click "Operator Station" or "Admin Dashboard" to test the respective desktop interfaces.**

---

## 🚀 **METHOD 2: Direct App Type Testing**

### **For Operator Desktop Testing:**
```bash
# Set app type to operator
export EXPO_PUBLIC_APP_TYPE=operator

# Start the app
npm start

# Open in browser at desktop resolution (>1024px width)
# Browser will automatically load OperatorDesktopDashboardEnhanced
```

### **For Admin Desktop Testing:**
```bash
# Set app type to admin  
export EXPO_PUBLIC_APP_TYPE=admin

# Start the app
npm start

# Open in browser at desktop resolution
# Browser will automatically load AdminDesktopDashboard
```

---

## 🔐 **LOGIN CREDENTIALS FOR TESTING**

### **Operator Login:**
```
Employee ID: OP001, OP002, or any text
PIN: 1234, 5678, or any 4 digits
Shift: Morning/Afternoon/Evening
```

### **Admin Login:**
```
Username: admin, manager, or any text
Password: admin123, password, or any text
MFA Code: 123456 (any 6 digits)
```

*Note: These are mock credentials for testing. Real production would have secure authentication.*

---

## 🖥️ **DESKTOP INTERFACE FEATURES TO TEST**

### **Operator Desktop Dashboard:**
✅ **Print Queue Management**
- View all pending print jobs
- Assign jobs to specific printers
- Set job priorities

✅ **Real-Time Printer Control**
- Monitor printer status (Online/Busy/Error)
- Check supply levels (paper/ink)
- Pause/Resume printers
- Direct print job assignment

✅ **Enhanced Job Processing**
- Customer communication via chat
- Job specification management
- Progress tracking
- Completion notifications

✅ **Multi-Printer Support**
- Laser printers (HP LaserJet)
- Inkjet printers (Canon PIXMA)
- Photo printers (Epson SureColor)
- Supply level monitoring

### **Admin Desktop Dashboard:**
✅ **Business Analytics**
- Daily/Weekly/Monthly reports
- Revenue tracking
- Job statistics
- Performance metrics

✅ **Staff Management**
- Operator performance monitoring
- Shift management
- Activity tracking

✅ **System Administration**
- Pricing management
- Service configuration
- User management
- System settings

✅ **Customer Preview Mode**
- Test customer experience
- View app from customer perspective
- Quality assurance testing

---

## 📱 **DEVICE DETECTION TESTING**

The app automatically detects screen size and serves appropriate interfaces:

### **Screen Size Detection:**
- **Desktop** (≥1024px width) → Full desktop dashboard
- **Tablet** (768-1023px width) → Tablet interface  
- **Mobile** (<768px width) → Mobile interface

### **To Test Different Interfaces:**
1. **Desktop Mode** - Browser window > 1024px wide
2. **Tablet Mode** - Resize to 768-1023px wide
3. **Mobile Mode** - Resize to < 768px wide

### **Browser Developer Tools:**
```
F12 → Device Toolbar → Select Device:
- Desktop: Use "Responsive" and set to 1200x800
- Tablet: Use "iPad" or set to 768x1024  
- Mobile: Use "iPhone" or set to 375x667
```

---

## 🧪 **TESTING SCENARIOS**

### **Operator Dashboard Testing:**

1. **Login as Operator**
   - Use OP001 / 1234 credentials
   - Select morning shift

2. **Test Printer Management**
   - View printer status dashboard
   - Assign print jobs to different printers
   - Monitor supply levels
   - Test pause/resume functionality

3. **Process Print Jobs**
   - Review print queue
   - Assign jobs to optimal printers
   - Track printing progress
   - Complete job processing

4. **Customer Communication**
   - Access chat with customers
   - Provide order updates
   - Handle customer queries

### **Admin Dashboard Testing:**

1. **Login as Admin**
   - Use admin / admin123 credentials
   - Complete MFA with 123456

2. **View Analytics**
   - Check daily revenue reports
   - Monitor job statistics
   - Review performance metrics

3. **Manage System**
   - Update pricing settings
   - Configure services
   - Monitor operator activity

4. **Customer Preview**
   - Switch to customer preview mode
   - Test customer journey
   - Verify app functionality

---

## 🚨 **TROUBLESHOOTING**

### **If Desktop Interface Doesn't Load:**
1. **Check Browser Window Size** - Must be > 1024px width
2. **Clear Browser Cache** - Hard refresh (Ctrl+F5 or Cmd+Shift+R)
3. **Check Environment Variables** - Ensure EXPO_PUBLIC_DEV_MODE=true
4. **Restart Dev Server** - Stop and restart npm/bun start

### **If Login Doesn't Work:**
- Use any text for credentials (mock authentication)
- Ensure development mode is enabled
- Check browser console for errors

### **If Features Are Missing:**
- Verify desktop screen resolution (≥1024px)
- Check that correct app type is loaded
- Refresh browser and try again

---

## ⚡ **QUICK START COMMANDS**

```bash
# Quick desktop testing setup
cd /home/user/workspace
echo "EXPO_PUBLIC_DEV_MODE=true" > .env
npm start

# Then open browser to localhost:8081 with window width > 1024px
# Select "Operator Station" or "Admin Dashboard" from dev mode selector
```

---

## 📊 **EXPECTED RESULTS**

### **Successful Operator Desktop Test:**
- ✅ Professional printer management interface
- ✅ Real-time job queue with assignment controls  
- ✅ Multi-printer status dashboard
- ✅ Direct print job processing
- ✅ Supply level monitoring
- ✅ Customer chat integration

### **Successful Admin Desktop Test:**
- ✅ Comprehensive analytics dashboard
- ✅ Business performance metrics
- ✅ Staff management interface
- ✅ System configuration tools
- ✅ Customer preview functionality

**Both interfaces should provide full desktop functionality with professional layouts optimized for large screens and mouse/keyboard interaction.**

---

## 🎯 **NEXT STEPS**

After successful testing, you can:
1. **Customize Interfaces** - Modify layouts, colors, features
2. **Add Real Data** - Connect to actual printers and databases
3. **Deploy Separately** - Build different versions for different devices
4. **Scale System** - Add multi-location support and advanced features

**Your desktop testing environment is now ready for comprehensive operator and admin dashboard evaluation!** 🚀