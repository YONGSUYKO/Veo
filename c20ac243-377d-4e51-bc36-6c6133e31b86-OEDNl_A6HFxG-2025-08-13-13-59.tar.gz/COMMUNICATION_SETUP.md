# 📧📱 Communication System Setup Guide

## ✅ What's Implemented

I've created a complete communication system for your print shop app:

### 🔧 Core Services
- **EmailService** (`src/services/emailService.ts`) - Brevo integration for emails
- **SmsService** (`src/services/smsService.ts`) - Twilio integration for SMS
- **ContactSupportModal** (`src/components/ContactSupportModal.tsx`) - In-app contact form

### 📧 Email Features
- **Customer → Owner**: Direct messaging through app
- **Owner → Customer**: Order confirmations, status updates
- **Fallback**: Opens native email app if Brevo fails
- **Professional HTML templates** with your branding

### 📱 SMS Features  
- **Order confirmations** sent automatically
- **Status updates** (printing, ready, delivered)
- **Philippine phone number support** (+63 format)
- **Test SMS** functionality in profile

### 🎯 Integration Points
- **Profile Screen**: "Contact Support" button opens direct message form
- **Order Tracking**: Automatic email/SMS notifications 
- **Payment Flow**: Order confirmation messages
- **Guest Checkout**: Works with email/phone collection

## 🔑 Setup Instructions

### 1. Get Brevo API Key
1. Sign up at [brevo.com](https://brevo.com)
2. Go to Settings → API Keys
3. Create new API key
4. Add to `.env`: `EXPO_PUBLIC_BREVO_API_KEY=your-key`

### 2. Get Twilio Credentials
1. Sign up at [twilio.com](https://twilio.com)
2. Get Account SID, Auth Token, Phone Number
3. Add to `.env`:
```
EXPO_PUBLIC_TWILIO_ACCOUNT_SID=your-sid
EXPO_PUBLIC_TWILIO_AUTH_TOKEN=your-token  
EXPO_PUBLIC_TWILIO_PHONE_NUMBER=+1234567890
```

### 3. Configure Business Email
Edit `src/services/emailService.ts` line 15:
```typescript
businessEmail: 'your-email@yourdomain.com', // Change this
```

## 🚀 How It Works

### Customer Experience
1. **Contact Support**: Tap in profile → fills form → sends to your email
2. **Order Updates**: Automatic SMS/email when status changes
3. **Direct Reply**: You reply to emails, customer gets your response

### Your Workflow  
1. **Receive Messages**: Customer messages arrive in your email inbox
2. **Reply Directly**: Reply to email = customer gets your response
3. **Auto Notifications**: System sends SMS/email for order updates
4. **Test Features**: Use "Test SMS" in profile to verify setup

## 📱 Ready Features
- ✅ Guest customer messaging (no login required)
- ✅ Order confirmation emails/SMS
- ✅ Status update notifications  
- ✅ Professional email templates
- ✅ Philippine SMS support
- ✅ Fallback to native email
- ✅ Contact form with order context

The system is production-ready - just add your API keys!