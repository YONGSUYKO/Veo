# PISO Print Express - Deployment Guide

## 🏗️ Architecture Overview

PISO Print Express is designed as **3 separate applications** for different deployment scenarios:

### 📱 Customer Mobile App
- **Target**: End customers on personal phones
- **Platform**: Android & iOS
- **Distribution**: Google Play Store / Apple App Store
- **Features**: Order placement, payment, tracking only
- **Authentication**: Optional (guest users allowed)
- **Access**: No admin/operator features

### 🏪 Operator Station App  
- **Target**: Store staff on tablets/kiosks
- **Platform**: Android tablets, Windows/Mac kiosks
- **Distribution**: Direct installation on store devices
- **Features**: Job processing, customer assistance, payment handling
- **Authentication**: Required (employee login)
- **Access**: No admin settings access

### 💼 Admin Dashboard App
- **Target**: Business owners/managers
- **Platform**: Desktop computers, web browsers
- **Distribution**: Web portal or desktop app installation
- **Features**: Full system control, analytics, settings, reports
- **Authentication**: Required (secure admin login + MFA)
- **Access**: Complete system administration

---

## 🚀 Deployment Instructions

### Development/Testing Mode
```bash
# Test all features in one app
export EXPO_PUBLIC_DEV_MODE=true
bun run start
```

### Customer App Deployment
```bash
# Set environment for customer app
export EXPO_PUBLIC_APP_TYPE=customer
export EXPO_PUBLIC_DEV_MODE=false

# Build for app stores
bun run build:android  # For Google Play
bun run build:ios      # For Apple App Store
```

### Operator Station Deployment
```bash
# Set environment for operator app
export EXPO_PUBLIC_APP_TYPE=operator
export EXPO_PUBLIC_DEV_MODE=false

# Build for tablets/kiosks
bun run build:android  # For Android tablets
bun run build:windows  # For Windows kiosks
```

### Admin Dashboard Deployment
```bash
# Set environment for admin app
export EXPO_PUBLIC_APP_TYPE=admin
export EXPO_PUBLIC_DEV_MODE=false

# Build for desktop/web
bun run build:web      # For web portal
bun run build:desktop  # For desktop app
```

---

## 🔧 Configuration

### Environment Variables

Create `.env` files for each deployment:

#### `.env.customer`
```env
EXPO_PUBLIC_APP_TYPE=customer
EXPO_PUBLIC_DEV_MODE=false
EXPO_PUBLIC_API_BASE_URL=https://api.pisoprint.com
```

#### `.env.operator`
```env
EXPO_PUBLIC_APP_TYPE=operator
EXPO_PUBLIC_DEV_MODE=false
EXPO_PUBLIC_API_BASE_URL=https://api.pisoprint.com
EXPO_PUBLIC_STORE_ID=store_001
```

#### `.env.admin`
```env
EXPO_PUBLIC_APP_TYPE=admin
EXPO_PUBLIC_DEV_MODE=false
EXPO_PUBLIC_API_BASE_URL=https://admin-api.pisoprint.com
EXPO_PUBLIC_ADMIN_PORTAL_URL=https://admin.pisoprint.com
```

---

## 📦 Build Commands

### Customer Mobile App
```bash
# Android
eas build --platform android --profile customer

# iOS  
eas build --platform ios --profile customer

# Both
eas build --platform all --profile customer
```

### Operator Station
```bash
# Android Tablet
eas build --platform android --profile operator

# Windows Kiosk
npx electron-builder --win --config.operator
```

### Admin Dashboard
```bash
# Web Portal
npm run build:web -- --profile admin

# Desktop App
npx electron-builder --mac --win --linux --config.admin
```

---

## 🎯 User Experience Separation

### Customer App Features ONLY:
- ✅ Service selection (Document/Scan/Photo)
- ✅ File upload and configuration
- ✅ Payment processing
- ✅ Order tracking
- ❌ No role selection screen
- ❌ No operator controls
- ❌ No admin settings

### Operator Station Features:
- ✅ Employee authentication
- ✅ Print job queue management
- ✅ Customer assistance mode
- ✅ Payment processing
- ✅ Job status updates
- ❌ No system settings
- ❌ No business analytics

### Admin Dashboard Features:
- ✅ Secure admin authentication
- ✅ Complete system management
- ✅ Business analytics & reports
- ✅ Staff management
- ✅ System configuration
- ✅ Customer preview mode

---

## 🔐 Security Considerations

### Customer App Security:
- Guest users allowed for ease of use
- Optional account creation
- Secure payment processing
- Order history for registered users

### Operator Station Security:
- Mandatory employee authentication
- Shift-based access control
- Session timeout after inactivity
- Limited system access

### Admin Dashboard Security:
- Multi-factor authentication (MFA)
- Role-based permissions
- Audit logging
- IP restriction options
- Session management

---

## 📱 Platform-Specific Deployments

### Mobile (Customer)
- **Android**: Google Play Console
- **iOS**: Apple App Store Connect
- **Features**: Touch-optimized, camera access, notifications

### Tablet/Kiosk (Operator)
- **Android Tablets**: Direct APK installation
- **Windows Kiosks**: MSI installer or app store
- **Features**: Larger screen optimization, barcode scanning

### Desktop/Web (Admin)
- **Web Portal**: Hosted web application
- **Windows**: Electron-based desktop app
- **macOS**: Native app or Electron
- **Features**: Multi-window support, advanced reporting

---

## 🚦 Testing Strategy

1. **Development Mode**: Test all features in one app
2. **Staging Deployments**: Test each app type separately
3. **User Acceptance Testing**: Real users test their specific app
4. **Production Deployment**: Deploy each app to its target platform

---

This architecture ensures complete separation of concerns, appropriate security for each user type, and optimal user experience for different contexts and locations!